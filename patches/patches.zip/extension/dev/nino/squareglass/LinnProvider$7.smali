.class public final synthetic Ldev/nino/squareglass/LinnProvider$7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:Ldev/nino/squareglass/LinnProvider;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$7;->f$0:Ljava/lang/String;

    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider$7;->f$1:Ldev/nino/squareglass/LinnProvider;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider$7;->f$0:Ljava/lang/String;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$7;->f$1:Ldev/nino/squareglass/LinnProvider;

    invoke-static {v0, p0}, Ldev/nino/squareglass/LinnProvider;->lambda$addAddress$0(Ljava/lang/String;Ldev/nino/squareglass/LinnProvider;)V

    return-void
.end method
