.class final Ldev/nino/squareglass/RecommendationUpdates$Pending;
.super Ljava/lang/Object;
.source "RecommendationUpdates.java"

# interfaces
.implements Ljava/lang/Runnable;
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/RecommendationUpdates;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Pending"
.end annotation


# instance fields
.field final before:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "*>;"
        }
    .end annotation
.end field

.field button:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field changed:Z

.field completed:Z

.field event:Z

.field final owner:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field revision:Ljava/lang/String;

.field success:Z

.field final view:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroidx/recyclerview/widget/RecyclerView;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;Landroidx/recyclerview/widget/RecyclerView;Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Landroidx/recyclerview/widget/RecyclerView;",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    .line 79
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 77
    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->button:Ljava/lang/ref/WeakReference;

    .line 80
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->owner:Ljava/lang/ref/WeakReference;

    new-instance p1, Ljava/lang/ref/WeakReference;

    invoke-direct {p1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->view:Ljava/lang/ref/WeakReference;

    .line 81
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1, p3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object p1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->before:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    .line 142
    invoke-virtual {p0}, Ldev/nino/squareglass/RecommendationUpdates$Pending;->run()V

    return-void
.end method

.method public run()V
    .locals 12

    .line 85
    iget-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->owner:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->view:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v4, v1

    check-cast v4, Landroidx/recyclerview/widget/RecyclerView;

    .line 86
    invoke-static {}, Ldev/nino/squareglass/RecommendationUpdates;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v1

    invoke-virtual {v1, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    if-eqz v0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/RecommendationUpdates;->-$$Nest$sfgetpending()Ljava/util/WeakHashMap;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->button:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    invoke-virtual {v1, v2}, Landroid/view/View;->setEnabled(Z)V

    :cond_1
    if-eqz v4, :cond_2

    .line 88
    invoke-virtual {v4, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_2
    if-eqz v0, :cond_11

    if-eqz v4, :cond_11

    .line 89
    iget-boolean v3, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->changed:Z

    if-nez v3, :cond_3

    goto/16 :goto_6

    .line 90
    :cond_3
    iget-boolean v3, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->success:Z

    if-eqz v3, :cond_4

    invoke-static {}, Ldev/nino/squareglass/RecommendationUpdates;->-$$Nest$sfgetrecent()Ljava/util/WeakHashMap;

    move-result-object v3

    new-instance v5, Ldev/nino/squareglass/RecommendationUpdates$Revision;

    invoke-static {v0}, Ldev/nino/squareglass/NativePlaylistBridge;->contentRevision(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6, v4}, Ldev/nino/squareglass/RecommendationUpdates$Revision;-><init>(Ljava/lang/String;Landroidx/recyclerview/widget/RecyclerView;)V

    invoke-virtual {v3, v0, v5}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 92
    :cond_4
    invoke-virtual {v4}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$LayoutManager;

    move-result-object v3

    .line 93
    instance-of v5, v3, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 v6, 0x0

    if-eqz v5, :cond_5

    check-cast v3, Landroidx/recyclerview/widget/LinearLayoutManager;

    move-object v5, v3

    goto :goto_0

    :cond_5
    move-object v5, v6

    :goto_0
    const/4 v3, -0x1

    if-nez v5, :cond_6

    move v7, v3

    goto :goto_1

    .line 94
    :cond_6
    invoke-virtual {v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->findFirstVisibleItemPosition()I

    move-result v7

    :goto_1
    if-gez v7, :cond_7

    move-object v8, v6

    goto :goto_2

    .line 95
    :cond_7
    invoke-virtual {v5, v7}, Landroidx/recyclerview/widget/LinearLayoutManager;->findViewByPosition(I)Landroid/view/View;

    move-result-object v8

    :goto_2
    if-eqz v1, :cond_9

    .line 99
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v9

    if-eq v9, v4, :cond_9

    .line 100
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v9

    instance-of v9, v9, Landroid/view/View;

    if-eqz v9, :cond_8

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    goto :goto_2

    :cond_8
    move-object v1, v6

    goto :goto_2

    :cond_9
    if-eqz v1, :cond_a

    .line 101
    invoke-virtual {v4, v1}, Landroidx/recyclerview/widget/RecyclerView;->getChildAdapterPosition(Landroid/view/View;)I

    move-result v9

    if-ltz v9, :cond_a

    .line 102
    invoke-virtual {v4, v1}, Landroidx/recyclerview/widget/RecyclerView;->getChildAdapterPosition(Landroid/view/View;)I

    move-result v7

    move-object v8, v1

    :cond_a
    move v1, v7

    const/4 v7, 0x0

    if-nez v8, :cond_b

    move v9, v7

    goto :goto_3

    .line 104
    :cond_b
    invoke-virtual {v8}, Landroid/view/View;->getTop()I

    move-result v9

    invoke-virtual {v4}, Landroid/view/View;->getPaddingTop()I

    move-result v10

    sub-int/2addr v9, v10

    :goto_3
    const/4 v10, 0x2

    .line 105
    new-array v10, v10, [I

    if-eqz v8, :cond_c

    invoke-virtual {v8, v10}, Landroid/view/View;->getLocationInWindow([I)V

    .line 106
    :cond_c
    aget v2, v10, v2

    .line 107
    iget-object v8, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->before:Ljava/util/List;

    invoke-static {v0, v8}, Ldev/nino/squareglass/NativePlaylistBridge;->callback(Ljava/lang/Object;Ljava/util/List;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/recyclerview/widget/DiffUtil$Callback;

    .line 108
    invoke-static {v8}, Landroidx/recyclerview/widget/DiffUtil;->calculateDiff(Landroidx/recyclerview/widget/DiffUtil$Callback;)Landroidx/recyclerview/widget/DiffUtil$DiffResult;

    move-result-object v8

    if-ltz v1, :cond_f

    .line 111
    iget-object v10, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->before:Ljava/util/List;

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v10

    if-ge v1, v10, :cond_f

    .line 112
    :goto_4
    iget-object v10, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->before:Ljava/util/List;

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v10

    if-ge v7, v10, :cond_f

    if-gez v3, :cond_f

    add-int v10, v1, v7

    .line 114
    iget-object v11, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->before:Ljava/util/List;

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    if-ge v10, v11, :cond_d

    invoke-virtual {v8, v10}, Landroidx/recyclerview/widget/DiffUtil$DiffResult;->convertOldPositionToNew(I)I

    move-result v3

    :cond_d
    if-gez v3, :cond_e

    if-lez v7, :cond_e

    sub-int v10, v1, v7

    if-ltz v10, :cond_e

    .line 115
    invoke-virtual {v8, v10}, Landroidx/recyclerview/widget/DiffUtil$DiffResult;->convertOldPositionToNew(I)I

    move-result v3

    :cond_e
    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_f
    move-object v7, v8

    .line 118
    invoke-virtual {v4}, Landroidx/recyclerview/widget/RecyclerView;->getItemAnimator()Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;

    move-result-object v8

    .line 119
    invoke-virtual {v4, v6}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V

    .line 120
    invoke-static {v0, v7}, Ldev/nino/squareglass/NativePlaylistBridge;->dispatch(Ljava/lang/Object;Ljava/lang/Object;)V

    if-eqz v5, :cond_10

    if-ltz v3, :cond_10

    .line 123
    invoke-virtual {v4}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    move v7, v2

    new-instance v2, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;

    move v6, v3

    move-object v3, p0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;-><init>(Ldev/nino/squareglass/RecommendationUpdates$Pending;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/LinearLayoutManager;IILandroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V

    invoke-virtual {v0, v2}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    goto :goto_5

    :cond_10
    move v6, v3

    .line 138
    invoke-virtual {v4, v8}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V

    .line 139
    :goto_5
    new-instance p0, Ljava/lang/StringBuilder;

    const-string v0, "Recommendation Add: one native diff; anchor="

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " -> "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " offset="

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "SquareGlass"

    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_11
    :goto_6
    return-void
.end method

.method schedule(J)V
    .locals 1

    .line 83
    invoke-static {}, Ldev/nino/squareglass/RecommendationUpdates;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-static {}, Ldev/nino/squareglass/RecommendationUpdates;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    invoke-virtual {v0, p0, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
