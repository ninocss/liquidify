.class public final Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;
.super Ljava/lang/Object;
.source "DesignEntry.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDesignEntry.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DesignEntry.kt\ndev/nino/squareglass/ComposableSingletons$DesignEntryKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 4 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,602:1\n1#2:603\n75#3:604\n1128#4,6:605\n1128#4,6:611\n1128#4,6:617\n*S KotlinDebug\n*F\n+ 1 DesignEntry.kt\ndev/nino/squareglass/ComposableSingletons$DesignEntryKt\n*L\n40#1:604\n41#1:605,6\n507#1:611,6\n515#1:617,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;

.field private static lambda$-1699851796:Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private static lambda$-2113737026:Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/lazy/LazyItemScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private static lambda$2054685994:Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private static lambda$329193799:Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/lazy/LazyItemScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private static lambda$717846605:Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$0eVeXZunqvPV8v7n_OZM310Paec(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda__1699851796$lambda$0$0$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$YN8UQqbxOSvW2AXuMtfNYByWEng(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda__1699851796$lambda$0$1$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$r1CE-W8-0bj0QnwqBXuQLTOFubQ(Landroid/content/Context;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda_329193799$lambda$0$0$0(Landroid/content/Context;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;

    invoke-direct {v0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;-><init>()V

    sput-object v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->INSTANCE:Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;

    .line 39
    new-instance v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$3;

    invoke-direct {v0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$3;-><init>()V

    const v1, 0x139f1947

    const/4 v2, 0x0

    invoke-static {v1, v2, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function3;

    sput-object v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$329193799:Lkotlin/jvm/functions/Function3;

    .line 45
    new-instance v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$4;

    invoke-direct {v0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$4;-><init>()V

    const v1, -0x7dfd1142

    invoke-static {v1, v2, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function3;

    sput-object v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$-2113737026:Lkotlin/jvm/functions/Function3;

    .line 476
    new-instance v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$5;

    invoke-direct {v0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$5;-><init>()V

    const v1, 0x2ac9784d

    invoke-static {v1, v2, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function3;

    sput-object v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$717846605:Lkotlin/jvm/functions/Function3;

    .line 495
    new-instance v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$6;

    invoke-direct {v0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$6;-><init>()V

    const v1, -0x6551ae14

    invoke-static {v1, v2, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function3;

    sput-object v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$-1699851796:Lkotlin/jvm/functions/Function3;

    .line 545
    new-instance v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$7;

    invoke-direct {v0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$7;-><init>()V

    const v1, 0x7a78052a

    invoke-static {v1, v2, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function3;

    sput-object v0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$2054685994:Lkotlin/jvm/functions/Function3;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static final lambda_2054685994$lambda$0(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 12

    const-string v1, "$this$CategoryCard"

    invoke-static {p0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C545@22771L358,554@23150L378,563@23549L392:DesignEntry.kt#vqphja"

    invoke-static {p1, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, p2, 0x11

    const/16 v2, 0x10

    if-eq v1, v2, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    and-int/lit8 v2, p2, 0x1

    invoke-interface {p1, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, -0x1

    const-string v2, "dev.nino.squareglass.ComposableSingletons$DesignEntryKt.lambda$2054685994.<anonymous> (DesignEntry.kt:545)"

    const v3, 0x7a78052a

    invoke-static {v3, p2, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 546
    :cond_1
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    .line 552
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->blur()F

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v6

    const v9, 0xd86db6

    const/4 v10, 0x0

    .line 546
    const-string v1, "Blur Strength"

    const-string v2, "Background blur radius"

    const-string v3, "blur"

    const/4 v4, 0x0

    const/16 v5, 0x18

    const-string v7, "dp"

    move-object v8, p1

    invoke-static/range {v0 .. v10}, Ldev/nino/squareglass/DesignEntry;->access$CardRange(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 555
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    .line 561
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->opacity()F

    move-result v1

    const/high16 v11, 0x42c80000    # 100.0f

    mul-float/2addr v1, v11

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v6

    .line 555
    const-string v1, "Surface Opacity"

    const-string v2, "Tinted glass layer opacity"

    const-string v3, "opacity"

    const/16 v4, 0x14

    const/16 v5, 0x5a

    const-string v7, "%"

    invoke-static/range {v0 .. v10}, Ldev/nino/squareglass/DesignEntry;->access$CardRange(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 564
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    .line 570
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v1

    mul-float/2addr v1, v11

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v6

    .line 564
    const-string v1, "Refraction (Lens)"

    const-string v2, "Prismatic lens curvature (AGSL shader)"

    const-string v3, "lens"

    const/4 v4, 0x0

    const/16 v5, 0x64

    const-string v7, "%"

    invoke-static/range {v0 .. v10}, Ldev/nino/squareglass/DesignEntry;->access$CardRange(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    .line 545
    :cond_2
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 573
    :cond_3
    :goto_1
    sget-object v0, Lkotlin/u;->a:Lkotlin/u;

    return-object v0
.end method

.method static final lambda_329193799$lambda$0(Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 8

    const-string v0, "$this$item"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "C39@1828L7,40@1920L92,40@1848L164:DesignEntry.kt#vqphja"

    invoke-static {p1, p0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 p0, p2, 0x11

    const/16 v0, 0x10

    if-eq p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    and-int/lit8 v0, p2, 0x1

    invoke-interface {p1, p0, v0}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result p0

    if-eqz p0, :cond_4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_1

    const/4 p0, -0x1

    const-string v0, "dev.nino.squareglass.ComposableSingletons$DesignEntryKt.lambda$329193799.<anonymous> (DesignEntry.kt:39)"

    const v1, 0x139f1947

    invoke-static {v1, p2, p0, v0}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 40
    :cond_1
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalContext()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object p0

    check-cast p0, Landroidx/compose/runtime/CompositionLocal;

    const p2, 0x789c5f52

    const-string v0, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    .line 604
    invoke-static {p1, p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p1, p0}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 40
    check-cast p0, Landroid/content/Context;

    .line 41
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    const p2, -0x57c20b7d

    const-string v1, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {p1, p2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p1, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result p2

    .line 605
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    if-nez p2, :cond_2

    .line 606
    sget-object p2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {p2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object p2

    if-ne v1, p2, :cond_3

    .line 41
    :cond_2
    new-instance v1, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$2;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$2;-><init>(Landroid/content/Context;)V

    .line 608
    invoke-interface {p1, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 41
    :cond_3
    move-object v4, v1

    check-cast v4, Lam0/a;

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v6, 0x61b6

    const/4 v7, 0x0

    const-string v1, "Output"

    const-string v2, "Choose a device before starting music"

    const-string v3, "Connect"

    move-object v5, p1

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/DesignEntry;->access$ActionRow(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    :cond_4
    move-object v5, p1

    .line 39
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 44
    :cond_5
    :goto_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final lambda_329193799$lambda$0$0$0(Landroid/content/Context;)Lkotlin/u;
    .locals 1

    .line 42
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    invoke-static {v0, p0}, Ldev/nino/squareglass/DesignEntry;->access$activity(Ldev/nino/squareglass/DesignEntry;Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-static {p0}, Ldev/nino/squareglass/SquareOutput;->showFromSettings(Landroid/app/Activity;)V

    .line 43
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final lambda_717846605$lambda$0(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 8

    const-string v1, "$this$CategoryCard"

    invoke-static {p0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C476@19509L206,481@19736L191,486@19948L207:DesignEntry.kt#vqphja"

    invoke-static {p1, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, p2, 0x11

    const/16 v2, 0x10

    if-eq v1, v2, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    and-int/lit8 v2, p2, 0x1

    invoke-interface {p1, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, -0x1

    const-string v2, "dev.nino.squareglass.ComposableSingletons$DesignEntryKt.lambda$717846605.<anonymous> (DesignEntry.kt:476)"

    const v3, 0x2ac9784d

    invoke-static {v3, p2, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 477
    :cond_1
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    const/16 v6, 0x61b6

    const/16 v7, 0x8

    const-string v1, "Glass Navigation Bar"

    const-string v2, "Translucent tab bar with light refraction"

    const-string v3, "nav"

    const/4 v4, 0x0

    move-object v5, p1

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/DesignEntry;->access$CardToggle(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 482
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    const-string v1, "Glass Mini-Player"

    const-string v2, "Floating bottom playback bar"

    const-string v3, "mini"

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/DesignEntry;->access$CardToggle(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 487
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    const-string v1, "Glass Full Player"

    const-string v2, "Translucent controls in full-screen player"

    const-string v3, "player"

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/DesignEntry;->access$CardToggle(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    .line 476
    :cond_2
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 492
    :cond_3
    :goto_1
    sget-object v0, Lkotlin/u;->a:Lkotlin/u;

    return-object v0
.end method

.method static final lambda__1699851796$lambda$0(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 12

    const-string v1, "$this$CategoryCard"

    invoke-static {p0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C495@20312L219,506@20926L84,501@20641L369,514@21313L83,509@21031L365:DesignEntry.kt#vqphja"

    invoke-static {p1, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, p2, 0x11

    const/16 v2, 0x10

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eq v1, v2, :cond_0

    move v1, v8

    goto :goto_0

    :cond_0
    move v1, v9

    :goto_0
    and-int/lit8 v2, p2, 0x1

    invoke-interface {p1, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, -0x1

    const-string v2, "dev.nino.squareglass.ComposableSingletons$DesignEntryKt.lambda$-1699851796.<anonymous> (DesignEntry.kt:495)"

    const v3, -0x6551ae14

    invoke-static {v3, p2, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 496
    :cond_1
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    const/16 v6, 0x61b6

    const/16 v7, 0x8

    const-string v1, "Mini-Player Swipe Gestures"

    const-string v2, "Swipe left/right to quickly skip tracks"

    const-string v3, "miniGestures"

    const/4 v4, 0x0

    move-object v5, p1

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/DesignEntry;->access$CardToggle(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 501
    const-string v0, "Add to Queue"

    const-string v1, "Favorite"

    const-string v2, "Off"

    const-string v3, "Play Next"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    .line 502
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    .line 506
    const-string v1, "swipeRight"

    const/4 v10, 0x3

    invoke-static {v1, v8, v9, v10}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v4

    const v1, -0x579e2940

    .line 507
    const-string v11, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {p1, v1, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 611
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .line 612
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_2

    .line 613
    new-instance v1, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$0;

    invoke-direct {v1}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$0;-><init>()V

    .line 614
    invoke-interface {p1, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 507
    :cond_2
    move-object v5, v1

    check-cast v5, Lam0/l;

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v7, 0x361b6

    const/4 v8, 0x0

    .line 502
    const-string v1, "Track Swipe Right"

    const-string v2, "Action when swiping right on tracks"

    move-object v6, p1

    invoke-static/range {v0 .. v8}, Ldev/nino/squareglass/DesignEntry;->access$CardChoice(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;II)V

    .line 510
    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    .line 514
    const-string v1, "swipeLeft"

    const/4 v2, 0x2

    invoke-static {v1, v2, v9, v10}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v4

    const v1, -0x579df8e1

    .line 515
    invoke-static {p1, v1, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 617
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .line 618
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_3

    .line 619
    new-instance v1, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$1;

    invoke-direct {v1}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$1;-><init>()V

    .line 620
    invoke-interface {p1, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 515
    :cond_3
    move-object v5, v1

    check-cast v5, Lam0/l;

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v7, 0x361b6

    const/4 v8, 0x0

    .line 510
    const-string v1, "Track Swipe Left"

    const-string v2, "Action when swiping left on tracks"

    move-object v6, p1

    invoke-static/range {v0 .. v8}, Ldev/nino/squareglass/DesignEntry;->access$CardChoice(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    .line 495
    :cond_4
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 518
    :cond_5
    :goto_1
    sget-object v0, Lkotlin/u;->a:Lkotlin/u;

    return-object v0
.end method

.method private static final lambda__1699851796$lambda$0$0$0(I)Lkotlin/u;
    .locals 1

    .line 508
    const-string v0, "swipeRight"

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    .line 509
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final lambda__1699851796$lambda$0$1$0(I)Lkotlin/u;
    .locals 1

    .line 516
    const-string v0, "swipeLeft"

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    .line 517
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final lambda__2113737026$lambda$0(Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 2

    const-string v0, "$this$item"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "C44@2075L7:DesignEntry.kt#vqphja"

    invoke-static {p1, p0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 p0, p2, 0x11

    const/16 v0, 0x10

    if-eq p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    and-int/lit8 v0, p2, 0x1

    invoke-interface {p1, p0, v0}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result p0

    if-eqz p0, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_1

    const/4 p0, -0x1

    const-string v0, "dev.nino.squareglass.ComposableSingletons$DesignEntryKt.lambda$-2113737026.<anonymous> (DesignEntry.kt:44)"

    const v1, -0x7dfd1142

    invoke-static {v1, p2, p0, v0}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 45
    :cond_1
    sget-object p0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    const/4 p2, 0x6

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/DesignEntry;->access$Entry(Ldev/nino/squareglass/DesignEntry;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    :cond_2
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_3
    :goto_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final getLambda$-1699851796$extension_debug()Lkotlin/jvm/functions/Function3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    sget-object p0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$-1699851796:Lkotlin/jvm/functions/Function3;

    return-object p0
.end method

.method public final getLambda$-2113737026$extension_debug()Lkotlin/jvm/functions/Function3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/lazy/LazyItemScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    sget-object p0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$-2113737026:Lkotlin/jvm/functions/Function3;

    return-object p0
.end method

.method public final getLambda$2054685994$extension_debug()Lkotlin/jvm/functions/Function3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    sget-object p0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$2054685994:Lkotlin/jvm/functions/Function3;

    return-object p0
.end method

.method public final getLambda$329193799$extension_debug()Lkotlin/jvm/functions/Function3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/lazy/LazyItemScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    sget-object p0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$329193799:Lkotlin/jvm/functions/Function3;

    return-object p0
.end method

.method public final getLambda$717846605$extension_debug()Lkotlin/jvm/functions/Function3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    sget-object p0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->lambda$717846605:Lkotlin/jvm/functions/Function3;

    return-object p0
.end method
