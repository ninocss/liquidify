.class public final synthetic Ldev/nino/squareglass/NativeTabs$8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Z


# direct methods
.method public synthetic constructor <init>(Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Ldev/nino/squareglass/NativeTabs$8;->f$0:Z

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-boolean p0, p0, Ldev/nino/squareglass/NativeTabs$8;->f$0:Z

    check-cast p1, Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeTabs;->$r8$lambda$qX1i1eJkTZXUrWFhEx_CFwO8Q_M(ZLandroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
