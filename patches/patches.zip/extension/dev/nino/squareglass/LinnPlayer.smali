.class public final Ldev/nino/squareglass/LinnPlayer;
.super Ljava/lang/Object;
.source "LinnPlayer.java"

# interfaces
.implements Lcom/aspiro/wamp/player/k0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LinnPlayer$Action;
    }
.end annotation


# instance fields
.field volatile closed:Z

.field volatile completedControl:J

.field final controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

.field volatile device:Ldev/nino/squareglass/LinnProvider$Device;

.field volatile duration:I

.field final eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

.field events:Ldev/nino/squareglass/LinnEvents;

.field volatile failedObservations:I

.field generation:I

.field volatile index:I

.field volatile lastFullObservation:J

.field final latest:Ldev/nino/squareglass/LinnCommandQueue;

.field final nativeIndices:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field volatile nextRecovery:J

.field final occurrences:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field poll:Ljava/util/concurrent/ScheduledFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation
.end field

.field volatile position:I

.field final previous:Lcom/aspiro/wamp/player/k0;

.field final provider:Ldev/nino/squareglass/LinnProvider;

.field final queue:Lcom/aspiro/wamp/playqueue/y;

.field volatile ready:Z

.field final remote:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field repeat:Lcom/aspiro/wamp/enums/RepeatMode;

.field volatile rollbackConfirmed:Z

.field final selection:Ldev/nino/squareglass/LinnTrackSelection;

.field shuffled:Z

.field signature:Ljava/lang/String;

.field sourcePlayer:Lcom/aspiro/wamp/player/k0;

.field volatile state:Lcom/aspiro/wamp/enums/MusicServiceState;

.field volatile syncing:Z

.field token:Ljava/lang/String;

.field final tracks:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/aspiro/wamp/model/MediaItem;",
            ">;"
        }
    .end annotation
.end field

.field volatile transferred:Z

.field volume:Landroidx/media/VolumeProviderCompat;

.field wasPlaying:Z


# direct methods
.method public static synthetic $r8$lambda$-QlXJG_75yI5XvCNIRVwKvwtIb8(Ldev/nino/squareglass/LinnPlayer;)Z
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$transfer$4()Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$5hIf8FY9WMRN4AgZBuVy_kReqYE(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionPlay$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$7PicGHndXZcdeFB-7Jo-M7sM2sU(Ldev/nino/squareglass/LinnPlayer;ILjava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer;->lambda$synchronize$2(ILjava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$BgebqcwLCmOaZiUsv6My8Oh1JO4(Ldev/nino/squareglass/LinnPlayer;)Z
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$transfer$2()Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$Br1Hq9dv5kxtwVHHGBUS-kISeuk(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionPause$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$Iia6Oct-_GT5ocOZG5kOr0yWwoU(Ldev/nino/squareglass/LinnPlayer;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionSeekTo$0(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$KcPPpCtRTHOrP6spGDVHDDsIoqw(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$eventChanged$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$KsVHXcapauDE4FV7bUa0qIFa4yo(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider;Ljava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer;->lambda$new$3(Ldev/nino/squareglass/LinnProvider;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$MhGCgF-1Os4P1cg2J5wmbCyRpwA(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$synchronize$0(Ldev/nino/squareglass/LinnPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$NfY8NX4v1ucAxaJf3tq7WoCd5kY(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$new$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$TNWXaqRX9fgCtjRrfHFrmvaFDpg(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionStop$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$Y0KvIceBb19s4cFCnJRu5nl8blM(Ldev/nino/squareglass/LinnPlayer;)Ldev/nino/squareglass/OpenHome;
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$new$0()Ldev/nino/squareglass/OpenHome;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$YLk1UqFwthJYQXCFYNKGLSEpQLo(Ldev/nino/squareglass/LinnPlayer;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$skip$0(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$YmGLJU2FBpibDY4g0pcldIPRAUQ(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnEvent;J)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnPlayer;->lambda$eventReceived$0(Ldev/nino/squareglass/LinnEvent;J)V

    return-void
.end method

.method public static synthetic $r8$lambda$_8o0jQO4NdqV5ltaY5URG_dHFmI(Ldev/nino/squareglass/LinnPlayer;JII)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LinnPlayer;->lambda$observe$0(JII)V

    return-void
.end method

.method public static synthetic $r8$lambda$a2yszlRI_hLyocI33hJLXtDJdAI(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$optimistic$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$at1i57ZQ87hkxMme_cpxvBw8L_k(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider;)Z
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$new$1(Ldev/nino/squareglass/LinnProvider;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$bOllUWf6NMqJgkHwtx8mNxfQoOs(Ldev/nino/squareglass/LinnPlayer;JJLdev/nino/squareglass/LinnPlayer$Action;J)V
    .locals 0

    invoke-direct/range {p0 .. p7}, Ldev/nino/squareglass/LinnPlayer;->lambda$submit$0(JJLdev/nino/squareglass/LinnPlayer$Action;J)V

    return-void
.end method

.method public static synthetic $r8$lambda$fExB-2TvMTaslsrCavU2kb14EHI(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$observe$2(Ldev/nino/squareglass/OpenHome;)V

    return-void
.end method

.method public static synthetic $r8$lambda$h3Y4bMUm39MMhb-Q3ikAcC1wUvs(Ldev/nino/squareglass/LinnPlayer;)Z
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$transfer$0()Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$i1GphCa2Y40br91Z-c20rkMd_vA(Ldev/nino/squareglass/LinnPlayer;JLcom/aspiro/wamp/enums/MusicServiceState;IILdev/nino/squareglass/OpenHome;II)V
    .locals 0

    invoke-direct/range {p0 .. p8}, Ldev/nino/squareglass/LinnPlayer;->lambda$observe$1(JLcom/aspiro/wamp/enums/MusicServiceState;IILdev/nino/squareglass/OpenHome;II)V

    return-void
.end method

.method public static synthetic $r8$lambda$iy6vxg9FOOAHuIp8dWFdRYZqEms(Ldev/nino/squareglass/LinnPlayer;)Ljava/lang/Void;
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$transfer$3()Ljava/lang/Void;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$k-HtG2Jm2UuPv0OmnqLuXewsqqQ(Ldev/nino/squareglass/LinnPlayer;ILdev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer;->lambda$synchronize$1(ILdev/nino/squareglass/LinnPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$kxZO4ZIvpPhH70mB3urDZxVEgYU(Ldev/nino/squareglass/LinnPlayer;[Ldev/nino/squareglass/OpenHome;Ldev/nino/squareglass/LinnDiscovery;Ldev/nino/squareglass/LinnDiscovery$Result;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnPlayer;->lambda$recover$0([Ldev/nino/squareglass/OpenHome;Ldev/nino/squareglass/LinnDiscovery;Ldev/nino/squareglass/LinnDiscovery$Result;)V

    return-void
.end method

.method public static synthetic $r8$lambda$nMZ86Y3NyM-gB50ArR_Y7Hp3m4I(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;Ljava/util/List;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnPlayer;->lambda$adoptRemote$0(Ljava/util/List;Ljava/util/List;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$o0Q4hj5Vb7JBBuWUUSRVaf09xcg(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$recover$1(Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method

.method public static synthetic $r8$lambda$qNU3OPFOdR0HSBowVJAfVDAodL0(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer;->lambda$transfer$1(Ljava/util/List;I)V

    return-void
.end method

.method constructor <init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V
    .locals 6

    .line 51
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    .line 25
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    .line 26
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    .line 27
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->occurrences:Ljava/util/List;

    .line 30
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    .line 33
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    const/4 v0, 0x1

    .line 39
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->rollbackConfirmed:Z

    .line 44
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 46
    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 47
    const-string v0, ""

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    .line 52
    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iput-object p3, p0, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    .line 53
    instance-of p2, p3, Ldev/nino/squareglass/LinnPlayer;

    if-eqz p2, :cond_0

    move-object p2, p3

    check-cast p2, Ldev/nino/squareglass/LinnPlayer;

    iget-object p2, p2, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    goto :goto_0

    :cond_0
    move-object p2, p3

    :goto_0
    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    .line 54
    invoke-interface {p3}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object p2

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    new-instance p2, Ldev/nino/squareglass/LinnCommandQueue;

    iget-object p3, p1, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-direct {p2, p3}, Ldev/nino/squareglass/LinnCommandQueue;-><init>(Ljava/util/concurrent/Executor;)V

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->latest:Ldev/nino/squareglass/LinnCommandQueue;

    .line 55
    new-instance v0, Ldev/nino/squareglass/LinnTrackSelection;

    iget-object v1, p1, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$17;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$17;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    new-instance v3, Ldev/nino/squareglass/LinnPlayer$18;

    invoke-direct {v3, p0, p1}, Ldev/nino/squareglass/LinnPlayer$18;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider;)V

    new-instance v4, Ldev/nino/squareglass/LinnPlayer$19;

    invoke-direct {v4, p0}, Ldev/nino/squareglass/LinnPlayer$19;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    new-instance v5, Ldev/nino/squareglass/LinnPlayer$20;

    invoke-direct {v5, p0, p1}, Ldev/nino/squareglass/LinnPlayer$20;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider;)V

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/LinnTrackSelection;-><init>(Ljava/util/concurrent/ScheduledExecutorService;Ljava/util/function/Supplier;Ljava/util/function/BooleanSupplier;Ljava/lang/Runnable;Ljava/util/function/Consumer;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    .line 58
    iget p1, p1, Ldev/nino/squareglass/LinnProvider;->generation:I

    iput p1, p0, Ldev/nino/squareglass/LinnPlayer;->generation:I

    return-void
.end method

.method private synthetic lambda$adoptRemote$0(Ljava/util/List;Ljava/util/List;I)V
    .locals 2

    .line 355
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-eqz v0, :cond_0

    goto :goto_1

    .line 356
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p1, p2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    const/4 p1, 0x0

    move p2, p1

    .line 357
    :goto_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge p2, v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_1
    invoke-static {p1, p3}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    .line 358
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->persist()V

    :cond_2
    :goto_1
    return-void
.end method

.method private synthetic lambda$eventChanged$0()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 228
    :try_start_0
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->observe(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void

    :catchall_0
    move-exception v0

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    throw v0
.end method

.method private synthetic lambda$eventReceived$0(Ldev/nino/squareglass/LinnEvent;J)V
    .locals 9

    .line 202
    const-string v0, "Duration"

    const-string v1, "Seconds"

    const-string v2, "Id"

    const-string v3, "IdArray"

    iget-boolean v4, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v4, :cond_10

    iget-boolean v4, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v4, :cond_10

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    invoke-virtual {v4}, Ldev/nino/squareglass/LinnTrackSelection;->active()Z

    move-result v4

    const-string v5, "Volume"

    if-eqz v4, :cond_0

    iget-object v4, p1, Ldev/nino/squareglass/LinnEvent;->service:Ljava/lang/String;

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_10

    :cond_0
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v4, v4, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v4, :cond_10

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v6

    cmp-long v4, p2, v6

    if-nez v4, :cond_10

    iget-wide v6, p0, Ldev/nino/squareglass/LinnPlayer;->completedControl:J

    cmp-long p2, v6, p2

    if-gez p2, :cond_1

    goto/16 :goto_2

    .line 203
    :cond_1
    iget-object p2, p1, Ldev/nino/squareglass/LinnEvent;->service:Ljava/lang/String;

    invoke-virtual {v5, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_2

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object p2

    iget-object p3, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_2

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->eventChanged()V

    return-void

    .line 205
    :cond_2
    :try_start_0
    iget-object p2, p1, Ldev/nino/squareglass/LinnEvent;->values:Ljava/util/Map;

    .line 206
    const-string p3, "Product"

    iget-object v4, p1, Ldev/nino/squareglass/LinnEvent;->service:Ljava/lang/String;

    invoke-virtual {p3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    const/4 v4, 0x1

    const/4 v6, 0x0

    if-eqz p3, :cond_4

    const-string p3, "SourceXmlChangeCount"

    invoke-interface {p2, p3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_3

    iget-object p3, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p3, p3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {p3}, Ldev/nino/squareglass/OpenHome;->invalidateSources()V

    :cond_3
    move p3, v4

    goto :goto_0

    :cond_4
    move p3, v6

    .line 207
    :goto_0
    const-string v7, "Playlist"

    iget-object v8, p1, Ldev/nino/squareglass/LinnEvent;->service:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_b

    .line 208
    invoke-interface {p2, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_5

    invoke-interface {p2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ldev/nino/squareglass/OpenHome;->decodeIds(Ljava/lang/String;)Ljava/util/List;

    move-result-object v3

    iget-object v7, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v3, v7}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    move p3, v4

    .line 209
    :cond_5
    invoke-interface {p2, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6

    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p2, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-interface {v3, v2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v2

    if-ltz v2, :cond_7

    .line 210
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iget v3, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-eq v2, v3, :cond_6

    iput v2, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iput v6, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    :cond_6
    move v4, p3

    .line 212
    :cond_7
    const-string p3, "TransportState"

    invoke-interface {p2, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/String;

    if-eqz p3, :cond_a

    .line 213
    const-string v2, "Buffering"

    invoke-virtual {v2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_a

    const-string v2, "Playing"

    invoke-virtual {v2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8

    sget-object p3, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_1

    :cond_8
    const-string v2, "Paused"

    invoke-virtual {v2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_9

    sget-object p3, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_1

    :cond_9
    sget-object p3, Lcom/aspiro/wamp/enums/MusicServiceState;->STOPPED:Lcom/aspiro/wamp/enums/MusicServiceState;

    :goto_1
    iput-object p3, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    :cond_a
    move p3, v4

    .line 215
    :cond_b
    const-string v2, "Time"

    iget-object v3, p1, Ldev/nino/squareglass/LinnEvent;->service:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d

    .line 216
    invoke-interface {p2, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const-wide/16 v3, 0x3e8

    const-wide/32 v7, 0x7fffffff

    if-eqz v2, :cond_c

    invoke-interface {p2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    mul-long/2addr v1, v3

    invoke-static {v7, v8, v1, v2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v1

    long-to-int v1, v1

    iput v1, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    .line 217
    :cond_c
    invoke-interface {p2, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d

    invoke-interface {p2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    mul-long/2addr v0, v3

    invoke-static {v7, v8, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    long-to-int v0, v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    .line 219
    :cond_d
    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-ltz v0, :cond_e

    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_e

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getCurrentItemPosition()I

    move-result v0

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-eq v0, v1, :cond_e

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    invoke-interface {v0, v1, v6}, Lcom/aspiro/wamp/playqueue/y;->goTo(IZ)Lcom/aspiro/wamp/playqueue/u0;

    .line 220
    :cond_e
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget v2, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {v0, v1, v2}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    .line 221
    iget-object p1, p1, Ldev/nino/squareglass/LinnEvent;->service:Ljava/lang/String;

    invoke-virtual {v5, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_f

    invoke-interface {p2, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_f

    .line 222
    invoke-interface {p2, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide p1

    const-wide/16 v0, 0x64

    cmp-long v0, p1, v0

    if-gtz v0, :cond_f

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    if-eqz v0, :cond_f

    long-to-int p1, p1

    invoke-virtual {v0, p1}, Landroidx/media/VolumeProviderCompat;->setCurrentVolume(I)V

    iget-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p2, p2, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    invoke-virtual {p2, p1}, Ldev/nino/squareglass/LinnNativeVolume;->changed(I)V

    :cond_f
    if-eqz p3, :cond_10

    .line 224
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->eventChanged()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 225
    :catch_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->eventChanged()V

    :cond_10
    :goto_2
    return-void
.end method

.method private synthetic lambda$new$0()Ldev/nino/squareglass/OpenHome;
    .locals 0

    .line 55
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    return-object p0
.end method

.method private synthetic lambda$new$1(Ldev/nino/squareglass/LinnProvider;)Z
    .locals 1

    .line 55
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_0

    iget-boolean p0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez p0, :cond_0

    iget-boolean p0, p1, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private synthetic lambda$new$2()V
    .locals 2

    .line 56
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/LinnPlayer;->completedControl:J

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->eventChanged()V

    return-void
.end method

.method private synthetic lambda$new$3(Ldev/nino/squareglass/LinnProvider;Ljava/lang/Exception;)V
    .locals 2

    .line 57
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/LinnPlayer;->completedControl:J

    invoke-virtual {p2}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->eventChanged()V

    return-void
.end method

.method private synthetic lambda$observe$0(JII)V
    .locals 2

    .line 251
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_0

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    cmp-long p1, p1, v0

    if-nez p1, :cond_0

    iput p3, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iput p4, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget p2, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {p1, p2, p0}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    :cond_0
    return-void
.end method

.method private synthetic lambda$observe$1(JLcom/aspiro/wamp/enums/MusicServiceState;IILdev/nino/squareglass/OpenHome;II)V
    .locals 2

    .line 268
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_5

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v0, :cond_5

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    cmp-long p1, p1, v0

    if-eqz p1, :cond_0

    goto :goto_0

    .line 269
    :cond_0
    iput-object p3, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    .line 270
    iput p4, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iput p5, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    .line 271
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 p2, 0x0

    if-nez p1, :cond_3

    .line 272
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p1}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_1

    .line 273
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    new-instance p1, Ldev/nino/squareglass/LinnPlayer$14;

    invoke-direct {p1, p0, p6}, Ldev/nino/squareglass/LinnPlayer$14;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;)V

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void

    .line 281
    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p1}, Lcom/aspiro/wamp/playqueue/y;->getCurrentItemPosition()I

    move-result p1

    iget-object p3, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object p4, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne p3, p4, :cond_2

    const/4 p2, 0x1

    :cond_2
    iget p3, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    invoke-virtual {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnPlayer;->synchronize(IZI)V

    return-void

    :cond_3
    if-ltz p7, :cond_4

    .line 284
    iget p1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-eq p7, p1, :cond_4

    iput p7, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p1, p7, p2}, Lcom/aspiro/wamp/playqueue/y;->goTo(IZ)Lcom/aspiro/wamp/playqueue/u0;

    .line 285
    :cond_4
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget p2, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget p3, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {p1, p2, p3}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    invoke-virtual {p1, p8}, Landroidx/media/VolumeProviderCompat;->setCurrentVolume(I)V

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    invoke-virtual {p0, p8}, Ldev/nino/squareglass/LinnNativeVolume;->changed(I)V

    :cond_5
    :goto_0
    return-void
.end method

.method private synthetic lambda$observe$2(Ldev/nino/squareglass/OpenHome;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 274
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 275
    invoke-virtual {p1}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, v0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v2, "Queue changed in another controller"

    if-eqz v1, :cond_2

    const/4 v1, 0x0

    .line 276
    new-array v1, v1, [Ljava/lang/String;

    const-string v3, "Playlist"

    const-string v4, "Stop"

    invoke-virtual {p1, v3, v4, v1}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 277
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Long;

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    invoke-virtual {p1}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v7

    invoke-interface {v7, v0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    invoke-static {v5, v6}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v5}, [Ljava/lang/String;

    move-result-object v5

    const-string v6, "DeleteId"

    invoke-virtual {p1, v3, v6, v5}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    invoke-interface {v0, v4}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/io/IOException;

    invoke-direct {p0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 278
    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    const/4 p1, 0x1

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    .line 279
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v0, "Bereit \u2013 Musik ausw\u00e4hlen"

    invoke-virtual {p0, p1, v0}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    return-void

    .line 275
    :cond_2
    new-instance p0, Ljava/io/IOException;

    invoke-direct {p0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private synthetic lambda$onActionPause$0()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 471
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "Pause"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$onActionPlay$0()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 469
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "Play"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$onActionSeekTo$0(I)V
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 482
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-static {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->seekConfirmed(Ldev/nino/squareglass/OpenHome;I)V

    return-void
.end method

.method private synthetic lambda$onActionStop$0()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 484
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "Stop"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$optimistic$0()V
    .locals 2

    .line 380
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    :cond_0
    return-void
.end method

.method private synthetic lambda$recover$0([Ldev/nino/squareglass/OpenHome;Ldev/nino/squareglass/LinnDiscovery;Ldev/nino/squareglass/LinnDiscovery$Result;)V
    .locals 3

    const/4 v0, 0x0

    .line 308
    aget-object v1, p1, v0

    if-nez v1, :cond_1

    iget-object v1, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->uuid:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->uuid:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 310
    :cond_0
    :try_start_0
    new-instance v1, Ldev/nino/squareglass/OpenHome;

    iget-object p3, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->location:Ljava/lang/String;

    invoke-direct {v1, p3}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    .line 311
    iget-object p3, v1, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    invoke-virtual {p3, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    const-string p0, "Playlist"

    const-string p3, "TransportState"

    invoke-virtual {v1, p0, p3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    aput-object v1, p1, v0

    invoke-virtual {p2}, Ldev/nino/squareglass/LinnDiscovery;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    :goto_0
    return-void
.end method

.method private synthetic lambda$recover$1(Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 2

    .line 318
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v0, v0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eq v0, p0, :cond_0

    goto :goto_2

    .line 319
    :cond_0
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->readdress(Ldev/nino/squareglass/LinnProvider$Device;)V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iput-object p1, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v1, p1, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v0, v1, p1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 320
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz v0, :cond_1

    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    goto :goto_0

    :cond_1
    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    :goto_0
    iget-boolean p0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz p0, :cond_2

    const-string p0, "Bereit \u2013 Musik ausw\u00e4hlen"

    goto :goto_1

    :cond_2
    const-string p0, ""

    :goto_1
    invoke-virtual {p1, v0, p0}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    :cond_3
    :goto_2
    return-void
.end method

.method private synthetic lambda$skip$0(Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 472
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v0, "TransportState"

    const-string v1, "Playlist"

    invoke-virtual {p0, v1, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "Playing"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/String;

    invoke-virtual {p0, v1, p1, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    if-nez v0, :cond_0

    const-string p1, "Pause"

    new-array v0, v2, [Ljava/lang/String;

    invoke-virtual {p0, v1, p1, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    :cond_0
    return-void
.end method

.method private synthetic lambda$submit$0(JJLdev/nino/squareglass/LinnPlayer$Action;J)V
    .locals 4

    .line 370
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-eqz v0, :cond_0

    goto :goto_2

    .line 371
    :cond_0
    sget-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "control_queue_ms="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v2, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sub-long/2addr v2, p1

    const-wide/32 p1, 0xf4240

    div-long/2addr v2, p1

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    .line 372
    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    sget-object p2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {p2, p3, p4}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide p2

    add-long/2addr v0, p2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 373
    :try_start_0
    invoke-interface {p5}, Ldev/nino/squareglass/LinnPlayer$Action;->run()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 375
    :goto_0
    iget-wide p1, p0, Ldev/nino/squareglass/LinnPlayer;->completedControl:J

    invoke-static {p1, p2, p6, p7}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p1

    iput-wide p1, p0, Ldev/nino/squareglass/LinnPlayer;->completedControl:J

    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->eventChanged()V

    return-void

    :catchall_0
    move-exception p1

    goto :goto_1

    :catch_0
    move-exception p1

    .line 374
    :try_start_1
    iget-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 375
    :goto_1
    iget-wide p2, p0, Ldev/nino/squareglass/LinnPlayer;->completedControl:J

    invoke-static {p2, p3, p6, p7}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p2

    iput-wide p2, p0, Ldev/nino/squareglass/LinnPlayer;->completedControl:J

    sget-object p2, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p2}, Ljava/lang/ThreadLocal;->remove()V

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->eventChanged()V

    throw p1

    :cond_1
    :goto_2
    return-void
.end method

.method private synthetic lambda$synchronize$0(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 9

    .line 388
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v0, v0, Ldev/nino/squareglass/LinnProvider;->generation:I

    .line 389
    sget-object v1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    iget-object v5, p1, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    int-to-long v5, v5

    const-wide/16 v7, 0x96

    mul-long/2addr v5, v7

    const-wide/16 v7, 0x4e20

    add-long/2addr v5, v7

    const-wide/32 v7, 0x1d4c0

    invoke-static {v7, v8, v5, v6}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v5

    invoke-virtual {v4, v5, v6}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v4

    add-long/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 391
    :try_start_0
    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->transfer()V

    .line 392
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$12;

    invoke-direct {v2, p0, v0, p1}, Ldev/nino/squareglass/LinnPlayer$12;-><init>(Ldev/nino/squareglass/LinnPlayer;ILdev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 399
    :goto_0
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :catch_0
    move-exception p1

    .line 398
    :try_start_1
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$13;

    invoke-direct {v2, p0, v0, p1}, Ldev/nino/squareglass/LinnPlayer$13;-><init>(Ldev/nino/squareglass/LinnPlayer;ILjava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    .line 399
    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    throw p0
.end method

.method private synthetic lambda$synchronize$1(ILdev/nino/squareglass/LinnPlayer;)V
    .locals 1

    .line 393
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v0, v0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-eq p1, v0, :cond_0

    goto :goto_1

    .line 394
    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->close()V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iput-object p2, p1, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    invoke-static {p2}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->start()V

    .line 395
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object p2, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v0, ""

    invoke-virtual {p1, p2, v0}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 396
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p1}, Lcom/aspiro/wamp/broadcast/l;->c()V

    goto :goto_0

    :cond_1
    return-void

    .line 393
    :cond_2
    :goto_1
    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->close()V

    return-void
.end method

.method private synthetic lambda$synchronize$2(ILjava/lang/Exception;)V
    .locals 1

    .line 398
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v0, v0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-eq p1, v0, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez p1, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    :cond_1
    const/4 p1, 0x0

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    invoke-static {p2}, Ldev/nino/squareglass/LinnProvider;->explain(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_2
    :goto_0
    return-void
.end method

.method private synthetic lambda$transfer$0()Z
    .locals 2

    .line 113
    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->generation:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v1, v1, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-ne v0, v1, :cond_0

    iget-boolean p0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private synthetic lambda$transfer$1(Ljava/util/List;I)V
    .locals 3

    .line 114
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->TRANSFERRING:Ldev/nino/squareglass/LinnProvider$Phase;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Warteschlange "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "/"

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v0, p1}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$transfer$2()Z
    .locals 2

    .line 116
    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->generation:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v1, v1, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-ne v0, v1, :cond_0

    iget-boolean p0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private synthetic lambda$transfer$3()Ljava/lang/Void;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 122
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->isLocal()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->getCurrentMediaPosition()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    .line 123
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->isLocal()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    invoke-interface {p0}, Lcom/aspiro/wamp/player/k0;->onActionPause()V

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method private synthetic lambda$transfer$4()Z
    .locals 2

    .line 147
    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->generation:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v1, v1, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-ne v0, v1, :cond_0

    iget-boolean p0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method static seekConfirmed(Ldev/nino/squareglass/OpenHome;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 176
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/OpenHome;->seekConfirmed(I)V

    return-void
.end method


# virtual methods
.method adoptExisting()V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 186
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->playlistSource()Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_2

    .line 187
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    goto/16 :goto_2

    .line 189
    :cond_1
    :try_start_0
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->readRemoteTracks(Ljava/util/List;)Ljava/util/List;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 190
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v3, "Id"

    const-string v4, "Playlist"

    invoke-virtual {v2, v4, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v2

    if-ltz v2, :cond_5

    .line 191
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v3, v3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v3}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    goto :goto_2

    .line 192
    :cond_2
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v3, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v1, 0x0

    move v3, v1

    :goto_0
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    if-ge v3, v5, :cond_3

    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 193
    :cond_3
    iput v2, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iput-boolean v1, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    .line 194
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Shuffle"

    invoke-virtual {v0, v4, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    .line 195
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v2, "Repeat"

    invoke-virtual {v0, v4, v2}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->ALL:Lcom/aspiro/wamp/enums/RepeatMode;

    goto :goto_1

    :cond_4
    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    :goto_1
    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    :catch_0
    :cond_5
    :goto_2
    return-void
.end method

.method adoptRemote(Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 351
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->readRemoteTracks(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    .line 352
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v1}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, p1}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    return-void

    .line 353
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v2, "Playlist"

    const-string v3, "Id"

    invoke-virtual {v1, v2, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v1

    .line 354
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v3, Ldev/nino/squareglass/LinnPlayer$26;

    invoke-direct {v3, p0, v0, p1, v1}, Ldev/nino/squareglass/LinnPlayer$26;-><init>(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;Ljava/util/List;I)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method capture()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 61
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    if-eqz v0, :cond_7

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_7

    .line 62
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->occurrences:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 63
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/aspiro/wamp/playqueue/u0;

    .line 64
    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v3

    .line 65
    instance-of v4, v3, Lcom/aspiro/wamp/model/Track;

    if-eqz v4, :cond_1

    move-object v5, v3

    check-cast v5, Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v5}, Lcom/aspiro/wamp/model/Track;->isUpload()Z

    move-result v5

    if-nez v5, :cond_1

    invoke-virtual {v3}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v5

    if-gtz v5, :cond_0

    goto :goto_1

    .line 69
    :cond_0
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 70
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->occurrences:Ljava/util/List;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/u0;->getUid()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    :goto_1
    if-eqz v4, :cond_3

    .line 66
    check-cast v3, Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v3}, Lcom/aspiro/wamp/model/Track;->isUpload()Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "Upload"

    goto :goto_2

    :cond_2
    const-string v0, "keine g\u00fcltige TIDAL-ID"

    goto :goto_2

    :cond_3
    const-string v0, "kein Online-Musiktitel"

    .line 67
    :goto_2
    new-instance v1, Ljava/lang/Exception;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Linn: Titel "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    add-int/2addr p0, v2

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " der Warteschlange ist nicht unterst\u00fctzt ("

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "). Bitte eine reine Online-Musikqueue w\u00e4hlen."

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1

    .line 72
    :cond_4
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getCurrentItemPosition()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    .line 73
    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-ltz v0, :cond_6

    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_6

    .line 74
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->getCurrentMediaPosition()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->getState()Lcom/aspiro/wamp/enums/MusicServiceState;

    move-result-object v0

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne v0, v1, :cond_5

    goto :goto_3

    :cond_5
    const/4 v2, 0x0

    :goto_3
    iput-boolean v2, p0, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    .line 75
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->isShuffled()Z

    move-result v0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getRepeatMode()Lcom/aspiro/wamp/enums/RepeatMode;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 76
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    return-void

    .line 73
    :cond_6
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "Current queue position is unavailable."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    .line 61
    :cond_7
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "Open an online TIDAL track first."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method close()V
    .locals 2

    const/4 v0, 0x1

    .line 229
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnTrackSelection;->close()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->poll:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnEvents;->close()V

    :cond_1
    return-void
.end method

.method command(Ldev/nino/squareglass/LinnPlayer$Action;)V
    .locals 3

    const/4 v0, 0x0

    const-wide/16 v1, 0xbb8

    .line 362
    invoke-virtual {p0, v0, p1, v1, v2}, Ldev/nino/squareglass/LinnPlayer;->submit(Ljava/lang/String;Ldev/nino/squareglass/LinnPlayer$Action;J)V

    return-void
.end method

.method commandLatest(Ljava/lang/String;Ldev/nino/squareglass/LinnPlayer$Action;)V
    .locals 2

    const-wide/16 v0, 0xbb8

    .line 364
    invoke-virtual {p0, p1, p2, v0, v1}, Ldev/nino/squareglass/LinnPlayer;->submit(Ljava/lang/String;Ldev/nino/squareglass/LinnPlayer$Action;J)V

    return-void
.end method

.method createVolume(I)V
    .locals 3

    .line 170
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$1;

    const/4 v1, 0x2

    const/16 v2, 0x64

    invoke-direct {v0, p0, v1, v2, p1}, Ldev/nino/squareglass/LinnPlayer$1;-><init>(Ldev/nino/squareglass/LinnPlayer;III)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    return-void
.end method

.method eventChanged()V
    .locals 3

    .line 228
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->observations:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$16;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnPlayer$16;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method

.method eventReceived(Ldev/nino/squareglass/LinnEvent;)V
    .locals 4

    .line 200
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    .line 201
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v3, Ldev/nino/squareglass/LinnPlayer$30;

    invoke-direct {v3, p0, p1, v0, v1}, Ldev/nino/squareglass/LinnPlayer$30;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnEvent;J)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public getCurrentBitDepth()Ljava/lang/Integer;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getCurrentBitRate()Ljava/lang/Integer;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getCurrentCodec()Ljava/lang/String;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getCurrentMediaDuration()I
    .locals 0

    .line 495
    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    return p0
.end method

.method public getCurrentMediaPosition()I
    .locals 0

    .line 496
    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    return p0
.end method

.method public getCurrentSampleRate()Ljava/lang/Integer;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getPlayQueue()Lcom/aspiro/wamp/playqueue/y;
    .locals 0

    .line 493
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    return-object p0
.end method

.method public getState()Lcom/aspiro/wamp/enums/MusicServiceState;
    .locals 0

    .line 494
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    return-object p0
.end method

.method public getVideoPlayerController()Lli/a;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getVolumeProvider()Landroidx/media/VolumeProviderCompat;
    .locals 0

    .line 497
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    return-object p0
.end method

.method public isCurrentStreamAudioOnly()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isCurrentStreamDolbyAtmos()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamHiResLosslessQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamHighQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamLossless()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamLowQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamMasterQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamOnline()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isCurrentStreamPaygatedPreview()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamPreview()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isLocal()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isRepeatSupported()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isSeekingSupported()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method metadata(Lcom/aspiro/wamp/model/MediaItem;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 79
    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getDisplayTitle()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getArtistNames()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, ""

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getArtistNames()Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 80
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\"><item id=\""

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "\" parentID=\"0\" restricted=\"1\"><dc:title>"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "</dc:title><upnp:artist>"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "</upnp:artist><upnp:class>object.item.audioItem.musicTrack</upnp:class><res>"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p2}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "</res></item></DIDL-Lite>"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method observe()V
    .locals 1

    const/4 v0, 0x0

    .line 239
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->observe(Z)V

    return-void
.end method

.method observe(Z)V
    .locals 16

    move-object/from16 v1, p0

    .line 241
    const-string v0, "Volume"

    .line 0
    const-string v10, "observation_failed count="

    .line 241
    iget-boolean v2, v1, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v2, :cond_f

    iget-boolean v2, v1, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v2, :cond_f

    iget-object v2, v1, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    invoke-virtual {v2}, Ldev/nino/squareglass/LinnTrackSelection;->active()Z

    move-result v2

    if-nez v2, :cond_f

    iget-object v2, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v2, v2, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz v2, :cond_0

    goto/16 :goto_4

    .line 242
    :cond_0
    iget-object v2, v1, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v2

    iget-wide v4, v1, Ldev/nino/squareglass/LinnPlayer;->completedControl:J

    cmp-long v4, v4, v2

    if-gez v4, :cond_1

    goto/16 :goto_4

    .line 243
    :cond_1
    iget v4, v1, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    const/4 v5, 0x3

    if-lt v4, v5, :cond_2

    invoke-virtual {v1}, Ldev/nino/squareglass/LinnPlayer;->recover()V

    return-void

    .line 244
    :cond_2
    sget-object v4, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v5

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v7, 0x165a0bc00L

    add-long/2addr v5, v7

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v11, 0x1

    .line 246
    :try_start_0
    iget-object v4, v1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v7, v4, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 247
    const-string v4, ""

    const-string v5, "Duration"

    const-string v6, "Seconds"

    const-string v8, "Time"

    const/4 v9, 0x0

    if-nez p1, :cond_5

    :try_start_1
    iget-boolean v12, v1, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v12, :cond_5

    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    if-eqz v12, :cond_5

    invoke-virtual {v12}, Ldev/nino/squareglass/LinnEvents;->healthy()Z

    move-result v12

    if-eqz v12, :cond_5

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v12

    iget-wide v14, v1, Ldev/nino/squareglass/LinnPlayer;->lastFullObservation:J

    sub-long/2addr v12, v14

    sget-object v14, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v14, 0x6fc23ac00L

    cmp-long v12, v12, v14

    if-gez v12, :cond_5

    .line 248
    new-array v0, v9, [Ljava/lang/String;

    invoke-virtual {v7, v8, v8, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    .line 249
    invoke-interface {v0, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    mul-int/lit16 v6, v6, 0x3e8

    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    mul-int/lit16 v5, v0, 0x3e8

    .line 250
    iput v9, v1, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v7, Ldev/nino/squareglass/LinnProvider$Phase;->RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

    if-ne v0, v7, :cond_3

    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v7, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    invoke-virtual {v0, v7, v4}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 251
    :cond_3
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v7, v0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnPlayer$0;

    move v4, v6

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/LinnPlayer$0;-><init>(Ldev/nino/squareglass/LinnPlayer;JII)V

    invoke-virtual {v7, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 292
    :cond_4
    :goto_0
    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    .line 253
    :cond_5
    :try_start_2
    iget-boolean v12, v1, Ldev/nino/squareglass/LinnPlayer;->ready:Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const-string v13, "TransportState"

    const-string v14, "Playlist"

    if-eqz v12, :cond_6

    :try_start_3
    invoke-virtual {v7, v14, v13}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    iput v9, v1, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v4, Ldev/nino/squareglass/LinnProvider$Phase;->RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

    if-ne v0, v4, :cond_4

    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v4, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v5, "Bereit \u2013 Musik ausw\u00e4hlen"

    invoke-virtual {v0, v4, v5}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    goto :goto_0

    .line 254
    :cond_6
    invoke-virtual {v7}, Ldev/nino/squareglass/OpenHome;->playlistSource()Z

    move-result v12

    if-nez v12, :cond_7

    iput-boolean v11, v1, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v4, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v5, "Andere Quelle aktiv \u2013 Musik ausw\u00e4hlen"

    invoke-virtual {v0, v4, v5}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    goto :goto_0

    .line 255
    :cond_7
    invoke-virtual {v7}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v12

    .line 256
    iget-object v15, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v12, v15}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_8

    iget-boolean v15, v1, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v15, :cond_8

    invoke-virtual {v1, v12}, Ldev/nino/squareglass/LinnPlayer;->adoptRemote(Ljava/util/List;)V

    goto :goto_0

    .line 257
    :cond_8
    const-string v12, "Id"

    invoke-virtual {v7, v14, v12}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    move v15, v11

    :try_start_4
    invoke-static {v12}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v11
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    move/from16 p1, v15

    .line 258
    :try_start_5
    new-array v15, v9, [Ljava/lang/String;

    invoke-virtual {v7, v8, v8, v15}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v8

    .line 259
    invoke-interface {v8, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    mul-int/lit16 v6, v6, 0x3e8

    invoke-interface {v8, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    mul-int/lit16 v5, v5, 0x3e8

    .line 260
    invoke-virtual {v7, v14, v13}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 261
    const-string v13, "Buffering"

    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_9

    iget-object v8, v1, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_1

    :cond_9
    const-string v13, "Playing"

    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_a

    sget-object v8, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_1

    :cond_a
    const-string v13, "Paused"

    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_b

    sget-object v8, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_1

    :cond_b
    sget-object v8, Lcom/aspiro/wamp/enums/MusicServiceState;->STOPPED:Lcom/aspiro/wamp/enums/MusicServiceState;

    .line 262
    :goto_1
    iget-object v13, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v13, v11, v12}, Ldev/nino/squareglass/LinnQueuePlan;->confirmedIndex(Ljava/util/List;J)I

    move-result v11

    if-gez v11, :cond_c

    const/4 v11, -0x1

    goto :goto_2

    :cond_c
    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v12, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/Integer;

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v11

    .line 263
    :goto_2
    invoke-virtual {v7, v0, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 264
    iput v9, v1, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    .line 265
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v12

    iput-wide v12, v1, Ldev/nino/squareglass/LinnPlayer;->lastFullObservation:J

    .line 266
    iget-object v9, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v9, v9, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v12, Ldev/nino/squareglass/LinnProvider$Phase;->RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

    if-ne v9, v12, :cond_d

    iget-object v9, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v12, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    invoke-virtual {v9, v12, v4}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 267
    :cond_d
    iget-object v4, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v12, v4, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    move v9, v0

    new-instance v0, Ldev/nino/squareglass/LinnPlayer$2;

    move v4, v6

    move v6, v5

    move v5, v4

    move-object v4, v8

    move v8, v11

    invoke-direct/range {v0 .. v9}, Ldev/nino/squareglass/LinnPlayer$2;-><init>(Ldev/nino/squareglass/LinnPlayer;JLcom/aspiro/wamp/enums/MusicServiceState;IILdev/nino/squareglass/OpenHome;II)V

    invoke-virtual {v12, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto/16 :goto_0

    :catch_0
    move-exception v0

    goto :goto_3

    :catch_1
    move-exception v0

    move/from16 p1, v15

    goto :goto_3

    :catch_2
    move-exception v0

    move/from16 p1, v11

    .line 288
    :goto_3
    :try_start_6
    iget-boolean v4, v1, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v4, :cond_4

    iget-boolean v4, v1, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v4, :cond_4

    iget-object v4, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v4, v4, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v4, :cond_4

    iget-object v4, v1, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4

    cmp-long v2, v2, v4

    if-eqz v2, :cond_e

    goto/16 :goto_0

    .line 289
    :cond_e
    iget v2, v1, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    add-int/lit8 v2, v2, 0x1

    iput v2, v1, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    .line 290
    iget-object v2, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v3, Ldev/nino/squareglass/LinnProvider$Phase;->RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v4, "Verbindung unterbrochen \u2013 erneut verbinden\u2026"

    invoke-virtual {v2, v3, v4}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 291
    sget-object v2, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, v1, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " type="

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v2, v0}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    .line 292
    sget-object v1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->remove()V

    throw v0

    :cond_f
    :goto_4
    return-void
.end method

.method public onActionNext()V
    .locals 2

    .line 474
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v1, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-eq v0, v1, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnTrackSelection;->active()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    const-string v0, "Next"

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->skip(Ljava/lang/String;)V

    return-void

    :cond_2
    :goto_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->singleSkip(Z)V

    return-void
.end method

.method public onActionPause()V
    .locals 2

    .line 471
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v0, :cond_1

    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->optimistic(Lcom/aspiro/wamp/enums/MusicServiceState;)V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/LinnTrackSelection;->play(Z)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    return-void

    :cond_0
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$27;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnPlayer$27;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    :cond_1
    return-void
.end method

.method public onActionPlay()V
    .locals 2

    .line 466
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getCurrentItemPosition()I

    move-result v0

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/LinnPlayer;->select(IZ)V

    return-void

    .line 467
    :cond_0
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->optimistic(Lcom/aspiro/wamp/enums/MusicServiceState;)V

    .line 468
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/LinnTrackSelection;->play(Z)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    return-void

    .line 469
    :cond_1
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$9;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnPlayer$9;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method public onActionPlayPosition(IZZ)V
    .locals 0

    .line 486
    invoke-virtual {p0, p1, p3}, Ldev/nino/squareglass/LinnPlayer;->select(IZ)V

    return-void
.end method

.method public onActionPrevious(Z)V
    .locals 1

    .line 475
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    if-nez p1, :cond_1

    iget p1, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    const/16 v0, 0x1388

    if-le p1, v0, :cond_1

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->onActionSeekTo(I)V

    return-void

    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-eq p1, v0, :cond_3

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnTrackSelection;->active()Z

    move-result p1

    if-eqz p1, :cond_2

    goto :goto_0

    :cond_2
    const-string p1, "Previous"

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->skip(Ljava/lang/String;)V

    return-void

    :cond_3
    :goto_0
    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->singleSkip(Z)V

    return-void
.end method

.method public onActionSeekTo(I)V
    .locals 5

    .line 477
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v0, :cond_4

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_4

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v0, :cond_4

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v0, v0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 478
    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 479
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    invoke-virtual {v1, p1}, Ldev/nino/squareglass/LinnTrackSelection;->seek(I)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    .line 480
    :cond_1
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    iget v2, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v1

    if-ltz v1, :cond_3

    .line 481
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne p0, v1, :cond_2

    const/4 v0, 0x1

    :cond_2
    invoke-virtual {v2, v3, v4, p1, v0}, Ldev/nino/squareglass/LinnTrackSelection;->seekCurrent(JIZ)V

    return-void

    .line 482
    :cond_3
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$21;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/LinnPlayer$21;-><init>(Ldev/nino/squareglass/LinnPlayer;I)V

    const-string p1, "seek"

    invoke-virtual {p0, p1, v0}, Ldev/nino/squareglass/LinnPlayer;->commandLatest(Ljava/lang/String;Ldev/nino/squareglass/LinnPlayer$Action;)V

    :cond_4
    :goto_0
    return-void
.end method

.method public onActionStop(Lcom/aspiro/wamp/player/PlaybackEndReason;)V
    .locals 0

    .line 484
    iget-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnTrackSelection;->close()V

    sget-object p1, Lcom/aspiro/wamp/enums/MusicServiceState;->STOPPED:Lcom/aspiro/wamp/enums/MusicServiceState;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->optimistic(Lcom/aspiro/wamp/enums/MusicServiceState;)V

    new-instance p1, Ldev/nino/squareglass/LinnPlayer$28;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/LinnPlayer$28;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    :cond_0
    return-void
.end method

.method public onActionTogglePlayback()V
    .locals 2

    .line 485
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->onActionPause()V

    return-void

    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->onActionPlay()V

    return-void
.end method

.method public onActionWifiQualityChanged()V
    .locals 0

    return-void
.end method

.method public onActivated(ILcom/aspiro/wamp/player/k0;)V
    .locals 0

    return-void
.end method

.method public onDeactivated()V
    .locals 0

    return-void
.end method

.method public onServicePreEnterForeground()V
    .locals 0

    return-void
.end method

.method public onServicePreLeaveForeground()V
    .locals 0

    return-void
.end method

.method public onTaskRemoved()V
    .locals 0

    return-void
.end method

.method optimistic(Lcom/aspiro/wamp/enums/MusicServiceState;)V
    .locals 1

    .line 380
    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p1, p1, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnPlayer$25;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnPlayer$25;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method persist()V
    .locals 10

    .line 412
    :try_start_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/aspiro/wamp/model/MediaItem;

    new-instance v3, Lcom/aspiro/wamp/model/Track;

    check-cast v2, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v3, v2}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    const/4 v2, 0x0

    invoke-virtual {v3, v2}, Lcom/aspiro/wamp/model/Track;->setSource(Lcom/aspiro/wamp/playqueue/source/model/Source;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 413
    :cond_0
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    new-instance v2, Ljava/io/ObjectOutputStream;

    invoke-direct {v2, v1}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-virtual {v2, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V

    .line 414
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v0

    const/high16 v2, 0x400000

    if-gt v0, v2, :cond_4

    .line 415
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    move v3, v2

    :goto_1
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_1

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v4, 0x3a

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v4, 0x2c

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 416
    :cond_1
    new-instance v3, Lorg/json/JSONArray;

    invoke-direct {v3}, Lorg/json/JSONArray;-><init>()V

    .line 417
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->occurrences:Ljava/util/List;

    invoke-interface {v6, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_2

    .line 418
    :cond_2
    invoke-static {}, Ljava/util/Base64;->getUrlEncoder()Ljava/util/Base64$Encoder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/Base64$Encoder;->withoutPadding()Ljava/util/Base64$Encoder;

    move-result-object v4

    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v5, v5, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    sget-object v6, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v5, v6}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/Base64$Encoder;->encodeToString([B)Ljava/lang/String;

    move-result-object v4

    .line 419
    const-string v5, "squareglass_linn"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "squareglass_linn_session_"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    filled-new-array {v5, v4}, [Ljava/lang/String;

    move-result-object v4

    move v5, v2

    :goto_3
    const/4 v6, 0x2

    if-ge v5, v6, :cond_3

    aget-object v7, v4, v5

    .line 420
    iget-object v8, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v8, v8, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    invoke-virtual {v8, v7, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v7

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "sessionUuid"

    iget-object v9, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v9, v9, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "sessionLocation"

    iget-object v9, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v9, v9, Ldev/nino/squareglass/LinnProvider$Device;->location:Ljava/lang/String;

    .line 421
    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "queue"

    .line 422
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v9

    invoke-static {v9, v6}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v7, v8, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const-string v7, "mapping"

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const-string v7, "occurrences"

    .line 423
    invoke-virtual {v3}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const-string v7, "shuffled"

    iget-boolean v8, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const-string v7, "repeat"

    iget-object v8, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    invoke-virtual {v8}, Lcom/aspiro/wamp/enums/RepeatMode;->name()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_3
    return-void

    .line 414
    :cond_4
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Queue snapshot too large"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catchall_0
    move-exception v0

    .line 413
    :try_start_3
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_4

    :catchall_1
    move-exception v1

    :try_start_4
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 424
    :catch_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    const-string v0, "Linn is connected; saving its reconnect state failed."

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method prepareReady()V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v0, 0x1

    .line 180
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    .line 181
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Volume"

    invoke-virtual {v0, v1, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 182
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->createVolume(I)V

    .line 183
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v0, "squareglass_linn"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "autoResume"

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method readRemoteTracks(Ljava/util/List;)Ljava/util/List;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/aspiro/wamp/model/MediaItem;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 329
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 330
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v1, p1}, Ldev/nino/squareglass/OpenHome;->readTracks(Ljava/util/List;)Ljava/util/Map;

    move-result-object v1

    .line 331
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 332
    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    .line 333
    new-instance v3, Ljava/net/URI;

    const-string v4, "Uri"

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-direct {v3, v4}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 334
    const-string v4, "tidal"

    invoke-virtual {v3}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    .line 335
    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v3}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v3

    const-string v5, "&"

    invoke-virtual {v3, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    array-length v5, v3

    const/4 v6, 0x0

    move v7, v6

    :goto_1
    const/4 v8, 0x1

    if-ge v7, v5, :cond_1

    aget-object v9, v3, v7

    .line 336
    const-string v10, "="

    const/4 v11, 0x2

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v9

    array-length v10, v9

    if-ne v10, v11, :cond_0

    aget-object v10, v9, v6

    aget-object v8, v9, v8

    const-string v9, "UTF-8"

    invoke-static {v8, v9}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v4, v10, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 338
    :cond_1
    const-string v3, "trackId"

    invoke-interface {v4, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    .line 339
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/aspiro/wamp/model/MediaItem;

    invoke-virtual {v5}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v6

    if-ne v6, v3, :cond_2

    new-instance v4, Lcom/aspiro/wamp/model/Track;

    check-cast v5, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v4, v5}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    goto :goto_2

    :cond_3
    const/4 v4, 0x0

    :goto_2
    if-nez v4, :cond_4

    .line 341
    const-string v4, "Metadata"

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sget-object v4, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v2, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v2

    invoke-static {v2}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object v2

    invoke-interface {v2}, Lorg/w3c/dom/Document;->getDocumentElement()Lorg/w3c/dom/Element;

    move-result-object v2

    .line 342
    new-instance v4, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v4}, Lcom/aspiro/wamp/model/Track;-><init>()V

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setId(I)V

    const-string v3, "title"

    invoke-static {v2, v3}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setTitle(Ljava/lang/String;)V

    .line 343
    new-instance v3, Lcom/aspiro/wamp/model/Artist;

    invoke-direct {v3}, Lcom/aspiro/wamp/model/Artist;-><init>()V

    const-string v5, "artist"

    invoke-static {v2, v5}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcom/aspiro/wamp/model/Artist;->setName(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setArtist(Lcom/aspiro/wamp/model/Artist;)V

    invoke-static {v3}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setArtists(Ljava/util/List;)V

    .line 344
    new-instance v3, Lcom/aspiro/wamp/model/Album;

    invoke-direct {v3}, Lcom/aspiro/wamp/model/Album;-><init>()V

    const-string v5, "album"

    invoke-static {v2, v5}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcom/aspiro/wamp/model/Album;->setTitle(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setAlbum(Lcom/aspiro/wamp/model/Album;)V

    invoke-virtual {v4, v8}, Lcom/aspiro/wamp/model/Track;->setAllowStreaming(Z)V

    invoke-virtual {v4, v8}, Lcom/aspiro/wamp/model/Track;->setStreamReady(Z)V

    .line 346
    :cond_4
    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 334
    :cond_5
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Linn queue now contains non-TIDAL content; its playback was left untouched."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_6
    return-object v0
.end method

.method readdress(Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 8

    .line 231
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eq v0, p0, :cond_0

    return-void

    .line 232
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnTrackSelection;->close()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/LinnPlayer;->completedControl:J

    .line 233
    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnEvents;->close()V

    .line 234
    :cond_1
    new-instance p1, Ldev/nino/squareglass/LinnEvents;

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$23;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnPlayer$23;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$24;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$24;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-direct {p1, v0, v1, v2}, Ldev/nino/squareglass/LinnEvents;-><init>(Ldev/nino/squareglass/OpenHome;Ljava/lang/Runnable;Ljava/util/function/Consumer;)V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnEvents;->start()V

    .line 235
    iget-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    const/4 v0, 0x0

    if-eqz p1, :cond_2

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, p1, Ldev/nino/squareglass/LinnProvider;->observations:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$22;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$22;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    const-wide/16 v5, 0x2

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x0

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->poll:Ljava/util/concurrent/ScheduledFuture;

    .line 236
    :cond_2
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p1, p1, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    invoke-virtual {p1, v1, v0}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v0, v0, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    const-string v1, "sessionLocation"

    invoke-interface {p1, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 237
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->eventChanged()V

    return-void
.end method

.method reattach()V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 428
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->playlistSource()Z

    move-result v0

    if-eqz v0, :cond_a

    .line 429
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->sessionPreferences()Landroid/content/SharedPreferences;

    move-result-object v0

    .line 430
    const-string v1, "shuffled"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    const-string v1, "repeat"

    const-string v3, "OFF"

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/aspiro/wamp/enums/RepeatMode;->valueOf(Ljava/lang/String;)Lcom/aspiro/wamp/enums/RepeatMode;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 431
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v1, v1, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    const-string v3, "sessionUuid"

    const-string v4, ""

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    .line 432
    const-string v1, "queue"

    invoke-interface {v0, v1, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    invoke-static {v1, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    .line 433
    array-length v3, v1

    const/high16 v5, 0x400000

    if-gt v3, v5, :cond_8

    .line 434
    new-instance v3, Ljava/io/ObjectInputStream;

    new-instance v5, Ljava/io/ByteArrayInputStream;

    invoke-direct {v5, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v3, v5}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V

    :try_start_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-virtual {v3}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-interface {v1, v5}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v3}, Ljava/io/ObjectInputStream;->close()V

    .line 435
    const-string v1, "mapping"

    invoke-interface {v0, v1, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ","

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    array-length v1, v0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_2

    aget-object v4, v0, v3

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_1

    .line 436
    const-string v5, ":"

    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    aget-object v6, v4, v2

    invoke-static {v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x1

    aget-object v4, v4, v5

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    if-ltz v4, :cond_0

    .line 437
    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_0

    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v5, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Invalid queue mapping"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 439
    :cond_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    .line 440
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    .line 441
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->readRemoteTracks(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    .line 442
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v3, v3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v3}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    .line 443
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->clear()V

    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v3, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 444
    :goto_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge v2, v0, :cond_4

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    .line 442
    :cond_3
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Linn queue is changing. Retry reconnecting."

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 446
    :cond_4
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Shuffle"

    const-string v2, "Playlist"

    invoke-virtual {v0, v2, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    .line 447
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v3, "Repeat"

    invoke-virtual {v0, v2, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    goto :goto_3

    .line 448
    :cond_5
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v1, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-eq v0, v1, :cond_6

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->ALL:Lcom/aspiro/wamp/enums/RepeatMode;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 449
    :cond_6
    :goto_3
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Id"

    invoke-virtual {v0, v2, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-interface {v2, v0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v0

    if-ltz v0, :cond_7

    .line 450
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    .line 451
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Volume"

    invoke-virtual {v0, v1, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 452
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->createVolume(I)V

    return-void

    .line 450
    :cond_7
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Linn current track is unavailable"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :catchall_0
    move-exception p0

    .line 434
    :try_start_1
    invoke-virtual {v3}, Ljava/io/ObjectInputStream;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_4

    :catchall_1
    move-exception v0

    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw p0

    .line 433
    :cond_8
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Invalid queue snapshot"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 431
    :cond_9
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Different Linn session"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 428
    :cond_a
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Another Linn source is active"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method recover()V
    .locals 11

    .line 295
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    iget-wide v2, p0, Ldev/nino/squareglass/LinnPlayer;->nextRecovery:J

    cmp-long v2, v0, v2

    if-ltz v2, :cond_4

    iget-boolean v2, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v2, :cond_4

    iget-boolean v2, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v2, :cond_4

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v2, v2, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz v2, :cond_0

    goto/16 :goto_2

    .line 296
    :cond_0
    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    iget v3, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    add-int/lit8 v3, v3, -0x3

    const/4 v4, 0x5

    invoke-static {v4, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    const-wide/16 v4, 0x1

    shl-long v3, v4, v3

    const-wide/16 v5, 0x1e

    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v2

    add-long/2addr v2, v0

    iput-wide v2, p0, Ldev/nino/squareglass/LinnPlayer;->nextRecovery:J

    .line 297
    sget-object v2, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v3, 0x1dcd65000L

    add-long/2addr v0, v3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v2, 0x1

    .line 299
    :try_start_0
    new-array v3, v2, [Ldev/nino/squareglass/OpenHome;

    const/4 v4, 0x0

    const/4 v5, 0x0

    aput-object v4, v3, v5

    .line 300
    sget-object v6, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v7

    sget-object v9, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/32 v9, 0x77359400

    add-long/2addr v7, v9

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 302
    :try_start_1
    new-instance v6, Ldev/nino/squareglass/OpenHome;

    iget-object v7, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v7, v7, Ldev/nino/squareglass/LinnProvider$Device;->location:Ljava/lang/String;

    invoke-direct {v6, v7}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    .line 303
    iget-object v7, v6, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    iget-object v8, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v8, v8, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_1

    const-string v7, "Playlist"

    const-string v8, "TransportState"

    invoke-virtual {v6, v7, v8}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    aput-object v6, v3, v5
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 305
    :catch_0
    :cond_1
    :try_start_2
    sget-object v6, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 306
    aget-object v0, v3, v5

    if-nez v0, :cond_2

    new-instance v0, Ldev/nino/squareglass/LinnDiscovery;

    invoke-direct {v0}, Ldev/nino/squareglass/LinnDiscovery;-><init>()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 307
    :try_start_3
    new-instance v1, Ldev/nino/squareglass/LinnPlayer$10;

    invoke-direct {v1, p0, v3, v0}, Ldev/nino/squareglass/LinnPlayer$10;-><init>(Ldev/nino/squareglass/LinnPlayer;[Ldev/nino/squareglass/OpenHome;Ldev/nino/squareglass/LinnDiscovery;)V

    const/16 v6, 0x7d0

    invoke-virtual {v0, v4, v6, v1}, Ldev/nino/squareglass/LinnDiscovery;->search(Ljava/lang/String;ILjava/util/function/Consumer;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 314
    :try_start_4
    invoke-virtual {v0}, Ldev/nino/squareglass/LinnDiscovery;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    goto :goto_1

    :catchall_0
    move-exception v1

    .line 306
    :try_start_5
    invoke-virtual {v0}, Ldev/nino/squareglass/LinnDiscovery;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    goto :goto_0

    :catchall_1
    move-exception v0

    :try_start_6
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_0
    throw v1

    .line 315
    :cond_2
    :goto_1
    aget-object v0, v3, v5

    if-eqz v0, :cond_3

    .line 316
    new-instance v0, Ldev/nino/squareglass/LinnProvider$Device;

    aget-object v1, v3, v5

    invoke-direct {v0, v1}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    iput v5, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    .line 317
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v3, Ldev/nino/squareglass/LinnPlayer$11;

    invoke-direct {v3, p0, v0}, Ldev/nino/squareglass/LinnPlayer$11;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    invoke-interface {v1, v3}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 324
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :catchall_2
    move-exception p0

    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->remove()V

    throw p0

    :catch_1
    :cond_3
    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->remove()V

    .line 325
    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    add-int/2addr v0, v2

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    :cond_4
    :goto_2
    return-void
.end method

.method restoreNativeQueue()V
    .locals 9

    .line 455
    new-instance v0, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;

    sget-object v1, Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType$None;->INSTANCE:Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType$None;

    const/4 v2, 0x0

    const-string v3, "squareglass-linn"

    const-string v4, "Linn queue"

    invoke-direct {v0, v3, v4, v1, v2}, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType;Lcom/tidal/android/navigation/NavigationInfo$Node;)V

    .line 456
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/aspiro/wamp/model/MediaItem;

    new-instance v3, Lcom/aspiro/wamp/model/Track;

    check-cast v2, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v3, v2}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    invoke-virtual {v0, v3}, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;->addSourceItem(Lcom/aspiro/wamp/model/MediaItem;)V

    goto :goto_0

    .line 459
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    new-instance v2, Lcom/aspiro/wamp/playqueue/w0;

    iget v3, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    sget-object v5, Lcom/aspiro/wamp/enums/ShuffleMode;->TURN_OFF:Lcom/aspiro/wamp/enums/ShuffleMode;

    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v4, 0x0

    invoke-direct/range {v2 .. v8}, Lcom/aspiro/wamp/playqueue/w0;-><init>(IZLcom/aspiro/wamp/enums/ShuffleMode;Lcom/aspiro/wamp/enums/RepeatMode;ZZ)V

    invoke-interface {v1, v0, v2}, Lcom/aspiro/wamp/playqueue/y;->prepare(Lcom/aspiro/wamp/playqueue/source/model/Source;Lcom/aspiro/wamp/playqueue/w0;)V

    .line 460
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    iget-boolean v1, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    invoke-static {v0, v1}, Ldev/nino/squareglass/NativeLinnBridge;->restoreShuffle(Lcom/aspiro/wamp/playqueue/y;Z)V

    .line 461
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Lcom/aspiro/wamp/playqueue/y;->goTo(IZ)Lcom/aspiro/wamp/playqueue/u0;

    .line 462
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    .line 463
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->occurrences:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/aspiro/wamp/playqueue/u0;

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->occurrences:Ljava/util/List;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/u0;->getUid()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ":"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v1

    invoke-virtual {v1}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_1
    return-void
.end method

.method select(IZ)V
    .locals 4

    .line 403
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_5

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v0, :cond_5

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v0, v0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    if-ltz p1, :cond_5

    .line 404
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lt p1, v0, :cond_1

    goto :goto_2

    .line 405
    :cond_1
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    const/4 v1, 0x0

    if-nez v0, :cond_4

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_1

    .line 406
    :cond_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v0

    .line 407
    iput p1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iput v1, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    if-eqz p2, :cond_3

    sget-object p1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_0

    :cond_3
    sget-object p1, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    :goto_0
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->optimistic(Lcom/aspiro/wamp/enums/MusicServiceState;)V

    .line 408
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->selection:Ldev/nino/squareglass/LinnTrackSelection;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3, v1, p2}, Ldev/nino/squareglass/LinnTrackSelection;->select(JIZ)V

    return-void

    .line 405
    :cond_4
    :goto_1
    invoke-virtual {p0, p1, p2, v1}, Ldev/nino/squareglass/LinnPlayer;->synchronize(IZI)V

    :cond_5
    :goto_2
    return-void
.end method

.method sessionPreferences()Landroid/content/SharedPreferences;
    .locals 5

    .line 83
    invoke-static {}, Ljava/util/Base64;->getUrlEncoder()Ljava/util/Base64$Encoder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Base64$Encoder;->withoutPadding()Ljava/util/Base64$Encoder;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v1, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/Base64$Encoder;->encodeToString([B)Ljava/lang/String;

    move-result-object v0

    .line 84
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "squareglass_linn_session_"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 85
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    const-string v3, "sessionUuid"

    const-string v4, ""

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-object v0

    .line 86
    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v0, "squareglass_linn"

    invoke-virtual {p0, v0, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    return-object p0
.end method

.method singleSkip(Z)V
    .locals 2

    .line 473
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-static {v0, p1}, Ldev/nino/squareglass/NativeLinnBridge;->skip(Lcom/aspiro/wamp/playqueue/y;Z)I

    move-result p1

    if-ltz p1, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0, p1, v0}, Ldev/nino/squareglass/LinnPlayer;->select(IZ)V

    :cond_1
    return-void
.end method

.method skip(Ljava/lang/String;)V
    .locals 1

    .line 472
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$15;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/LinnPlayer$15;-><init>(Ldev/nino/squareglass/LinnPlayer;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method snapshotSignature()Ljava/lang/String;
    .locals 5

    .line 178
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/16 v3, 0x3a

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/aspiro/wamp/playqueue/u0;

    invoke-interface {v2}, Lcom/aspiro/wamp/playqueue/u0;->getUid()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-interface {v2}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v2

    invoke-virtual {v2}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v2, 0x2c

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/y;->isShuffled()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p0}, Lcom/aspiro/wamp/playqueue/y;->getRepeatMode()Lcom/aspiro/wamp/enums/RepeatMode;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method start()V
    .locals 8

    .line 197
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->persist()V

    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->observations:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$22;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$22;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    const-wide/16 v5, 0x2

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x0

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->poll:Ljava/util/concurrent/ScheduledFuture;

    .line 198
    new-instance v0, Ldev/nino/squareglass/LinnEvents;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$23;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$23;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    new-instance v3, Ldev/nino/squareglass/LinnPlayer$24;

    invoke-direct {v3, p0}, Ldev/nino/squareglass/LinnPlayer$24;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-direct {v0, v1, v2, v3}, Ldev/nino/squareglass/LinnEvents;-><init>(Ldev/nino/squareglass/OpenHome;Ljava/lang/Runnable;Ljava/util/function/Consumer;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnEvents;->start()V

    return-void
.end method

.method submit(Ljava/lang/String;Ldev/nino/squareglass/LinnPlayer$Action;J)V
    .locals 10

    .line 366
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v0, v0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 367
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->controlRevision:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    move-result-wide v8

    .line 368
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    .line 369
    new-instance v1, Ldev/nino/squareglass/LinnPlayer$3;

    move-object v2, p0

    move-object v7, p2

    move-wide v5, p3

    invoke-direct/range {v1 .. v9}, Ldev/nino/squareglass/LinnPlayer$3;-><init>(Ldev/nino/squareglass/LinnPlayer;JJLdev/nino/squareglass/LinnPlayer$Action;J)V

    if-nez p1, :cond_1

    .line 377
    iget-object p0, v2, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {p0, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_1
    iget-object p0, v2, Ldev/nino/squareglass/LinnPlayer;->latest:Ldev/nino/squareglass/LinnCommandQueue;

    invoke-virtual {p0, p1, v1}, Ldev/nino/squareglass/LinnCommandQueue;->execute(Ljava/lang/String;Ljava/lang/Runnable;)V

    :cond_2
    :goto_0
    return-void
.end method

.method synchronize(IZI)V
    .locals 3

    .line 383
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    .line 384
    new-instance v0, Ldev/nino/squareglass/LinnPlayer;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v0, v1, v2, p0}, Ldev/nino/squareglass/LinnPlayer;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V

    .line 385
    :try_start_0
    invoke-virtual {v0}, Ldev/nino/squareglass/LinnPlayer;->capture()V

    iput p1, v0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iput-boolean p2, v0, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    iput p3, v0, Ldev/nino/squareglass/LinnPlayer;->position:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 387
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p1, p1, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance p2, Ldev/nino/squareglass/LinnPlayer$29;

    invoke-direct {p2, p0, v0}, Ldev/nino/squareglass/LinnPlayer$29;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V

    invoke-interface {p1, p2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    :catch_0
    move-exception p1

    const/4 p2, 0x0

    .line 386
    iput-boolean p2, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method

.method transfer()V
    .locals 42
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object/from16 v1, p0

    .line 89
    const-string v2, "Play"

    const-string v3, "SetSourceIndex"

    const-string v4, "SetShuffle"

    const-string v5, "SetRepeat"

    const-string v6, "Playing"

    const-string v7, "Pause"

    const-string v8, "0"

    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v9, Ldev/nino/squareglass/LinnProvider$Phase;->CHECKING:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v10, "Ger\u00e4t pr\u00fcfen\u2026"

    invoke-virtual {v0, v9, v10}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 90
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v9, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    .line 91
    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->preflight()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->token:Ljava/lang/String;

    const-string v0, "TracksMax"

    const-string v15, "Playlist"

    invoke-virtual {v9, v15, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v14

    .line 92
    const-string v0, "SourceIndex"

    const-string v10, "Product"

    invoke-virtual {v9, v10, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->playlistIndex()I

    move-result v0

    .line 93
    const-string v12, "TransportState"

    invoke-virtual {v9, v15, v12}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "Id"

    move-object/from16 v16, v2

    invoke-virtual {v9, v15, v13}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move/from16 v17, v0

    .line 94
    const-string v0, "Repeat"

    move-object/from16 v18, v6

    invoke-virtual {v9, v15, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v0, "Shuffle"

    move-object/from16 v19, v8

    invoke-virtual {v9, v15, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v20, v4

    const/4 v4, 0x0

    .line 95
    new-array v0, v4, [Ljava/lang/String;

    move/from16 v21, v4

    const-string v4, "Time"

    invoke-virtual {v9, v4, v4, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    move-object/from16 v22, v8

    const-string v8, "Seconds"

    invoke-interface {v0, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    move-object/from16 v23, v5

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    .line 96
    const-string v0, "Volume"

    invoke-virtual {v9, v0, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    move-object/from16 v24, v11

    .line 97
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v25, v9

    move-object/from16 v26, v10

    move/from16 v9, v21

    .line 98
    :goto_0
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v10

    if-ge v9, v10, :cond_1

    .line 99
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    move-object/from16 v27, v12

    sget-object v12, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-ne v10, v12, :cond_0

    iget v10, v1, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-eq v9, v10, :cond_0

    move-object/from16 v28, v13

    move/from16 v29, v14

    goto :goto_1

    .line 100
    :cond_0
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v10, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/aspiro/wamp/model/MediaItem;

    invoke-virtual {v10}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v12

    move-object/from16 v28, v13

    iget-object v13, v1, Ldev/nino/squareglass/LinnPlayer;->token:Ljava/lang/String;

    invoke-static {v12, v13}, Ldev/nino/squareglass/OpenHome;->tidalUri(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 101
    new-instance v13, Ldev/nino/squareglass/LinnQueueTransaction$Track;

    move/from16 v29, v14

    iget-object v14, v1, Ldev/nino/squareglass/LinnPlayer;->occurrences:Ljava/util/List;

    invoke-interface {v14, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    invoke-virtual {v1, v10, v12}, Ldev/nino/squareglass/LinnPlayer;->metadata(Lcom/aspiro/wamp/model/MediaItem;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v13, v14, v12, v10}, Ldev/nino/squareglass/LinnQueueTransaction$Track;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v11, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v10, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_1
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v12, v27

    move-object/from16 v13, v28

    move/from16 v14, v29

    goto :goto_0

    :cond_1
    move-object/from16 v27, v12

    move-object/from16 v28, v13

    move/from16 v29, v14

    .line 103
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 104
    invoke-virtual {v1}, Ldev/nino/squareglass/LinnPlayer;->sessionPreferences()Landroid/content/SharedPreferences;

    move-result-object v9

    .line 105
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v10, v10, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    const-string v14, "sessionUuid"

    move-object/from16 v30, v11

    const-string v11, ""

    invoke-interface {v9, v14, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v10, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_4

    .line 106
    :try_start_0
    new-instance v10, Lorg/json/JSONArray;

    const-string v14, "occurrences"
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move/from16 v31, v5

    :try_start_1
    const-string v5, "[]"

    invoke-interface {v9, v14, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v10, v5}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move/from16 v5, v21

    .line 107
    :goto_2
    invoke-virtual {v10}, Lorg/json/JSONArray;->length()I

    move-result v14

    if-ge v5, v14, :cond_2

    invoke-virtual {v10, v5}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v14

    invoke-interface {v12, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    .line 108
    :cond_2
    const-string v5, "mapping"

    invoke-interface {v9, v5, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v9, ","

    invoke-virtual {v5, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    array-length v9, v5

    move/from16 v10, v21

    :goto_3
    if-ge v10, v9, :cond_5

    aget-object v11, v5, v10

    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_3

    const-string v14, ":"

    invoke-virtual {v11, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v11

    aget-object v11, v11, v21

    invoke-static {v11}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v32

    invoke-static/range {v32 .. v33}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v11

    invoke-interface {v13, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :cond_3
    add-int/lit8 v10, v10, 0x1

    goto :goto_3

    :catch_0
    move/from16 v31, v5

    .line 109
    :catch_1
    invoke-interface {v12}, Ljava/util/List;->clear()V

    invoke-interface {v13}, Ljava/util/List;->clear()V

    goto :goto_4

    :cond_4
    move/from16 v31, v5

    .line 110
    :cond_5
    :goto_4
    new-instance v9, Ldev/nino/squareglass/LinnQueueTransaction;

    move-object/from16 v5, v24

    move-object/from16 v10, v25

    move-object/from16 v34, v27

    move/from16 v14, v29

    move-object/from16 v11, v30

    move/from16 v25, v0

    move-object/from16 v24, v6

    move-object/from16 v6, v26

    move-object/from16 v0, v28

    invoke-direct/range {v9 .. v14}, Ldev/nino/squareglass/LinnQueueTransaction;-><init>(Ldev/nino/squareglass/OpenHome;Ljava/util/List;Ljava/util/List;Ljava/util/List;I)V

    move-object/from16 v41, v10

    move-object v10, v9

    move-object/from16 v9, v41

    .line 113
    :try_start_2
    new-instance v12, Ldev/nino/squareglass/LinnPlayer$4;

    invoke-direct {v12, v1}, Ldev/nino/squareglass/LinnPlayer$4;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    new-instance v13, Ldev/nino/squareglass/LinnPlayer$5;

    invoke-direct {v13, v1, v11}, Ldev/nino/squareglass/LinnPlayer$5;-><init>(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;)V

    invoke-virtual {v10, v12, v13}, Ldev/nino/squareglass/LinnQueueTransaction;->stage(Ljava/util/function/BooleanSupplier;Ljava/util/function/IntConsumer;)V

    .line 115
    iget-object v11, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    iget-object v12, v10, Ldev/nino/squareglass/LinnQueueTransaction;->remote:Ljava/util/List;

    invoke-interface {v11, v12}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 116
    new-instance v11, Ldev/nino/squareglass/LinnPlayer$6;

    invoke-direct {v11, v1}, Ldev/nino/squareglass/LinnPlayer$6;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-static {v11}, Ldev/nino/squareglass/LinnQueueTransaction;->requireCurrent(Ljava/util/function/BooleanSupplier;)V

    .line 117
    iget-object v11, v1, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    iget v12, v1, Ldev/nino/squareglass/LinnPlayer;->index:I

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v11, v12}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v11

    .line 118
    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v12, v12, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_12

    const/16 v26, 0x1

    if-eqz v12, :cond_6

    :try_start_3
    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v12, v12, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    iget-object v12, v12, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v12, v12, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    iget-object v13, v1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v13, v13, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_6

    .line 119
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_6

    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v12, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Long;

    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    move-result-wide v12

    invoke-static {v12, v13}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    if-eqz v12, :cond_6

    move/from16 v12, v26

    goto :goto_6

    :catch_2
    move-exception v0

    move-object/from16 v17, v5

    move-object v5, v10

    move-object/from16 v8, v20

    move/from16 v26, v21

    move-object/from16 v4, v34

    move-object v10, v0

    move-object/from16 v20, v7

    move/from16 v0, v26

    :goto_5
    move-object/from16 v7, v23

    goto/16 :goto_1d

    :cond_6
    move/from16 v12, v21

    :goto_6
    if-nez v12, :cond_8

    .line 121
    :try_start_4
    new-instance v13, Ljava/util/concurrent/FutureTask;

    new-instance v14, Ldev/nino/squareglass/LinnPlayer$7;

    invoke-direct {v14, v1}, Ldev/nino/squareglass/LinnPlayer$7;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-direct {v13, v14}, Ljava/util/concurrent/FutureTask;-><init>(Ljava/util/concurrent/Callable;)V

    .line 126
    iget-object v14, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v14, v14, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    invoke-virtual {v14, v13}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    sget-object v14, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    move-object/from16 v27, v10

    move/from16 v28, v11

    const-wide/16 v10, 0x5

    :try_start_5
    invoke-virtual {v13, v10, v11, v14}, Ljava/util/concurrent/FutureTask;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    .line 127
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    instance-of v11, v10, Ldev/nino/squareglass/LinnPlayer;

    if-eqz v11, :cond_9

    check-cast v10, Ldev/nino/squareglass/LinnPlayer;

    iget-object v10, v10, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v10, v10, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    iget-object v11, v1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v11, v11, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_9

    .line 128
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->sourcePlayer:Lcom/aspiro/wamp/player/k0;

    check-cast v10, Ldev/nino/squareglass/LinnPlayer;

    .line 129
    iget-object v11, v10, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v11, v11, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    move/from16 v13, v21

    new-array v14, v13, [Ljava/lang/String;

    invoke-virtual {v11, v15, v7, v14}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 130
    iget-object v11, v10, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v11, v11, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v13, v10, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v13, v13, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v13, v15, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v36

    const-string v38, "Paused"

    const-wide/16 v39, 0x1388

    move-object/from16 v35, v11

    invoke-virtual/range {v35 .. v40}, Ldev/nino/squareglass/OpenHome;->confirm(JLjava/lang/String;J)V

    .line 131
    iget-object v11, v10, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v11, v11, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v13, 0x0

    new-array v14, v13, [Ljava/lang/String;

    invoke-virtual {v11, v4, v4, v14}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v4

    invoke-interface {v4, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    mul-int/lit16 v4, v4, 0x3e8

    iput v4, v1, Ldev/nino/squareglass/LinnPlayer;->position:I

    .line 132
    iget-object v4, v10, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    iget-object v8, v10, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v8, v8, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v8, v15, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-interface {v4, v0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v0

    if-ltz v0, :cond_7

    .line 133
    iget-object v4, v10, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v4, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, v1, Ldev/nino/squareglass/LinnPlayer;->index:I

    .line 134
    :cond_7
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    iget v4, v1, Ldev/nino/squareglass/LinnPlayer;->index:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v11
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    goto :goto_9

    :catch_3
    move-exception v0

    goto :goto_7

    :catch_4
    move-exception v0

    move-object/from16 v27, v10

    :goto_7
    move-object v10, v0

    move-object/from16 v17, v5

    move-object/from16 v8, v20

    move-object/from16 v5, v27

    move-object/from16 v4, v34

    const/4 v0, 0x0

    :goto_8
    const/16 v26, 0x0

    move-object/from16 v20, v7

    goto/16 :goto_5

    :cond_8
    move-object/from16 v27, v10

    move/from16 v28, v11

    :cond_9
    move/from16 v11, v28

    .line 137
    :goto_9
    :try_start_6
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v4, Ldev/nino/squareglass/LinnProvider$Phase;->CONFIRMING:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v8, "Wiedergabe best\u00e4tigen\u2026"

    invoke-virtual {v0, v4, v8}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_11

    if-nez v12, :cond_a

    const/4 v13, 0x0

    .line 139
    :try_start_7
    new-array v0, v13, [Ljava/lang/String;

    invoke-virtual {v9, v15, v7, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_5

    goto :goto_a

    :catch_5
    move-exception v0

    move-object v10, v0

    move-object/from16 v17, v5

    move-object/from16 v8, v20

    move/from16 v0, v26

    move-object/from16 v5, v27

    move-object/from16 v4, v34

    goto :goto_8

    .line 140
    :cond_a
    :goto_a
    :try_start_8
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_10

    if-nez v0, :cond_b

    :try_start_9
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v6, v3, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_5

    .line 141
    :cond_b
    :try_start_a
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v4, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_10

    const-string v8, "1"

    if-ne v0, v4, :cond_c

    move-object/from16 v0, v19

    goto :goto_b

    :cond_c
    move-object v0, v8

    :goto_b
    move-object/from16 v4, v24

    :try_start_b
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_f

    if-nez v0, :cond_e

    :try_start_c
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v10, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    if-ne v0, v10, :cond_d

    move-object/from16 v0, v19

    goto :goto_c

    :cond_d
    move-object v0, v8

    :goto_c
    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_6

    move-object/from16 v10, v23

    :try_start_d
    invoke-virtual {v9, v15, v10, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    goto :goto_d

    :catch_6
    move-exception v0

    move-object/from16 v10, v23

    goto/16 :goto_17

    :cond_e
    move-object/from16 v10, v23

    .line 142
    :goto_d
    iget-boolean v0, v1, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_e

    if-eqz v0, :cond_f

    move-object v0, v8

    goto :goto_e

    :cond_f
    move-object/from16 v0, v19

    :goto_e
    move-object/from16 v13, v22

    :try_start_e
    invoke-virtual {v13, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_d

    if-nez v0, :cond_11

    :try_start_f
    iget-boolean v0, v1, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    if-eqz v0, :cond_10

    goto :goto_f

    :cond_10
    move-object/from16 v8, v19

    :goto_f
    filled-new-array {v8}, [Ljava/lang/String;

    move-result-object v0
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_7

    move-object/from16 v8, v20

    :try_start_10
    invoke-virtual {v9, v15, v8, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    goto :goto_10

    :catch_7
    move-exception v0

    move-object/from16 v8, v20

    goto/16 :goto_16

    :cond_11
    move-object/from16 v8, v20

    :goto_10
    if-nez v12, :cond_12

    .line 143
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v11

    iget v0, v1, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget-boolean v14, v1, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    invoke-virtual {v9, v11, v12, v0, v14}, Ldev/nino/squareglass/OpenHome;->selectTrack(JIZ)V

    move-object/from16 v24, v4

    move-object/from16 v17, v5

    move-object/from16 v20, v7

    move-object v7, v10

    move-object/from16 v22, v13

    move-object/from16 v5, v27

    move-object/from16 v4, v34

    goto/16 :goto_13

    .line 144
    :cond_12
    iget-boolean v0, v1, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_c

    const-string v12, "Paused"

    if-eqz v0, :cond_13

    move-object/from16 v0, v18

    goto :goto_11

    :cond_13
    move-object v0, v12

    :goto_11
    move-object/from16 v14, v34

    :try_start_11
    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_16

    .line 145
    iget-boolean v0, v1, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_b

    if-eqz v0, :cond_14

    move-object/from16 v0, v16

    goto :goto_12

    :cond_14
    move-object v0, v7

    :goto_12
    move-object/from16 v24, v4

    move-object/from16 v17, v5

    const/4 v4, 0x0

    :try_start_12
    new-array v5, v4, [Ljava/lang/String;

    invoke-virtual {v9, v15, v0, v5}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    iget-boolean v0, v1, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_8

    if-eqz v0, :cond_15

    move-object/from16 v12, v18

    :cond_15
    move-object/from16 v22, v13

    move-object/from16 v34, v14

    const-wide/16 v13, 0x1388

    move-object/from16 v20, v7

    move-object v7, v10

    move-wide v10, v4

    move-object/from16 v5, v27

    move-object/from16 v4, v34

    :try_start_13
    invoke-virtual/range {v9 .. v14}, Ldev/nino/squareglass/OpenHome;->confirm(JLjava/lang/String;J)V

    goto :goto_13

    :catch_8
    move-exception v0

    goto :goto_15

    :cond_16
    move-object/from16 v24, v4

    move-object/from16 v17, v5

    move-object/from16 v20, v7

    move-object v7, v10

    move-object/from16 v22, v13

    move-object v4, v14

    move-object/from16 v5, v27

    .line 147
    :goto_13
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$8;

    invoke-direct {v0, v1}, Ldev/nino/squareglass/LinnPlayer$8;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {v5, v0}, Ldev/nino/squareglass/LinnQueueTransaction;->commit(Ljava/util/function/BooleanSupplier;)V
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_13} :catch_a

    .line 148
    :try_start_14
    iget-boolean v0, v1, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    if-eqz v0, :cond_17

    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_14

    :cond_17
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    :goto_14
    iput-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    move/from16 v0, v25

    .line 149
    invoke-virtual {v1, v0}, Ldev/nino/squareglass/LinnPlayer;->createVolume(I)V

    .line 150
    sget-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "queue_reused="

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v11, v5, Ldev/nino/squareglass/LinnQueueTransaction;->retained:Ljava/util/Map;

    invoke-interface {v11}, Ljava/util/Map;->size()I

    move-result v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v11, " queue_inserted="

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v11, v5, Ldev/nino/squareglass/LinnQueueTransaction;->inserted:Ljava/util/List;

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-interface {v0, v10}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_14} :catch_9

    return-void

    :catch_9
    move-exception v0

    move-object v10, v0

    move/from16 v0, v26

    goto/16 :goto_1d

    :catch_a
    move-exception v0

    goto :goto_1a

    :catch_b
    move-exception v0

    move-object/from16 v24, v4

    move-object/from16 v17, v5

    :goto_15
    move-object/from16 v20, v7

    move-object v7, v10

    move-object/from16 v22, v13

    move-object v4, v14

    move-object/from16 v5, v27

    goto :goto_1a

    :catch_c
    move-exception v0

    :goto_16
    move-object/from16 v24, v4

    move-object/from16 v17, v5

    move-object/from16 v20, v7

    move-object v7, v10

    move-object/from16 v22, v13

    move-object/from16 v5, v27

    move-object/from16 v4, v34

    goto :goto_1a

    :catch_d
    move-exception v0

    move-object/from16 v24, v4

    move-object/from16 v17, v5

    move-object/from16 v22, v13

    goto :goto_18

    :catch_e
    move-exception v0

    :goto_17
    move-object/from16 v24, v4

    move-object/from16 v17, v5

    :goto_18
    move-object/from16 v8, v20

    move-object/from16 v5, v27

    move-object/from16 v4, v34

    move-object/from16 v20, v7

    move-object v7, v10

    goto :goto_1a

    :catch_f
    move-exception v0

    move-object/from16 v24, v4

    goto :goto_19

    :catch_10
    move-exception v0

    :goto_19
    move-object/from16 v17, v5

    move-object/from16 v8, v20

    move-object/from16 v5, v27

    move-object/from16 v4, v34

    move-object/from16 v20, v7

    move-object/from16 v7, v23

    :goto_1a
    move-object v10, v0

    move/from16 v0, v26

    goto :goto_1c

    :catch_11
    move-exception v0

    move-object/from16 v17, v5

    move-object/from16 v8, v20

    move-object/from16 v5, v27

    goto :goto_1b

    :catch_12
    move-exception v0

    move-object/from16 v17, v5

    move-object v5, v10

    move-object/from16 v8, v20

    :goto_1b
    move-object/from16 v4, v34

    move-object/from16 v20, v7

    move-object/from16 v7, v23

    move-object v10, v0

    const/4 v0, 0x0

    :goto_1c
    const/16 v26, 0x0

    :goto_1d
    if-nez v26, :cond_1e

    .line 153
    :try_start_15
    instance-of v11, v10, Ldev/nino/squareglass/OpenHome$Fault;

    if-eqz v11, :cond_19

    move-object v11, v10

    check-cast v11, Ldev/nino/squareglass/OpenHome$Fault;

    iget-object v11, v11, Ldev/nino/squareglass/OpenHome$Fault;->kind:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v12, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    if-eq v11, v12, :cond_18

    goto :goto_1e

    .line 154
    :cond_18
    new-instance v0, Ljava/io/IOException;

    const-string v2, "Recovery paused: device write outcome is uncertain"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 155
    :cond_19
    :goto_1e
    sget-object v11, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v12

    sget-object v14, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v25, 0x37e11d600L

    add-long v12, v12, v25

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 156
    invoke-virtual {v5}, Ldev/nino/squareglass/LinnQueueTransaction;->verifyRollback()V
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_15} :catch_13

    .line 157
    const-string v11, "Stop"

    if-eqz v0, :cond_1a

    const/4 v13, 0x0

    :try_start_16
    new-array v12, v13, [Ljava/lang/String;

    invoke-virtual {v9, v15, v11, v12}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 158
    :cond_1a
    invoke-virtual {v5}, Ldev/nino/squareglass/LinnQueueTransaction;->rollback()Ljava/util/Map;

    move-result-object v5

    if-eqz v0, :cond_1e

    .line 160
    filled-new-array/range {v24 .. v24}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v15, v7, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    filled-new-array/range {v22 .. v22}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v15, v8, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-object/from16 v7, v19

    .line 161
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1b

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-interface {v5, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    move/from16 v2, v31

    mul-int/lit16 v5, v2, 0x3e8

    move-object/from16 v2, v18

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v9, v7, v8, v5, v0}, Ldev/nino/squareglass/OpenHome;->selectTrack(JIZ)V

    goto :goto_1f

    :cond_1b
    move-object/from16 v2, v18

    .line 162
    :goto_1f
    filled-new-array/range {v17 .. v17}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v6, v3, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 163
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1d

    const-string v0, "Stopped"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1c

    move-object v2, v11

    goto :goto_20

    :cond_1c
    move-object/from16 v2, v20

    goto :goto_20

    :cond_1d
    move-object/from16 v2, v16

    :goto_20
    const/4 v13, 0x0

    new-array v0, v13, [Ljava/lang/String;

    invoke-virtual {v9, v15, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_16} :catch_13

    goto :goto_21

    :catch_13
    move-exception v0

    const/4 v13, 0x0

    .line 165
    iput-boolean v13, v1, Ldev/nino/squareglass/LinnPlayer;->rollbackConfirmed:Z

    invoke-virtual {v10, v0}, Ljava/lang/Exception;->addSuppressed(Ljava/lang/Throwable;)V

    sget-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "recovery=unconfirmed original="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    .line 166
    :cond_1e
    :goto_21
    throw v10
.end method
