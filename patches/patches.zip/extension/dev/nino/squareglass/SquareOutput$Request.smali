.class final Ldev/nino/squareglass/SquareOutput$Request;
.super Ljava/lang/Object;
.source "SquareOutput.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareOutput;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Request"
.end annotation


# instance fields
.field final revision:I

.field final session:Ldev/nino/squareglass/SquareOutput$Session;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/SquareOutput$Session;I)V
    .locals 0

    .line 79
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Request;->session:Ldev/nino/squareglass/SquareOutput$Session;

    iput p2, p0, Ldev/nino/squareglass/SquareOutput$Request;->revision:I

    return-void
.end method
