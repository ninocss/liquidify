.class final Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "LiquidViewMotion.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/LiquidViewMotion;->animate(Landroid/view/View;Ljava/lang/String;FFZLjava/util/function/Consumer;Ljava/lang/Runnable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $finished:Ljava/lang/Runnable;

.field final synthetic $from:F

.field final synthetic $settle:Z

.field final synthetic $target:F

.field final synthetic $update:Ljava/util/function/Consumer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/function/Consumer<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(FFZLjava/util/function/Consumer;Ljava/lang/Runnable;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FFZ",
            "Ljava/util/function/Consumer<",
            "Ljava/lang/Float;",
            ">;",
            "Ljava/lang/Runnable;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;",
            ">;)V"
        }
    .end annotation

    iput p1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$from:F

    iput p2, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$target:F

    iput-boolean p3, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$settle:Z

    iput-object p4, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$update:Ljava/util/function/Consumer;

    iput-object p5, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$finished:Ljava/lang/Runnable;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method

.method static final invokeSuspend$lambda$0(Ljava/util/function/Consumer;FLandroidx/compose/animation/core/Animatable;)Lkotlin/u;
    .locals 1

    .line 36
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p2}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    move-result p1

    :cond_0
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    invoke-interface {p0, p1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    .line 37
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;

    iget v1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$from:F

    iget v2, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$target:F

    iget-boolean v3, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$settle:Z

    iget-object v4, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$update:Ljava/util/function/Consumer;

    iget-object v5, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$finished:Ljava/lang/Runnable;

    move-object v6, p2

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;-><init>(FFZLjava/util/function/Consumer;Ljava/lang/Runnable;Lkotlin/coroutines/e;)V

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 33
    iget v1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->label:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->L$0:Ljava/lang/Object;

    check-cast v0, Landroidx/compose/animation/core/Animatable;

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_1

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 34
    iget p1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$from:F

    const/4 v1, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p1, v4, v1, v3}, Landroidx/compose/animation/core/AnimatableKt;->Animatable$default(FFILjava/lang/Object;)Landroidx/compose/animation/core/Animatable;

    move-result-object v5

    .line 35
    iget p1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$target:F

    invoke-static {p1}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v6

    iget-boolean p1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$settle:Z

    if-eqz p1, :cond_2

    sget-object p1, Ldev/nino/squareglass/material/LiquidMotion;->INSTANCE:Ldev/nino/squareglass/material/LiquidMotion;

    invoke-virtual {p1}, Ldev/nino/squareglass/material/LiquidMotion;->settle()Landroidx/compose/animation/core/SpringSpec;

    move-result-object p1

    goto :goto_0

    :cond_2
    sget-object p1, Ldev/nino/squareglass/material/LiquidMotion;->INSTANCE:Ldev/nino/squareglass/material/LiquidMotion;

    invoke-virtual {p1}, Ldev/nino/squareglass/material/LiquidMotion;->shape()Landroidx/compose/animation/core/SpringSpec;

    move-result-object p1

    :goto_0
    move-object v7, p1

    check-cast v7, Landroidx/compose/animation/core/AnimationSpec;

    iget-object p1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$update:Ljava/util/function/Consumer;

    iget v1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$target:F

    new-instance v9, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1$0;

    invoke-direct {v9, p1, v1}, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1$0;-><init>(Ljava/util/function/Consumer;F)V

    move-object v10, p0

    check-cast v10, Lkotlin/coroutines/e;

    invoke-static {v5}, Ldev/nino/squareglass/HostCompat;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->L$0:Ljava/lang/Object;

    iput v2, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->label:I

    const/4 v8, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-static/range {v5 .. v12}, Landroidx/compose/animation/core/Animatable;->animateTo$default(Landroidx/compose/animation/core/Animatable;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationSpec;Ljava/lang/Object;Lam0/l;Lkotlin/coroutines/e;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_3

    return-object v0

    .line 38
    :cond_3
    :goto_1
    iget-object p1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$update:Ljava/util/function/Consumer;

    iget v0, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$target:F

    invoke-static {v0}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v0

    invoke-interface {p1, v0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    .line 39
    iget-object p0, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->$finished:Ljava/lang/Runnable;

    if-eqz p0, :cond_4

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    .line 40
    :cond_4
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
