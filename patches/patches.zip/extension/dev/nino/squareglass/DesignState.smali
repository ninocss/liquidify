.class public final Ldev/nino/squareglass/DesignState;
.super Ljava/lang/Object;
.source "DesignState.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDesignState.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DesignState.kt\ndev/nino/squareglass/DesignState\n+ 2 SnapshotIntState.kt\nandroidx/compose/runtime/SnapshotIntStateKt__SnapshotIntStateKt\n*L\n1#1,29:1\n78#2:30\n111#2,2:31\n*S KotlinDebug\n*F\n+ 1 DesignState.kt\ndev/nino/squareglass/DesignState\n*L\n11#1:30\n11#1:31,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0008\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0008\u0010\r\u001a\u00020\u000eH\u0007J\u0006\u0010\u000f\u001a\u00020\u0010R+\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u00058F@BX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u000b\u0010\u000c\u001a\u0004\u0008\u0007\u0010\u0008\"\u0004\u0008\t\u0010\n\u00a8\u0006\u0011"
    }
    d2 = {
        "Ldev/nino/squareglass/DesignState;",
        "",
        "<init>",
        "()V",
        "<set-?>",
        "",
        "revision",
        "getRevision",
        "()I",
        "setRevision",
        "(I)V",
        "revision$delegate",
        "Landroidx/compose/runtime/MutableIntState;",
        "changed",
        "",
        "config",
        "Ldev/nino/squareglass/material/GlassEffectConfig;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/DesignState;

.field private static final revision$delegate:Landroidx/compose/runtime/MutableIntState;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/DesignState;

    invoke-direct {v0}, Ldev/nino/squareglass/DesignState;-><init>()V

    sput-object v0, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    const/4 v0, 0x0

    .line 11
    invoke-static {v0}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/DesignState;->revision$delegate:Landroidx/compose/runtime/MutableIntState;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final changed()V
    .locals 2

    .line 13
    sget-object v0, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v0}, Ldev/nino/squareglass/DesignState;->getRevision()I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    invoke-direct {v0, v1}, Ldev/nino/squareglass/DesignState;->setRevision(I)V

    return-void
.end method

.method private final setRevision(I)V
    .locals 0

    .line 11
    sget-object p0, Ldev/nino/squareglass/DesignState;->revision$delegate:Landroidx/compose/runtime/MutableIntState;

    .line 31
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method


# virtual methods
.method public final config()Ldev/nino/squareglass/material/GlassEffectConfig;
    .locals 40

    .line 15
    invoke-virtual/range {p0 .. p0}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 17
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, v1, :cond_0

    move v4, v2

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    move v4, v0

    .line 18
    :goto_0
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->blur()F

    move-result v6

    .line 19
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v7

    .line 20
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v8

    .line 21
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquareSettings;->readableOpacity(Z)F

    move-result v22

    .line 22
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    if-ne v0, v2, :cond_1

    sget-object v0, Ldev/nino/squareglass/material/GlassStyle;->BLUR:Ldev/nino/squareglass/material/GlassStyle;

    goto :goto_1

    :cond_1
    sget-object v0, Ldev/nino/squareglass/material/GlassStyle;->LIQUID:Ldev/nino/squareglass/material/GlassStyle;

    :goto_1
    move-object/from16 v18, v0

    .line 23
    const-string v0, "player"

    invoke-static {v0}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v25

    .line 24
    const-string v0, "mini"

    invoke-static {v0}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v26

    .line 25
    const-string v0, "nav"

    invoke-static {v0}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v27

    .line 16
    new-instance v3, Ldev/nino/squareglass/material/GlassEffectConfig;

    const v38, 0xff16fe2

    const/16 v39, 0x0

    const/4 v5, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const-wide/16 v19, 0x0

    const/16 v21, 0x0

    const-wide/16 v23, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    invoke-direct/range {v3 .. v39}, Ldev/nino/squareglass/material/GlassEffectConfig;-><init>(ZFFFFZZJJFFFLdev/nino/squareglass/material/GlassStyle;JFFJZZZZFFFFJFJILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v3
.end method

.method public final getRevision()I
    .locals 0

    .line 11
    sget-object p0, Ldev/nino/squareglass/DesignState;->revision$delegate:Landroidx/compose/runtime/MutableIntState;

    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 30
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method
