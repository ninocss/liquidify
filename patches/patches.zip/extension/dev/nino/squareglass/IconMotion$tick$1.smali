.class public final Ldev/nino/squareglass/IconMotion$tick$1;
.super Ljava/lang/Object;
.source "IconMotion.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/IconMotion;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016\u00a8\u0006\u0004"
    }
    d2 = {
        "dev/nino/squareglass/IconMotion$tick$1",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 38
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    .line 40
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 41
    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getPolicy$p()Ldev/nino/squareglass/MotionPolicy;

    move-result-object v2

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    invoke-static {}, Ldev/nino/squareglass/SquareMenus;->hasOpenMenu()Z

    move-result v3

    if-nez v3, :cond_0

    move v3, v5

    goto :goto_0

    :cond_0
    move v3, v4

    :goto_0
    invoke-virtual {v2, v0, v1, v3}, Ldev/nino/squareglass/MotionPolicy;->ready(JZ)Z

    move-result v2

    if-eqz v2, :cond_5

    move v2, v4

    .line 43
    :cond_1
    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getEntries$p()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_5

    .line 44
    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getCursor$p()I

    move-result v3

    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getEntries$p()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-lt v3, v6, :cond_2

    sget-object v3, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    invoke-static {v4}, Ldev/nino/squareglass/IconMotion;->access$setCursor$p(I)V

    .line 45
    :cond_2
    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getEntries$p()Ljava/util/ArrayList;

    move-result-object v3

    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getCursor$p()I

    move-result v6

    sget-object v7, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    add-int/lit8 v7, v6, 0x1

    invoke-static {v7}, Ldev/nino/squareglass/IconMotion;->access$setCursor$p(I)V

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const-string v6, "get(...)"

    invoke-static {v3, v6}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Ldev/nino/squareglass/IconMotion$Entry;

    add-int/lit8 v2, v2, 0x1

    .line 46
    invoke-virtual {v3}, Ldev/nino/squareglass/IconMotion$Entry;->getAvailable()Lam0/a;

    move-result-object v6

    invoke-interface {v6}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-eqz v6, :cond_1

    .line 47
    invoke-virtual {v3}, Ldev/nino/squareglass/IconMotion$Entry;->getFire()Lam0/l;

    move-result-object v2

    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getIdleStyle$p()I

    move-result v3

    sget-object v6, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    add-int/lit8 v6, v3, 0x1

    invoke-static {v6}, Ldev/nino/squareglass/IconMotion;->access$setIdleStyle$p(I)V

    rem-int/lit8 v3, v3, 0x3

    if-eq v3, v5, :cond_4

    const/4 v6, 0x2

    if-eq v3, v6, :cond_3

    move v3, v4

    goto :goto_1

    :cond_3
    const/4 v3, 0x5

    goto :goto_1

    :cond_4
    const/4 v3, 0x4

    :goto_1
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    sget v2, Ldev/nino/squareglass/ProbeDiagnostics;->idleAnimations:I

    add-int/2addr v2, v5

    sput v2, Ldev/nino/squareglass/ProbeDiagnostics;->idleAnimations:I

    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getPolicy$p()Ldev/nino/squareglass/MotionPolicy;

    move-result-object v2

    invoke-virtual {v2, v0, v1}, Ldev/nino/squareglass/MotionPolicy;->fired(J)V

    .line 52
    :cond_5
    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getPolicy$p()Ldev/nino/squareglass/MotionPolicy;

    move-result-object v2

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v3

    if-eqz v3, :cond_6

    invoke-static {}, Ldev/nino/squareglass/SquareMenus;->hasOpenMenu()Z

    move-result v3

    if-nez v3, :cond_6

    move v4, v5

    :cond_6
    invoke-virtual {v2, v0, v1, v4}, Ldev/nino/squareglass/MotionPolicy;->ready(JZ)Z

    move-result v0

    if-nez v0, :cond_7

    const-wide/16 v0, 0xbb8

    goto :goto_2

    :cond_7
    const-wide/16 v0, 0x2ee0

    .line 53
    :goto_2
    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getEntries$p()Ljava/util/ArrayList;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_8

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v2

    if-eqz v2, :cond_8

    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getHandler$p()Landroid/os/Handler;

    move-result-object v2

    check-cast p0, Ljava/lang/Runnable;

    invoke-virtual {v2, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_8
    return-void
.end method
