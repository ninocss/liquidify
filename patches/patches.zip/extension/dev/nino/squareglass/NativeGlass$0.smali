.class public final synthetic Ldev/nino/squareglass/NativeGlass$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Lam0/a;

.field public final synthetic f$1:Landroidx/compose/ui/Modifier;

.field public final synthetic f$2:Z

.field public final synthetic f$3:Landroidx/compose/material3/IconButtonColors;

.field public final synthetic f$4:Landroidx/compose/foundation/interaction/MutableInteractionSource;

.field public final synthetic f$5:Lam0/p;

.field public final synthetic f$6:I

.field public final synthetic f$7:I


# direct methods
.method public synthetic constructor <init>(Lam0/a;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lam0/p;II)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeGlass$0;->f$0:Lam0/a;

    iput-object p2, p0, Ldev/nino/squareglass/NativeGlass$0;->f$1:Landroidx/compose/ui/Modifier;

    iput-boolean p3, p0, Ldev/nino/squareglass/NativeGlass$0;->f$2:Z

    iput-object p4, p0, Ldev/nino/squareglass/NativeGlass$0;->f$3:Landroidx/compose/material3/IconButtonColors;

    iput-object p5, p0, Ldev/nino/squareglass/NativeGlass$0;->f$4:Landroidx/compose/foundation/interaction/MutableInteractionSource;

    iput-object p6, p0, Ldev/nino/squareglass/NativeGlass$0;->f$5:Lam0/p;

    iput p7, p0, Ldev/nino/squareglass/NativeGlass$0;->f$6:I

    iput p8, p0, Ldev/nino/squareglass/NativeGlass$0;->f$7:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeGlass$0;->f$0:Lam0/a;

    iget-object v1, p0, Ldev/nino/squareglass/NativeGlass$0;->f$1:Landroidx/compose/ui/Modifier;

    iget-boolean v2, p0, Ldev/nino/squareglass/NativeGlass$0;->f$2:Z

    iget-object v3, p0, Ldev/nino/squareglass/NativeGlass$0;->f$3:Landroidx/compose/material3/IconButtonColors;

    iget-object v4, p0, Ldev/nino/squareglass/NativeGlass$0;->f$4:Landroidx/compose/foundation/interaction/MutableInteractionSource;

    iget-object v5, p0, Ldev/nino/squareglass/NativeGlass$0;->f$5:Lam0/p;

    iget v6, p0, Ldev/nino/squareglass/NativeGlass$0;->f$6:I

    iget v7, p0, Ldev/nino/squareglass/NativeGlass$0;->f$7:I

    move-object v8, p1

    check-cast v8, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v9

    invoke-static/range {v0 .. v9}, Ldev/nino/squareglass/NativeGlass;->playerIconButton$lambda$2(Lam0/a;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lam0/p;IILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
