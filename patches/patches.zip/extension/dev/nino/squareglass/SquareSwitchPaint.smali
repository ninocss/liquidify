.class public final Ldev/nino/squareglass/SquareSwitchPaint;
.super Ljava/lang/Object;
.source "SquareSwitchPaint.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static thumbDisabled()J
    .locals 2

    .line 10
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    if-eqz v0, :cond_0

    const v0, -0x38342c

    goto :goto_0

    :cond_0
    const/4 v0, -0x1

    :goto_0
    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    return-wide v0
.end method

.method public static thumbEnabled()J
    .locals 2

    .line 9
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    if-eqz v0, :cond_0

    const v0, -0xf2f1ef

    goto :goto_0

    :cond_0
    const/4 v0, -0x1

    :goto_0
    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    return-wide v0
.end method

.method public static trackDisabled()J
    .locals 2

    .line 13
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    if-eqz v0, :cond_0

    const v0, -0xbab6af

    goto :goto_0

    :cond_0
    const v0, -0x4b473c

    :goto_0
    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    return-wide v0
.end method

.method public static trackOff()J
    .locals 2

    .line 11
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    if-eqz v0, :cond_0

    const v0, -0x8c8679

    goto :goto_0

    :cond_0
    const v0, -0x7d776a

    :goto_0
    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    return-wide v0
.end method

.method public static trackOn()J
    .locals 2

    .line 12
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    return-wide v0
.end method
