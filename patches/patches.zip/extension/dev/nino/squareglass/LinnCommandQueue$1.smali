.class public final synthetic Ldev/nino/squareglass/LinnCommandQueue$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ljava/util/concurrent/atomic/AtomicLong;

.field public final synthetic f$1:J

.field public final synthetic f$2:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Ljava/util/concurrent/atomic/AtomicLong;JLjava/lang/Runnable;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnCommandQueue$1;->f$0:Ljava/util/concurrent/atomic/AtomicLong;

    iput-wide p2, p0, Ldev/nino/squareglass/LinnCommandQueue$1;->f$1:J

    iput-object p4, p0, Ldev/nino/squareglass/LinnCommandQueue$1;->f$2:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnCommandQueue$1;->f$0:Ljava/util/concurrent/atomic/AtomicLong;

    iget-wide v1, p0, Ldev/nino/squareglass/LinnCommandQueue$1;->f$1:J

    iget-object p0, p0, Ldev/nino/squareglass/LinnCommandQueue$1;->f$2:Ljava/lang/Runnable;

    invoke-static {v0, v1, v2, p0}, Ldev/nino/squareglass/LinnCommandQueue;->lambda$execute$1(Ljava/util/concurrent/atomic/AtomicLong;JLjava/lang/Runnable;)V

    return-void
.end method
