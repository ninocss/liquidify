.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/PlayerArtwork$Frame;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$6;->f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$6;->f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

    check-cast p1, Landroidx/compose/ui/layout/LayoutCoordinates;

    invoke-static {p0, p1}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$uEDCyZTJFNL4yC4RhHkNthCFHF8(Ldev/nino/squareglass/PlayerArtwork$Frame;Landroidx/compose/ui/layout/LayoutCoordinates;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
