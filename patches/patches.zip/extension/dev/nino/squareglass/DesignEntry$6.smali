.class public final synthetic Ldev/nino/squareglass/DesignEntry$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$6;->f$0:Ljava/lang/String;

    iput-boolean p2, p0, Ldev/nino/squareglass/DesignEntry$6;->f$1:Z

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$6;->f$0:Ljava/lang/String;

    iget-boolean p0, p0, Ldev/nino/squareglass/DesignEntry$6;->f$1:Z

    invoke-static {v0, p0}, Ldev/nino/squareglass/DesignEntry;->$r8$lambda$EEAno2NmQDfQsjX_JHbpIa4dJfY(Ljava/lang/String;Z)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
