.class public final synthetic Ldev/nino/squareglass/DesignEntry$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Lam0/l;

.field public final synthetic f$1:I

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Lam0/l;ILandroidx/compose/runtime/MutableState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$6;->f$0:Lam0/l;

    iput p2, p0, Ldev/nino/squareglass/DesignEntry$6;->f$1:I

    iput-object p3, p0, Ldev/nino/squareglass/DesignEntry$6;->f$2:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$6;->f$0:Lam0/l;

    iget v1, p0, Ldev/nino/squareglass/DesignEntry$6;->f$1:I

    iget-object p0, p0, Ldev/nino/squareglass/DesignEntry$6;->f$2:Landroidx/compose/runtime/MutableState;

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/DesignEntry;->$r8$lambda$3i0U6EuX6qMeG1Hx2c1DXQQJtNY(Lam0/l;ILandroidx/compose/runtime/MutableState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
