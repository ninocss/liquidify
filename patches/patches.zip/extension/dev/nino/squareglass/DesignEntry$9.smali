.class public final synthetic Ldev/nino/squareglass/DesignEntry$9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/DesignEntry;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Ljava/lang/String;

.field public final synthetic f$4:Lam0/a;

.field public final synthetic f$5:I

.field public final synthetic f$6:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lam0/a;II)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$9;->f$0:Ldev/nino/squareglass/DesignEntry;

    iput-object p2, p0, Ldev/nino/squareglass/DesignEntry$9;->f$1:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/DesignEntry$9;->f$2:Ljava/lang/String;

    iput-object p4, p0, Ldev/nino/squareglass/DesignEntry$9;->f$3:Ljava/lang/String;

    iput-object p5, p0, Ldev/nino/squareglass/DesignEntry$9;->f$4:Lam0/a;

    iput p6, p0, Ldev/nino/squareglass/DesignEntry$9;->f$5:I

    iput p7, p0, Ldev/nino/squareglass/DesignEntry$9;->f$6:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$9;->f$0:Ldev/nino/squareglass/DesignEntry;

    iget-object v1, p0, Ldev/nino/squareglass/DesignEntry$9;->f$1:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/DesignEntry$9;->f$2:Ljava/lang/String;

    iget-object v3, p0, Ldev/nino/squareglass/DesignEntry$9;->f$3:Ljava/lang/String;

    iget-object v4, p0, Ldev/nino/squareglass/DesignEntry$9;->f$4:Lam0/a;

    iget v5, p0, Ldev/nino/squareglass/DesignEntry$9;->f$5:I

    iget v6, p0, Ldev/nino/squareglass/DesignEntry$9;->f$6:I

    move-object v7, p1

    check-cast v7, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-static/range {v0 .. v8}, Ldev/nino/squareglass/DesignEntry;->ActionRow$lambda$1(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lam0/a;IILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
