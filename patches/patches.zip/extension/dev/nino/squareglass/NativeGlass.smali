.class public final Ldev/nino/squareglass/NativeGlass;
.super Ljava/lang/Object;
.source "NativeGlass.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeGlass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeGlass.kt\ndev/nino/squareglass/NativeGlass\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 4 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 5 Dp.kt\nandroidx/compose/ui/unit/DpKt\n*L\n1#1,92:1\n85#2:93\n117#2,2:94\n75#3:96\n1128#4,6:97\n1128#4,6:103\n1128#4,6:109\n1128#4,6:115\n1128#4,6:121\n113#5:127\n113#5:128\n113#5:129\n123#5:130\n123#5:131\n113#5:132\n*S KotlinDebug\n*F\n+ 1 NativeGlass.kt\ndev/nino/squareglass/NativeGlass\n*L\n30#1:93\n30#1:94,2\n36#1:96\n55#1:97,6\n56#1:103,6\n61#1:109,6\n62#1:115,6\n63#1:121,6\n71#1:127\n83#1:128\n86#1:129\n57#1:130\n59#1:131\n62#1:132\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u000b\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0000\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013H\u0007J\u001d\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u0018H\u0007\u00a2\u0006\u0002\u0010\u0019J\u0015\u0010\u001a\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0015H\u0007\u00a2\u0006\u0002\u0010\u001bJ\u0015\u0010\u001c\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0015H\u0007\u00a2\u0006\u0002\u0010\u001bJ\u0015\u0010\u001d\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0015H\u0007\u00a2\u0006\u0002\u0010\u001bJ\u0008\u0010\u001e\u001a\u00020\u001fH\u0007R+\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u00058B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u000b\u0010\u000c\u001a\u0004\u0008\u0007\u0010\u0008\"\u0004\u0008\t\u0010\nR\u0011\u0010\r\u001a\u00020\u00058G\u00a2\u0006\u0006\u001a\u0004\u0008\u000e\u0010\u000f\u00a8\u0006 "
    }
    d2 = {
        "Ldev/nino/squareglass/NativeGlass;",
        "",
        "<init>",
        "()V",
        "<set-?>",
        "",
        "hostDark",
        "getHostDark",
        "()Z",
        "setHostDark",
        "(Z)V",
        "hostDark$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "dark",
        "getDark",
        "(Landroidx/compose/runtime/Composer;I)Z",
        "observeHostBackground",
        "",
        "packedColor",
        "",
        "surface",
        "Landroidx/compose/ui/Modifier;",
        "original",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "miniSurface",
        "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "playerButton",
        "secondaryBar",
        "iconTint",
        "Landroidx/compose/ui/graphics/ColorFilter;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/NativeGlass;

.field private static final hostDark$delegate:Landroidx/compose/runtime/MutableState;


# direct methods
.method public static synthetic $r8$lambda$4Lvp3erVyIc87gzAt3ruWp0w64o(JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/NativeGlass;->surface$lambda$4$0(JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$BgPhUfGizNVTVQn4bCDM3gzEtNQ(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/NativeGlass;->surface$lambda$1$0(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$MetCFISltODYrQDmI2aVoc8enms()Ldev/nino/squareglass/backdrop/shadow/Shadow;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/NativeGlass;->surface$lambda$3$0()Ldev/nino/squareglass/backdrop/shadow/Shadow;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$YmHWjpTvqaRhkQW05tqjk_c9W38()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/NativeGlass;->surface$lambda$2$0()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$ZCIpaH-rNi_qW6xlxuy_zsjbUlY(Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/NativeGlass;->surface$lambda$0$0(Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/graphics/Shape;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Ldev/nino/squareglass/NativeGlass;

    invoke-direct {v0}, Ldev/nino/squareglass/NativeGlass;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v0, 0x1

    .line 30
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/NativeGlass;->hostDark$delegate:Landroidx/compose/runtime/MutableState;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final getHostDark()Z
    .locals 0

    .line 30
    sget-object p0, Ldev/nino/squareglass/NativeGlass;->hostDark$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 93
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public static final iconTint()Landroidx/compose/ui/graphics/ColorFilter;
    .locals 6

    .line 90
    sget-object v0, Landroidx/compose/ui/graphics/ColorFilter;->Companion:Landroidx/compose/ui/graphics/ColorFilter$Companion;

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x0

    invoke-static/range {v0 .. v5}, Landroidx/compose/ui/graphics/ColorFilter$Companion;->tint-xETnrds$default(Landroidx/compose/ui/graphics/ColorFilter$Companion;JIILjava/lang/Object;)Landroidx/compose/ui/graphics/ColorFilter;

    move-result-object v0

    return-object v0
.end method

.method public static final miniSurface(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 14

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(miniSurface)N(original)71@3026L90,71@3002L115:NativeGlass.kt#vqphja"

    const v1, -0x5d0a0de0

    .line 69
    invoke-static {p1, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.NativeGlass.miniSurface (NativeGlass.kt:68)"

    move/from16 v3, p2

    invoke-static {v1, v3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 70
    :cond_0
    sget-object v0, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v0}, Ldev/nino/squareglass/DesignState;->getRevision()I

    const/high16 v0, 0x41000000    # 8.0f

    .line 127
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    const/4 v12, 0x7

    const/4 v13, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v7, p0

    .line 71
    invoke-static/range {v7 .. v13}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 72
    sget-object v9, Ldev/nino/squareglass/MiniProgress;->INSTANCE:Ldev/nino/squareglass/MiniProgress;

    sget-object v0, Ldev/nino/squareglass/AccessoryGlass;->INSTANCE:Ldev/nino/squareglass/AccessoryGlass;

    sget-object v2, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-virtual {v2}, Ldev/nino/squareglass/NativeBackdrop;->getAccessory()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v2

    const-string v3, "mini"

    invoke-static {v3}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v3

    const v7, 0x30c00

    const/16 v8, 0x10

    const-string v4, "mini"

    const/4 v5, 0x0

    move-object v6, p1

    invoke-virtual/range {v0 .. v8}, Ldev/nino/squareglass/AccessoryGlass;->surface(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;ZLjava/lang/String;Lam0/l;Landroidx/compose/runtime/Composer;II)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v1, 0x30

    invoke-virtual {v9, v0, p1, v1}, Ldev/nino/squareglass/MiniProgress;->decorate(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 69
    :cond_1
    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object v0
.end method

.method public static final observeHostBackground(J)V
    .locals 1

    .line 43
    sput-wide p0, Ldev/nino/squareglass/ProbeDiagnostics;->hostBackground:J

    .line 44
    sget-object v0, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide p0

    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/ColorKt;->luminance-8_81llA(J)F

    move-result p0

    const/high16 p1, 0x3f000000    # 0.5f

    cmpg-float p0, p0, p1

    if-gez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    invoke-direct {v0, p0}, Ldev/nino/squareglass/NativeGlass;->setHostDark(Z)V

    return-void
.end method

.method public static final playerButton(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 3

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(playerButton)N(original)76@3221L17:NativeGlass.kt#vqphja"

    const v1, 0x3c5f4547

    .line 77
    invoke-static {p1, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.NativeGlass.playerButton (NativeGlass.kt:76)"

    invoke-static {v1, p2, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    sget-object v0, Ldev/nino/squareglass/GlassMotion;->INSTANCE:Ldev/nino/squareglass/GlassMotion;

    and-int/lit8 p2, p2, 0xe

    or-int/lit8 p2, p2, 0x30

    invoke-virtual {v0, p0, p1, p2}, Ldev/nino/squareglass/GlassMotion;->control(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1
    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method public static final secondaryBar(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 7

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(secondaryBar)N(original):NativeGlass.kt#vqphja"

    const v1, -0x34409dc5    # -2.5085046E7f

    .line 81
    invoke-static {p1, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.NativeGlass.secondaryBar (NativeGlass.kt:80)"

    invoke-static {v1, p2, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 82
    :cond_0
    sget-object v0, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v0}, Ldev/nino/squareglass/DesignState;->getRevision()I

    const/high16 v0, 0x41e00000    # 28.0f

    .line 128
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 83
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    .line 84
    const-string v1, "player"

    invoke-static {v1}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    const v1, -0x26902a0d

    invoke-interface {p1, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "83@3454L24"

    invoke-static {p1, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    check-cast v0, Landroidx/compose/ui/graphics/Shape;

    and-int/lit8 v1, p2, 0xe

    shl-int/lit8 p2, p2, 0x3

    and-int/lit16 p2, p2, 0x380

    or-int/2addr p2, v1

    invoke-static {p0, v0, p1, p2}, Ldev/nino/squareglass/NativeGlass;->surface(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_0

    :cond_1
    const v1, -0x26902297

    .line 85
    invoke-interface {p1, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "84@3552L4"

    invoke-static {p1, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    check-cast v0, Landroidx/compose/ui/graphics/Shape;

    invoke-static {p0, v0}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object p0, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    shr-int/lit8 p2, p2, 0x3

    and-int/lit8 p2, p2, 0xe

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result p0

    invoke-static {p0}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result p0

    invoke-static {p0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_0
    const/high16 p2, 0x41400000    # 12.0f

    .line 129
    invoke-static {p2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result p2

    const/high16 v0, 0x40c00000    # 6.0f

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 86
    invoke-static {p0, p2, v0}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p2

    if-eqz p2, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 81
    :cond_2
    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method private final setHostDark(Z)V
    .locals 0

    .line 30
    sget-object p0, Ldev/nino/squareglass/NativeGlass;->hostDark$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 94
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public static final surface(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 23

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "original"

    move-object/from16 v4, p0

    invoke-static {v4, v3}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "shape"

    invoke-static {v0, v3}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const v3, -0x30f1bc82

    .line 49
    invoke-interface {v1, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "C(surface)N(original,shape)50@2021L4,50@2107L4,54@2335L9,55@2368L248,60@2642L21,61@2686L26,62@2742L49:NativeGlass.kt#vqphja"

    invoke-static {v1, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, -0x1

    const-string v6, "dev.nino.squareglass.NativeGlass.surface (NativeGlass.kt:48)"

    invoke-static {v3, v2, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 50
    :cond_0
    sget-object v3, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v3}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 51
    sget-object v3, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    shr-int/lit8 v5, v2, 0x6

    and-int/lit8 v5, v5, 0xe

    invoke-virtual {v3, v1, v5}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v6

    if-eqz v6, :cond_1

    const-wide v6, 0xff33343aL

    invoke-static {v6, v7}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v6

    goto :goto_0

    :cond_1
    sget-object v6, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v6

    :goto_0
    move-wide v8, v6

    invoke-virtual {v3, v1, v5}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v6

    invoke-static {v6}, Ldev/nino/squareglass/SquareSettings;->readableOpacity(Z)F

    move-result v10

    const/16 v14, 0xe

    const/4 v15, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static/range {v8 .. v15}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v6

    .line 52
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v8

    const/4 v9, 0x2

    if-ne v8, v9, :cond_3

    const v2, 0x4ce3e5fa    # 1.1948437E8f

    invoke-interface {v1, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "51@2223L4"

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static/range {p0 .. p1}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    invoke-virtual {v3, v1, v5}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v7

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v9, 0x0

    invoke-static/range {v6 .. v11}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 65
    :cond_2
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return-object v0

    :cond_3
    const v3, 0x4ce4fbc4    # 1.2005328E8f

    .line 52
    invoke-interface {v1, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 54
    sget-object v3, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-virtual {v3}, Ldev/nino/squareglass/NativeBackdrop;->getActive()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v5

    const v3, 0x448b9127

    .line 55
    const-string v8, "CC(remember):NativeGlass.kt#9igjgp"

    invoke-static {v1, v3, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v3, v2, 0x70

    xor-int/lit8 v3, v3, 0x30

    const/16 v9, 0x20

    if-le v3, v9, :cond_4

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    :cond_4
    and-int/lit8 v2, v2, 0x30

    if-ne v2, v9, :cond_6

    :cond_5
    const/4 v2, 0x1

    goto :goto_1

    :cond_6
    const/4 v2, 0x0

    .line 97
    :goto_1
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    if-nez v2, :cond_7

    .line 98
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v3, v2, :cond_8

    .line 55
    :cond_7
    new-instance v3, Ldev/nino/squareglass/NativeGlass$0;

    invoke-direct {v3, v0}, Ldev/nino/squareglass/NativeGlass$0;-><init>(Landroidx/compose/ui/graphics/Shape;)V

    .line 100
    invoke-interface {v1, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 55
    :cond_8
    check-cast v3, Lam0/a;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v0, 0x448b9636

    .line 56
    invoke-static {v1, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 103
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .line 104
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v0, v2, :cond_9

    .line 105
    new-instance v0, Ldev/nino/squareglass/NativeGlass$1;

    invoke-direct {v0}, Ldev/nino/squareglass/NativeGlass$1;-><init>()V

    .line 106
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 56
    :cond_9
    check-cast v0, Lam0/l;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v2, 0x448bb793

    .line 61
    invoke-static {v1, v2, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 109
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .line 110
    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v2, v9, :cond_a

    .line 111
    new-instance v2, Ldev/nino/squareglass/NativeGlass$2;

    invoke-direct {v2}, Ldev/nino/squareglass/NativeGlass$2;-><init>()V

    .line 112
    invoke-interface {v1, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 61
    :cond_a
    check-cast v2, Lam0/a;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v9, 0x448bbd18

    .line 62
    invoke-static {v1, v9, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 115
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .line 116
    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v9, v10, :cond_b

    .line 117
    new-instance v9, Ldev/nino/squareglass/NativeGlass$3;

    invoke-direct {v9}, Ldev/nino/squareglass/NativeGlass$3;-><init>()V

    .line 118
    invoke-interface {v1, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 62
    :cond_b
    check-cast v9, Lam0/a;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v10, 0x448bc42f

    .line 63
    invoke-static {v1, v10, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v1, v6, v7}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v8

    .line 121
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    if-nez v8, :cond_c

    .line 122
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v10, v8, :cond_d

    .line 63
    :cond_c
    new-instance v10, Ldev/nino/squareglass/NativeGlass$4;

    invoke-direct {v10, v6, v7}, Ldev/nino/squareglass/NativeGlass$4;-><init>(J)V

    .line 124
    invoke-interface {v1, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 63
    :cond_d
    move-object v15, v10

    check-cast v15, Lam0/l;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v21, 0xfbe0

    const/16 v22, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    move-object v7, v0

    move-object v8, v2

    move-object v6, v3

    .line 53
    invoke-static/range {v4 .. v22}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->drawBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/a;Lam0/a;Lam0/a;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 65
    :cond_e
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return-object v0
.end method

.method private static final surface$lambda$0$0(Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    return-object p0
.end method

.method private static final surface$lambda$1$0(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 8

    const-string v0, "$this$drawBackdrop"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    invoke-static {p0}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->vibrancy(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)V

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->blur()F

    move-result v0

    .line 130
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 57
    invoke-interface {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0, v3, v1, v2}, Ldev/nino/squareglass/backdrop/effects/BlurKt;->blur-3YTHUZs$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FIILjava/lang/Object;)V

    .line 58
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    if-nez v0, :cond_0

    const/high16 v0, 0x41c00000    # 24.0f

    .line 59
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v1

    mul-float/2addr v0, v1

    .line 131
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 59
    invoke-interface {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v2

    const/high16 v0, 0x42000000    # 32.0f

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v1

    mul-float/2addr v0, v1

    .line 131
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 59
    invoke-interface {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v3

    const/16 v6, 0xc

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v1, p0

    invoke-static/range {v1 .. v7}, Ldev/nino/squareglass/backdrop/effects/LensKt;->lens$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFZZILjava/lang/Object;)V

    .line 60
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final surface$lambda$2$0()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    .line 61
    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Companion:Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;->getDefault()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v0

    return-object v0
.end method

.method private static final surface$lambda$3$0()Ldev/nino/squareglass/backdrop/shadow/Shadow;
    .locals 10

    .line 62
    new-instance v0, Ldev/nino/squareglass/backdrop/shadow/Shadow;

    const/high16 v1, 0x41400000    # 12.0f

    .line 132
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    const/16 v8, 0x1e

    const/4 v9, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    .line 62
    invoke-direct/range {v0 .. v9}, Ldev/nino/squareglass/backdrop/shadow/Shadow;-><init>(FJJFIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method private static final surface$lambda$4$0(JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 14

    const-string v0, "$this$drawBackdrop"

    move-object/from16 v1, p2

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    sget v0, Ldev/nino/squareglass/ProbeDiagnostics;->glassDraws:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Ldev/nino/squareglass/ProbeDiagnostics;->glassDraws:I

    const/16 v12, 0x7e

    const/4 v13, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    move-wide v2, p0

    invoke-static/range {v1 .. v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final getDark(Landroidx/compose/runtime/Composer;I)Z
    .locals 3

    const v0, -0x2ee17f9b

    .line 32
    invoke-interface {p1, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "C(<get-dark>)35@1520L7:NativeGlass.kt#vqphja"

    invoke-static {p1, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, -0x1

    const-string v2, "dev.nino.squareglass.NativeGlass.<get-dark> (NativeGlass.kt:31)"

    invoke-static {v0, p2, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 33
    :cond_0
    sget-object p2, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {p2}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 34
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result p2

    if-nez p2, :cond_2

    invoke-direct {p0}, Ldev/nino/squareglass/NativeGlass;->getHostDark()Z

    move-result p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 39
    :cond_1
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return p0

    .line 35
    :cond_2
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeMode()I

    move-result p0

    .line 36
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalConfiguration()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object p2

    check-cast p2, Landroidx/compose/runtime/CompositionLocal;

    const v0, 0x789c5f52

    const-string v1, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    .line 96
    invoke-static {p1, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p1, p2}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object p2

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    check-cast p2, Landroid/content/res/Configuration;

    iget p2, p2, Landroid/content/res/Configuration;->uiMode:I

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p0, :cond_3

    const/4 p2, 0x2

    if-ne p0, p2, :cond_4

    goto :goto_0

    :cond_3
    and-int/lit8 p0, p2, 0x30

    const/16 p2, 0x20

    if-ne p0, p2, :cond_4

    goto :goto_0

    :cond_4
    move v0, v1

    .line 37
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 39
    :cond_5
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return v0
.end method
