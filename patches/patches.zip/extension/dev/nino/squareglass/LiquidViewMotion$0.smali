.class public final synthetic Ldev/nino/squareglass/LiquidViewMotion$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LiquidViewMotion$Binding;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Lkotlinx/coroutines/Job;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LiquidViewMotion$Binding;Ljava/lang/String;Lkotlinx/coroutines/Job;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LiquidViewMotion$0;->f$0:Ldev/nino/squareglass/LiquidViewMotion$Binding;

    iput-object p2, p0, Ldev/nino/squareglass/LiquidViewMotion$0;->f$1:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/LiquidViewMotion$0;->f$2:Lkotlinx/coroutines/Job;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LiquidViewMotion$0;->f$0:Ldev/nino/squareglass/LiquidViewMotion$Binding;

    iget-object v1, p0, Ldev/nino/squareglass/LiquidViewMotion$0;->f$1:Ljava/lang/String;

    iget-object p0, p0, Ldev/nino/squareglass/LiquidViewMotion$0;->f$2:Lkotlinx/coroutines/Job;

    check-cast p1, Ljava/lang/Throwable;

    invoke-static {v0, v1, p0, p1}, Ldev/nino/squareglass/LiquidViewMotion;->animate$lambda$1(Ldev/nino/squareglass/LiquidViewMotion$Binding;Ljava/lang/String;Lkotlinx/coroutines/Job;Ljava/lang/Throwable;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
