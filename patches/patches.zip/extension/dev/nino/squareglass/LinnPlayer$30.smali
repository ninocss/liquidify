.class public final synthetic Ldev/nino/squareglass/LinnPlayer$30;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:Ldev/nino/squareglass/LinnEvent;

.field public final synthetic f$2:J


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnEvent;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$30;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer$30;->f$1:Ldev/nino/squareglass/LinnEvent;

    iput-wide p3, p0, Ldev/nino/squareglass/LinnPlayer$30;->f$2:J

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$30;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer$30;->f$1:Ldev/nino/squareglass/LinnEvent;

    iget-wide v2, p0, Ldev/nino/squareglass/LinnPlayer$30;->f$2:J

    invoke-static {v0, v1, v2, v3}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$YmGLJU2FBpibDY4g0pcldIPRAUQ(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnEvent;J)V

    return-void
.end method
