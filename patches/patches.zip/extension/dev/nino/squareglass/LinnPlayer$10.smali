.class public final synthetic Ldev/nino/squareglass/LinnPlayer$10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:[Ldev/nino/squareglass/OpenHome;

.field public final synthetic f$2:Ldev/nino/squareglass/LinnDiscovery;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;[Ldev/nino/squareglass/OpenHome;Ldev/nino/squareglass/LinnDiscovery;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$10;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer$10;->f$1:[Ldev/nino/squareglass/OpenHome;

    iput-object p3, p0, Ldev/nino/squareglass/LinnPlayer$10;->f$2:Ldev/nino/squareglass/LinnDiscovery;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$10;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer$10;->f$1:[Ldev/nino/squareglass/OpenHome;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer$10;->f$2:Ldev/nino/squareglass/LinnDiscovery;

    check-cast p1, Ldev/nino/squareglass/LinnDiscovery$Result;

    invoke-static {v0, v1, p0, p1}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$kxZO4ZIvpPhH70mB3urDZxVEgYU(Ldev/nino/squareglass/LinnPlayer;[Ldev/nino/squareglass/OpenHome;Ldev/nino/squareglass/LinnDiscovery;Ldev/nino/squareglass/LinnDiscovery$Result;)V

    return-void
.end method
