.class public final synthetic Ldev/nino/squareglass/NativeTabs$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:Ljava/util/List;

.field public final synthetic f$2:I

.field public final synthetic f$3:Lam0/l;

.field public final synthetic f$4:J

.field public final synthetic f$5:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$6:J


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Ljava/util/List;ILam0/l;JLandroidx/compose/runtime/MutableState;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeTabs$6;->f$0:Ljava/util/List;

    iput-object p2, p0, Ldev/nino/squareglass/NativeTabs$6;->f$1:Ljava/util/List;

    iput p3, p0, Ldev/nino/squareglass/NativeTabs$6;->f$2:I

    iput-object p4, p0, Ldev/nino/squareglass/NativeTabs$6;->f$3:Lam0/l;

    iput-wide p5, p0, Ldev/nino/squareglass/NativeTabs$6;->f$4:J

    iput-object p7, p0, Ldev/nino/squareglass/NativeTabs$6;->f$5:Landroidx/compose/runtime/MutableState;

    iput-wide p8, p0, Ldev/nino/squareglass/NativeTabs$6;->f$6:J

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeTabs$6;->f$0:Ljava/util/List;

    iget-object v1, p0, Ldev/nino/squareglass/NativeTabs$6;->f$1:Ljava/util/List;

    iget v2, p0, Ldev/nino/squareglass/NativeTabs$6;->f$2:I

    iget-object v3, p0, Ldev/nino/squareglass/NativeTabs$6;->f$3:Lam0/l;

    iget-wide v4, p0, Ldev/nino/squareglass/NativeTabs$6;->f$4:J

    iget-object v6, p0, Ldev/nino/squareglass/NativeTabs$6;->f$5:Landroidx/compose/runtime/MutableState;

    iget-wide v7, p0, Ldev/nino/squareglass/NativeTabs$6;->f$6:J

    move-object v9, p1

    check-cast v9, Landroidx/compose/foundation/layout/RowScope;

    move-object v10, p2

    check-cast v10, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v11

    invoke-static/range {v0 .. v11}, Ldev/nino/squareglass/NativeTabs;->$r8$lambda$o3Ws-GrrZfvg33KGmzMMyqrRvrY(Ljava/util/List;Ljava/util/List;ILam0/l;JLandroidx/compose/runtime/MutableState;JLandroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
