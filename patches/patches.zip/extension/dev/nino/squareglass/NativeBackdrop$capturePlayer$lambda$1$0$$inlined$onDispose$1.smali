.class public final Ldev/nino/squareglass/NativeBackdrop$capturePlayer$lambda$1$0$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source "Effects.kt"

# interfaces
.implements Landroidx/compose/runtime/DisposableEffectResult;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/NativeBackdrop;->capturePlayer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEffects.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Effects.kt\nandroidx/compose/runtime/DisposableEffectScope$onDispose$1\n+ 2 NativeBackdrop.kt\ndev/nino/squareglass/NativeBackdrop\n*L\n1#1,603:1\n67#2,6:604\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016\u00a8\u0006\u0004\u00b8\u0006\u0000"
    }
    d2 = {
        "androidx/compose/runtime/DisposableEffectScope$onDispose$1",
        "Landroidx/compose/runtime/DisposableEffectResult;",
        "dispose",
        "",
        "runtime"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $backdrop$inlined:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V
    .locals 0

    iput-object p1, p0, Ldev/nino/squareglass/NativeBackdrop$capturePlayer$lambda$1$0$$inlined$onDispose$1;->$backdrop$inlined:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    .line 66
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public dispose()V
    .locals 1

    .line 604
    invoke-static {}, Ldev/nino/squareglass/NativeBackdrop;->access$getPlayerSource$p()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/NativeBackdrop$capturePlayer$lambda$1$0$$inlined$onDispose$1;->$backdrop$inlined:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    if-ne v0, p0, :cond_1

    const/4 p0, 0x0

    .line 605
    invoke-static {p0}, Ldev/nino/squareglass/NativeBackdrop;->access$setPlayerSource$p(Ldev/nino/squareglass/backdrop/Backdrop;)V

    .line 606
    sget-object p0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    sget-object v0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-static {v0}, Ldev/nino/squareglass/NativeBackdrop;->access$getNativeSource(Ldev/nino/squareglass/NativeBackdrop;)Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object v0

    if-eqz v0, :cond_0

    check-cast v0, Ldev/nino/squareglass/backdrop/Backdrop;

    goto :goto_0

    :cond_0
    invoke-static {}, Ldev/nino/squareglass/backdrop/backdrops/EmptyBackdropKt;->emptyBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v0

    :goto_0
    invoke-static {p0, v0}, Ldev/nino/squareglass/NativeBackdrop;->access$setActive(Ldev/nino/squareglass/NativeBackdrop;Ldev/nino/squareglass/backdrop/Backdrop;)V

    .line 607
    sget-object p0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-static {p0}, Ldev/nino/squareglass/NativeBackdrop;->access$getNativeSource(Ldev/nino/squareglass/NativeBackdrop;)Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->requestCapture()V

    :cond_1
    return-void
.end method
