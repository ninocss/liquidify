.class final enum Ldev/nino/squareglass/LinnProvider$Phase;
.super Ljava/lang/Enum;
.source "LinnProvider.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/LinnProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "Phase"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Ldev/nino/squareglass/LinnProvider$Phase;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ldev/nino/squareglass/LinnProvider$Phase;

.field public static final enum ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

.field public static final enum CHECKING:Ldev/nino/squareglass/LinnProvider$Phase;

.field public static final enum CONFIRMING:Ldev/nino/squareglass/LinnProvider$Phase;

.field public static final enum DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

.field public static final enum ERROR:Ldev/nino/squareglass/LinnProvider$Phase;

.field public static final enum READY:Ldev/nino/squareglass/LinnProvider$Phase;

.field public static final enum RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

.field public static final enum TRANSFERRING:Ldev/nino/squareglass/LinnProvider$Phase;


# direct methods
.method private static synthetic $values()[Ldev/nino/squareglass/LinnProvider$Phase;
    .locals 8

    .line 32
    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v1, Ldev/nino/squareglass/LinnProvider$Phase;->CHECKING:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v2, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v3, Ldev/nino/squareglass/LinnProvider$Phase;->TRANSFERRING:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v4, Ldev/nino/squareglass/LinnProvider$Phase;->CONFIRMING:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v5, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v6, Ldev/nino/squareglass/LinnProvider$Phase;->RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v7, Ldev/nino/squareglass/LinnProvider$Phase;->ERROR:Ldev/nino/squareglass/LinnProvider$Phase;

    filled-new-array/range {v0 .. v7}, [Ldev/nino/squareglass/LinnProvider$Phase;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 32
    new-instance v0, Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, "DISCONNECTED"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnProvider$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, "CHECKING"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnProvider$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->CHECKING:Ldev/nino/squareglass/LinnProvider$Phase;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, "READY"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnProvider$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, "TRANSFERRING"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnProvider$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->TRANSFERRING:Ldev/nino/squareglass/LinnProvider$Phase;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, "CONFIRMING"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnProvider$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->CONFIRMING:Ldev/nino/squareglass/LinnProvider$Phase;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, "ACTIVE"

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnProvider$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, "RECONNECTING"

    const/4 v2, 0x6

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnProvider$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, "ERROR"

    const/4 v2, 0x7

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnProvider$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->ERROR:Ldev/nino/squareglass/LinnProvider$Phase;

    invoke-static {}, Ldev/nino/squareglass/LinnProvider$Phase;->$values()[Ldev/nino/squareglass/LinnProvider$Phase;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->$VALUES:[Ldev/nino/squareglass/LinnProvider$Phase;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 32
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Ldev/nino/squareglass/LinnProvider$Phase;
    .locals 1
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 32
    const-class v0, Ldev/nino/squareglass/LinnProvider$Phase;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/LinnProvider$Phase;

    return-object p0
.end method

.method public static values()[Ldev/nino/squareglass/LinnProvider$Phase;
    .locals 1

    .line 32
    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->$VALUES:[Ldev/nino/squareglass/LinnProvider$Phase;

    invoke-virtual {v0}, [Ldev/nino/squareglass/LinnProvider$Phase;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ldev/nino/squareglass/LinnProvider$Phase;

    return-object v0
.end method
