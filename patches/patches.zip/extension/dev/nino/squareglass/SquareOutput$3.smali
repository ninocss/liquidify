.class public final synthetic Ldev/nino/squareglass/SquareOutput$3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$3;->f$0:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$3;->f$0:Ljava/lang/String;

    invoke-static {p0}, Ldev/nino/squareglass/SquareOutput;->lambda$linnFailure$0(Ljava/lang/String;)V

    return-void
.end method
