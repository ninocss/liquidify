.class public final synthetic Ldev/nino/squareglass/DesignEntry$15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/DesignEntry;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/DesignEntry;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$15;->f$0:Ldev/nino/squareglass/DesignEntry;

    iput p2, p0, Ldev/nino/squareglass/DesignEntry$15;->f$1:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$15;->f$0:Ldev/nino/squareglass/DesignEntry;

    iget p0, p0, Ldev/nino/squareglass/DesignEntry$15;->f$1:I

    check-cast p1, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {v0, p0, p1, p2}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$4(Ldev/nino/squareglass/DesignEntry;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
