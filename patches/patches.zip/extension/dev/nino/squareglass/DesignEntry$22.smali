.class public final synthetic Ldev/nino/squareglass/DesignEntry$22;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:I

.field public final synthetic f$2:I

.field public final synthetic f$3:Landroidx/compose/runtime/MutableFloatState;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$22;->f$0:Ljava/lang/String;

    iput p2, p0, Ldev/nino/squareglass/DesignEntry$22;->f$1:I

    iput p3, p0, Ldev/nino/squareglass/DesignEntry$22;->f$2:I

    iput-object p4, p0, Ldev/nino/squareglass/DesignEntry$22;->f$3:Landroidx/compose/runtime/MutableFloatState;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$22;->f$0:Ljava/lang/String;

    iget v1, p0, Ldev/nino/squareglass/DesignEntry$22;->f$1:I

    iget v2, p0, Ldev/nino/squareglass/DesignEntry$22;->f$2:I

    iget-object p0, p0, Ldev/nino/squareglass/DesignEntry$22;->f$3:Landroidx/compose/runtime/MutableFloatState;

    invoke-static {v0, v1, v2, p0}, Ldev/nino/squareglass/DesignEntry;->$r8$lambda$DPXCW4dr_6UggIztTPRhrHxcAJ8(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
