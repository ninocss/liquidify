.class public final Ldev/nino/squareglass/SquareDetails;
.super Ljava/lang/Object;
.source "SquareDetails.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/SquareDetails$Hero;,
        Ldev/nino/squareglass/SquareDetails$CoverFade;,
        Ldev/nino/squareglass/SquareDetails$Binding;
    }
.end annotation


# static fields
.field private static final ARTWORK:I = 0x7f0b00b8

.field private static final FIRST:I = 0x7f0b056e

.field private static final SECOND:I = 0x7f0b056f

.field private static final SUBTITLE:I = 0x7f0b069b

.field private static final TITLE:I = 0x7f0b06e3

.field private static final appliedTints:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final bindings:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ljava/lang/ref/WeakReference<",
            "Ldev/nino/squareglass/SquareDetails$Binding;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final bitmapSeedCache:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/graphics/Bitmap;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final buttonColors:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final buttonPaints:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation
.end field

.field private static final heroes:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ljava/lang/ref/WeakReference<",
            "Ldev/nino/squareglass/SquareDetails$Hero;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final seedCache:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/graphics/drawable/Drawable;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final trackPaints:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static bridge synthetic -$$Nest$smactionRail(Landroid/view/View;I[I)V
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/SquareDetails;->actionRail(Landroid/view/View;I[I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smbutton(Landroid/view/View;Z)V
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareDetails;->button(Landroid/view/View;Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smdp(Landroid/view/View;I)I
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$smforeground(Landroid/view/View;I)V
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smlabels(Landroid/view/View;)V
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails;->labels(Landroid/view/View;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smplaylistPaint(Landroid/view/View;)V
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails;->playlistPaint(Landroid/view/View;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 32
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareDetails;->bindings:Ljava/util/WeakHashMap;

    .line 33
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareDetails;->heroes:Ljava/util/WeakHashMap;

    .line 34
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareDetails;->buttonPaints:Ljava/util/WeakHashMap;

    .line 35
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareDetails;->buttonColors:Ljava/util/WeakHashMap;

    .line 36
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareDetails;->trackPaints:Ljava/util/WeakHashMap;

    .line 37
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareDetails;->seedCache:Ljava/util/WeakHashMap;

    .line 38
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareDetails;->bitmapSeedCache:Ljava/util/WeakHashMap;

    .line 39
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareDetails;->appliedTints:Ljava/util/WeakHashMap;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static varargs actionRail(Landroid/view/View;I[I)V
    .locals 10

    .line 210
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_d

    .line 211
    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 212
    array-length v1, p2

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/16 v4, 0xc

    if-ge v3, v1, :cond_3

    aget v5, p2, v3

    .line 213
    invoke-virtual {p0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    if-eqz v5, :cond_2

    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    move-result v6

    const/16 v7, 0x8

    if-ne v6, v7, :cond_1

    goto :goto_1

    .line 214
    :cond_1
    invoke-static {v5}, Ldev/nino/squareglass/SquareDetails;->unfilledAction(Landroid/view/View;)V

    .line 215
    invoke-static {v5, p1, v4}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    .line 216
    invoke-virtual {v5}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    instance-of v4, v4, Landroidx/constraintlayout/widget/ConstraintLayout;

    if-eqz v4, :cond_2

    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    instance-of v4, v4, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v4, :cond_2

    .line 217
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 219
    :cond_3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p0

    const/4 p1, 0x2

    if-ge p0, p1, :cond_4

    goto/16 :goto_d

    .line 220
    :cond_4
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    .line 221
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_5
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/view/View;

    invoke-virtual {p2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p2

    if-eq p2, p0, :cond_5

    goto/16 :goto_d

    :cond_6
    move p0, v2

    .line 222
    :goto_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge p0, p1, :cond_12

    .line 223
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p2

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 225
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    iget v1, v1, Landroid/content/res/Configuration;->fontScale:F

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    const/high16 v5, 0x42800000    # 64.0f

    mul-float/2addr v1, v5

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-static {p1, v1}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v1

    const/16 v5, 0x10

    const/4 v6, 0x6

    if-nez p0, :cond_7

    move v7, v5

    goto :goto_3

    :cond_7
    move v7, v6

    .line 226
    :goto_3
    invoke-static {p1, v7}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v7

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v8

    add-int/lit8 v8, v8, -0x1

    if-ne p0, v8, :cond_8

    goto :goto_4

    :cond_8
    move v5, v6

    :goto_4
    invoke-static {p1, v5}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v5

    .line 227
    iget v6, p2, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v8, -0x1

    if-nez v6, :cond_d

    iget v6, p2, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-ne v6, v1, :cond_d

    iget v6, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->horizontalWeight:F

    cmpl-float v6, v6, v3

    if-nez v6, :cond_d

    iget v6, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToStart:I

    if-nez p0, :cond_9

    move v9, v2

    goto :goto_5

    :cond_9
    move v9, v8

    :goto_5
    if-ne v6, v9, :cond_d

    iget v6, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToEnd:I

    if-nez p0, :cond_a

    move v9, v8

    goto :goto_6

    :cond_a
    add-int/lit8 v9, p0, -0x1

    .line 228
    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/view/View;

    invoke-virtual {v9}, Landroid/view/View;->getId()I

    move-result v9

    :goto_6
    if-ne v6, v9, :cond_d

    iget v6, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToEnd:I

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v9

    add-int/lit8 v9, v9, -0x1

    if-ne p0, v9, :cond_b

    move v9, v2

    goto :goto_7

    :cond_b
    move v9, v8

    :goto_7
    if-ne v6, v9, :cond_d

    iget v6, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToStart:I

    .line 229
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v9

    add-int/lit8 v9, v9, -0x1

    if-ne p0, v9, :cond_c

    move v9, v8

    goto :goto_8

    :cond_c
    add-int/lit8 v9, p0, 0x1

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/view/View;

    invoke-virtual {v9}, Landroid/view/View;->getId()I

    move-result v9

    :goto_8
    if-ne v6, v9, :cond_d

    iget v6, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    if-ne v6, v8, :cond_d

    iget v6, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    if-ne v6, v8, :cond_d

    .line 231
    invoke-virtual {p2}, Landroid/view/ViewGroup$MarginLayoutParams;->getMarginStart()I

    move-result v6

    if-ne v6, v7, :cond_d

    invoke-virtual {p2}, Landroid/view/ViewGroup$MarginLayoutParams;->getMarginEnd()I

    move-result v6

    if-ne v6, v5, :cond_d

    goto :goto_c

    .line 232
    :cond_d
    iput v2, p2, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v1, p2, Landroid/view/ViewGroup$LayoutParams;->height:I

    iput v3, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iput v2, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->horizontalChainStyle:I

    .line 233
    iput v8, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->leftToLeft:I

    iput v8, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->leftToRight:I

    iput v8, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->rightToLeft:I

    iput v8, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->rightToRight:I

    .line 234
    iput v8, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    iput v8, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    if-nez p0, :cond_e

    move v1, v2

    goto :goto_9

    :cond_e
    move v1, v8

    .line 235
    :goto_9
    iput v1, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToStart:I

    if-nez p0, :cond_f

    move v1, v8

    goto :goto_a

    :cond_f
    add-int/lit8 v1, p0, -0x1

    .line 236
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v1

    :goto_a
    iput v1, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToEnd:I

    .line 237
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    if-ne p0, v1, :cond_10

    move v1, v8

    goto :goto_b

    :cond_10
    add-int/lit8 v1, p0, 0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v1

    :goto_b
    iput v1, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToStart:I

    .line 238
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    if-ne p0, v1, :cond_11

    move v8, v2

    :cond_11
    iput v8, p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToEnd:I

    .line 239
    invoke-virtual {p2, v7}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {p2, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 240
    iput v7, p2, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iput v5, p2, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 241
    invoke-static {p1, v4}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v1

    iput v1, p2, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 242
    invoke-virtual {p1, p2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :goto_c
    add-int/lit8 p0, p0, 0x1

    goto/16 :goto_2

    :cond_12
    :goto_d
    return-void
.end method

.method public static albumHeader(Landroid/view/View;)V
    .locals 11

    .line 334
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 335
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    const v1, 0x7f0b00a9

    .line 336
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const v3, 0x7f0b056f

    const v4, 0x7f0b056e

    const/16 v5, 0x8

    const/4 v6, 0x0

    if-eqz v2, :cond_5

    .line 337
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    instance-of v7, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v7, :cond_5

    .line 338
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    check-cast v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 339
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    invoke-virtual {v8}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v8

    iget v8, v8, Landroid/util/DisplayMetrics;->widthPixels:I

    iput v8, v7, Landroid/view/ViewGroup$LayoutParams;->width:I

    iget v8, v7, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v8, v7, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 340
    iput v6, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    const/4 v8, -0x1

    iput v8, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    iput v8, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    iput v8, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    .line 341
    iput v6, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToStart:I

    iput v6, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToEnd:I

    const/4 v9, 0x0

    iput v9, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->verticalBias:F

    .line 342
    iput v6, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iput v6, v7, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 343
    invoke-virtual {v7, v6, v6, v6, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v7, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v7, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 344
    invoke-virtual {v2, v6, v6, v6, v6}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v2, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v2, v9}, Landroid/view/View;->setElevation(F)V

    invoke-virtual {v2, v6}, Landroid/view/View;->setClipToOutline(Z)V

    const v7, 0x7f0b008b

    .line 345
    invoke-virtual {v2, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    if-eqz v7, :cond_2

    .line 347
    invoke-static {v7}, Ldev/nino/squareglass/NativeArtworkBridge;->square(Landroid/view/View;)V

    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    iput v8, v9, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v8, v9, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 348
    instance-of v10, v9, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v10, :cond_1

    move-object v10, v9

    check-cast v10, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-virtual {v10, v6, v6, v6, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v10, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v10, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 349
    :cond_1
    invoke-virtual {v7, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 351
    :cond_2
    invoke-virtual {v2}, Landroid/view/View;->getForeground()Landroid/graphics/drawable/Drawable;

    move-result-object v7

    instance-of v7, v7, Ldev/nino/squareglass/SquareDetails$CoverFade;

    if-nez v7, :cond_3

    .line 352
    new-instance v7, Ldev/nino/squareglass/SquareDetails$CoverFade;

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v9

    invoke-direct {v7, v9}, Ldev/nino/squareglass/SquareDetails$CoverFade;-><init>(I)V

    invoke-virtual {v2, v7}, Landroid/view/View;->setForeground(Landroid/graphics/drawable/Drawable;)V

    :cond_3
    const v7, 0x7f0b06e3

    .line 353
    invoke-virtual {p0, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    invoke-static {v9, v1, v5}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    const v1, 0x7f0b00b6

    .line 354
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    invoke-static {v9, v7, v5}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    const v7, 0x7f0b05c1

    .line 355
    invoke-virtual {p0, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    invoke-static {v9, v1, v5}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    .line 356
    invoke-virtual {p0, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const/16 v9, 0x14

    invoke-static {v1, v7, v9}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    .line 357
    invoke-virtual {p0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_4

    .line 358
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    instance-of v7, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v7, :cond_4

    .line 359
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    check-cast v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 360
    iput v4, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v8, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    iput v8, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    iput v8, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    iput v6, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 361
    invoke-virtual {v1, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_4
    const v1, 0x7f0b02c6

    const v7, 0x7f0b0370

    const v8, 0x7f0b0274

    const v9, 0x7f0b064c

    .line 363
    filled-new-array {v1, v7, v8, v9}, [I

    move-result-object v1

    invoke-static {p0, v4, v1}, Ldev/nino/squareglass/SquareDetails;->actionRail(Landroid/view/View;I[I)V

    .line 364
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v7, -0x2

    iput v7, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 367
    :cond_5
    instance-of v1, v2, Landroid/widget/ImageView;

    if-eqz v1, :cond_6

    check-cast v2, Landroid/widget/ImageView;

    goto :goto_1

    .line 368
    :cond_6
    instance-of v1, v2, Landroid/view/ViewGroup;

    if-eqz v1, :cond_9

    const v1, 0x7f0b00b8

    .line 369
    invoke-virtual {v2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    .line 370
    instance-of v7, v1, Landroid/widget/ImageView;

    if-eqz v7, :cond_7

    move-object v2, v1

    check-cast v2, Landroid/widget/ImageView;

    goto :goto_1

    :cond_7
    move v1, v6

    .line 372
    :goto_0
    move-object v7, v2

    check-cast v7, Landroid/view/ViewGroup;

    invoke-virtual {v7}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v8

    if-ge v1, v8, :cond_9

    .line 373
    invoke-virtual {v7, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    .line 374
    instance-of v8, v7, Landroid/widget/ImageView;

    if-eqz v8, :cond_8

    move-object v2, v7

    check-cast v2, Landroid/widget/ImageView;

    goto :goto_1

    :cond_8
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_9
    const/4 v2, 0x0

    :goto_1
    const v1, 0x7f0b00b9

    .line 378
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    if-eqz v1, :cond_a

    .line 379
    invoke-virtual {v1, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_a
    if-eqz v2, :cond_b

    .line 380
    invoke-static {p0, v2}, Ldev/nino/squareglass/SquareDetails;->hero(Landroid/view/View;Landroid/widget/ImageView;)V

    goto :goto_2

    :cond_b
    if-eqz v1, :cond_c

    .line 381
    invoke-static {p0, v1}, Ldev/nino/squareglass/SquareDetails;->hero(Landroid/view/View;Landroid/widget/ImageView;)V

    :cond_c
    :goto_2
    const/4 v1, 0x7

    .line 382
    new-array v2, v1, [I

    fill-array-data v2, :array_0

    :goto_3
    if-ge v6, v1, :cond_d

    aget v5, v2, v6

    .line 383
    invoke-virtual {p0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v7

    invoke-static {v5, v7}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    .line 384
    :cond_d
    invoke-static {p0, v4, v3}, Ldev/nino/squareglass/SquareDetails;->controls(Landroid/view/View;II)V

    return-void

    nop

    :array_0
    .array-data 4
        0x7f0b06e3
        0x7f0b00b6
        0x7f0b05c1
        0x7f0b02c6
        0x7f0b0370
        0x7f0b0274
        0x7f0b064c
    .end array-data
.end method

.method private static below(Landroid/view/View;II)V
    .locals 4

    if-eqz p0, :cond_2

    .line 430
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-nez v0, :cond_0

    goto :goto_0

    .line 431
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 432
    iget v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_1

    iget v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    if-ne v1, p1, :cond_1

    iget v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    if-ne v1, v2, :cond_1

    iget v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    if-ne v1, v2, :cond_1

    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 433
    invoke-static {p0, p2}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v3

    if-ne v1, v3, :cond_1

    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    if-nez v1, :cond_1

    goto :goto_0

    .line 434
    :cond_1
    iput v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput p1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    iput v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    iput v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    .line 435
    invoke-static {p0, p2}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result p1

    iput p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 p1, 0x0

    .line 436
    iput p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_2
    :goto_0
    return-void
.end method

.method private static button(Landroid/view/View;Z)V
    .locals 8

    if-nez p0, :cond_0

    return-void

    .line 160
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    .line 161
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    .line 162
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v2

    const/4 v3, 0x0

    .line 163
    invoke-virtual {p0, v3}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 164
    sget-object v4, Ldev/nino/squareglass/SquareDetails;->buttonPaints:Ljava/util/WeakHashMap;

    invoke-virtual {v4, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v6

    if-ne v5, v6, :cond_1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    sget-object v6, Ldev/nino/squareglass/SquareDetails;->buttonColors:Ljava/util/WeakHashMap;

    invoke-virtual {v6, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    .line 165
    invoke-static {p0, v1}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    return-void

    .line 168
    :cond_1
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 169
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v6

    const/16 v7, 0x18

    invoke-static {p0, v6, v7}, Ldev/nino/squareglass/PageMaterial;->background(Landroid/view/View;II)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    .line 170
    invoke-virtual {v5, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 171
    invoke-static {p0, v7}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v5, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/high16 v7, 0x41c00000    # 24.0f

    .line 172
    invoke-static {p0, v7, p1}, Ldev/nino/squareglass/PageGlass;->install(Landroid/view/View;FZ)V

    .line 173
    invoke-static {p0}, Ldev/nino/squareglass/PageGlass;->hasSurface(Landroid/view/View;)Z

    move-result v7

    if-eqz v7, :cond_2

    const/4 v7, 0x0

    invoke-virtual {v5, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    :cond_2
    if-eqz v0, :cond_4

    if-eqz p1, :cond_3

    const p1, 0x33ffffff

    goto :goto_0

    :cond_3
    const p1, 0x22ffffff

    goto :goto_0

    :cond_4
    if-eqz p1, :cond_5

    const/high16 p1, 0x22000000

    goto :goto_0

    :cond_5
    const/high16 p1, 0x18000000

    .line 175
    :goto_0
    invoke-static {p0}, Ldev/nino/squareglass/PageGlass;->hasSurface(Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 176
    new-instance v6, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-direct {v6, p1, v5, v3}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 178
    :cond_6
    invoke-virtual {p0, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 179
    invoke-virtual {v4, p0, v6}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 180
    sget-object p1, Ldev/nino/squareglass/SquareDetails;->buttonColors:Ljava/util/WeakHashMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p1, p0, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 181
    invoke-static {p0, v1}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    return-void
.end method

.method public static chrome(Landroid/view/View;)V
    .locals 1

    .line 281
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-static {p0, v0}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    return-void
.end method

.method public static collectionTrack(Landroid/view/View;)V
    .locals 5

    .line 112
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 113
    :cond_0
    sget-object v0, Ldev/nino/squareglass/SquareDetails;->trackPaints:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_1

    .line 114
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    if-ne v2, v1, :cond_1

    :goto_0
    return-void

    .line 115
    :cond_1
    new-instance v1, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v2

    invoke-static {v2}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v2

    const v3, 0xffffff

    and-int/2addr v2, v3

    const/high16 v3, 0x16000000

    or-int/2addr v2, v3

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    const/4 v4, 0x0

    invoke-direct {v3, v4}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/4 v4, 0x0

    invoke-direct {v1, v2, v3, v4}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 117
    invoke-virtual {p0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v0, p0, v1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static control(Landroid/view/View;Z)V
    .locals 0

    .line 290
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareDetails;->button(Landroid/view/View;Z)V

    return-void
.end method

.method public static controls(Landroid/view/View;II)V
    .locals 16

    .line 185
    invoke-virtual/range {p0 .. p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    move-object/from16 v1, p0

    move/from16 v2, p2

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v0, :cond_b

    if-eqz v1, :cond_b

    .line 186
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    if-eq v3, v4, :cond_0

    goto/16 :goto_8

    :cond_0
    const/4 v3, 0x2

    .line 187
    new-array v4, v3, [Landroid/view/View;

    const/4 v5, 0x0

    aput-object v0, v4, v5

    const/4 v6, 0x1

    aput-object v1, v4, v6

    move v7, v5

    :goto_0
    if-ge v7, v3, :cond_a

    aget-object v8, v4, v7

    .line 188
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    instance-of v9, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-nez v9, :cond_1

    goto/16 :goto_7

    .line 189
    :cond_1
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 192
    invoke-virtual {v8}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    invoke-virtual {v10}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v10

    iget v10, v10, Landroid/content/res/Configuration;->fontScale:F

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-static {v11, v10}, Ljava/lang/Math;->max(FF)F

    move-result v10

    const/high16 v12, 0x42400000    # 48.0f

    mul-float/2addr v10, v12

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v10

    invoke-static {v8, v10}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v10

    if-ne v8, v0, :cond_2

    move v12, v6

    goto :goto_1

    :cond_2
    move v12, v5

    :goto_1
    const/16 v13, 0x10

    const/4 v14, 0x6

    if-eqz v12, :cond_3

    move v15, v13

    goto :goto_2

    :cond_3
    move v15, v14

    .line 194
    :goto_2
    invoke-static {v8, v15}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v15

    if-eqz v12, :cond_4

    move v13, v14

    :cond_4
    invoke-static {v8, v13}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v13

    .line 195
    iget v14, v9, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v3, -0x1

    if-nez v14, :cond_5

    iget v14, v9, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-ne v14, v10, :cond_5

    iget v14, v9, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    if-ne v14, v15, :cond_5

    iget v14, v9, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    if-ne v14, v13, :cond_5

    iget v14, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->horizontalWeight:F

    cmpl-float v14, v14, v11

    if-nez v14, :cond_5

    iget v14, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    if-ne v14, v3, :cond_5

    iget v14, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    if-ne v14, v3, :cond_5

    goto :goto_7

    .line 197
    :cond_5
    iput v5, v9, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v10, v9, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 198
    iput v11, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iput v5, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->horizontalChainStyle:I

    .line 199
    iput v3, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    iput v3, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    if-eqz v12, :cond_6

    move v10, v5

    goto :goto_3

    :cond_6
    move v10, v3

    .line 200
    :goto_3
    iput v10, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->leftToLeft:I

    if-eqz v12, :cond_7

    move v10, v3

    goto :goto_4

    :cond_7
    move/from16 v10, p1

    :goto_4
    iput v10, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->leftToRight:I

    if-eqz v12, :cond_8

    move v10, v2

    goto :goto_5

    :cond_8
    move v10, v3

    .line 201
    :goto_5
    iput v10, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->rightToLeft:I

    if-eqz v12, :cond_9

    move v10, v3

    goto :goto_6

    :cond_9
    move v10, v5

    :goto_6
    iput v10, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->rightToRight:I

    .line 202
    iput v3, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToStart:I

    iput v3, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToEnd:I

    iput v3, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToStart:I

    iput v3, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToEnd:I

    .line 203
    iget v3, v9, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget v10, v9, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    invoke-virtual {v9, v15, v3, v13, v10}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v9, v15}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v9, v13}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 204
    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :goto_7
    add-int/lit8 v7, v7, 0x1

    const/4 v3, 0x2

    goto/16 :goto_0

    .line 206
    :cond_a
    invoke-static {v0, v6}, Ldev/nino/squareglass/SquareDetails;->button(Landroid/view/View;Z)V

    invoke-static {v1, v5}, Ldev/nino/squareglass/SquareDetails;->button(Landroid/view/View;Z)V

    :cond_b
    :goto_8
    return-void
.end method

.method public static coverSeed(Landroid/graphics/drawable/Drawable;)I
    .locals 11

    const v0, -0x7f7f80

    if-nez p0, :cond_0

    return v0

    .line 65
    :cond_0
    sget-object v1, Ldev/nino/squareglass/SquareDetails;->seedCache:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    if-eqz v2, :cond_1

    .line 66
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0

    .line 67
    :cond_1
    instance-of v2, p0, Landroid/graphics/drawable/BitmapDrawable;

    if-eqz v2, :cond_2

    .line 68
    move-object v3, p0

    check-cast v3, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {v3}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object v3

    if-eqz v3, :cond_2

    .line 70
    sget-object v4, Ldev/nino/squareglass/SquareDetails;->bitmapSeedCache:Ljava/util/WeakHashMap;

    invoke-virtual {v4, v3}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    if-eqz v3, :cond_2

    .line 72
    invoke-virtual {v1, p0, v3}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0

    .line 77
    :cond_2
    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails$Hero;->-$$Nest$smsample(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;

    move-result-object v3

    if-nez v3, :cond_3

    return v0

    :cond_3
    const/16 v0, 0x240

    .line 79
    new-array v4, v0, [I

    const/16 v9, 0x18

    const/16 v10, 0x18

    const/4 v5, 0x0

    const/16 v6, 0x18

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 80
    invoke-virtual/range {v3 .. v10}, Landroid/graphics/Bitmap;->getPixels([IIIIIII)V

    .line 81
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->recycle()V

    .line 82
    invoke-static {v4}, Ldev/nino/squareglass/CoverColors;->seed([I)I

    move-result v0

    .line 83
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v1, p0, v3}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-eqz v2, :cond_4

    .line 85
    check-cast p0, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object p0

    if-eqz p0, :cond_4

    .line 86
    sget-object v1, Ldev/nino/squareglass/SquareDetails;->bitmapSeedCache:Ljava/util/WeakHashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, p0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_4
    return v0
.end method

.method private static dp(Landroid/view/View;I)I
    .locals 0

    int-to-float p1, p1

    .line 92
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method private static fade(Landroid/view/View;FF)Landroid/graphics/drawable/GradientDrawable;
    .locals 4

    .line 327
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p0

    invoke-static {p0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result p0

    const v0, 0xffffff

    and-int/2addr p0, v0

    .line 328
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v1, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/high16 v2, 0x437f0000    # 255.0f

    mul-float/2addr p1, v2

    .line 329
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    shl-int/lit8 p1, p1, 0x18

    or-int/2addr p1, p0

    const/high16 v3, 0x427f0000    # 63.75f

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    shl-int/lit8 v3, v3, 0x18

    or-int/2addr v3, p0

    mul-float/2addr p2, v2

    .line 330
    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    shl-int/lit8 p2, p2, 0x18

    or-int/2addr p0, p2

    filled-new-array {p1, v3, p0}, [I

    move-result-object p0

    invoke-direct {v0, v1, p0}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    return-object v0
.end method

.method private static foreground(Landroid/view/View;I)V
    .locals 6

    if-nez p0, :cond_0

    goto/16 :goto_5

    .line 121
    :cond_0
    sget-object v0, Ldev/nino/squareglass/SquareDetails;->appliedTints:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    .line 122
    instance-of v1, p0, Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x0

    if-eqz v1, :cond_7

    .line 123
    check-cast p0, Landroidx/appcompat/widget/Toolbar;

    .line 124
    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/Toolbar;->setTitleTextColor(I)V

    .line 125
    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->getNavigationIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->getNavigationIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    .line 126
    :cond_1
    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->getOverflowIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->getOverflowIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    .line 127
    :cond_2
    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->getMenu()Landroid/view/Menu;

    move-result-object v0

    move v1, v2

    .line 128
    :goto_0
    invoke-interface {v0}, Landroid/view/Menu;->size()I

    move-result v3

    if-ge v1, v3, :cond_6

    .line 129
    invoke-interface {v0, v1}, Landroid/view/Menu;->getItem(I)Landroid/view/MenuItem;

    move-result-object v3

    .line 130
    invoke-interface {v3}, Landroid/view/MenuItem;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    if-eqz v4, :cond_3

    invoke-interface {v3}, Landroid/view/MenuItem;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    sget-object v5, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {v4, p1, v5}, Landroid/graphics/drawable/Drawable;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V

    .line 131
    :cond_3
    invoke-interface {v3}, Landroid/view/MenuItem;->getIconTintList()Landroid/content/res/ColorStateList;

    move-result-object v4

    if-eqz v4, :cond_4

    .line 132
    invoke-virtual {v4}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v4

    if-eq v4, p1, :cond_5

    :cond_4
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-interface {v3, v4}, Landroid/view/MenuItem;->setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    :cond_5
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 135
    :cond_6
    :goto_1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-ge v2, v0, :cond_12

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, p1}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 137
    :cond_7
    instance-of v1, p0, Landroid/widget/TextView;

    if-eqz v1, :cond_d

    .line 138
    move-object v0, p0

    check-cast v0, Landroid/widget/TextView;

    .line 139
    invoke-virtual {v0}, Landroid/widget/TextView;->getCurrentTextColor()I

    move-result v1

    if-eq v1, p1, :cond_8

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 140
    :cond_8
    invoke-virtual {v0}, Landroid/widget/TextView;->getCompoundDrawablesRelative()[Landroid/graphics/drawable/Drawable;

    move-result-object v1

    array-length v3, v1

    move v4, v2

    :goto_2
    if-ge v4, v3, :cond_a

    aget-object v5, v1, v4

    if-eqz v5, :cond_9

    .line 141
    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v5

    invoke-virtual {v5, p1}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    :cond_9
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    .line 142
    :cond_a
    invoke-virtual {v0}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    move-result-object v0

    array-length v1, v0

    :goto_3
    if-ge v2, v1, :cond_c

    aget-object v3, v0, v2

    if-eqz v3, :cond_b

    .line 143
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    :cond_b
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    .line 144
    :cond_c
    sget-object v0, Ldev/nino/squareglass/SquareDetails;->appliedTints:Ljava/util/WeakHashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, p0, p1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 146
    :cond_d
    instance-of v1, p0, Landroid/widget/ImageView;

    if-eqz v1, :cond_11

    .line 147
    move-object v1, p0

    check-cast v1, Landroid/widget/ImageView;

    .line 148
    invoke-virtual {v1}, Landroid/widget/ImageView;->getImageTintList()Landroid/content/res/ColorStateList;

    move-result-object v2

    if-eqz v2, :cond_e

    .line 149
    invoke-virtual {v2}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v2

    if-eq v2, p1, :cond_f

    :cond_e
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 150
    :cond_f
    invoke-virtual {v1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    if-eqz v2, :cond_10

    invoke-virtual {v1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    .line 151
    :cond_10
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, p0, p1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 153
    :cond_11
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_12

    .line 154
    check-cast p0, Landroid/view/ViewGroup;

    .line 155
    :goto_4
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-ge v2, v0, :cond_12

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, p1}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_12
    :goto_5
    return-void
.end method

.method private static hero(Landroid/view/View;Landroid/widget/ImageView;)V
    .locals 3

    .line 387
    sget-object v0, Ldev/nino/squareglass/SquareDetails;->heroes:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/ref/WeakReference;

    if-eqz v1, :cond_0

    .line 388
    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/SquareDetails$Hero;

    const/4 p1, 0x0

    iput-object p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->last:Landroid/graphics/drawable/Drawable;

    return-void

    .line 389
    :cond_0
    new-instance v1, Ldev/nino/squareglass/SquareDetails$Hero;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/SquareDetails$Hero;-><init>(Landroid/view/View;Landroid/widget/ImageView;)V

    new-instance p1, Ljava/lang/ref/WeakReference;

    invoke-direct {p1, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v0, p0, p1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 390
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-virtual {v1, p0}, Ldev/nino/squareglass/SquareDetails$Hero;->onViewAttachedToWindow(Landroid/view/View;)V

    :cond_1
    return-void
.end method

.method public static install(Landroid/view/View;)V
    .locals 3

    .line 541
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    .line 542
    :cond_0
    sget-object v0, Ldev/nino/squareglass/SquareDetails;->bindings:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/ref/WeakReference;

    if-nez v1, :cond_1

    const/4 v1, 0x0

    goto :goto_0

    .line 543
    :cond_1
    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldev/nino/squareglass/SquareDetails$Binding;

    :goto_0
    if-eqz v1, :cond_2

    .line 544
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v1, p0}, Ldev/nino/squareglass/SquareDetails$Binding;->onViewAttachedToWindow(Landroid/view/View;)V

    return-void

    .line 545
    :cond_2
    new-instance v1, Ldev/nino/squareglass/SquareDetails$Binding;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SquareDetails$Binding;-><init>(Landroid/view/View;)V

    new-instance v2, Ljava/lang/ref/WeakReference;

    invoke-direct {v2, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v0, p0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 546
    invoke-virtual {p0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 547
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v1, p0}, Ldev/nino/squareglass/SquareDetails$Binding;->onViewAttachedToWindow(Landroid/view/View;)V

    :cond_3
    :goto_1
    return-void
.end method

.method public static isPlaceholder(Landroid/graphics/drawable/Drawable;)Z
    .locals 9

    const/4 v0, 0x1

    if-nez p0, :cond_0

    return v0

    .line 43
    :cond_0
    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails$Hero;->-$$Nest$smsample(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;

    move-result-object v1

    const/4 p0, 0x0

    if-nez v1, :cond_1

    return p0

    :cond_1
    const/16 v2, 0x240

    .line 45
    new-array v2, v2, [I

    const/16 v7, 0x18

    const/16 v8, 0x18

    const/4 v3, 0x0

    const/16 v4, 0x18

    const/4 v5, 0x0

    const/4 v6, 0x0

    .line 46
    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Bitmap;->getPixels([IIIIIII)V

    .line 47
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 48
    aget v1, v2, p0

    const v3, 0xffffff

    and-int v4, v1, v3

    const/16 v5, 0x17

    .line 49
    aget v5, v2, v5

    and-int/2addr v5, v3

    const/16 v6, 0x228

    .line 50
    aget v6, v2, v6

    and-int/2addr v6, v3

    const/16 v7, 0x23f

    .line 51
    aget v2, v2, v7

    and-int/2addr v2, v3

    if-ne v4, v5, :cond_2

    if-ne v5, v6, :cond_2

    if-ne v6, v2, :cond_2

    shr-int/lit8 v2, v4, 0x10

    and-int/lit16 v2, v2, 0xff

    const/16 v3, 0x8

    shr-int/2addr v4, v3

    and-int/lit16 v4, v4, 0xff

    and-int/lit16 v1, v1, 0xff

    const/16 v5, 0x28

    if-ge v2, v5, :cond_2

    if-ge v4, v5, :cond_2

    const/16 v5, 0x2d

    if-ge v1, v5, :cond_2

    sub-int/2addr v2, v4

    .line 56
    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    move-result v2

    const/4 v5, 0x6

    if-gt v2, v5, :cond_2

    sub-int/2addr v4, v1

    invoke-static {v4}, Ljava/lang/Math;->abs(I)I

    move-result v1

    if-gt v1, v3, :cond_2

    return v0

    :cond_2
    return p0
.end method

.method private static labels(Landroid/view/View;)V
    .locals 4

    .line 283
    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_1

    .line 284
    move-object v0, p0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getCurrentTextColor()I

    move-result v1

    const v2, 0xffffff

    and-int v3, v1, v2

    if-eq v3, v2, :cond_0

    if-eqz v3, :cond_0

    const v2, -0xeae9e6

    if-ne v1, v2, :cond_1

    .line 286
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 288
    :cond_1
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    :goto_0
    move-object v1, p0

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    if-ge v0, v2, :cond_2

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, Ldev/nino/squareglass/SquareDetails;->labels(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public static mixHeader(Landroid/view/View;)V
    .locals 7

    .line 292
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_2

    .line 293
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    .line 294
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    const v1, 0x7f0b00b8

    .line 295
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    .line 296
    invoke-virtual {v1}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    instance-of v3, v3, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v3, :cond_2

    .line 297
    invoke-virtual {v1}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 299
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    iget v4, v4, Landroid/util/DisplayMetrics;->widthPixels:I

    const/16 v5, 0x230

    invoke-static {p0, v5}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 300
    iput v4, v3, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v4, v3, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 301
    iput v2, v3, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    const/4 v4, -0x1

    .line 302
    iput v4, v3, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    .line 303
    iput v4, v3, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    .line 304
    iput v2, v3, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToStart:I

    .line 305
    iput v2, v3, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToEnd:I

    .line 307
    iput v2, v3, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iput v2, v3, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 308
    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 309
    invoke-virtual {v1}, Landroid/widget/ImageView;->getForeground()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    instance-of v4, v4, Ldev/nino/squareglass/SquareDetails$CoverFade;

    if-nez v4, :cond_1

    .line 310
    new-instance v4, Ldev/nino/squareglass/SquareDetails$CoverFade;

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v5

    invoke-direct {v4, v5}, Ldev/nino/squareglass/SquareDetails$CoverFade;-><init>(I)V

    invoke-virtual {v1, v4}, Landroid/widget/ImageView;->setForeground(Landroid/graphics/drawable/Drawable;)V

    .line 311
    :cond_1
    sget-object v4, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v1, v4}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 312
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setClipToOutline(Z)V

    const/4 v4, 0x0

    .line 313
    invoke-virtual {v1, v4}, Landroid/widget/ImageView;->setElevation(F)V

    .line 314
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    .line 315
    iget v3, v3, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v5

    iget v5, v5, Landroid/content/res/Configuration;->fontScale:F

    const/high16 v6, 0x43680000    # 232.0f

    mul-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {p0, v5}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v5

    add-int/2addr v3, v5

    iput v3, v4, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 316
    invoke-virtual {p0, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 317
    invoke-static {p0, v1}, Ldev/nino/squareglass/SquareDetails;->hero(Landroid/view/View;Landroid/widget/ImageView;)V

    :cond_2
    const v1, 0x7f0b06e3

    .line 319
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v3

    invoke-static {v1, v3}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    const v1, 0x7f0b069b

    .line 320
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v0, :cond_3

    const v3, -0x4b473c

    goto :goto_0

    :cond_3
    const v3, -0xa29d93

    :goto_0
    invoke-static {v1, v3}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    const v1, 0x7f0b056e

    .line 321
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const/4 v3, 0x1

    invoke-static {v1, v3}, Ldev/nino/squareglass/SquareDetails;->button(Landroid/view/View;Z)V

    const v1, 0x7f0b056f

    .line 322
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1, v2}, Ldev/nino/squareglass/SquareDetails;->button(Landroid/view/View;Z)V

    const v1, 0x7f0b0274

    const v3, 0x7f0b064c

    const v4, 0x7f0b02c6

    .line 323
    filled-new-array {v4, v1, v3}, [I

    move-result-object v1

    :goto_1
    const/4 v3, 0x3

    if-ge v2, v3, :cond_4

    aget v3, v1, v2

    .line 324
    invoke-virtual {p0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v4

    invoke-static {v3, v4}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_4
    :goto_2
    return-void
.end method

.method public static playlist(Landroid/view/View;)V
    .locals 8

    .line 393
    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails;->install(Landroid/view/View;)V

    const v0, 0x7f0b057a

    .line 394
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    goto/16 :goto_0

    :cond_0
    const v1, 0x7f0b00b8

    .line 396
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    const/4 v3, -0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_2

    .line 397
    invoke-virtual {v2}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    instance-of v5, v5, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v5, :cond_2

    .line 398
    invoke-virtual {v2}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 400
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v6

    iget v6, v6, Landroid/util/DisplayMetrics;->widthPixels:I

    const/16 v7, 0x230

    invoke-static {p0, v7}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result p0

    invoke-static {v6, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    iput p0, v5, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 401
    iget p0, v5, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput p0, v5, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 402
    iput v4, v5, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v3, v5, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    iput v3, v5, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    .line 403
    iput v4, v5, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToStart:I

    iput v4, v5, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToEnd:I

    .line 404
    iput v4, v5, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 405
    iput v4, v5, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 406
    invoke-virtual {v2, v5}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    sget-object p0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v2, p0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 407
    invoke-virtual {v2}, Landroid/widget/ImageView;->getForeground()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    instance-of p0, p0, Ldev/nino/squareglass/SquareDetails$CoverFade;

    if-nez p0, :cond_1

    .line 408
    new-instance p0, Ldev/nino/squareglass/SquareDetails$CoverFade;

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v5

    invoke-static {v5}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v5

    invoke-direct {p0, v5}, Ldev/nino/squareglass/SquareDetails$CoverFade;-><init>(I)V

    invoke-virtual {v2, p0}, Landroid/widget/ImageView;->setForeground(Landroid/graphics/drawable/Drawable;)V

    :cond_1
    const/4 p0, 0x0

    .line 409
    invoke-virtual {v2, p0}, Landroid/widget/ImageView;->setElevation(F)V

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setClipToOutline(Z)V

    .line 410
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    const/4 v5, -0x2

    .line 411
    iput v5, p0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 412
    invoke-virtual {v0, p0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v0, v2}, Ldev/nino/squareglass/SquareDetails;->hero(Landroid/view/View;Landroid/widget/ImageView;)V

    :cond_2
    const p0, 0x7f0b06e3

    .line 414
    invoke-virtual {v0, p0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/16 v5, -0x14

    invoke-static {v2, v1, v5}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    const v1, 0x7f0b021f

    .line 415
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/16 v5, 0x8

    invoke-static {v2, p0, v5}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    const p0, 0x7f0b0239

    .line 416
    invoke-virtual {v0, p0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-static {v2, v1, v5}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    const v1, 0x7f0b057b

    .line 417
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/16 v6, 0xc

    invoke-static {v2, p0, v6}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    const p0, 0x7f0b0568

    .line 418
    invoke-virtual {v0, p0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/16 v6, 0x14

    invoke-static {v2, v1, v6}, Ldev/nino/squareglass/SquareDetails;->below(Landroid/view/View;II)V

    const v1, 0x7f0b065c

    .line 419
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_3

    .line 421
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 422
    iput p0, v2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v3, v2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    iput v3, v2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    iput v3, v2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    .line 423
    iput v4, v2, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    invoke-virtual {v1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3
    const v1, 0x7f0b0591

    const v2, 0x7f0b064c

    const v3, 0x7f0b02c6

    const v4, 0x7f0b0290

    const v6, 0x7f0b0274

    .line 425
    filled-new-array {v3, v4, v6, v1, v2}, [I

    move-result-object v1

    invoke-static {v0, p0, v1}, Ldev/nino/squareglass/SquareDetails;->actionRail(Landroid/view/View;I[I)V

    const p0, 0x7f0b00b9

    .line 426
    invoke-virtual {v0, p0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    check-cast p0, Landroid/widget/ImageView;

    if-eqz p0, :cond_4

    .line 427
    invoke-virtual {p0, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_4
    :goto_0
    return-void
.end method

.method private static playlistPaint(Landroid/view/View;)V
    .locals 9

    const v0, 0x7f0b057a

    .line 439
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    if-nez p0, :cond_0

    goto/16 :goto_3

    .line 441
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    const v1, 0x7f0b06e3

    .line 442
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v2

    invoke-static {v1, v2}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    const v1, 0x7f0b057b

    const v2, 0x7f0b0579

    const v3, 0x7f0b021f

    const v4, 0x7f0b0239

    .line 443
    filled-new-array {v3, v4, v1, v2}, [I

    move-result-object v1

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/4 v4, 0x4

    if-ge v3, v4, :cond_2

    aget v4, v1, v3

    .line 444
    invoke-virtual {p0, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    if-eqz v0, :cond_1

    const v5, -0x4b473c

    goto :goto_1

    :cond_1
    const v5, -0xa29d93

    :goto_1
    invoke-static {v4, v5}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    const v1, 0x7f0b065c

    const v3, 0x7f0b0568

    .line 445
    invoke-static {p0, v3, v1}, Ldev/nino/squareglass/SquareDetails;->controls(Landroid/view/View;II)V

    const v1, 0x7f0b02c6

    const v4, 0x7f0b0290

    const v5, 0x7f0b0274

    const v6, 0x7f0b0591

    const v7, 0x7f0b064c

    .line 448
    filled-new-array {v1, v4, v5, v6, v7}, [I

    move-result-object v8

    invoke-static {p0, v3, v8}, Ldev/nino/squareglass/SquareDetails;->actionRail(Landroid/view/View;I[I)V

    .line 449
    filled-new-array {v1, v4, v5, v6, v7}, [I

    move-result-object v1

    :goto_2
    const/4 v3, 0x5

    if-ge v2, v3, :cond_3

    aget v3, v1, v2

    .line 450
    invoke-virtual {p0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v4

    invoke-static {v3, v4}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    :goto_3
    return-void
.end method

.method private static rounded(Landroid/view/View;I)V
    .locals 1

    if-nez p0, :cond_0

    return-void

    .line 96
    :cond_0
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result p1

    .line 97
    new-instance v0, Ldev/nino/squareglass/SquareDetails$1;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/SquareDetails$1;-><init>(I)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    const/4 p1, 0x1

    .line 102
    invoke-virtual {p0, p1}, Landroid/view/View;->setClipToOutline(Z)V

    return-void
.end method

.method public static track(Landroid/view/View;)V
    .locals 3

    .line 105
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const v0, 0x7f0b056e

    .line 106
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_2

    const v0, 0x7f0b0568

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    const v0, 0x7f0b00b8

    .line 107
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const/16 v2, 0xa

    invoke-static {v1, v2}, Ldev/nino/squareglass/SquareDetails;->rounded(Landroid/view/View;I)V

    .line 108
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-static {p0}, Ldev/nino/squareglass/SquareGestures;->bind(Landroid/view/View;)V

    :cond_2
    :goto_0
    return-void
.end method

.method private static unfilledAction(Landroid/view/View;)V
    .locals 10

    .line 246
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    .line 247
    sget-object v1, Ldev/nino/squareglass/SquareDetails;->buttonPaints:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p0}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eq v2, v4, :cond_1

    .line 248
    :cond_0
    invoke-virtual {p0, v3}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 249
    new-instance v2, Landroid/graphics/drawable/RippleDrawable;

    const v4, 0xffffff

    and-int/2addr v4, v0

    const/high16 v5, 0x18000000

    or-int/2addr v4, v5

    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-direct {v2, v4, v3, v3}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 250
    invoke-virtual {p0, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v1, p0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const v1, 0x7f0b05b4

    .line 254
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_2

    .line 255
    invoke-virtual {v1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    if-eqz v2, :cond_2

    invoke-virtual {v1, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_2
    const v1, 0x7f0b0277

    .line 256
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_3

    .line 257
    invoke-virtual {v1}, Landroid/view/View;->getForeground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    if-eqz v2, :cond_3

    invoke-virtual {v1, v3}, Landroid/view/View;->setForeground(Landroid/graphics/drawable/Drawable;)V

    :cond_3
    const v1, 0x7f0b035d

    .line 258
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const v2, 0x7f0b06c8

    invoke-virtual {p0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/4 v3, 0x0

    if-nez v1, :cond_4

    const/4 v4, 0x1

    goto :goto_0

    :cond_4
    move v4, v3

    :goto_0
    if-eqz v4, :cond_5

    const v1, 0x7f0b0276

    .line 260
    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    :cond_5
    if-nez v2, :cond_6

    const v2, 0x7f0b0279

    .line 261
    invoke-virtual {p0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    :cond_6
    const/4 v5, -0x1

    if-eqz v1, :cond_9

    .line 262
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    instance-of v6, v6, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v6, :cond_9

    .line 263
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v4, :cond_7

    const/16 v4, 0xa

    goto :goto_1

    :cond_7
    const/16 v4, 0x8

    .line 265
    :goto_1
    invoke-static {v1, v4}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v4

    .line 266
    iget v7, v6, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/16 v8, 0x18

    invoke-static {v1, v8}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v9

    if-ne v7, v9, :cond_8

    iget v7, v6, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-static {v1, v8}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v9

    if-ne v7, v9, :cond_8

    iget v7, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-ne v7, v4, :cond_8

    iget v7, v6, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    if-nez v7, :cond_8

    iget v7, v6, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    if-eq v7, v5, :cond_9

    .line 267
    :cond_8
    invoke-static {v1, v8}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v7

    iput v7, v6, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-static {v1, v8}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v7

    iput v7, v6, Landroid/view/ViewGroup$LayoutParams;->height:I

    iput v4, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 268
    iput v3, v6, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v5, v6, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    invoke-virtual {v1, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_9
    if-eqz v2, :cond_b

    .line 271
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v1, :cond_b

    .line 272
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 274
    iget v4, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    const/16 v6, 0x26

    if-ne v4, v5, :cond_a

    iget v4, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    if-nez v4, :cond_a

    iget v4, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    if-ne v4, v5, :cond_a

    iget v4, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    invoke-static {v2, v6}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v7

    if-eq v4, v7, :cond_b

    .line 275
    :cond_a
    iput v5, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    iput v3, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v5, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    .line 276
    invoke-static {v2, v6}, Ldev/nino/squareglass/SquareDetails;->dp(Landroid/view/View;I)I

    move-result v3

    iput v3, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    invoke-virtual {v2, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 279
    :cond_b
    invoke-static {p0, v0}, Ldev/nino/squareglass/SquareDetails;->foreground(Landroid/view/View;I)V

    return-void
.end method
