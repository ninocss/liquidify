.class final Ldev/nino/squareglass/IconMotion$decorate$6$1$1;
.super Lkotlin/coroutines/jvm/internal/RestrictedSuspendLambda;
.source "IconMotion.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/IconMotion$decorate$6$1;->invoke(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/RestrictedSuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nIconMotion.kt\nKotlin\n*S Kotlin\n*F\n+ 1 IconMotion.kt\ndev/nino/squareglass/IconMotion$decorate$6$1$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,151:1\n296#2,2:152\n*S KotlinDebug\n*F\n+ 1 IconMotion.kt\ndev/nino/squareglass/IconMotion$decorate$6$1$1\n*L\n139#1:152,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $lastTap$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field I$0:I

.field I$1:I

.field I$2:I

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/IconMotion$decorate$6$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->$lastTap$delegate:Landroidx/compose/runtime/MutableState;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/RestrictedSuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;

    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->$lastTap$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {v0, p0, p2}, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;-><init>(Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V

    iput-object p1, v0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->invoke(Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    iget-object v0, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->L$0:Ljava/lang/Object;

    check-cast v0, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 131
    iget v2, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->label:I

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    if-eq v2, v5, :cond_1

    if-ne v2, v3, :cond_0

    iget v2, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->I$1:I

    iget v6, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->I$0:I

    iget-object v7, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->L$1:Ljava/lang/Object;

    check-cast v7, Landroidx/compose/ui/input/pointer/PointerInputChange;

    :try_start_0
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_3

    :catchall_0
    move-exception p0

    goto/16 :goto_5

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_0

    :cond_2
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 132
    sget-object p1, Landroidx/compose/ui/input/pointer/PointerEventPass;->Initial:Landroidx/compose/ui/input/pointer/PointerEventPass;

    move-object v2, p0

    check-cast v2, Lkotlin/coroutines/e;

    iput-object v0, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->L$0:Ljava/lang/Object;

    iput v5, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->label:I

    invoke-static {v0, v4, p1, v2}, Landroidx/compose/foundation/gestures/TapGestureDetectorKt;->awaitFirstDown(Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;ZLandroidx/compose/ui/input/pointer/PointerEventPass;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_3

    goto :goto_2

    .line 131
    :cond_3
    :goto_0
    check-cast p1, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 133
    sget-object v2, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    invoke-static {v2, v5}, Ldev/nino/squareglass/IconMotion;->access$interacted(Ldev/nino/squareglass/IconMotion;Z)V

    move-object v7, p1

    move v2, v4

    move v6, v2

    move p1, v5

    :goto_1
    if-eqz p1, :cond_9

    .line 138
    :try_start_1
    sget-object v8, Landroidx/compose/ui/input/pointer/PointerEventPass;->Initial:Landroidx/compose/ui/input/pointer/PointerEventPass;

    move-object v9, p0

    check-cast v9, Lkotlin/coroutines/e;

    iput-object v0, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->L$0:Ljava/lang/Object;

    iput-object v7, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->L$1:Ljava/lang/Object;

    iput v6, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->I$0:I

    iput v2, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->I$1:I

    iput p1, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->I$2:I

    iput v3, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->label:I

    invoke-interface {v0, v8, v9}, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;->awaitPointerEvent(Landroidx/compose/ui/input/pointer/PointerEventPass;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_4

    :goto_2
    return-object v1

    .line 131
    :cond_4
    :goto_3
    check-cast p1, Landroidx/compose/ui/input/pointer/PointerEvent;

    .line 139
    invoke-virtual {p1}, Landroidx/compose/ui/input/pointer/PointerEvent;->getChanges()Ljava/util/List;

    move-result-object v8

    check-cast v8, Ljava/lang/Iterable;

    .line 152
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_5
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_6

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    move-object v10, v9

    check-cast v10, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 139
    invoke-virtual {v10}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getId-J3iCeTQ()J

    move-result-wide v10

    invoke-virtual {v7}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getId-J3iCeTQ()J

    move-result-wide v12

    invoke-static {v10, v11, v12, v13}, Landroidx/compose/ui/input/pointer/PointerId;->equals-impl0(JJ)Z

    move-result v10

    if-eqz v10, :cond_5

    goto :goto_4

    :cond_6
    const/4 v9, 0x0

    :goto_4
    check-cast v9, Landroidx/compose/ui/input/pointer/PointerInputChange;

    if-eqz v9, :cond_a

    .line 140
    invoke-virtual {p1}, Landroidx/compose/ui/input/pointer/PointerEvent;->getChanges()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-le p1, v5, :cond_7

    goto :goto_6

    .line 141
    :cond_7
    invoke-virtual {v9}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPosition-F1C5BW0()J

    move-result-wide v10

    invoke-virtual {v7}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPosition-F1C5BW0()J

    move-result-wide v12

    invoke-static {v10, v11, v12, v13}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    move-result-wide v10

    invoke-static {v10, v11}, Landroidx/compose/ui/geometry/Offset;->getDistance-impl(J)F

    move-result p1

    invoke-interface {v0}, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;->getViewConfiguration()Landroidx/compose/ui/platform/ViewConfiguration;

    move-result-object v8

    invoke-interface {v8}, Landroidx/compose/ui/platform/ViewConfiguration;->getTouchSlop()F

    move-result v8

    cmpl-float p1, p1, v8

    if-lez p1, :cond_8

    move v6, v5

    .line 142
    :cond_8
    invoke-virtual {v9}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPressed()Z

    move-result p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    .line 143
    :goto_5
    sget-object p1, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    invoke-static {p1, v4}, Ldev/nino/squareglass/IconMotion;->access$interacted(Ldev/nino/squareglass/IconMotion;Z)V

    throw p0

    :cond_9
    move v5, v2

    :cond_a
    :goto_6
    sget-object p1, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    invoke-static {p1, v4}, Ldev/nino/squareglass/IconMotion;->access$interacted(Ldev/nino/squareglass/IconMotion;Z)V

    if-nez v6, :cond_b

    if-nez v5, :cond_b

    .line 145
    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$decorate$6$1$1;->$lastTap$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    invoke-static {p0, v0, v1}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$9(Landroidx/compose/runtime/MutableState;J)V

    .line 147
    :cond_b
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
