.class Ldev/nino/squareglass/SquareSongMenu$4;
.super Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
.source "SquareSongMenu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/SquareSongMenu;->onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/SquareSongMenu;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/SquareSongMenu;Landroid/view/View;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 237
    iput-object p1, p0, Ldev/nino/squareglass/SquareSongMenu$4;->this$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-direct {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;-><init>(Landroid/view/View;)V

    return-void
.end method
