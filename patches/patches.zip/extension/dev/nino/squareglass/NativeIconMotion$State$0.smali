.class public final synthetic Ldev/nino/squareglass/NativeIconMotion$State$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/NativeIconMotion$State;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/NativeIconMotion$State;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeIconMotion$State$0;->f$0:Ldev/nino/squareglass/NativeIconMotion$State;

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/NativeIconMotion$State$0;->f$0:Ldev/nino/squareglass/NativeIconMotion$State;

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeIconMotion$State;->$r8$lambda$AACN_lCz5yuuEjiyK81Srtk9_EQ(Ldev/nino/squareglass/NativeIconMotion$State;Landroid/animation/ValueAnimator;)V

    return-void
.end method
