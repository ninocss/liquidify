.class final Ldev/nino/squareglass/RecommendationUpdates$Revision;
.super Ljava/lang/Object;
.source "RecommendationUpdates.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/RecommendationUpdates;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Revision"
.end annotation


# instance fields
.field final time:J

.field final value:Ljava/lang/String;

.field final view:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroidx/recyclerview/widget/RecyclerView;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/String;Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 2

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Revision;->time:J

    .line 17
    iput-object p1, p0, Ldev/nino/squareglass/RecommendationUpdates$Revision;->value:Ljava/lang/String;

    new-instance p1, Ljava/lang/ref/WeakReference;

    invoke-direct {p1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Ldev/nino/squareglass/RecommendationUpdates$Revision;->view:Ljava/lang/ref/WeakReference;

    return-void
.end method
