.class public final synthetic Ldev/nino/squareglass/SleepTimer$8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/widget/TextView;

.field public final synthetic f$1:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/TextView;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$8;->f$0:Landroid/widget/TextView;

    iput-object p2, p0, Ldev/nino/squareglass/SleepTimer$8;->f$1:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SleepTimer$8;->f$0:Landroid/widget/TextView;

    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$8;->f$1:Landroid/content/Context;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/SleepTimer;->lambda$button$1(Landroid/widget/TextView;Landroid/content/Context;Landroid/view/View;)V

    return-void
.end method
