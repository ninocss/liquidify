.class public final Ldev/nino/squareglass/SquareExplore;
.super Ljava/lang/Object;
.source "SquareExplore.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/SquareExplore$Binding;
    }
.end annotation


# static fields
.field private static final bindings:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ljava/lang/ref/WeakReference<",
            "Ldev/nino/squareglass/SquareExplore$Binding;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 17
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareExplore;->bindings:Ljava/util/WeakHashMap;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static clearSearch(Landroid/view/View;)V
    .locals 3

    .line 40
    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_1

    .line 41
    move-object v0, p0

    check-cast v0, Landroid/widget/TextView;

    .line 42
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 43
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    if-eqz v1, :cond_0

    const v1, -0x4b473c

    goto :goto_0

    :cond_0
    const v1, -0xa29d93

    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setHintTextColor(I)V

    .line 44
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const v1, 0x7f090005

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getFont(I)Landroid/graphics/Typeface;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 45
    instance-of p0, v0, Landroid/widget/EditText;

    if-eqz p0, :cond_3

    .line 46
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p0

    invoke-static {p0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p0

    const v1, 0xffffff

    and-int/2addr p0, v1

    const/high16 v1, 0x33000000

    or-int/2addr p0, v1

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setHighlightColor(I)V

    .line 47
    invoke-virtual {v0}, Landroid/widget/TextView;->getTextCursorDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    if-eqz p0, :cond_3

    .line 48
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v2

    invoke-static {v2}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setTextCursorDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void

    .line 50
    :cond_1
    instance-of v0, p0, Landroid/widget/ImageView;

    if-eqz v0, :cond_2

    .line 51
    check-cast p0, Landroid/widget/ImageView;

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    return-void

    .line 52
    :cond_2
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_3

    const/4 v0, 0x0

    .line 53
    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundColor(I)V

    .line 54
    check-cast p0, Landroid/view/ViewGroup;

    .line 55
    :goto_1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, Ldev/nino/squareglass/SquareExplore;->clearSearch(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    return-void
.end method

.method public static install(Landroid/view/View;)V
    .locals 3

    .line 19
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 20
    :cond_0
    sget-object v0, Ldev/nino/squareglass/SquareExplore;->bindings:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/ref/WeakReference;

    if-eqz v1, :cond_1

    .line 21
    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/SquareExplore$Binding;

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/SquareExplore$Binding;->paint(Landroid/view/View;)V

    return-void

    .line 22
    :cond_1
    new-instance v1, Ldev/nino/squareglass/SquareExplore$Binding;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SquareExplore$Binding;-><init>(Landroid/view/View;)V

    new-instance v2, Ljava/lang/ref/WeakReference;

    invoke-direct {v2, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v0, p0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    invoke-virtual {p0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 24
    invoke-virtual {v1, p0}, Ldev/nino/squareglass/SquareExplore$Binding;->paint(Landroid/view/View;)V

    return-void
.end method

.method public static search(Landroid/view/View;)V
    .locals 3

    .line 29
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 30
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 31
    invoke-static {p0}, Ldev/nino/squareglass/SquareExplore;->clearSearch(Landroid/view/View;)V

    const/high16 v1, 0x41e00000    # 28.0f

    .line 32
    invoke-static {p0, v1}, Ldev/nino/squareglass/PageGlass;->install(Landroid/view/View;F)V

    .line 33
    invoke-static {p0}, Ldev/nino/squareglass/PageGlass;->hasSurface(Landroid/view/View;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    goto :goto_0

    .line 34
    :cond_1
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v1

    const/16 v2, 0x1c

    invoke-static {p0, v1, v2}, Ldev/nino/squareglass/PageMaterial;->background(Landroid/view/View;II)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    const/4 v1, 0x1

    .line 35
    invoke-virtual {p0, v1}, Landroid/view/View;->setClipToOutline(Z)V

    const/high16 v1, 0x42400000    # 48.0f

    mul-float/2addr v0, v1

    .line 36
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->setMinimumHeight(I)V

    return-void
.end method
