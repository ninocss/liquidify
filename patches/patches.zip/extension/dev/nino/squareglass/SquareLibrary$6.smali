.class public final synthetic Ldev/nino/squareglass/SquareLibrary$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:I

.field public final synthetic f$2:I

.field public final synthetic f$3:Z

.field public final synthetic f$4:Ljava/lang/String;

.field public final synthetic f$5:Lam0/a;

.field public final synthetic f$6:I


# direct methods
.method public synthetic constructor <init>(IIIZLjava/lang/String;Lam0/a;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$0:I

    iput p2, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$1:I

    iput p3, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$2:I

    iput-boolean p4, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$3:Z

    iput-object p5, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$4:Ljava/lang/String;

    iput-object p6, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$5:Lam0/a;

    iput p7, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$6:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    iget v0, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$0:I

    iget v1, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$1:I

    iget v2, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$2:I

    iget-boolean v3, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$3:Z

    iget-object v4, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$4:Ljava/lang/String;

    iget-object v5, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$5:Lam0/a;

    iget v6, p0, Ldev/nino/squareglass/SquareLibrary$6;->f$6:I

    move-object v7, p1

    check-cast v7, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-static/range {v0 .. v8}, Ldev/nino/squareglass/SquareLibrary;->Entry$lambda$1(IIIZLjava/lang/String;Lam0/a;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
