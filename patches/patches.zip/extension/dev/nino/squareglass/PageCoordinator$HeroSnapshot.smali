.class final Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;
.super Ljava/lang/Object;
.source "PageCoordinator.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/PageCoordinator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "HeroSnapshot"
.end annotation


# instance fields
.field final covers:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation
.end field

.field final seeds:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 1

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;->covers:Ljava/util/ArrayList;

    .line 21
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;->seeds:Ljava/util/ArrayList;

    return-void
.end method

.method synthetic constructor <init>(Ldev/nino/squareglass/PageCoordinator-IA;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;-><init>()V

    return-void
.end method
