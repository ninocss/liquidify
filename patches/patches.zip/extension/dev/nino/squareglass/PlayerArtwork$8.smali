.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/PlayerArtwork$Frame;Landroidx/compose/runtime/MutableState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$8;->f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

    iput-object p2, p0, Ldev/nino/squareglass/PlayerArtwork$8;->f$1:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/PlayerArtwork$8;->f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$8;->f$1:Landroidx/compose/runtime/MutableState;

    check-cast p1, Landroidx/compose/ui/layout/LayoutCoordinates;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$ImAULibSxnyJcZt7DMJj2dRdXUg(Ldev/nino/squareglass/PlayerArtwork$Frame;Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/LayoutCoordinates;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
