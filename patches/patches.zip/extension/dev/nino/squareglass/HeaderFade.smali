.class public final Ldev/nino/squareglass/HeaderFade;
.super Landroid/graphics/drawable/Drawable;
.source "HeaderFade.java"


# instance fields
.field private amount:F

.field private final paint:Landroid/graphics/Paint;

.field private tone:I


# direct methods
.method public constructor <init>(I)V
    .locals 2

    .line 8
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 6
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Ldev/nino/squareglass/HeaderFade;->paint:Landroid/graphics/Paint;

    .line 8
    iput p1, p0, Ldev/nino/squareglass/HeaderFade;->tone:I

    return-void
.end method

.method private shader()V
    .locals 11

    .line 15
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    iget v1, p0, Ldev/nino/squareglass/HeaderFade;->tone:I

    const v2, 0xffffff

    and-int/2addr v1, v2

    .line 16
    iget-object v2, p0, Ldev/nino/squareglass/HeaderFade;->paint:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/LinearGradient;

    iget v4, v0, Landroid/graphics/Rect;->top:I

    int-to-float v5, v4

    iget v4, v0, Landroid/graphics/Rect;->top:I

    add-int/lit8 v4, v4, 0x1

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    invoke-static {v4, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-float v7, v0

    iget v0, p0, Ldev/nino/squareglass/HeaderFade;->tone:I

    const/high16 v4, -0x6000000

    or-int/2addr v4, v1

    const/high16 v6, -0x2e000000

    or-int/2addr v6, v1

    filled-new-array {v0, v0, v4, v6, v1}, [I

    move-result-object v8

    const/4 v0, 0x5

    new-array v9, v0, [F

    fill-array-data v9, :array_0

    sget-object v10, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v4, 0x0

    const/4 v6, 0x0

    invoke-direct/range {v3 .. v10}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 19
    iget-object v0, p0, Ldev/nino/squareglass/HeaderFade;->paint:Landroid/graphics/Paint;

    iget p0, p0, Ldev/nino/squareglass/HeaderFade;->amount:F

    const/high16 v1, 0x437f0000    # 255.0f

    mul-float/2addr p0, v1

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    invoke-virtual {v0, p0}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3f2e147b    # 0.68f
        0x3f6147ae    # 0.88f
        0x3f75c28f    # 0.96f
        0x3f800000    # 1.0f
    .end array-data
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 2

    .line 22
    iget v0, p0, Ldev/nino/squareglass/HeaderFade;->amount:F

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-lez v0, :cond_0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/HeaderFade;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, p0}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    :cond_0
    return-void
.end method

.method public getOpacity()I
    .locals 0

    const/4 p0, -0x3

    return p0
.end method

.method protected onBoundsChange(Landroid/graphics/Rect;)V
    .locals 0

    .line 21
    invoke-direct {p0}, Ldev/nino/squareglass/HeaderFade;->shader()V

    return-void
.end method

.method public progress()F
    .locals 0

    .line 9
    iget p0, p0, Ldev/nino/squareglass/HeaderFade;->amount:F

    return p0
.end method

.method public setAlpha(I)V
    .locals 1

    .line 23
    iget-object p1, p0, Ldev/nino/squareglass/HeaderFade;->paint:Landroid/graphics/Paint;

    iget p0, p0, Ldev/nino/squareglass/HeaderFade;->amount:F

    const/high16 v0, 0x437f0000    # 255.0f

    mul-float/2addr p0, v0

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    invoke-virtual {p1, p0}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 0

    .line 24
    iget-object p0, p0, Ldev/nino/squareglass/HeaderFade;->paint:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    return-void
.end method

.method public update(IF)V
    .locals 1

    .line 11
    iget v0, p0, Ldev/nino/squareglass/HeaderFade;->tone:I

    if-ne v0, p1, :cond_0

    iget v0, p0, Ldev/nino/squareglass/HeaderFade;->amount:F

    cmpl-float v0, v0, p2

    if-nez v0, :cond_0

    return-void

    .line 12
    :cond_0
    iput p1, p0, Ldev/nino/squareglass/HeaderFade;->tone:I

    iput p2, p0, Ldev/nino/squareglass/HeaderFade;->amount:F

    invoke-direct {p0}, Ldev/nino/squareglass/HeaderFade;->shader()V

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method
