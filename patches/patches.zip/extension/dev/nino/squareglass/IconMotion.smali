.class public final Ldev/nino/squareglass/IconMotion;
.super Ljava/lang/Object;
.source "IconMotion.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/IconMotion$Entry;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nIconMotion.kt\nKotlin\n*S Kotlin\n*F\n+ 1 IconMotion.kt\ndev/nino/squareglass/IconMotion\n+ 2 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 Effects.kt\nandroidx/compose/runtime/DisposableEffectScope\n+ 5 DrawScope.kt\nandroidx/compose/ui/graphics/drawscope/DrawScopeKt\n+ 6 Offset.kt\nandroidx/compose/ui/geometry/Offset\n+ 7 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 8 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n+ 9 SnapshotIntState.kt\nandroidx/compose/runtime/SnapshotIntStateKt__SnapshotIntStateKt\n+ 10 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,185:1\n75#2:186\n75#2:187\n1128#3,6:188\n1128#3,6:194\n1128#3,6:200\n1128#3,6:206\n1128#3,6:212\n1128#3,6:218\n1128#3,6:224\n1128#3,6:230\n1128#3,6:236\n1128#3,6:242\n1128#3,6:248\n1128#3,6:254\n1128#3,6:260\n1128#3,6:266\n1128#3,6:272\n66#4,5:278\n249#5,14:283\n65#6:297\n69#6:300\n60#7:298\n70#7:301\n22#8:299\n22#8:302\n78#9:303\n111#9,2:304\n78#9:306\n111#9,2:307\n78#9:318\n111#9,2:319\n85#10:309\n117#10,2:310\n85#10:312\n117#10,2:313\n85#10:315\n117#10,2:316\n*S KotlinDebug\n*F\n+ 1 IconMotion.kt\ndev/nino/squareglass/IconMotion\n*L\n91#1:186\n92#1:187\n93#1:188,6\n94#1:194,6\n95#1:200,6\n96#1:206,6\n97#1:212,6\n98#1:218,6\n99#1:224,6\n101#1:230,6\n104#1:236,6\n118#1:242,6\n121#1:248,6\n131#1:254,6\n137#1:260,6\n138#1:266,6\n157#1:272,6\n116#1:278,5\n163#1:283,14\n172#1:297\n173#1:300\n172#1:298\n173#1:301\n172#1:299\n173#1:302\n94#1:303\n94#1:304,2\n95#1:306\n95#1:307,2\n99#1:318\n99#1:319,2\n96#1:309\n96#1:310,2\n97#1:312\n97#1:313,2\n98#1:315\n98#1:316,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000o\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0013\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0002*\u0001\u0010\u0008\u00c7\u0002\u0018\u00002\u00020\u0001:\u00011B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0007J\u0010\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\u0018\u0010\u0019\u001a\u00020\u00012\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001dH\u0007J\u0010\u0010\u001e\u001a\u00020\u00132\u0006\u0010\u001f\u001a\u00020\u0001H\u0007J\u000e\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020!J\u0015\u0010#\u001a\u00020!2\u0006\u0010\"\u001a\u00020!H\u0007\u00a2\u0006\u0002\u0010$J\u001d\u0010%\u001a\u00020!2\u0006\u0010\"\u001a\u00020!2\u0006\u0010&\u001a\u00020\rH\u0007\u00a2\u0006\u0002\u0010\'J\u001d\u0010(\u001a\u00020!2\u0006\u0010\"\u001a\u00020!2\u0006\u0010)\u001a\u00020\u0018H\u0007\u00a2\u0006\u0002\u0010*J%\u0010+\u001a\u00020!2\u0006\u0010\"\u001a\u00020!2\u0006\u0010,\u001a\u00020\r2\u0006\u0010-\u001a\u00020\rH\u0007\u00a2\u0006\u0002\u0010.J/\u0010/\u001a\u00020!2\u0006\u0010\"\u001a\u00020!2\u0006\u0010,\u001a\u00020\r2\u0006\u0010-\u001a\u00020\r2\u0008\u0010)\u001a\u0004\u0018\u00010\u0018H\u0003\u00a2\u0006\u0002\u00100R\u001e\u0010\u0004\u001a\u0012\u0012\u0004\u0012\u00020\u00060\u0005j\u0008\u0012\u0004\u0012\u00020\u0006`\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u00020\u0010X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u0011\u00a8\u00062\u00b2\u0006\n\u0010\u0014\u001a\u00020\rX\u008a\u008e\u0002\u00b2\u0006\n\u00103\u001a\u00020\rX\u008a\u008e\u0002\u00b2\u0006\n\u00104\u001a\u000205X\u008a\u008e\u0002\u00b2\u0006\n\u00106\u001a\u000207X\u008a\u008e\u0002\u00b2\u0006\u000c\u00108\u001a\u0004\u0018\u00010\u0018X\u008a\u008e\u0002\u00b2\u0006\n\u00109\u001a\u00020\rX\u008a\u008e\u0002"
    }
    d2 = {
        "Ldev/nino/squareglass/IconMotion;",
        "",
        "<init>",
        "()V",
        "entries",
        "Ljava/util/ArrayList;",
        "Ldev/nino/squareglass/IconMotion$Entry;",
        "Lkotlin/collections/ArrayList;",
        "handler",
        "Landroid/os/Handler;",
        "policy",
        "Ldev/nino/squareglass/MotionPolicy;",
        "cursor",
        "",
        "idleStyle",
        "tick",
        "dev/nino/squareglass/IconMotion$tick$1",
        "Ldev/nino/squareglass/IconMotion$tick$1;",
        "touch",
        "",
        "event",
        "Landroid/view/MotionEvent;",
        "interacted",
        "down",
        "",
        "registerNative",
        "view",
        "Landroid/view/View;",
        "fire",
        "Ljava/util/function/IntConsumer;",
        "unregisterNative",
        "token",
        "watch",
        "Landroidx/compose/ui/Modifier;",
        "original",
        "settings",
        "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "settingsResource",
        "resource",
        "(Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "favorite",
        "liked",
        "(Landroidx/compose/ui/Modifier;ZLandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "icon",
        "key",
        "pulse",
        "(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "decorate",
        "(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "Entry",
        "extension_debug",
        "kind",
        "bounds",
        "Landroidx/compose/ui/geometry/Rect;",
        "lastTap",
        "",
        "previousLike",
        "previousPulse"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/IconMotion;

.field private static cursor:I

.field private static final entries:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ldev/nino/squareglass/IconMotion$Entry;",
            ">;"
        }
    .end annotation
.end field

.field private static final handler:Landroid/os/Handler;

.field private static idleStyle:I

.field private static final policy:Ldev/nino/squareglass/MotionPolicy;

.field private static final tick:Ldev/nino/squareglass/IconMotion$tick$1;


# direct methods
.method public static synthetic $r8$lambda$3Dp4PRN2OScJdjXmkx9-fPuU8LQ(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/LayoutCoordinates;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$24$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/LayoutCoordinates;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$6dmXf_GYDZGbWFPCaCHRfIYUv9s(Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableIntState;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$19$0(Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableIntState;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$BMOtxV--Ke_F2PVMdEdrSsa5Lsc(Landroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$26$0(Landroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ivl4e9B9EcSgBdskUtuNCHcdl2o(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)Z
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$20$0$0(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$JfJUMPP2JMtf2r4tKuDq3URC6nU(Landroidx/compose/runtime/State;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$20$0$1(Landroidx/compose/runtime/State;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$RoxybppyHnZ5bUWmupygxMVJ698(Landroidx/compose/runtime/State;Landroid/view/View;Landroidx/lifecycle/Lifecycle;Landroidx/compose/runtime/State;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$20$0(Landroidx/compose/runtime/State;Landroid/view/View;Landroidx/lifecycle/Lifecycle;Landroidx/compose/runtime/State;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Ldev/nino/squareglass/IconMotion;

    invoke-direct {v0}, Ldev/nino/squareglass/IconMotion;-><init>()V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    .line 33
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    .line 34
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    .line 35
    new-instance v0, Ldev/nino/squareglass/MotionPolicy;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/MotionPolicy;-><init>(J)V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->policy:Ldev/nino/squareglass/MotionPolicy;

    .line 38
    new-instance v0, Ldev/nino/squareglass/IconMotion$tick$1;

    invoke-direct {v0}, Ldev/nino/squareglass/IconMotion$tick$1;-><init>()V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    const/16 v0, 0x8

    sput v0, Ldev/nino/squareglass/IconMotion;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$decorate$lambda$11(Landroidx/compose/runtime/MutableState;)J
    .locals 2

    .line 31
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$11(Landroidx/compose/runtime/MutableState;)J

    move-result-wide v0

    return-wide v0
.end method

.method public static final synthetic access$decorate$lambda$12(Landroidx/compose/runtime/MutableState;J)V
    .locals 0

    .line 31
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$12(Landroidx/compose/runtime/MutableState;J)V

    return-void
.end method

.method public static final synthetic access$decorate$lambda$14(Landroidx/compose/runtime/MutableState;)Ljava/lang/Boolean;
    .locals 0

    .line 31
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$14(Landroidx/compose/runtime/MutableState;)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$decorate$lambda$15(Landroidx/compose/runtime/MutableState;Ljava/lang/Boolean;)V
    .locals 0

    .line 31
    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$15(Landroidx/compose/runtime/MutableState;Ljava/lang/Boolean;)V

    return-void
.end method

.method public static final synthetic access$decorate$lambda$17(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 31
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$17(Landroidx/compose/runtime/MutableIntState;)I

    move-result p0

    return p0
.end method

.method public static final synthetic access$decorate$lambda$18(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 0

    .line 31
    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$18(Landroidx/compose/runtime/MutableIntState;I)V

    return-void
.end method

.method public static final synthetic access$decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 31
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I

    move-result p0

    return p0
.end method

.method public static final synthetic access$decorate$lambda$5(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 31
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$5(Landroidx/compose/runtime/MutableIntState;)I

    move-result p0

    return p0
.end method

.method public static final synthetic access$getCursor$p()I
    .locals 1

    .line 31
    sget v0, Ldev/nino/squareglass/IconMotion;->cursor:I

    return v0
.end method

.method public static final synthetic access$getEntries$p()Ljava/util/ArrayList;
    .locals 1

    .line 31
    sget-object v0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static final synthetic access$getHandler$p()Landroid/os/Handler;
    .locals 1

    .line 31
    sget-object v0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    return-object v0
.end method

.method public static final synthetic access$getIdleStyle$p()I
    .locals 1

    .line 31
    sget v0, Ldev/nino/squareglass/IconMotion;->idleStyle:I

    return v0
.end method

.method public static final synthetic access$getPolicy$p()Ldev/nino/squareglass/MotionPolicy;
    .locals 1

    .line 31
    sget-object v0, Ldev/nino/squareglass/IconMotion;->policy:Ldev/nino/squareglass/MotionPolicy;

    return-object v0
.end method

.method public static final synthetic access$getTick$p()Ldev/nino/squareglass/IconMotion$tick$1;
    .locals 1

    .line 31
    sget-object v0, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    return-object v0
.end method

.method public static final synthetic access$interacted(Ldev/nino/squareglass/IconMotion;Z)V
    .locals 0

    .line 31
    invoke-direct {p0, p1}, Ldev/nino/squareglass/IconMotion;->interacted(Z)V

    return-void
.end method

.method public static final synthetic access$setCursor$p(I)V
    .locals 0

    .line 31
    sput p0, Ldev/nino/squareglass/IconMotion;->cursor:I

    return-void
.end method

.method public static final synthetic access$setIdleStyle$p(I)V
    .locals 0

    .line 31
    sput p0, Ldev/nino/squareglass/IconMotion;->idleStyle:I

    return-void
.end method

.method private final decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 21

    move/from16 v0, p3

    move-object/from16 v1, p4

    move-object/from16 v6, p5

    move/from16 v8, p6

    const-string v2, "C(decorate)N(original,key,pulse,liked)90@4309L7,91@4359L7,92@4398L25,93@4445L31,94@4497L31,95@4551L36,96@4611L34,97@4674L32,98@4736L35,100@4847L47,101@4918L26,102@4970L28,103@5044L800,103@5007L837,117@5875L78,117@5853L100,120@5984L330,120@5962L352,130@6352L192,130@6323L221,136@6590L28,137@6650L953,156@7620L1395:IconMotion.kt#vqphja"

    const v3, 0x2c0a9bc9

    .line 89
    invoke-static {v6, v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, -0x1

    const-string v4, "dev.nino.squareglass.IconMotion.decorate (IconMotion.kt:88)"

    invoke-static {v3, v8, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 90
    :cond_0
    sget-object v2, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v2}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 91
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalView()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v2

    check-cast v2, Landroidx/compose/runtime/CompositionLocal;

    const v3, 0x789c5f52

    .line 186
    const-string v4, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 91
    check-cast v2, Landroid/view/View;

    .line 92
    invoke-static {}, Landroidx/lifecycle/compose/LocalLifecycleOwnerKt;->getLocalLifecycleOwner()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v5

    check-cast v5, Landroidx/compose/runtime/CompositionLocal;

    .line 187
    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    check-cast v3, Landroidx/lifecycle/LifecycleOwner;

    .line 92
    invoke-interface {v3}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    move-result-object v3

    const v4, 0x53d2e9e2

    .line 93
    const-string v9, "CC(remember):IconMotion.kt#9igjgp"

    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 188
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 189
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x2

    const/4 v10, 0x0

    if-ne v4, v5, :cond_1

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v5, 0x0

    .line 93
    invoke-static {v4, v5, v7, v10}, Landroidx/compose/animation/core/AnimatableKt;->Animatable$default(FFILjava/lang/Object;)Landroidx/compose/animation/core/Animatable;

    move-result-object v4

    .line 191
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 93
    :cond_1
    move-object v13, v4

    check-cast v13, Landroidx/compose/animation/core/Animatable;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d2efc8

    .line 94
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 194
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 195
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    const/4 v11, 0x0

    if-ne v4, v5, :cond_2

    .line 94
    invoke-static {v11}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v4

    .line 197
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 94
    :cond_2
    move-object v14, v4

    check-cast v14, Landroidx/compose/runtime/MutableIntState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d2f648

    .line 95
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 200
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 201
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_3

    .line 95
    invoke-static {v11}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v4

    .line 203
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 95
    :cond_3
    move-object v15, v4

    check-cast v15, Landroidx/compose/runtime/MutableIntState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d2fd0d

    .line 96
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 206
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 207
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_4

    .line 96
    sget-object v4, Landroidx/compose/ui/geometry/Rect;->Companion:Landroidx/compose/ui/geometry/Rect$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/geometry/Rect$Companion;->getZero()Landroidx/compose/ui/geometry/Rect;

    move-result-object v4

    invoke-static {v4, v10, v7, v10}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 209
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 96
    :cond_4
    move-object v12, v4

    check-cast v12, Landroidx/compose/runtime/MutableState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d3048b

    .line 97
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 212
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 213
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_5

    const-wide/16 v4, -0x4e20

    .line 97
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-static {v4, v10, v7, v10}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 215
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 97
    :cond_5
    move-object/from16 v16, v4

    check-cast v16, Landroidx/compose/runtime/MutableState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d30c69

    .line 98
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 218
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 219
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_6

    .line 98
    invoke-static {v1, v10, v7, v10}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 221
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 98
    :cond_6
    move-object/from16 v17, v4

    check-cast v17, Landroidx/compose/runtime/MutableState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d3142c

    .line 99
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 224
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 225
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_7

    .line 99
    invoke-static {v0}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v4

    .line 227
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 99
    :cond_7
    check-cast v4, Landroidx/compose/runtime/MutableIntState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object/from16 v18, v12

    .line 100
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v12

    const v5, 0x53d32218

    .line 101
    invoke-static {v6, v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 230
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .line 231
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_8

    .line 101
    new-instance v5, Ldev/nino/squareglass/IconMotion$4;

    invoke-direct {v5, v15, v14}, Ldev/nino/squareglass/IconMotion$4;-><init>(Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableIntState;)V

    .line 233
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 101
    :cond_8
    check-cast v5, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v7, 0x6

    .line 102
    invoke-static {v5, v6, v7}, Landroidx/compose/runtime/SnapshotStateKt;->rememberUpdatedState(Ljava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/State;

    move-result-object v7

    .line 103
    invoke-static/range {v18 .. v18}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$8(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/geometry/Rect;

    move-result-object v10

    invoke-static {v10, v6, v11}, Landroidx/compose/runtime/SnapshotStateKt;->rememberUpdatedState(Ljava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/State;

    move-result-object v10

    move-object/from16 v19, v4

    .line 104
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const v11, 0x53d33da9

    invoke-static {v6, v11, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v10}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v11

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v20

    or-int v11, v11, v20

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v20

    or-int v11, v11, v20

    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v20

    or-int v11, v11, v20

    move-object/from16 v20, v4

    .line 236
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    if-nez v11, :cond_9

    .line 237
    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v4, v11, :cond_a

    .line 104
    :cond_9
    new-instance v4, Ldev/nino/squareglass/IconMotion$5;

    invoke-direct {v4, v10, v2, v3, v7}, Ldev/nino/squareglass/IconMotion$5;-><init>(Landroidx/compose/runtime/State;Landroid/view/View;Landroidx/lifecycle/Lifecycle;Landroidx/compose/runtime/State;)V

    .line 239
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 104
    :cond_a
    check-cast v4, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    shl-int/lit8 v7, v8, 0x3

    and-int/lit16 v7, v7, 0x380

    move-object v11, v5

    move-object/from16 v10, v19

    move-object v5, v4

    move-object/from16 v4, v20

    invoke-static/range {v2 .. v7}, Landroidx/compose/runtime/EffectsKt;->DisposableEffect(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lam0/l;Landroidx/compose/runtime/Composer;I)V

    .line 118
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const v3, 0x53d3a2b7

    invoke-static {v6, v3, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit16 v3, v8, 0x380

    xor-int/lit16 v3, v3, 0x180

    const/4 v4, 0x1

    const/16 v5, 0x100

    if-le v3, v5, :cond_b

    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v3

    if-nez v3, :cond_c

    :cond_b
    and-int/lit16 v3, v8, 0x180

    if-ne v3, v5, :cond_d

    :cond_c
    move v3, v4

    goto :goto_0

    :cond_d
    const/4 v3, 0x0

    .line 242
    :goto_0
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    if-nez v3, :cond_e

    .line 243
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v5, v3, :cond_f

    .line 118
    :cond_e
    new-instance v3, Ldev/nino/squareglass/IconMotion$decorate$2$1;

    const/4 v5, 0x0

    invoke-direct {v3, v0, v11, v10, v5}, Ldev/nino/squareglass/IconMotion$decorate$2$1;-><init>(ILam0/l;Landroidx/compose/runtime/MutableIntState;Lkotlin/coroutines/e;)V

    move-object v5, v3

    check-cast v5, Lam0/p;

    .line 245
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 118
    :cond_f
    check-cast v5, Lam0/p;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    shr-int/lit8 v0, v8, 0x6

    and-int/lit8 v0, v0, 0xe

    invoke-static {v2, v5, v6, v0}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lam0/p;Landroidx/compose/runtime/Composer;I)V

    const v0, 0x53d3b153

    .line 121
    invoke-static {v6, v0, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit16 v0, v8, 0x1c00

    xor-int/lit16 v0, v0, 0xc00

    const/16 v2, 0x800

    if-le v0, v2, :cond_10

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12

    :cond_10
    and-int/lit16 v0, v8, 0xc00

    if-ne v0, v2, :cond_11

    goto :goto_1

    :cond_11
    const/4 v4, 0x0

    .line 248
    :cond_12
    :goto_1
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    if-nez v4, :cond_14

    .line 249
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v0, v2, :cond_13

    goto :goto_2

    :cond_13
    move-object v2, v11

    move-object/from16 v4, v16

    goto :goto_3

    .line 121
    :cond_14
    :goto_2
    new-instance v0, Ldev/nino/squareglass/IconMotion$decorate$3$1;

    const/4 v5, 0x0

    move-object v2, v11

    move-object/from16 v4, v16

    move-object/from16 v3, v17

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/IconMotion$decorate$3$1;-><init>(Ljava/lang/Boolean;Lam0/l;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V

    check-cast v0, Lam0/p;

    .line 251
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 121
    :goto_3
    check-cast v0, Lam0/p;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    shr-int/lit8 v3, v8, 0x9

    and-int/lit8 v3, v3, 0xe

    invoke-static {v1, v0, v6, v3}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lam0/p;Landroidx/compose/runtime/Composer;I)V

    .line 131
    invoke-static {v14}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const v3, 0x53d3dec9

    invoke-static {v6, v3, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v12}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v3

    invoke-interface {v6, v13}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v3, v5

    .line 254
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    if-nez v3, :cond_16

    .line 255
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v5, v3, :cond_15

    goto :goto_4

    :cond_15
    move-object v7, v5

    move-object/from16 v3, v18

    const/4 v5, 0x0

    goto :goto_5

    .line 131
    :cond_16
    :goto_4
    new-instance v11, Ldev/nino/squareglass/IconMotion$decorate$4$1;

    const/16 v16, 0x0

    move-object/from16 v3, v18

    const/4 v5, 0x0

    invoke-direct/range {v11 .. v16}, Ldev/nino/squareglass/IconMotion$decorate$4$1;-><init>(ZLandroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableIntState;Lkotlin/coroutines/e;)V

    move-object v7, v11

    check-cast v7, Lam0/p;

    .line 257
    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 131
    :goto_5
    check-cast v7, Lam0/p;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v0, v1, v7, v6, v5}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Ljava/lang/Object;Lam0/p;Landroidx/compose/runtime/Composer;I)V

    const v0, 0x53d3fbe5

    .line 137
    invoke-static {v6, v0, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 260
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .line 261
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_17

    .line 137
    new-instance v0, Ldev/nino/squareglass/IconMotion$6;

    invoke-direct {v0, v3}, Ldev/nino/squareglass/IconMotion$6;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 263
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 137
    :cond_17
    check-cast v0, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Landroidx/compose/ui/layout/OnGloballyPositionedModifierKt;->onGloballyPositioned(Landroidx/compose/ui/Modifier;Lam0/l;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 138
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const v3, 0x53d40702

    invoke-static {v6, v3, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 266
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 267
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v3, v5, :cond_18

    .line 138
    new-instance v3, Ldev/nino/squareglass/IconMotion$decorate$6$1;

    invoke-direct {v3, v2, v4}, Ldev/nino/squareglass/IconMotion$decorate$6$1;-><init>(Lam0/l;Landroidx/compose/runtime/MutableState;)V

    check-cast v3, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 269
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 138
    :cond_18
    check-cast v3, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v0, v1, v3}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->pointerInput(Landroidx/compose/ui/Modifier;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const v1, 0x53d481fc

    .line 157
    invoke-static {v6, v1, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v13}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .line 272
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    if-nez v1, :cond_19

    .line 273
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v2, v1, :cond_1a

    .line 157
    :cond_19
    new-instance v2, Ldev/nino/squareglass/IconMotion$7;

    invoke-direct {v2, v13, v15}, Ldev/nino/squareglass/IconMotion$7;-><init>(Landroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/MutableIntState;)V

    .line 275
    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 157
    :cond_1a
    check-cast v2, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v0, v2}, Landroidx/compose/ui/draw/DrawModifierKt;->drawWithContent(Landroidx/compose/ui/Modifier;Lam0/l;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 89
    :cond_1b
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object v0
.end method

.method private static final decorate$lambda$11(Landroidx/compose/runtime/MutableState;)J
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;)J"
        }
    .end annotation

    .line 97
    check-cast p0, Landroidx/compose/runtime/State;

    .line 312
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    return-wide v0
.end method

.method private static final decorate$lambda$12(Landroidx/compose/runtime/MutableState;J)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;J)V"
        }
    .end annotation

    .line 97
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    .line 313
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private static final decorate$lambda$14(Landroidx/compose/runtime/MutableState;)Ljava/lang/Boolean;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Boolean;"
        }
    .end annotation

    .line 98
    check-cast p0, Landroidx/compose/runtime/State;

    .line 315
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    return-object p0
.end method

.method private static final decorate$lambda$15(Landroidx/compose/runtime/MutableState;Ljava/lang/Boolean;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Ljava/lang/Boolean;",
            ")V"
        }
    .end annotation

    .line 316
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private static final decorate$lambda$17(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 99
    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 318
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method

.method private static final decorate$lambda$18(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 0

    .line 319
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method

.method private static final decorate$lambda$19$0(Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableIntState;I)Lkotlin/u;
    .locals 1

    .line 101
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p0, p2}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$6(Landroidx/compose/runtime/MutableIntState;I)V

    invoke-static {p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I

    move-result p0

    add-int/lit8 p0, p0, 0x1

    invoke-static {p1, p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$3(Landroidx/compose/runtime/MutableIntState;I)V

    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 94
    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 303
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method

.method private static final decorate$lambda$20$0(Landroidx/compose/runtime/State;Landroid/view/View;Landroidx/lifecycle/Lifecycle;Landroidx/compose/runtime/State;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 2

    const-string v0, "$this$DisposableEffect"

    invoke-static {p4, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p4, 0x2

    .line 105
    new-array p4, p4, [I

    .line 106
    new-instance v0, Ldev/nino/squareglass/IconMotion$Entry;

    new-instance v1, Ldev/nino/squareglass/IconMotion$2;

    invoke-direct {v1, p0, p1, p4, p2}, Ldev/nino/squareglass/IconMotion$2;-><init>(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)V

    new-instance p0, Ldev/nino/squareglass/IconMotion$3;

    invoke-direct {p0, p3}, Ldev/nino/squareglass/IconMotion$3;-><init>(Landroidx/compose/runtime/State;)V

    invoke-direct {v0, v1, p0}, Ldev/nino/squareglass/IconMotion$Entry;-><init>(Lam0/a;Lam0/l;)V

    .line 114
    sget-object p0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz p1, :cond_0

    .line 115
    sget-object p0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    sget-object p1, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    check-cast p1, Ljava/lang/Runnable;

    const-wide/16 p2, 0x1f4

    invoke-virtual {p0, p1, p2, p3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 278
    :cond_0
    new-instance p0, Ldev/nino/squareglass/IconMotion$decorate$lambda$20$0$$inlined$onDispose$1;

    invoke-direct {p0, v0}, Ldev/nino/squareglass/IconMotion$decorate$lambda$20$0$$inlined$onDispose$1;-><init>(Ldev/nino/squareglass/IconMotion$Entry;)V

    check-cast p0, Landroidx/compose/runtime/DisposableEffectResult;

    return-object p0
.end method

.method private static final decorate$lambda$20$0$0(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)Z
    .locals 11

    .line 107
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/geometry/Rect;

    .line 108
    invoke-virtual {p1, p2}, Landroid/view/View;->getLocationInWindow([I)V

    .line 109
    invoke-virtual {p1}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-static {}, Landroid/view/WindowInsets$Type;->ime()I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/view/WindowInsets;->isVisible(I)Z

    move-result v0

    if-ne v0, v1, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    .line 110
    :goto_0
    invoke-virtual {p1}, Landroid/view/View;->isShown()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-virtual {p1}, Landroid/view/View;->hasWindowFocus()Z

    move-result v3

    if-eqz v3, :cond_1

    if-nez v0, :cond_1

    .line 111
    invoke-virtual {p3}, Landroidx/lifecycle/Lifecycle;->getCurrentState()Landroidx/lifecycle/Lifecycle$State;

    move-result-object p3

    sget-object v0, Landroidx/lifecycle/Lifecycle$State;->RESUMED:Landroidx/lifecycle/Lifecycle$State;

    invoke-virtual {p3, v0}, Landroidx/lifecycle/Lifecycle$State;->isAtLeast(Landroidx/lifecycle/Lifecycle$State;)Z

    move-result p3

    if-eqz p3, :cond_1

    .line 112
    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getLeft()F

    move-result v3

    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getTop()F

    move-result v4

    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getRight()F

    move-result v5

    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getBottom()F

    move-result v6

    aget p0, p2, v2

    int-to-float v7, p0

    aget p0, p2, v1

    int-to-float v8, p0

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p0

    int-to-float v9, p0

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p0

    int-to-float v10, p0

    invoke-static/range {v3 .. v10}, Ldev/nino/squareglass/MotionPolicy;->visible(FFFFFFFF)Z

    move-result p0

    if-eqz p0, :cond_1

    return v1

    :cond_1
    return v2
.end method

.method private static final decorate$lambda$20$0$1(Landroidx/compose/runtime/State;I)Lkotlin/u;
    .locals 0

    .line 113
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lam0/l;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final decorate$lambda$24$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/LayoutCoordinates;)Lkotlin/u;
    .locals 1

    const-string v0, "it"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    invoke-static {p1}, Landroidx/compose/ui/layout/LayoutCoordinatesKt;->boundsInWindow(Landroidx/compose/ui/layout/LayoutCoordinates;)Landroidx/compose/ui/geometry/Rect;

    move-result-object p1

    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$9(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/geometry/Rect;)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final decorate$lambda$26$0(Landroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;
    .locals 25

    move-object/from16 v0, p2

    const-string v1, "$this$drawWithContent"

    invoke-static {v0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 158
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v1

    const/high16 v2, 0x3f800000    # 1.0f

    if-eqz v1, :cond_0

    invoke-virtual/range {p0 .. p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    const v3, 0x40490fdb    # (float)Math.PI

    mul-float v4, v1, v3

    float-to-double v5, v4

    .line 159
    invoke-static {v5, v6}, Ljava/lang/Math;->sin(D)D

    move-result-wide v5

    double-to-float v5, v5

    .line 160
    invoke-static/range {p1 .. p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$5(Landroidx/compose/runtime/MutableIntState;)I

    move-result v6

    const v7, 0x3df5c28f    # 0.12f

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/high16 v10, 0x40000000    # 2.0f

    if-eq v6, v9, :cond_2

    if-eq v6, v8, :cond_1

    const v6, 0x3e19999a    # 0.15f

    mul-float/2addr v6, v5

    :goto_1
    sub-float v7, v2, v1

    mul-float/2addr v6, v7

    add-float/2addr v6, v2

    goto :goto_2

    :cond_1
    mul-float v6, v4, v10

    float-to-double v11, v6

    invoke-static {v11, v12}, Ljava/lang/Math;->sin(D)D

    move-result-wide v11

    double-to-float v6, v11

    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v6

    mul-float/2addr v6, v7

    goto :goto_1

    :cond_2
    mul-float/2addr v7, v5

    sub-float v6, v2, v7

    .line 161
    :goto_2
    invoke-static/range {p1 .. p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$5(Landroidx/compose/runtime/MutableIntState;)I

    move-result v7

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-eq v7, v11, :cond_4

    if-eq v7, v9, :cond_4

    const/4 v9, 0x4

    if-eq v7, v9, :cond_3

    if-eq v7, v8, :cond_4

    const/high16 v7, 0x40800000    # 4.0f

    mul-float/2addr v4, v7

    float-to-double v7, v4

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v4, v7

    sub-float v7, v2, v1

    mul-float/2addr v4, v7

    const/high16 v7, 0x40e00000    # 7.0f

    goto :goto_3

    :cond_3
    mul-float/2addr v4, v10

    float-to-double v7, v4

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v4, v7

    sub-float v7, v2, v1

    mul-float/2addr v4, v7

    const/high16 v7, 0x41200000    # 10.0f

    :goto_3
    mul-float/2addr v4, v7

    goto :goto_4

    :cond_4
    move v4, v12

    :goto_4
    neg-float v7, v5

    const/high16 v8, 0x40200000    # 2.5f

    mul-float/2addr v7, v8

    .line 162
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getDensity()F

    move-result v9

    mul-float/2addr v7, v9

    .line 163
    move-object v13, v0

    check-cast v13, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 283
    invoke-interface {v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v9

    .line 287
    invoke-interface {v9}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getSize-NH-jbRc()J

    move-result-wide v14

    .line 288
    invoke-interface {v9}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v16

    invoke-interface/range {v16 .. v16}, Landroidx/compose/ui/graphics/Canvas;->save()V

    move/from16 p0, v3

    .line 290
    :try_start_0
    invoke-interface {v9}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v3

    .line 164
    invoke-interface {v3, v12, v7}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    move-object/from16 v16, v13

    .line 165
    invoke-interface {v3}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->getCenter-F1C5BW0()J

    move-result-wide v12

    invoke-interface {v3, v4, v12, v13}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->rotate-Uv8p0NA(FJ)V

    invoke-interface {v3}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->getCenter-F1C5BW0()J

    move-result-wide v12

    invoke-interface {v3, v6, v6, v12, v13}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->scale-0AR0LA0(FFJ)V

    .line 166
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 293
    invoke-interface {v9}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v3

    invoke-interface {v3}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 294
    invoke-interface {v9, v14, v15}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    .line 167
    invoke-static/range {p1 .. p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$5(Landroidx/compose/runtime/MutableIntState;)I

    move-result v3

    if-ne v3, v11, :cond_5

    cmpg-float v3, v1, v2

    if-gez v3, :cond_5

    const-wide v3, 0xffff6899L

    .line 168
    invoke-static {v3, v4}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v17

    sub-float v3, v2, v1

    const/4 v7, 0x0

    invoke-static {v3, v7, v2}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result v19

    const/16 v23, 0xe

    const/16 v24, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    invoke-static/range {v17 .. v24}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v2

    const/4 v4, 0x0

    :goto_5
    const/4 v6, 0x6

    if-ge v4, v6, :cond_5

    int-to-float v6, v4

    const/high16 v7, 0x42700000    # 60.0f

    mul-float/2addr v6, v7

    const/high16 v7, 0x42b40000    # 90.0f

    sub-float/2addr v6, v7

    mul-float v6, v6, p0

    const/high16 v7, 0x43340000    # 180.0f

    div-float/2addr v6, v7

    const/high16 v7, 0x41c00000    # 24.0f

    mul-float/2addr v7, v1

    const/high16 v9, 0x41400000    # 12.0f

    add-float/2addr v7, v9

    .line 171
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getDensity()F

    move-result v9

    mul-float/2addr v7, v9

    .line 172
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getCenter-F1C5BW0()J

    move-result-wide v11

    const/16 v9, 0x20

    shr-long/2addr v11, v9

    long-to-int v9, v11

    .line 299
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v9

    float-to-double v11, v6

    .line 172
    invoke-static {v11, v12}, Ljava/lang/Math;->cos(D)D

    move-result-wide v13

    double-to-float v6, v13

    mul-float/2addr v6, v7

    add-float/2addr v9, v6

    .line 173
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getCenter-F1C5BW0()J

    move-result-wide v13

    const-wide v17, 0xffffffffL

    and-long v13, v13, v17

    long-to-int v6, v13

    .line 302
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v6

    .line 173
    invoke-static {v11, v12}, Ljava/lang/Math;->sin(D)D

    move-result-wide v11

    double-to-float v11, v11

    mul-float/2addr v11, v7

    add-float/2addr v6, v11

    const/high16 v7, 0x41000000    # 8.0f

    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getDensity()F

    move-result v11

    mul-float/2addr v11, v7

    mul-float/2addr v11, v1

    sub-float/2addr v6, v11

    const/high16 v7, 0x3fc00000    # 1.5f

    mul-float/2addr v7, v5

    add-float/2addr v7, v8

    .line 174
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getDensity()F

    move-result v11

    mul-float/2addr v7, v11

    .line 175
    invoke-static {}, Landroidx/compose/ui/graphics/AndroidPath_androidKt;->Path()Landroidx/compose/ui/graphics/Path;

    move-result-object v14

    add-float v11, v6, v7

    .line 176
    invoke-interface {v14, v9, v11}, Landroidx/compose/ui/graphics/Path;->moveTo(FF)V

    mul-float v12, v7, v10

    sub-float v18, v9, v12

    const v13, 0x3e99999a    # 0.3f

    mul-float/2addr v13, v7

    sub-float v19, v6, v13

    sub-float v20, v9, v7

    sub-float v21, v6, v12

    const v13, 0x3f333333    # 0.7f

    mul-float/2addr v13, v7

    sub-float v23, v6, v13

    move/from16 v22, v9

    move-object/from16 v17, v14

    invoke-interface/range {v17 .. v23}, Landroidx/compose/ui/graphics/Path;->cubicTo(FFFFFF)V

    add-float v18, v22, v7

    add-float v20, v22, v12

    move/from16 v23, v21

    move/from16 v21, v19

    move/from16 v19, v23

    move/from16 v23, v11

    .line 177
    invoke-interface/range {v17 .. v23}, Landroidx/compose/ui/graphics/Path;->cubicTo(FFFFFF)V

    invoke-interface/range {v17 .. v17}, Landroidx/compose/ui/graphics/Path;->close()V

    const/16 v21, 0x3c

    const/16 v22, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    move-object/from16 v13, v16

    move-wide v15, v2

    .line 179
    invoke-static/range {v13 .. v22}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawPath-LG529CI$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Path;JFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    add-int/lit8 v4, v4, 0x1

    move-object/from16 v16, v13

    goto/16 :goto_5

    .line 182
    :cond_5
    sget-object v0, Lkotlin/u;->a:Lkotlin/u;

    return-object v0

    :catchall_0
    move-exception v0

    .line 293
    invoke-interface {v9}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v1

    invoke-interface {v1}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 294
    invoke-interface {v9, v14, v15}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    throw v0
.end method

.method private static final decorate$lambda$3(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 0

    .line 304
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method

.method private static final decorate$lambda$5(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 95
    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 306
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method

.method private static final decorate$lambda$6(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 0

    .line 307
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method

.method private static final decorate$lambda$8(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/geometry/Rect;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Landroidx/compose/ui/geometry/Rect;",
            ">;)",
            "Landroidx/compose/ui/geometry/Rect;"
        }
    .end annotation

    .line 96
    check-cast p0, Landroidx/compose/runtime/State;

    .line 309
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/geometry/Rect;

    return-object p0
.end method

.method private static final decorate$lambda$9(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/geometry/Rect;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Landroidx/compose/ui/geometry/Rect;",
            ">;",
            "Landroidx/compose/ui/geometry/Rect;",
            ")V"
        }
    .end annotation

    .line 310
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public static final favorite(Landroidx/compose/ui/Modifier;ZLandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 10

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(favorite)N(original,liked)85@4007L28:IconMotion.kt#vqphja"

    const v1, -0x2e6fcbec

    .line 86
    invoke-static {p2, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.IconMotion.favorite (IconMotion.kt:85)"

    invoke-static {v1, p3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    sget-object v3, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    and-int/lit8 p1, p3, 0xe

    or-int/lit16 p1, p1, 0x1b0

    shl-int/lit8 p3, p3, 0x6

    and-int/lit16 v0, p3, 0x1c00

    or-int/2addr p1, v0

    const v0, 0xe000

    and-int/2addr p3, v0

    or-int v9, p1, p3

    const/4 v5, 0x7

    const/4 v6, 0x0

    move-object v4, p0

    move-object v8, p2

    invoke-direct/range {v3 .. v9}, Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method private final interacted(Z)V
    .locals 2

    .line 60
    sget-object p0, Ldev/nino/squareglass/IconMotion;->policy:Ldev/nino/squareglass/MotionPolicy;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1, p1}, Ldev/nino/squareglass/MotionPolicy;->touch(JZ)V

    return-void
.end method

.method public static final registerNative(Landroid/view/View;Ljava/util/function/IntConsumer;)Ljava/lang/Object;
    .locals 3

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fire"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 62
    new-instance v0, Ldev/nino/squareglass/IconMotion$Entry;

    new-instance v1, Ldev/nino/squareglass/IconMotion$0;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/IconMotion$0;-><init>(Landroid/view/View;)V

    new-instance p0, Ldev/nino/squareglass/IconMotion$1;

    invoke-direct {p0, p1}, Ldev/nino/squareglass/IconMotion$1;-><init>(Ljava/util/function/IntConsumer;)V

    invoke-direct {v0, v1, p0}, Ldev/nino/squareglass/IconMotion$Entry;-><init>(Lam0/a;Lam0/l;)V

    .line 67
    sget-object p0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz p1, :cond_0

    .line 68
    sget-object p0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    sget-object p1, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    check-cast p1, Ljava/lang/Runnable;

    const-wide/16 v1, 0x1f4

    invoke-virtual {p0, p1, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-object v0
.end method

.method static final registerNative$lambda$0(Landroid/view/View;)Z
    .locals 2

    .line 63
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 64
    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->hasWindowFocus()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0, v0}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 65
    invoke-virtual {p0}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object p0

    const/4 v0, 0x1

    if-eqz p0, :cond_0

    invoke-static {}, Landroid/view/WindowInsets$Type;->ime()I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/WindowInsets;->isVisible(I)Z

    move-result p0

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    return v0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return p0
.end method

.method static final registerNative$lambda$1(Ljava/util/function/IntConsumer;I)Lkotlin/u;
    .locals 0

    .line 66
    invoke-interface {p0, p1}, Ljava/util/function/IntConsumer;->accept(I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method public static final settings(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 10

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(settings)N(original)82@3733L27:IconMotion.kt#vqphja"

    const v1, -0x29fba5af

    .line 83
    invoke-static {p1, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.IconMotion.settings (IconMotion.kt:82)"

    invoke-static {v1, p2, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    sget-object v3, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    and-int/lit8 v0, p2, 0xe

    or-int/lit16 v0, v0, 0xdb0

    shl-int/lit8 p2, p2, 0x9

    const v1, 0xe000

    and-int/2addr p2, v1

    or-int v9, v0, p2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v4, p0

    move-object v8, p1

    invoke-direct/range {v3 .. v9}, Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method public static final settingsResource(Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 3

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(settingsResource)N(original,resource):IconMotion.kt#vqphja"

    const v1, -0x51ec8cba

    .line 85
    invoke-static {p2, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.IconMotion.settingsResource (IconMotion.kt:84)"

    invoke-static {v1, p3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    const v0, 0x7f08048e

    if-ne p1, v0, :cond_1

    const p1, 0x7703c638

    invoke-interface {p2, p1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string p1, "84@3887L18"

    invoke-static {p2, p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 p1, p3, 0xe

    shr-int/lit8 p3, p3, 0x3

    and-int/lit8 p3, p3, 0x70

    or-int/2addr p1, p3

    invoke-static {p0, p2, p1}, Ldev/nino/squareglass/IconMotion;->settings(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    goto :goto_0

    :cond_1
    const p1, 0x7703c92e

    invoke-interface {p2, p1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_0
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_2
    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method public static final touch(Landroid/view/MotionEvent;)V
    .locals 5

    const-string v0, "event"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p0

    .line 58
    sget-object v0, Ldev/nino/squareglass/IconMotion;->policy:Ldev/nino/squareglass/MotionPolicy;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    const/4 v3, 0x1

    if-eq p0, v3, :cond_0

    const/4 v4, 0x3

    if-eq p0, v4, :cond_0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    :goto_0
    invoke-virtual {v0, v1, v2, v3}, Ldev/nino/squareglass/MotionPolicy;->touch(JZ)V

    return-void
.end method

.method public static final unregisterNative(Ljava/lang/Object;)V
    .locals 1

    const-string v0, "token"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    sget-object v0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    check-cast p0, Ldev/nino/squareglass/IconMotion$Entry;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_0

    sget-object p0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    sget-object v0, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    check-cast v0, Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public final icon(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 8

    const-string v0, "original"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(icon)N(original,key,pulse)86@4113L33:IconMotion.kt#vqphja"

    const v1, -0x30ec217f

    .line 87
    invoke-static {p4, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.IconMotion.icon (IconMotion.kt:86)"

    invoke-static {v1, p5, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    and-int/lit8 v0, p5, 0xe

    or-int/lit16 v0, v0, 0xc00

    and-int/lit8 v1, p5, 0x70

    or-int/2addr v0, v1

    and-int/lit16 v1, p5, 0x380

    or-int/2addr v0, v1

    shl-int/lit8 p5, p5, 0x3

    const v1, 0xe000

    and-int/2addr p5, v1

    or-int v7, v0, p5

    const/4 v5, 0x0

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move v4, p3

    move-object v6, p4

    invoke-direct/range {v1 .. v7}, Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method public final watch(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;
    .locals 1

    const-string p0, "original"

    invoke-static {p1, p0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    sget-object v0, Ldev/nino/squareglass/IconMotion$watch$1;->INSTANCE:Ldev/nino/squareglass/IconMotion$watch$1;

    check-cast v0, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    invoke-static {p1, p0, v0}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->pointerInput(Landroidx/compose/ui/Modifier;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method
