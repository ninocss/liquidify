.class public final Ldev/nino/squareglass/OutputSelection;
.super Ljava/lang/Object;
.source "OutputSelection.java"


# instance fields
.field private expires:J

.field private revision:I

.field private target:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public accepts(I)Z
    .locals 0

    .line 9
    iget p0, p0, Ldev/nino/squareglass/OutputSelection;->revision:I

    if-ne p1, p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public begin(Ljava/lang/String;J)V
    .locals 2

    .line 11
    iget-object v0, p0, Ldev/nino/squareglass/OutputSelection;->target:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iput-object p1, p0, Ldev/nino/squareglass/OutputSelection;->target:Ljava/lang/String;

    const-wide/16 v0, 0x3a98

    add-long/2addr p2, v0

    iput-wide p2, p0, Ldev/nino/squareglass/OutputSelection;->expires:J

    :cond_0
    return-void
.end method

.method public deadline(Ljava/lang/String;JJ)V
    .locals 2

    .line 12
    iput-object p1, p0, Ldev/nino/squareglass/OutputSelection;->target:Ljava/lang/String;

    const-wide/16 v0, 0x0

    invoke-static {v0, v1, p4, p5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p4

    add-long/2addr p2, p4

    iput-wide p2, p0, Ldev/nino/squareglass/OutputSelection;->expires:J

    return-void
.end method

.method public failed()V
    .locals 1

    const/4 v0, 0x0

    .line 21
    iput-object v0, p0, Ldev/nino/squareglass/OutputSelection;->target:Ljava/lang/String;

    return-void
.end method

.method public invalidate()V
    .locals 1

    .line 10
    iget v0, p0, Ldev/nino/squareglass/OutputSelection;->revision:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ldev/nino/squareglass/OutputSelection;->revision:I

    return-void
.end method

.method public nextRequest()I
    .locals 1

    .line 8
    iget v0, p0, Ldev/nino/squareglass/OutputSelection;->revision:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ldev/nino/squareglass/OutputSelection;->revision:I

    return v0
.end method

.method public observe(Ljava/lang/String;J)I
    .locals 4

    .line 16
    iget-object v0, p0, Ldev/nino/squareglass/OutputSelection;->target:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 17
    :cond_0
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v0, 0x0

    if-eqz p1, :cond_1

    iput-object v0, p0, Ldev/nino/squareglass/OutputSelection;->target:Ljava/lang/String;

    const/4 p0, 0x1

    return p0

    .line 18
    :cond_1
    iget-wide v2, p0, Ldev/nino/squareglass/OutputSelection;->expires:J

    cmp-long p1, p2, v2

    if-ltz p1, :cond_2

    iput-object v0, p0, Ldev/nino/squareglass/OutputSelection;->target:Ljava/lang/String;

    const/4 p0, -0x1

    return p0

    :cond_2
    return v1
.end method

.method public target()Ljava/lang/String;
    .locals 0

    .line 13
    iget-object p0, p0, Ldev/nino/squareglass/OutputSelection;->target:Ljava/lang/String;

    return-object p0
.end method
