.class final Ldev/nino/squareglass/NativePlayback$Entry;
.super Ljava/lang/Object;
.source "NativePlayback.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/NativePlayback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Entry"
.end annotation


# instance fields
.field hours:[I

.field last:J

.field track:Lcom/aspiro/wamp/model/Track;


# direct methods
.method constructor <init>()V
    .locals 1

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x18

    .line 33
    new-array v0, v0, [I

    iput-object v0, p0, Ldev/nino/squareglass/NativePlayback$Entry;->hours:[I

    return-void
.end method
