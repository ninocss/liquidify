.class public final synthetic Ldev/nino/squareglass/PageGlass$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/PageGlass;

.field public final synthetic f$1:F

.field public final synthetic f$2:Z

.field public final synthetic f$3:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/PageGlass;FZI)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PageGlass$0;->f$0:Ldev/nino/squareglass/PageGlass;

    iput p2, p0, Ldev/nino/squareglass/PageGlass$0;->f$1:F

    iput-boolean p3, p0, Ldev/nino/squareglass/PageGlass$0;->f$2:Z

    iput p4, p0, Ldev/nino/squareglass/PageGlass$0;->f$3:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/PageGlass$0;->f$0:Ldev/nino/squareglass/PageGlass;

    iget v1, p0, Ldev/nino/squareglass/PageGlass$0;->f$1:F

    iget-boolean v2, p0, Ldev/nino/squareglass/PageGlass$0;->f$2:Z

    iget v3, p0, Ldev/nino/squareglass/PageGlass$0;->f$3:I

    move-object v4, p1

    check-cast v4, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/PageGlass;->Surface$lambda$0(Ldev/nino/squareglass/PageGlass;FZILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
