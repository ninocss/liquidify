.class public final synthetic Ldev/nino/squareglass/LiquidViewMotion$animate$job$1$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ljava/util/function/Consumer;

.field public final synthetic f$1:F


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/Consumer;F)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1$0;->f$0:Ljava/util/function/Consumer;

    iput p2, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1$0;->f$1:F

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1$0;->f$0:Ljava/util/function/Consumer;

    iget p0, p0, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1$0;->f$1:F

    check-cast p1, Landroidx/compose/animation/core/Animatable;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;->invokeSuspend$lambda$0(Ljava/util/function/Consumer;FLandroidx/compose/animation/core/Animatable;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
