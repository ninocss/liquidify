.class public final synthetic Ldev/nino/squareglass/MiniProgress$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:J

.field public final synthetic f$1:Landroidx/compose/runtime/MutableFloatState;


# direct methods
.method public synthetic constructor <init>(JLandroidx/compose/runtime/MutableFloatState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Ldev/nino/squareglass/MiniProgress$0;->f$0:J

    iput-object p3, p0, Ldev/nino/squareglass/MiniProgress$0;->f$1:Landroidx/compose/runtime/MutableFloatState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iget-wide v0, p0, Ldev/nino/squareglass/MiniProgress$0;->f$0:J

    iget-object p0, p0, Ldev/nino/squareglass/MiniProgress$0;->f$1:Landroidx/compose/runtime/MutableFloatState;

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;

    invoke-static {v0, v1, p0, p1}, Ldev/nino/squareglass/MiniProgress;->$r8$lambda$fD__iDS5ne1R2rmnBTzaTltNuf0(JLandroidx/compose/runtime/MutableFloatState;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
