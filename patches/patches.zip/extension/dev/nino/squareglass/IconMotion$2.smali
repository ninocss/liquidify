.class public final synthetic Ldev/nino/squareglass/IconMotion$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Landroidx/compose/runtime/State;

.field public final synthetic f$1:Landroid/view/View;

.field public final synthetic f$2:[I

.field public final synthetic f$3:Landroidx/lifecycle/Lifecycle;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/IconMotion$2;->f$0:Landroidx/compose/runtime/State;

    iput-object p2, p0, Ldev/nino/squareglass/IconMotion$2;->f$1:Landroid/view/View;

    iput-object p3, p0, Ldev/nino/squareglass/IconMotion$2;->f$2:[I

    iput-object p4, p0, Ldev/nino/squareglass/IconMotion$2;->f$3:Landroidx/lifecycle/Lifecycle;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/IconMotion$2;->f$0:Landroidx/compose/runtime/State;

    iget-object v1, p0, Ldev/nino/squareglass/IconMotion$2;->f$1:Landroid/view/View;

    iget-object v2, p0, Ldev/nino/squareglass/IconMotion$2;->f$2:[I

    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$2;->f$3:Landroidx/lifecycle/Lifecycle;

    invoke-static {v0, v1, v2, p0}, Ldev/nino/squareglass/IconMotion;->$r8$lambda$OGfaHqE4BfYVoK0DEXXzvKGwp_Y(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method
