.class public final synthetic Ldev/nino/squareglass/LinnProvider$4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnProvider;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$4;->f$0:Ldev/nino/squareglass/LinnProvider;

    iput p2, p0, Ldev/nino/squareglass/LinnProvider$4;->f$1:I

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider$4;->f$0:Ldev/nino/squareglass/LinnProvider;

    iget p0, p0, Ldev/nino/squareglass/LinnProvider$4;->f$1:I

    check-cast p1, Ldev/nino/squareglass/LinnDiscovery$Result;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/LinnProvider;->$r8$lambda$U-SezvwHkaPK8-pV9LHVRz5etsU(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnDiscovery$Result;)V

    return-void
.end method
