.class public final Ldev/nino/squareglass/SquareRuntime;
.super Ljava/lang/Object;
.source "SquareRuntime.java"


# static fields
.field private static localeInitialized:Z = false


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static context(Landroid/content/Context;)Landroid/content/Context;
    .locals 4

    .line 12
    invoke-static {p0}, Ldev/nino/squareglass/SquareSettings;->initialize(Landroid/content/Context;)V

    .line 13
    invoke-static {p0}, Ldev/nino/squareglass/NativePlayback;->initialize(Landroid/content/Context;)V

    .line 14
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-eqz v0, :cond_1

    .line 15
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeMode()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, -0x1

    goto :goto_0

    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeMode()I

    move-result v0

    .line 16
    :goto_0
    invoke-static {}, Landroidx/appcompat/app/AppCompatDelegate;->getDefaultNightMode()I

    move-result v1

    if-eq v1, v0, :cond_1

    .line 17
    invoke-static {v0}, Landroidx/appcompat/app/AppCompatDelegate;->setDefaultNightMode(I)V

    .line 20
    :cond_1
    sget-boolean v0, Ldev/nino/squareglass/SquareRuntime;->localeInitialized:Z

    if-nez v0, :cond_3

    const/4 v0, 0x1

    .line 21
    sput-boolean v0, Ldev/nino/squareglass/SquareRuntime;->localeInitialized:Z

    .line 22
    const-class v0, Landroid/app/LocaleManager;

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/LocaleManager;

    if-eqz v0, :cond_3

    .line 24
    invoke-virtual {v0}, Landroid/app/LocaleManager;->getApplicationLocales()Landroid/os/LocaleList;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/LocaleList;->toLanguageTags()Ljava/lang/String;

    move-result-object v1

    .line 25
    const-string v2, "en"

    if-eqz v1, :cond_2

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    .line 26
    :cond_2
    invoke-static {v2}, Landroid/os/LocaleList;->forLanguageTags(Ljava/lang/String;)Landroid/os/LocaleList;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/LocaleManager;->setApplicationLocales(Landroid/os/LocaleList;)V

    .line 30
    :cond_3
    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    invoke-static {v0}, Ljava/util/Locale;->setDefault(Ljava/util/Locale;)V

    .line 31
    new-instance v0, Landroid/content/res/Configuration;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 32
    sget-object v1, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V

    .line 33
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v1

    if-eqz v1, :cond_5

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeMode()I

    move-result v1

    if-eqz v1, :cond_5

    iget v1, v0, Landroid/content/res/Configuration;->uiMode:I

    and-int/lit8 v1, v1, -0x31

    .line 34
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeMode()I

    move-result v2

    const/4 v3, 0x2

    if-ne v2, v3, :cond_4

    const/16 v2, 0x20

    goto :goto_1

    :cond_4
    const/16 v2, 0x10

    :goto_1
    or-int/2addr v1, v2

    iput v1, v0, Landroid/content/res/Configuration;->uiMode:I

    .line 35
    :cond_5
    invoke-virtual {p0, v0}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    move-result-object p0

    return-object p0
.end method
