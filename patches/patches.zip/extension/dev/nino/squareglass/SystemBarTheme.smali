.class public final Ldev/nino/squareglass/SystemBarTheme;
.super Ljava/lang/Object;
.source "SystemBarTheme.java"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;
.implements Landroid/view/View$OnAttachStateChangeListener;


# instance fields
.field private final decor:Landroid/view/View;

.field private player:Z

.field private final window:Landroid/view/Window;


# direct methods
.method private constructor <init>(Landroid/view/Window;)V
    .locals 1

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    iput-object p1, p0, Ldev/nino/squareglass/SystemBarTheme;->window:Landroid/view/Window;

    .line 17
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/SystemBarTheme;->decor:Landroid/view/View;

    .line 18
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 19
    invoke-virtual {p1, p0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method

.method public static install(Landroid/app/Activity;)V
    .locals 1

    .line 21
    new-instance v0, Ldev/nino/squareglass/SystemBarTheme;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SystemBarTheme;-><init>(Landroid/view/Window;)V

    return-void
.end method

.method public static installPlayerWindow(Landroid/view/Window;)Ldev/nino/squareglass/SystemBarTheme;
    .locals 1

    .line 24
    new-instance v0, Ldev/nino/squareglass/SystemBarTheme;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SystemBarTheme;-><init>(Landroid/view/Window;)V

    const/4 p0, 0x1

    iput-boolean p0, v0, Ldev/nino/squareglass/SystemBarTheme;->player:Z

    return-object v0
.end method

.method public static installWindow(Landroid/view/Window;)Ldev/nino/squareglass/SystemBarTheme;
    .locals 1

    .line 22
    new-instance v0, Ldev/nino/squareglass/SystemBarTheme;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SystemBarTheme;-><init>(Landroid/view/Window;)V

    return-object v0
.end method


# virtual methods
.method public onPreDraw()Z
    .locals 3

    .line 27
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-eqz v0, :cond_1

    .line 28
    iget-object p0, p0, Ldev/nino/squareglass/SystemBarTheme;->window:Landroid/view/Window;

    invoke-virtual {p0}, Landroid/view/Window;->getInsetsController()Landroid/view/WindowInsetsController;

    move-result-object p0

    .line 31
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    const/16 v1, 0x18

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    if-eqz p0, :cond_1

    .line 32
    invoke-interface {p0}, Landroid/view/WindowInsetsController;->getSystemBarsAppearance()I

    move-result v2

    and-int/2addr v2, v1

    if-eq v2, v0, :cond_1

    .line 33
    invoke-interface {p0, v0, v1}, Landroid/view/WindowInsetsController;->setSystemBarsAppearance(II)V

    :cond_1
    const/4 p0, 0x1

    return p0
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    .line 42
    invoke-virtual {p0}, Ldev/nino/squareglass/SystemBarTheme;->release()V

    return-void
.end method

.method public release()V
    .locals 1

    .line 39
    iget-object v0, p0, Ldev/nino/squareglass/SystemBarTheme;->decor:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/SystemBarTheme;->decor:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 40
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/SystemBarTheme;->decor:Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method
