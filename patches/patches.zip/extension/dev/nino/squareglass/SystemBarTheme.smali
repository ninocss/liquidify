.class public final Ldev/nino/squareglass/SystemBarTheme;
.super Ljava/lang/Object;
.source "SystemBarTheme.java"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;
.implements Landroid/view/View$OnAttachStateChangeListener;


# instance fields
.field private final decor:Landroid/view/View;

.field private player:Z

.field private final window:Landroid/view/Window;


# direct methods
.method private constructor <init>(Landroid/view/Window;)V
    .locals 1

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    iput-object p1, p0, Ldev/nino/squareglass/SystemBarTheme;->window:Landroid/view/Window;

    .line 18
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/SystemBarTheme;->decor:Landroid/view/View;

    .line 19
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 20
    invoke-virtual {p1, p0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method

.method public static install(Landroid/app/Activity;)V
    .locals 1

    .line 22
    new-instance v0, Ldev/nino/squareglass/SystemBarTheme;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SystemBarTheme;-><init>(Landroid/view/Window;)V

    return-void
.end method

.method public static installPlayerWindow(Landroid/view/Window;)Ldev/nino/squareglass/SystemBarTheme;
    .locals 1

    .line 25
    new-instance v0, Ldev/nino/squareglass/SystemBarTheme;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SystemBarTheme;-><init>(Landroid/view/Window;)V

    const/4 p0, 0x1

    iput-boolean p0, v0, Ldev/nino/squareglass/SystemBarTheme;->player:Z

    return-object v0
.end method

.method public static installWindow(Landroid/view/Window;)Ldev/nino/squareglass/SystemBarTheme;
    .locals 1

    .line 23
    new-instance v0, Ldev/nino/squareglass/SystemBarTheme;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SystemBarTheme;-><init>(Landroid/view/Window;)V

    return-object v0
.end method


# virtual methods
.method public onPreDraw()Z
    .locals 5

    .line 28
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-eqz v0, :cond_2

    .line 29
    iget-object v0, p0, Ldev/nino/squareglass/SystemBarTheme;->window:Landroid/view/Window;

    invoke-virtual {v0}, Landroid/view/Window;->getInsetsController()Landroid/view/WindowInsetsController;

    move-result-object v0

    .line 32
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    const/16 v2, 0x18

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    move v3, v2

    :goto_0
    if-eqz v0, :cond_1

    .line 34
    invoke-interface {v0}, Landroid/view/WindowInsetsController;->getSystemBarsAppearance()I

    move-result v4

    and-int/2addr v4, v2

    if-eq v4, v3, :cond_1

    .line 35
    invoke-interface {v0, v3, v2}, Landroid/view/WindowInsetsController;->setSystemBarsAppearance(II)V

    .line 36
    :cond_1
    iget-boolean v0, p0, Ldev/nino/squareglass/SystemBarTheme;->player:Z

    if-nez v0, :cond_2

    .line 37
    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v0

    .line 38
    iget-object v1, p0, Ldev/nino/squareglass/SystemBarTheme;->window:Landroid/view/Window;

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v2, v0}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v1, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 39
    iget-object v1, p0, Ldev/nino/squareglass/SystemBarTheme;->window:Landroid/view/Window;

    invoke-virtual {v1, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 40
    iget-object v1, p0, Ldev/nino/squareglass/SystemBarTheme;->window:Landroid/view/Window;

    invoke-virtual {v1, v0}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 41
    iget-object p0, p0, Ldev/nino/squareglass/SystemBarTheme;->decor:Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_2
    const/4 p0, 0x1

    return p0
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    .line 51
    invoke-virtual {p0}, Ldev/nino/squareglass/SystemBarTheme;->release()V

    return-void
.end method

.method public release()V
    .locals 1

    .line 48
    iget-object v0, p0, Ldev/nino/squareglass/SystemBarTheme;->decor:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/SystemBarTheme;->decor:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 49
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/SystemBarTheme;->decor:Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method
