.class final Ldev/nino/squareglass/SquareDetails$Binding;
.super Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;
.source "SquareDetails.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;
.implements Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareDetails;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Binding"
.end annotation


# instance fields
.field final floatingSurfaces:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation
.end field

.field list:Landroidx/recyclerview/widget/RecyclerView;

.field final location:[I

.field observing:Z

.field final paint:Ljava/lang/Runnable;

.field final root:Landroid/view/View;

.field toolbarFade:Ldev/nino/squareglass/HeaderFade;

.field toolbarTone:I

.field topInset:I


# direct methods
.method public static synthetic $r8$lambda$akqvHZx0gjWoMmJnHf4GifNd0dk(Ldev/nino/squareglass/SquareDetails$Binding;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareDetails$Binding;->lambda$new$0(Landroid/view/View;)V

    return-void
.end method

.method constructor <init>(Landroid/view/View;)V
    .locals 1

    .line 475
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;-><init>()V

    const/4 v0, -0x1

    .line 471
    iput v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->topInset:I

    const/4 v0, 0x2

    .line 473
    new-array v0, v0, [I

    iput-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->location:[I

    .line 474
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->floatingSurfaces:Ljava/util/WeakHashMap;

    .line 476
    iput-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    .line 477
    new-instance v0, Ldev/nino/squareglass/SquareDetails$Binding$1;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/SquareDetails$Binding$1;-><init>(Ldev/nino/squareglass/SquareDetails$Binding;Landroid/view/View;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    return-void
.end method

.method private floating(Landroid/view/View;I)V
    .locals 4

    const/16 v0, 0x30

    .line 552
    invoke-static {p1, v0}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smdp(Landroid/view/View;I)I

    move-result v0

    const/16 v1, 0xc

    invoke-static {p1, v1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smdp(Landroid/view/View;I)I

    move-result v1

    .line 553
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    if-eqz v2, :cond_1

    .line 554
    iget v3, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-ne v3, v0, :cond_0

    iget v3, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-eq v3, v0, :cond_1

    .line 555
    :cond_0
    iput v0, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v0, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 557
    :cond_1
    invoke-virtual {p1, v0}, Landroid/view/View;->setMinimumWidth(I)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setMinimumHeight(I)V

    .line 558
    instance-of v0, p1, Landroid/widget/ImageView;

    if-eqz v0, :cond_4

    .line 559
    invoke-virtual {p1}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    if-ne v0, v1, :cond_2

    invoke-virtual {p1}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    if-eq v0, v1, :cond_3

    .line 560
    :cond_2
    invoke-virtual {p1, v1, v1, v1, v1}, Landroid/view/View;->setPadding(IIII)V

    .line 561
    :cond_3
    move-object v0, p1

    check-cast v0, Landroid/widget/ImageView;

    sget-object v1, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    :cond_4
    const/4 v0, 0x0

    .line 563
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 564
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->floatingSurfaces:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->floatingSurfaces:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-ne v0, v1, :cond_5

    return-void

    .line 565
    :cond_5
    new-instance v0, Landroid/graphics/drawable/InsetDrawable;

    const/16 v1, 0x14

    invoke-static {p1, p2, v1}, Ldev/nino/squareglass/PageMaterial;->background(Landroid/view/View;II)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v1, 0x4

    invoke-static {p1, v1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smdp(Landroid/view/View;I)I

    move-result v1

    invoke-direct {v0, p2, v1}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;I)V

    .line 566
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object p0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->floatingSurfaces:Ljava/util/WeakHashMap;

    invoke-virtual {p0, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private synthetic lambda$new$0(Landroid/view/View;)V
    .locals 5

    const v0, 0x7f0b06ef

    .line 478
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v0, v1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smforeground(Landroid/view/View;I)V

    const v0, 0x7f0b0302

    .line 479
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v0, v1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smforeground(Landroid/view/View;I)V

    .line 480
    invoke-static {p1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smplaylistPaint(Landroid/view/View;)V

    const v0, 0x7f0b056e

    .line 481
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 482
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/View;

    if-eqz v1, :cond_0

    .line 483
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    const v1, 0x7f0b056f

    .line 484
    invoke-static {p1, v0, v1}, Ldev/nino/squareglass/SquareDetails;->controls(Landroid/view/View;II)V

    const v1, 0x7f0b0274

    const v2, 0x7f0b064c

    const v3, 0x7f0b02c6

    const v4, 0x7f0b0370

    .line 485
    filled-new-array {v3, v4, v1, v2}, [I

    move-result-object v1

    invoke-static {p1, v0, v1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smactionRail(Landroid/view/View;I[I)V

    .line 487
    :cond_0
    invoke-direct {p0}, Ldev/nino/squareglass/SquareDetails$Binding;->topEdge()V

    return-void
.end method

.method static synthetic lambda$onChildViewAttachedToWindow$0(Landroid/view/View;)V
    .locals 1

    .line 587
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails;->track(Landroid/view/View;)V

    const v0, 0x7f0b056e

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    const v0, 0x7f0b0568

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smlabels(Landroid/view/View;)V

    :cond_0
    return-void
.end method

.method private topEdge()V
    .locals 10

    .line 491
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v1, 0x7f0b057a

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const v1, 0x7f0b00b8

    if-nez v0, :cond_0

    .line 492
    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v3, 0x7f0b00a9

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    :goto_0
    if-nez v2, :cond_1

    .line 493
    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {v2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    :cond_1
    if-nez v2, :cond_2

    goto/16 :goto_8

    :cond_2
    if-nez v0, :cond_3

    .line 495
    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/View;

    if-eqz v1, :cond_3

    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    :cond_3
    if-nez v0, :cond_4

    goto/16 :goto_8

    .line 497
    :cond_4
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, -0x1

    const/4 v4, 0x0

    if-eqz v1, :cond_6

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v1, :cond_6

    .line 498
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 499
    iget v5, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    if-nez v5, :cond_5

    iget v5, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    if-ne v5, v3, :cond_5

    iget v5, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-eqz v5, :cond_6

    .line 500
    :cond_5
    iput v4, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v3, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    iput v4, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget-object v5, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v5, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 503
    :cond_6
    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    invoke-virtual {v0}, Landroid/view/View;->getPaddingBottom()I

    move-result v6

    invoke-virtual {v0, v1, v4, v5, v6}, Landroid/view/View;->setPadding(IIII)V

    .line 504
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    const/4 v5, 0x0

    if-eqz v1, :cond_8

    .line 505
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 507
    iget v6, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-nez v6, :cond_7

    iget v6, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    if-ne v6, v3, :cond_7

    iget v6, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->verticalBias:F

    cmpl-float v6, v6, v5

    if-eqz v6, :cond_8

    .line 508
    :cond_7
    iput v4, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iput v4, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v3, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    iput v5, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->verticalBias:F

    .line 509
    invoke-virtual {v2, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 513
    :cond_8
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object v1

    if-nez v1, :cond_9

    move v1, v4

    goto :goto_1

    .line 514
    :cond_9
    invoke-static {}, Landroid/view/WindowInsets$Type;->statusBars()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/view/WindowInsets;->getInsets(I)Landroid/graphics/Insets;

    move-result-object v1

    iget v1, v1, Landroid/graphics/Insets;->top:I

    .line 515
    :goto_1
    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-static {v2, v1}, Ldev/nino/squareglass/PageInsets;->top(Landroid/view/View;I)V

    .line 517
    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v6, 0x7f0b0302

    invoke-virtual {v2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-nez v2, :cond_a

    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v6, 0x7f0b06ef

    invoke-virtual {v2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    :cond_a
    if-eqz v2, :cond_17

    .line 519
    invoke-static {v2, v1}, Ldev/nino/squareglass/PageCoordinator;->toolbarInset(Landroid/view/View;I)V

    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const/4 v6, 0x4

    invoke-static {v1, v6}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smdp(Landroid/view/View;I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v2, v1}, Landroid/view/View;->setElevation(F)V

    .line 520
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v1

    .line 521
    iget v6, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarTone:I

    if-eq v6, v1, :cond_b

    iput v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarTone:I

    iget-object v6, p0, Ldev/nino/squareglass/SquareDetails$Binding;->floatingSurfaces:Ljava/util/WeakHashMap;

    invoke-virtual {v6}, Ljava/util/WeakHashMap;->clear()V

    .line 522
    :cond_b
    instance-of v6, v2, Landroid/view/ViewGroup;

    if-eqz v6, :cond_17

    .line 523
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v6

    .line 524
    instance-of v7, v6, Landroid/graphics/drawable/ColorDrawable;

    if-eqz v7, :cond_c

    check-cast v6, Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {v6}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result v6

    goto :goto_2

    :cond_c
    move v6, v1

    .line 525
    :goto_2
    iget-object v7, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    if-nez v7, :cond_d

    move v7, v5

    goto :goto_3

    :cond_d
    invoke-virtual {v7}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollOffset()I

    move-result v7

    int-to-float v7, v7

    .line 528
    :goto_3
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v8

    instance-of v8, v8, Landroid/view/View;

    if-eqz v8, :cond_f

    iget-object v8, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    if-eq v0, v8, :cond_f

    .line 529
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v8

    const-string v9, "com.google.android.material.appbar.AppBarLayout"

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_e

    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v8

    neg-int v8, v8

    invoke-static {v4, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    int-to-float v8, v8

    add-float/2addr v7, v8

    .line 528
    :cond_e
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    goto :goto_3

    .line 530
    :cond_f
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_10

    invoke-virtual {v0, v3}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    if-nez v0, :cond_10

    cmpg-float v0, v7, v5

    if-gtz v0, :cond_10

    goto :goto_4

    :cond_10
    move v5, v7

    .line 531
    :goto_4
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarFade:Ldev/nino/squareglass/HeaderFade;

    if-nez v0, :cond_11

    new-instance v0, Ldev/nino/squareglass/HeaderFade;

    invoke-direct {v0, v6}, Ldev/nino/squareglass/HeaderFade;-><init>(I)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarFade:Ldev/nino/squareglass/HeaderFade;

    .line 532
    :cond_11
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarFade:Ldev/nino/squareglass/HeaderFade;

    iget-object v3, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const/16 v7, 0x40

    invoke-static {v3, v7}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smdp(Landroid/view/View;I)I

    move-result v3

    int-to-float v3, v3

    invoke-static {v5, v3}, Ldev/nino/squareglass/HeaderProgress;->opacity(FF)F

    move-result v3

    invoke-virtual {v0, v6, v3}, Ldev/nino/squareglass/HeaderFade;->update(IF)V

    .line 533
    invoke-virtual {v2}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iget-object v3, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarFade:Ldev/nino/squareglass/HeaderFade;

    if-eq v0, v3, :cond_12

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 534
    :cond_12
    move-object v0, v2

    check-cast v0, Landroid/view/ViewGroup;

    const/16 v3, 0xc

    .line 535
    invoke-static {v2, v3}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smdp(Landroid/view/View;I)I

    move-result v3

    .line 536
    invoke-virtual {v2}, Landroid/view/View;->getPaddingStart()I

    move-result v5

    if-ne v5, v3, :cond_13

    invoke-virtual {v2}, Landroid/view/View;->getPaddingEnd()I

    move-result v5

    if-eq v5, v3, :cond_14

    .line 537
    :cond_13
    invoke-virtual {v2}, Landroid/view/View;->getPaddingTop()I

    move-result v5

    invoke-virtual {v2}, Landroid/view/View;->getPaddingBottom()I

    move-result v6

    invoke-virtual {v2, v3, v5, v3, v6}, Landroid/view/View;->setPaddingRelative(IIII)V

    :cond_14
    move v2, v4

    .line 538
    :goto_5
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    if-ge v2, v3, :cond_17

    .line 539
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 540
    instance-of v5, v3, Landroid/widget/ImageButton;

    if-eqz v5, :cond_15

    invoke-direct {p0, v3, v1}, Ldev/nino/squareglass/SquareDetails$Binding;->floating(Landroid/view/View;I)V

    goto :goto_7

    .line 541
    :cond_15
    instance-of v5, v3, Landroid/view/ViewGroup;

    if-eqz v5, :cond_16

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const-string v6, "ActionMenuView"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_16

    .line 542
    check-cast v3, Landroid/view/ViewGroup;

    move v5, v4

    .line 543
    :goto_6
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v6

    if-ge v5, v6, :cond_16

    invoke-virtual {v3, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-direct {p0, v6, v1}, Ldev/nino/squareglass/SquareDetails$Binding;->floating(Landroid/view/View;I)V

    add-int/lit8 v5, v5, 0x1

    goto :goto_6

    :cond_16
    :goto_7
    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    :cond_17
    :goto_8
    return-void
.end method


# virtual methods
.method public onChildViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    .line 587
    new-instance p0, Ldev/nino/squareglass/SquareDetails$Binding$0;

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareDetails$Binding$0;-><init>(Landroid/view/View;)V

    invoke-virtual {p1, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onChildViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onGlobalLayout()V
    .locals 0

    .line 585
    iget-object p0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method public onPreDraw()Z
    .locals 0

    .line 568
    invoke-direct {p0}, Ldev/nino/squareglass/SquareDetails$Binding;->topEdge()V

    const/4 p0, 0x1

    return p0
.end method

.method public onScrolled(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    .line 591
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    iget-object p2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    invoke-virtual {p1, p2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    invoke-virtual {p1, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 2

    .line 570
    iget-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    if-eqz p1, :cond_0

    return-void

    .line 571
    :cond_0
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v0, 0x7f0b05b8

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    .line 572
    instance-of v0, p1, Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    if-nez v0, :cond_1

    .line 573
    check-cast p1, Landroidx/recyclerview/widget/RecyclerView;

    iput-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/RecyclerView;->addOnScrollListener(Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;)V

    .line 574
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/RecyclerView;->addOnChildAttachStateChangeListener(Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;)V

    .line 575
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v0, 0x0

    .line 576
    :goto_0
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/SquareDetails$Binding;->onChildViewAttachedToWindow(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 578
    :cond_1
    iget-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    if-nez p1, :cond_2

    .line 579
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 580
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    const/4 p1, 0x1

    .line 581
    iput-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    .line 583
    :cond_2
    iget-object p0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    .line 594
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 595
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p1, :cond_0

    .line 596
    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/RecyclerView;->removeOnScrollListener(Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;)V

    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/RecyclerView;->removeOnChildAttachStateChangeListener(Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;)V

    const/4 p1, 0x0

    iput-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    .line 598
    :cond_0
    iget-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    if-eqz p1, :cond_1

    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    if-eqz p1, :cond_1

    .line 599
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 600
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    :cond_1
    const/4 p1, 0x0

    .line 602
    iput-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    return-void
.end method
