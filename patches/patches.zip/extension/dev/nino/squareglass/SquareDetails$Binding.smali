.class final Ldev/nino/squareglass/SquareDetails$Binding;
.super Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;
.source "SquareDetails.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;
.implements Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareDetails;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Binding"
.end annotation


# instance fields
.field lastMenuCount:I

.field list:Landroidx/recyclerview/widget/RecyclerView;

.field observing:Z

.field final paint:Ljava/lang/Runnable;

.field final root:Landroid/view/View;

.field toolbarFade:Ldev/nino/squareglass/HeaderFade;

.field toolbarTone:I

.field topInset:I


# direct methods
.method public static synthetic $r8$lambda$akqvHZx0gjWoMmJnHf4GifNd0dk(Ldev/nino/squareglass/SquareDetails$Binding;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareDetails$Binding;->lambda$new$0(Landroid/view/View;)V

    return-void
.end method

.method constructor <init>(Landroid/view/View;)V
    .locals 1

    .line 559
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;-><init>()V

    const/4 v0, -0x1

    .line 556
    iput v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->topInset:I

    .line 558
    iput v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->lastMenuCount:I

    .line 560
    iput-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    .line 561
    new-instance v0, Ldev/nino/squareglass/SquareDetails$Binding$1;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/SquareDetails$Binding$1;-><init>(Ldev/nino/squareglass/SquareDetails$Binding;Landroid/view/View;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    return-void
.end method

.method private static artistPaint(Landroid/view/View;)V
    .locals 7

    .line 577
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    .line 578
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    const v2, 0x7f0b03d3

    .line 579
    invoke-virtual {p0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 580
    invoke-virtual {v2}, Landroid/view/View;->getForeground()Landroid/graphics/drawable/Drawable;

    move-result-object v3

    instance-of v3, v3, Ldev/nino/squareglass/SquareDetails$CoverFade;

    if-nez v3, :cond_0

    .line 581
    new-instance v3, Ldev/nino/squareglass/SquareDetails$CoverFade;

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v0

    invoke-direct {v3, v0}, Ldev/nino/squareglass/SquareDetails$CoverFade;-><init>(I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setForeground(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v0, 0x6

    .line 583
    new-array v2, v0, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v0, :cond_3

    aget v5, v2, v4

    .line 584
    invoke-virtual {p0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    if-eqz v5, :cond_2

    .line 586
    invoke-virtual {v5}, Landroid/view/View;->isClickable()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-static {v5, v3}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smbutton(Landroid/view/View;Z)V

    goto :goto_1

    .line 587
    :cond_1
    invoke-static {v5, v1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smforeground(Landroid/view/View;I)V

    :cond_2
    :goto_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_3
    return-void

    :array_0
    .array-data 4
        0x7f0b0324
        0x7f0b0569
        0x7f0b0108
        0x7f0b0109
        0x7f0b00e3
        0x7f0b00e4
    .end array-data
.end method

.method private synthetic lambda$new$0(Landroid/view/View;)V
    .locals 5

    .line 562
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    const v1, 0x7f0b06ef

    .line 563
    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v2

    invoke-static {v1, v2}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smforeground(Landroid/view/View;I)V

    const v1, 0x7f0b0302

    .line 564
    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-static {v1, v0}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smforeground(Landroid/view/View;I)V

    .line 565
    invoke-static {p1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smplaylistPaint(Landroid/view/View;)V

    .line 566
    invoke-static {p1}, Ldev/nino/squareglass/SquareDetails$Binding;->artistPaint(Landroid/view/View;)V

    const v0, 0x7f0b056e

    .line 567
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 568
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/View;

    if-eqz v1, :cond_0

    .line 569
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    const v1, 0x7f0b056f

    .line 570
    invoke-static {p1, v0, v1}, Ldev/nino/squareglass/SquareDetails;->controls(Landroid/view/View;II)V

    const v1, 0x7f0b0274

    const v2, 0x7f0b064c

    const v3, 0x7f0b02c6

    const v4, 0x7f0b0370

    .line 571
    filled-new-array {v3, v4, v1, v2}, [I

    move-result-object v1

    invoke-static {p1, v0, v1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smactionRail(Landroid/view/View;I[I)V

    .line 573
    :cond_0
    invoke-direct {p0}, Ldev/nino/squareglass/SquareDetails$Binding;->topEdge()V

    return-void
.end method

.method static synthetic lambda$onChildViewAttachedToWindow$0(Landroid/view/View;)V
    .locals 1

    .line 670
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails;->track(Landroid/view/View;)V

    const v0, 0x7f0b056e

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    const v0, 0x7f0b0568

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smlabels(Landroid/view/View;)V

    :cond_0
    return-void
.end method

.method private topEdge()V
    .locals 9

    .line 592
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v1, 0x7f0b057a

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const v1, 0x7f0b00b8

    if-nez v0, :cond_0

    .line 593
    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v3, 0x7f0b00a9

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    :goto_0
    if-nez v2, :cond_1

    .line 594
    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {v2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    :cond_1
    if-nez v2, :cond_2

    goto/16 :goto_4

    :cond_2
    if-nez v0, :cond_3

    .line 596
    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/View;

    if-eqz v1, :cond_3

    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    :cond_3
    if-nez v0, :cond_4

    goto/16 :goto_4

    .line 598
    :cond_4
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, -0x1

    const/4 v4, 0x0

    if-eqz v1, :cond_6

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v1, :cond_6

    .line 599
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 600
    iget v5, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    if-nez v5, :cond_5

    iget v5, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    if-ne v5, v3, :cond_5

    iget v5, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-eqz v5, :cond_6

    .line 601
    :cond_5
    iput v4, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v3, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    iput v4, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget-object v5, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v5, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 604
    :cond_6
    invoke-virtual {v0}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    if-eqz v1, :cond_7

    .line 605
    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    invoke-virtual {v0}, Landroid/view/View;->getPaddingBottom()I

    move-result v6

    invoke-virtual {v0, v1, v4, v5, v6}, Landroid/view/View;->setPadding(IIII)V

    .line 606
    :cond_7
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    const/4 v5, 0x0

    if-eqz v1, :cond_9

    .line 607
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 609
    iget v6, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-nez v6, :cond_8

    iget v6, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    if-ne v6, v3, :cond_8

    iget v6, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->verticalBias:F

    cmpl-float v6, v6, v5

    if-eqz v6, :cond_9

    .line 610
    :cond_8
    iput v4, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iput v4, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v3, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    iput v5, v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->verticalBias:F

    .line 611
    invoke-virtual {v2, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 615
    :cond_9
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object v1

    if-nez v1, :cond_a

    move v1, v4

    goto :goto_1

    .line 616
    :cond_a
    invoke-static {}, Landroid/view/WindowInsets$Type;->statusBars()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/view/WindowInsets;->getInsets(I)Landroid/graphics/Insets;

    move-result-object v1

    iget v1, v1, Landroid/graphics/Insets;->top:I

    .line 617
    :goto_1
    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-static {v2, v1}, Ldev/nino/squareglass/PageInsets;->top(Landroid/view/View;I)V

    .line 619
    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v6, 0x7f0b0302

    invoke-virtual {v2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-nez v2, :cond_b

    iget-object v2, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v6, 0x7f0b06ef

    invoke-virtual {v2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    :cond_b
    if-eqz v2, :cond_14

    .line 621
    invoke-static {v2, v1}, Ldev/nino/squareglass/PageCoordinator;->toolbarInset(Landroid/view/View;I)V

    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const/4 v6, 0x4

    invoke-static {v1, v6}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smdp(Landroid/view/View;I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v2, v1}, Landroid/view/View;->setElevation(F)V

    .line 622
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    .line 623
    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v6

    .line 624
    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    .line 625
    instance-of v7, v2, Landroidx/appcompat/widget/Toolbar;

    if-eqz v7, :cond_d

    .line 626
    move-object v7, v2

    check-cast v7, Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v7}, Landroidx/appcompat/widget/Toolbar;->getMenu()Landroid/view/Menu;

    move-result-object v7

    invoke-interface {v7}, Landroid/view/Menu;->size()I

    move-result v7

    .line 627
    iget v8, p0, Ldev/nino/squareglass/SquareDetails$Binding;->lastMenuCount:I

    if-ne v7, v8, :cond_c

    iget v8, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarTone:I

    if-eq v8, v6, :cond_d

    .line 628
    :cond_c
    iput v7, p0, Ldev/nino/squareglass/SquareDetails$Binding;->lastMenuCount:I

    .line 629
    invoke-static {v2, v1}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smforeground(Landroid/view/View;I)V

    .line 632
    :cond_d
    iput v6, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarTone:I

    .line 633
    instance-of v1, v2, Landroid/view/ViewGroup;

    if-eqz v1, :cond_14

    .line 634
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    .line 635
    instance-of v7, v1, Landroid/graphics/drawable/ColorDrawable;

    if-eqz v7, :cond_e

    check-cast v1, Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {v1}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result v6

    .line 636
    :cond_e
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    if-nez v1, :cond_f

    move v1, v5

    goto :goto_2

    :cond_f
    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollOffset()I

    move-result v1

    int-to-float v1, v1

    .line 639
    :goto_2
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v7

    instance-of v7, v7, Landroid/view/View;

    if-eqz v7, :cond_11

    iget-object v7, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    if-eq v0, v7, :cond_11

    .line 640
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v7

    const-string v8, "com.google.android.material.appbar.AppBarLayout"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_10

    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v7

    neg-int v7, v7

    invoke-static {v4, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    int-to-float v7, v7

    add-float/2addr v1, v7

    .line 639
    :cond_10
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    goto :goto_2

    .line 641
    :cond_11
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_12

    invoke-virtual {v0, v3}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    if-nez v0, :cond_12

    cmpg-float v0, v1, v5

    if-gtz v0, :cond_12

    goto :goto_3

    :cond_12
    move v5, v1

    .line 642
    :goto_3
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarFade:Ldev/nino/squareglass/HeaderFade;

    if-nez v0, :cond_13

    new-instance v0, Ldev/nino/squareglass/HeaderFade;

    invoke-direct {v0, v6}, Ldev/nino/squareglass/HeaderFade;-><init>(I)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarFade:Ldev/nino/squareglass/HeaderFade;

    .line 643
    :cond_13
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarFade:Ldev/nino/squareglass/HeaderFade;

    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const/16 v3, 0x40

    invoke-static {v1, v3}, Ldev/nino/squareglass/SquareDetails;->-$$Nest$smdp(Landroid/view/View;I)I

    move-result v1

    int-to-float v1, v1

    invoke-static {v5, v1}, Ldev/nino/squareglass/HeaderProgress;->opacity(FF)F

    move-result v1

    invoke-virtual {v0, v6, v1}, Ldev/nino/squareglass/HeaderFade;->update(IF)V

    .line 644
    invoke-virtual {v2}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->toolbarFade:Ldev/nino/squareglass/HeaderFade;

    if-eq v0, p0, :cond_14

    invoke-virtual {v2, p0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_14
    :goto_4
    return-void
.end method


# virtual methods
.method public onChildViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    .line 670
    new-instance p0, Ldev/nino/squareglass/SquareDetails$Binding$0;

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareDetails$Binding$0;-><init>(Landroid/view/View;)V

    invoke-virtual {p1, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onChildViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onGlobalLayout()V
    .locals 0

    .line 668
    iget-object p0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method public onPreDraw()Z
    .locals 0

    .line 649
    invoke-direct {p0}, Ldev/nino/squareglass/SquareDetails$Binding;->topEdge()V

    const/4 p0, 0x1

    return p0
.end method

.method public onScrolled(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    .line 674
    invoke-direct {p0}, Ldev/nino/squareglass/SquareDetails$Binding;->topEdge()V

    return-void
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 2

    .line 653
    iget-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    if-eqz p1, :cond_0

    return-void

    .line 654
    :cond_0
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    const v0, 0x7f0b05b8

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    .line 655
    instance-of v0, p1, Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    if-nez v0, :cond_1

    .line 656
    check-cast p1, Landroidx/recyclerview/widget/RecyclerView;

    iput-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/RecyclerView;->addOnScrollListener(Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;)V

    .line 657
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/RecyclerView;->addOnChildAttachStateChangeListener(Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;)V

    .line 658
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v0, 0x0

    .line 659
    :goto_0
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/SquareDetails$Binding;->onChildViewAttachedToWindow(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 661
    :cond_1
    iget-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    if-nez p1, :cond_2

    .line 662
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 663
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    const/4 p1, 0x1

    .line 664
    iput-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    .line 666
    :cond_2
    iget-object p0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    .line 677
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Binding;->paint:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 678
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz p1, :cond_0

    .line 679
    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/RecyclerView;->removeOnScrollListener(Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;)V

    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/RecyclerView;->removeOnChildAttachStateChangeListener(Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;)V

    const/4 p1, 0x0

    iput-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->list:Landroidx/recyclerview/widget/RecyclerView;

    .line 681
    :cond_0
    iget-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    if-eqz p1, :cond_1

    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    if-eqz p1, :cond_1

    .line 682
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 683
    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    :cond_1
    const/4 p1, 0x0

    .line 685
    iput-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Binding;->observing:Z

    return-void
.end method
