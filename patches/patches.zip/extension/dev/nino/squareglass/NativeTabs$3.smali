.class public final synthetic Ldev/nino/squareglass/NativeTabs$3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/runtime/State;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$2:Landroidx/compose/runtime/State;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/runtime/State;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/State;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeTabs$3;->f$0:Landroidx/compose/runtime/State;

    iput-object p2, p0, Ldev/nino/squareglass/NativeTabs$3;->f$1:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Ldev/nino/squareglass/NativeTabs$3;->f$2:Landroidx/compose/runtime/State;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeTabs$3;->f$0:Landroidx/compose/runtime/State;

    iget-object v1, p0, Ldev/nino/squareglass/NativeTabs$3;->f$1:Landroidx/compose/runtime/MutableState;

    iget-object p0, p0, Ldev/nino/squareglass/NativeTabs$3;->f$2:Landroidx/compose/runtime/State;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {v0, v1, p0, p1}, Ldev/nino/squareglass/NativeTabs;->$r8$lambda$NOiAvI0St6E9Iy40nfRXRXjFwlo(Landroidx/compose/runtime/State;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/State;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
