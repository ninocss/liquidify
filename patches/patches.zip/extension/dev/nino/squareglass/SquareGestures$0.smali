.class public final synthetic Ldev/nino/squareglass/SquareGestures$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareGestures;

.field public final synthetic f$1:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareGestures;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareGestures$0;->f$0:Ldev/nino/squareglass/SquareGestures;

    iput-object p2, p0, Ldev/nino/squareglass/SquareGestures$0;->f$1:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SquareGestures$0;->f$0:Ldev/nino/squareglass/SquareGestures;

    iget-object p0, p0, Ldev/nino/squareglass/SquareGestures$0;->f$1:Landroid/view/View;

    check-cast p1, Ljava/lang/Float;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/SquareGestures;->$r8$lambda$dmuR0JonfB_H4UmL6XbzgtscPoo(Ldev/nino/squareglass/SquareGestures;Landroid/view/View;Ljava/lang/Float;)V

    return-void
.end method
