.class public final Ldev/nino/squareglass/NativeIconMotion;
.super Ljava/lang/Object;
.source "NativeIconMotion.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/NativeIconMotion$State;
    }
.end annotation


# static fields
.field private static final states:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ldev/nino/squareglass/NativeIconMotion$State;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 16
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativeIconMotion;->states:Ljava/util/WeakHashMap;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static after(Landroid/view/View;Landroid/view/View;Landroid/graphics/Canvas;I)V
    .locals 18

    if-gez p3, :cond_0

    goto/16 :goto_1

    .line 64
    :cond_0
    invoke-virtual/range {p2 .. p3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 65
    sget-object v0, Ldev/nino/squareglass/NativeIconMotion;->states:Ljava/util/WeakHashMap;

    move-object/from16 v1, p0

    invoke-virtual {v0, v1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconMotion$State;

    if-eqz v0, :cond_2

    iget v2, v0, Ldev/nino/squareglass/NativeIconMotion$State;->kind:I

    const/4 v3, 0x2

    if-ne v2, v3, :cond_2

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v2

    if-nez v2, :cond_1

    goto/16 :goto_1

    .line 66
    :cond_1
    iget v0, v0, Ldev/nino/squareglass/NativeIconMotion$State;->progress:F

    invoke-virtual {v1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 67
    new-instance v2, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v2, v3}, Landroid/graphics/Paint;-><init>(I)V

    const v3, -0x9767

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v3, 0x3f800000    # 1.0f

    sub-float/2addr v3, v0

    const/high16 v4, 0x437f0000    # 255.0f

    mul-float/2addr v3, v4

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 68
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getLeft()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getWidth()I

    move-result v4

    int-to-float v4, v4

    const/high16 v5, 0x3f000000    # 0.5f

    mul-float/2addr v4, v5

    add-float/2addr v3, v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getTop()I

    move-result v4

    int-to-float v4, v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getHeight()I

    move-result v6

    int-to-float v6, v6

    mul-float/2addr v6, v5

    add-float/2addr v4, v6

    const/4 v5, 0x0

    :goto_0
    const/4 v6, 0x6

    if-ge v5, v6, :cond_2

    mul-int/lit8 v6, v5, 0x3c

    add-int/lit8 v6, v6, -0x5a

    int-to-double v6, v6

    const-wide v8, 0x400921fb54442d18L    # Math.PI

    mul-double/2addr v6, v8

    const-wide v8, 0x4066800000000000L    # 180.0

    div-double/2addr v6, v8

    const/high16 v8, 0x41c00000    # 24.0f

    mul-float/2addr v8, v0

    const/high16 v9, 0x41400000    # 12.0f

    add-float/2addr v8, v9

    mul-float/2addr v8, v1

    const/high16 v9, 0x40400000    # 3.0f

    mul-float/2addr v9, v1

    .line 71
    invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D

    move-result-wide v10

    double-to-float v10, v10

    mul-float/2addr v10, v8

    add-float/2addr v10, v3

    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    move-result-wide v6

    double-to-float v6, v6

    mul-float/2addr v6, v8

    add-float/2addr v6, v4

    const/high16 v7, 0x41000000    # 8.0f

    mul-float/2addr v7, v1

    mul-float/2addr v7, v0

    sub-float/2addr v6, v7

    .line 72
    new-instance v11, Landroid/graphics/Path;

    invoke-direct {v11}, Landroid/graphics/Path;-><init>()V

    add-float v7, v6, v9

    invoke-virtual {v11, v10, v7}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v8, 0x40000000    # 2.0f

    mul-float/2addr v8, v9

    sub-float v12, v10, v8

    const v13, 0x3e99999a    # 0.3f

    mul-float/2addr v13, v9

    sub-float v13, v6, v13

    sub-float v14, v10, v9

    sub-float v15, v6, v8

    const v16, 0x3f333333    # 0.7f

    mul-float v16, v16, v9

    sub-float v17, v6, v16

    move/from16 v16, v10

    invoke-virtual/range {v11 .. v17}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    add-float v12, v16, v9

    add-float v14, v16, v8

    move/from16 v17, v15

    move v15, v13

    move/from16 v13, v17

    move/from16 v17, v7

    .line 73
    invoke-virtual/range {v11 .. v17}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    invoke-virtual {v11}, Landroid/graphics/Path;->close()V

    move-object/from16 v6, p2

    invoke-virtual {v6, v11, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    return-void
.end method

.method public static attach(Landroid/view/View;)V
    .locals 2

    .line 32
    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0b02c6

    if-ne v0, v1, :cond_1

    sget-object v0, Ldev/nino/squareglass/NativeIconMotion;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 33
    :cond_0
    new-instance v1, Ldev/nino/squareglass/NativeIconMotion$State;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/NativeIconMotion$State;-><init>(Landroid/view/View;)V

    invoke-virtual {v0, p0, v1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Ldev/nino/squareglass/NativeIconMotion$0;

    invoke-direct {v0, v1}, Ldev/nino/squareglass/NativeIconMotion$0;-><init>(Ldev/nino/squareglass/NativeIconMotion$State;)V

    invoke-static {p0, v0}, Ldev/nino/squareglass/IconMotion;->registerNative(Landroid/view/View;Ljava/util/function/IntConsumer;)Ljava/lang/Object;

    move-result-object p0

    iput-object p0, v1, Ldev/nino/squareglass/NativeIconMotion$State;->token:Ljava/lang/Object;

    :cond_1
    :goto_0
    return-void
.end method

.method public static before(Landroid/view/View;Landroid/view/View;Landroid/graphics/Canvas;)I
    .locals 13

    .line 48
    sget-object v0, Ldev/nino/squareglass/NativeIconMotion;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconMotion$State;

    const/4 v1, -0x1

    if-eqz v0, :cond_b

    instance-of v2, p1, Landroid/widget/ImageView;

    if-nez v2, :cond_0

    goto/16 :goto_7

    .line 49
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->isSelected()Z

    move-result v2

    .line 50
    iget-boolean v3, v0, Ldev/nino/squareglass/NativeIconMotion$State;->selected:Z

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eq v2, v3, :cond_3

    .line 51
    iput-boolean v2, v0, Ldev/nino/squareglass/NativeIconMotion$State;->selected:Z

    .line 52
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v6

    iget-wide v8, v0, Ldev/nino/squareglass/NativeIconMotion$State;->tap:J

    sub-long/2addr v6, v8

    const-wide/16 v8, 0x2710

    cmp-long v3, v6, v8

    if-gez v3, :cond_2

    if-eqz v2, :cond_1

    move v3, v4

    goto :goto_0

    :cond_1
    move v3, v5

    :goto_0
    invoke-virtual {v0, v3}, Ldev/nino/squareglass/NativeIconMotion$State;->fire(I)V

    if-eqz v2, :cond_2

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v2

    if-eqz v2, :cond_2

    sget v2, Ldev/nino/squareglass/ProbeDiagnostics;->likeAnimations:I

    add-int/lit8 v2, v2, 0x1

    sput v2, Ldev/nino/squareglass/ProbeDiagnostics;->likeAnimations:I

    :cond_2
    const-wide/16 v2, -0x4e20

    .line 53
    iput-wide v2, v0, Ldev/nino/squareglass/NativeIconMotion$State;->tap:J

    .line 55
    :cond_3
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v2

    if-eqz v2, :cond_b

    iget v2, v0, Ldev/nino/squareglass/NativeIconMotion$State;->progress:F

    const/high16 v3, 0x3f800000    # 1.0f

    cmpl-float v2, v2, v3

    if-ltz v2, :cond_4

    goto/16 :goto_7

    .line 56
    :cond_4
    iget v1, v0, Ldev/nino/squareglass/NativeIconMotion$State;->progress:F

    const-wide v6, 0x400921fb54442d18L    # Math.PI

    float-to-double v8, v1

    mul-double/2addr v8, v6

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v6

    double-to-float v2, v6

    iget v6, v0, Ldev/nino/squareglass/NativeIconMotion$State;->kind:I

    const v7, 0x3df5c28f    # 0.12f

    const/4 v10, 0x5

    if-ne v6, v5, :cond_5

    mul-float/2addr v7, v2

    sub-float v6, v3, v7

    goto :goto_2

    .line 57
    :cond_5
    iget v6, v0, Ldev/nino/squareglass/NativeIconMotion$State;->kind:I

    if-ne v6, v10, :cond_6

    const-wide/high16 v11, 0x4000000000000000L    # 2.0

    mul-double/2addr v11, v8

    invoke-static {v11, v12}, Ljava/lang/Math;->sin(D)D

    move-result-wide v11

    double-to-float v6, v11

    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v6

    mul-float/2addr v6, v7

    goto :goto_1

    :cond_6
    const v6, 0x3e19999a    # 0.15f

    mul-float/2addr v6, v2

    :goto_1
    sub-float v7, v3, v1

    mul-float/2addr v6, v7

    add-float/2addr v6, v3

    .line 58
    :goto_2
    iget v7, v0, Ldev/nino/squareglass/NativeIconMotion$State;->kind:I

    const/4 v11, 0x0

    if-eq v7, v4, :cond_a

    iget v7, v0, Ldev/nino/squareglass/NativeIconMotion$State;->kind:I

    if-eq v7, v5, :cond_a

    iget v5, v0, Ldev/nino/squareglass/NativeIconMotion$State;->kind:I

    if-ne v5, v10, :cond_7

    goto :goto_5

    :cond_7
    iget v5, v0, Ldev/nino/squareglass/NativeIconMotion$State;->kind:I

    const/4 v7, 0x4

    if-ne v5, v7, :cond_8

    goto :goto_3

    :cond_8
    move v4, v7

    :goto_3
    int-to-double v4, v4

    mul-double/2addr v8, v4

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v4

    double-to-float v4, v4

    sub-float/2addr v3, v1

    mul-float/2addr v4, v3

    iget v0, v0, Ldev/nino/squareglass/NativeIconMotion$State;->kind:I

    if-ne v0, v7, :cond_9

    const/16 v0, 0xa

    goto :goto_4

    :cond_9
    const/4 v0, 0x7

    :goto_4
    int-to-float v0, v0

    mul-float/2addr v4, v0

    goto :goto_6

    :cond_a
    :goto_5
    move v4, v11

    .line 59
    :goto_6
    invoke-virtual {p2}, Landroid/graphics/Canvas;->save()I

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    const/high16 v5, 0x3f000000    # 0.5f

    mul-float/2addr v3, v5

    add-float/2addr v1, v3

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, v5

    add-float/2addr v3, p1

    neg-float p1, v2

    const/high16 v2, 0x40200000    # 2.5f

    mul-float/2addr p1, v2

    .line 60
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-virtual {p2, v11, p1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 61
    invoke-virtual {p2, v4, v1, v3}, Landroid/graphics/Canvas;->rotate(FFF)V

    invoke-virtual {p2, v6, v6, v1, v3}, Landroid/graphics/Canvas;->scale(FFFF)V

    return v0

    :cond_b
    :goto_7
    return v1
.end method

.method public static detach(Landroid/view/View;)V
    .locals 2

    .line 36
    sget-object v0, Ldev/nino/squareglass/NativeIconMotion;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconMotion$State;

    if-nez v0, :cond_0

    return-void

    .line 37
    :cond_0
    iget-object v1, v0, Ldev/nino/squareglass/NativeIconMotion$State;->token:Ljava/lang/Object;

    invoke-static {v1}, Ldev/nino/squareglass/IconMotion;->unregisterNative(Ljava/lang/Object;)V

    iget-object v1, v0, Ldev/nino/squareglass/NativeIconMotion$State;->animator:Landroid/animation/ValueAnimator;

    if-eqz v1, :cond_1

    iget-object v0, v0, Ldev/nino/squareglass/NativeIconMotion$State;->animator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public static touch(Landroid/view/View;Landroid/view/MotionEvent;)V
    .locals 7

    .line 40
    sget-object v0, Ldev/nino/squareglass/NativeIconMotion;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconMotion$State;

    if-nez v0, :cond_0

    goto :goto_0

    .line 41
    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_1

    .line 42
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    iput v3, v0, Ldev/nino/squareglass/NativeIconMotion$State;->x:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    iput v3, v0, Ldev/nino/squareglass/NativeIconMotion$State;->y:F

    const/4 v3, 0x0

    iput-boolean v3, v0, Ldev/nino/squareglass/NativeIconMotion$State;->moved:Z

    invoke-virtual {v0, v2}, Ldev/nino/squareglass/NativeIconMotion$State;->fire(I)V

    :cond_1
    const/4 v3, 0x2

    if-ne v1, v3, :cond_2

    .line 43
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    iget v4, v0, Ldev/nino/squareglass/NativeIconMotion$State;->x:F

    sub-float/2addr v3, v4

    float-to-double v3, v3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iget v5, v0, Ldev/nino/squareglass/NativeIconMotion$State;->y:F

    sub-float/2addr p1, v5

    float-to-double v5, p1

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result p0

    int-to-double p0, p0

    cmpl-double p0, v3, p0

    if-lez p0, :cond_2

    iput-boolean v2, v0, Ldev/nino/squareglass/NativeIconMotion$State;->moved:Z

    :cond_2
    const/4 p0, 0x3

    if-eq v1, p0, :cond_3

    const/4 p0, 0x5

    if-ne v1, p0, :cond_4

    .line 44
    :cond_3
    iput-boolean v2, v0, Ldev/nino/squareglass/NativeIconMotion$State;->moved:Z

    :cond_4
    if-ne v1, v2, :cond_5

    .line 45
    iget-boolean p0, v0, Ldev/nino/squareglass/NativeIconMotion$State;->moved:Z

    if-nez p0, :cond_5

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide p0

    iput-wide p0, v0, Ldev/nino/squareglass/NativeIconMotion$State;->tap:J

    :cond_5
    :goto_0
    return-void
.end method
