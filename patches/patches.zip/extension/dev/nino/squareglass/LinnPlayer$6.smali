.class public final synthetic Ldev/nino/squareglass/LinnPlayer$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:I

.field public final synthetic f$2:Ljava/lang/Exception;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;ILjava/lang/Exception;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput p2, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$1:I

    iput-object p3, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$2:Ljava/lang/Exception;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$1:I

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$2:Ljava/lang/Exception;

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$7PicGHndXZcdeFB-7Jo-M7sM2sU(Ldev/nino/squareglass/LinnPlayer;ILjava/lang/Exception;)V

    return-void
.end method
