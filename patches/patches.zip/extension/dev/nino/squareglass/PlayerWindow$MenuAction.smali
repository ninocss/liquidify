.class final Ldev/nino/squareglass/PlayerWindow$MenuAction;
.super Ljava/lang/Object;
.source "PlayerWindow.java"

# interfaces
.implements Lam0/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/PlayerWindow;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "MenuAction"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/u;",
        ">;"
    }
.end annotation


# instance fields
.field private final action:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lam0/a;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerWindow$MenuAction;->action:Lam0/a;

    return-void
.end method

.method static synthetic lambda$invoke$0(Ldev/nino/squareglass/PlayerWindow$Snapshot;)V
    .locals 1

    .line 36
    invoke-static {}, Ldev/nino/squareglass/PlayerWindow;->-$$Nest$sfgetpending()Ldev/nino/squareglass/PlayerWindow$Snapshot;

    move-result-object v0

    if-ne v0, p0, :cond_0

    const/4 v0, 0x0

    invoke-static {v0}, Ldev/nino/squareglass/PlayerWindow;->-$$Nest$sfputpending(Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    invoke-virtual {p0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->release()V

    :cond_0
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 25
    invoke-virtual {p0}, Ldev/nino/squareglass/PlayerWindow$MenuAction;->invoke()Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public invoke()Lkotlin/u;
    .locals 5

    .line 29
    invoke-static {}, Ldev/nino/squareglass/PlayerWindow;->-$$Nest$sfgetpending()Ldev/nino/squareglass/PlayerWindow$Snapshot;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/PlayerWindow;->-$$Nest$sfgetpending()Ldev/nino/squareglass/PlayerWindow$Snapshot;

    move-result-object v0

    invoke-virtual {v0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->release()V

    :cond_0
    const/4 v0, 0x0

    .line 30
    invoke-static {v0}, Ldev/nino/squareglass/PlayerWindow;->-$$Nest$sfputpending(Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    .line 31
    invoke-static {}, Ldev/nino/squareglass/PlayerWindow;->-$$Nest$sfgetplayer()Ljava/lang/ref/WeakReference;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    if-eqz v0, :cond_1

    .line 32
    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    if-lez v1, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v1

    if-lez v1, :cond_1

    .line 33
    new-instance v1, Ldev/nino/squareglass/PlayerWindow$Snapshot;

    invoke-direct {v1, v0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;-><init>(Landroid/view/View;)V

    invoke-static {v1}, Ldev/nino/squareglass/PlayerWindow;->-$$Nest$sfputpending(Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    .line 34
    :cond_1
    invoke-static {}, Ldev/nino/squareglass/PlayerWindow;->-$$Nest$sfgetpending()Ldev/nino/squareglass/PlayerWindow$Snapshot;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 35
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Ldev/nino/squareglass/PlayerWindow$MenuAction$0;

    invoke-direct {v2, v0}, Ldev/nino/squareglass/PlayerWindow$MenuAction$0;-><init>(Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    const-wide/16 v3, 0x2710

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 38
    :cond_2
    iget-object p0, p0, Ldev/nino/squareglass/PlayerWindow$MenuAction;->action:Lam0/a;

    invoke-interface {p0}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lkotlin/u;

    return-object p0
.end method
