.class final Ldev/nino/squareglass/LinnQueueTransaction;
.super Ljava/lang/Object;
.source "LinnQueueTransaction.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LinnQueueTransaction$Track;
    }
.end annotation


# instance fields
.field final backup:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field final desired:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ldev/nino/squareglass/LinnQueueTransaction$Track;",
            ">;"
        }
    .end annotation
.end field

.field final device:Ldev/nino/squareglass/OpenHome;

.field final expected:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field final inserted:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field final original:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field final remote:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field final retained:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private uncertain:Z


# direct methods
.method constructor <init>(Ldev/nino/squareglass/OpenHome;Ljava/util/List;Ljava/util/List;Ljava/util/List;I)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/OpenHome;",
            "Ljava/util/List<",
            "Ldev/nino/squareglass/LinnQueueTransaction$Track;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;I)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->remote:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->inserted:Ljava/util/List;

    .line 21
    iput-object p1, p0, Ldev/nino/squareglass/LinnQueueTransaction;->device:Ldev/nino/squareglass/OpenHome;

    iput-object p2, p0, Ldev/nino/squareglass/LinnQueueTransaction;->desired:Ljava/util/List;

    invoke-virtual {p1}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->original:Ljava/util/List;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v1, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    .line 22
    invoke-virtual {p1, v0}, Ldev/nino/squareglass/OpenHome;->readTracks(Ljava/util/List;)Ljava/util/Map;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnQueueTransaction;->backup:Ljava/util/Map;

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 23
    invoke-interface {v0, p4}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result v0

    invoke-interface {p4}, Ljava/util/List;->size()I

    move-result v1

    if-ne v0, v1, :cond_2

    .line 24
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v1, 0x0

    :goto_0
    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    invoke-interface {p3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {p4, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 25
    :cond_0
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :cond_1
    :goto_1
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_2

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Ldev/nino/squareglass/LinnQueueTransaction$Track;

    iget-object v1, p4, Ldev/nino/squareglass/LinnQueueTransaction$Track;->key:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    iget-object v2, p0, Ldev/nino/squareglass/LinnQueueTransaction;->backup:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    if-eqz v2, :cond_1

    .line 26
    iget-object v3, p4, Ldev/nino/squareglass/LinnQueueTransaction$Track;->uri:Ljava/lang/String;

    const-string v4, "Uri"

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    iget-object v3, p4, Ldev/nino/squareglass/LinnQueueTransaction$Track;->metadata:Ljava/lang/String;

    const-string v4, "Metadata"

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    iget-object p4, p4, Ldev/nino/squareglass/LinnQueueTransaction$Track;->key:Ljava/lang/String;

    invoke-interface {p1, p4, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    .line 28
    :cond_2
    new-instance p3, Ljava/util/ArrayList;

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p4

    :goto_2
    invoke-interface {p4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-interface {p4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/LinnQueueTransaction$Track;

    iget-object v0, v0, Ldev/nino/squareglass/LinnQueueTransaction$Track;->key:Ljava/lang/String;

    invoke-interface {p3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 29
    :cond_3
    iget-object p4, p0, Ldev/nino/squareglass/LinnQueueTransaction;->original:Ljava/util/List;

    invoke-static {p3, p1, p4}, Ldev/nino/squareglass/LinnQueuePlan;->retained(Ljava/util/List;Ljava/util/Map;Ljava/util/List;)Ljava/util/Map;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnQueueTransaction;->retained:Ljava/util/Map;

    .line 30
    iget-object p0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->original:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p2

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result p1

    sub-int/2addr p2, p1

    invoke-static {p0, p3, p2, p5}, Ldev/nino/squareglass/LinnQueuePlan;->stagingCapacity(IIII)V

    return-void
.end method

.method private assertExpected()V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 79
    iget-object v0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->device:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ldev/nino/squareglass/OpenHome$Fault;

    sget-object v1, Ldev/nino/squareglass/OpenHome$Failure;->CONFLICT:Ldev/nino/squareglass/OpenHome$Failure;

    const-string v5, "Linn queue changed in another controller"

    const/4 v6, 0x0

    const-string v2, "Queue transaction"

    const/4 v3, 0x0

    const-string v4, ""

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method static requireCurrent(Ljava/util/function/BooleanSupplier;)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 82
    invoke-interface {p0}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    move-result p0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Linn handoff was cancelled"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method commit(Ljava/util/function/BooleanSupplier;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 47
    new-instance v0, Ljava/util/HashSet;

    iget-object v1, p0, Ldev/nino/squareglass/LinnQueueTransaction;->remote:Ljava/util/List;

    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 48
    iget-object v1, p0, Ldev/nino/squareglass/LinnQueueTransaction;->original:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_0

    .line 49
    invoke-static {p1}, Ldev/nino/squareglass/LinnQueueTransaction;->requireCurrent(Ljava/util/function/BooleanSupplier;)V

    invoke-direct {p0}, Ldev/nino/squareglass/LinnQueueTransaction;->assertExpected()V

    .line 50
    :try_start_0
    iget-object v5, p0, Ldev/nino/squareglass/LinnQueueTransaction;->device:Ldev/nino/squareglass/OpenHome;

    const-string v6, "Playlist"

    const-string v7, "DeleteId"

    invoke-static {v3, v4}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v6, v7, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;
    :try_end_0
    .catch Ldev/nino/squareglass/OpenHome$Fault; {:try_start_0 .. :try_end_0} :catch_0

    .line 52
    iget-object v3, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :catch_0
    move-exception p1

    .line 51
    iget-object v0, p1, Ldev/nino/squareglass/OpenHome$Fault;->kind:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v1, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    if-ne v0, v1, :cond_1

    const/4 v0, 0x1

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->uncertain:Z

    :cond_1
    throw p1

    .line 54
    :cond_2
    invoke-direct {p0}, Ldev/nino/squareglass/LinnQueueTransaction;->assertExpected()V

    .line 55
    iget-object p1, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    iget-object p0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->remote:Ljava/util/List;

    invoke-interface {p1, p0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_3

    return-void

    :cond_3
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Linn queue order was not confirmed"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method rollback()Ljava/util/Map;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 58
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnQueueTransaction;->verifyRollback()V

    .line 59
    iget-object v0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->inserted:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    .line 60
    invoke-direct {p0}, Ldev/nino/squareglass/LinnQueueTransaction;->assertExpected()V

    iget-object v4, p0, Ldev/nino/squareglass/LinnQueueTransaction;->device:Ldev/nino/squareglass/OpenHome;

    invoke-static {v2, v3}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/String;

    move-result-object v2

    const-string v3, "Playlist"

    const-string v5, "DeleteId"

    invoke-virtual {v4, v3, v5, v2}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    iget-object v2, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    .line 62
    :cond_0
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 63
    iget-object v1, p0, Ldev/nino/squareglass/LinnQueueTransaction;->original:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const-wide/16 v2, 0x0

    move-wide v6, v2

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v10, v4

    check-cast v10, Ljava/lang/Long;

    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    .line 64
    invoke-direct {p0}, Ldev/nino/squareglass/LinnQueueTransaction;->assertExpected()V

    .line 65
    iget-object v8, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    invoke-interface {v8, v10}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_2

    .line 66
    iget-object v4, p0, Ldev/nino/squareglass/LinnQueueTransaction;->backup:Ljava/util/Map;

    invoke-interface {v4, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map;

    move-object v5, v4

    .line 67
    iget-object v4, p0, Ldev/nino/squareglass/LinnQueueTransaction;->device:Ldev/nino/squareglass/OpenHome;

    move-object v8, v5

    iget-object v5, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    const-string v9, "Uri"

    invoke-interface {v8, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const-string v11, "Metadata"

    invoke-interface {v8, v11}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    move-object v12, v9

    move-object v9, v8

    move-object v8, v12

    invoke-virtual/range {v4 .. v9}, Ldev/nino/squareglass/OpenHome;->insertConfirmed(Ljava/util/List;JLjava/lang/String;Ljava/lang/String;)J

    move-result-wide v4

    .line 68
    iget-object v8, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    cmp-long v9, v6, v2

    if-nez v9, :cond_1

    const/4 v6, 0x0

    goto :goto_2

    :cond_1
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface {v8, v6}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v6

    add-int/lit8 v6, v6, 0x1

    :goto_2
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-interface {v8, v6, v7}, Ljava/util/List;->add(ILjava/lang/Object;)V

    :cond_2
    move-wide v6, v4

    .line 70
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-interface {v0, v10, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    .line 72
    :cond_3
    invoke-direct {p0}, Ldev/nino/squareglass/LinnQueueTransaction;->assertExpected()V

    return-object v0
.end method

.method stage(Ljava/util/function/BooleanSupplier;Ljava/util/function/IntConsumer;)V
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 33
    invoke-direct {p0}, Ldev/nino/squareglass/LinnQueueTransaction;->assertExpected()V

    .line 34
    iget-object v0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->desired:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-wide/16 v1, 0x0

    move-wide v5, v1

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ldev/nino/squareglass/LinnQueueTransaction$Track;

    .line 35
    invoke-static {p1}, Ldev/nino/squareglass/LinnQueueTransaction;->requireCurrent(Ljava/util/function/BooleanSupplier;)V

    .line 36
    iget-object v4, p0, Ldev/nino/squareglass/LinnQueueTransaction;->retained:Ljava/util/Map;

    iget-object v7, v3, Ldev/nino/squareglass/LinnQueueTransaction$Track;->key:Ljava/lang/String;

    invoke-interface {v4, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Long;

    if-nez v4, :cond_2

    const/4 v9, 0x1

    move-object v4, v3

    .line 38
    :try_start_0
    iget-object v3, p0, Ldev/nino/squareglass/LinnQueueTransaction;->device:Ldev/nino/squareglass/OpenHome;

    move-object v7, v4

    iget-object v4, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    move-object v8, v7

    iget-object v7, v8, Ldev/nino/squareglass/LinnQueueTransaction$Track;->uri:Ljava/lang/String;

    iget-object v8, v8, Ldev/nino/squareglass/LinnQueueTransaction$Track;->metadata:Ljava/lang/String;

    invoke-virtual/range {v3 .. v8}, Ldev/nino/squareglass/OpenHome;->insertConfirmed(Ljava/util/List;JLjava/lang/String;Ljava/lang/String;)J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4
    :try_end_0
    .catch Ldev/nino/squareglass/OpenHome$Fault; {:try_start_0 .. :try_end_0} :catch_0

    .line 40
    iget-object v3, p0, Ldev/nino/squareglass/LinnQueueTransaction;->expected:Ljava/util/List;

    cmp-long v7, v5, v1

    if-nez v7, :cond_0

    const/4 v5, 0x0

    goto :goto_1

    :cond_0
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-interface {v3, v5}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v5

    add-int/2addr v5, v9

    :goto_1
    invoke-interface {v3, v5, v4}, Ljava/util/List;->add(ILjava/lang/Object;)V

    iget-object v3, p0, Ldev/nino/squareglass/LinnQueueTransaction;->inserted:Ljava/util/List;

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :catch_0
    move-exception v0

    move-object p1, v0

    .line 39
    iget-object p2, p1, Ldev/nino/squareglass/OpenHome$Fault;->kind:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v0, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    if-ne p2, v0, :cond_1

    iput-boolean v9, p0, Ldev/nino/squareglass/LinnQueueTransaction;->uncertain:Z

    :cond_1
    throw p1

    .line 42
    :cond_2
    :goto_2
    iget-object v3, p0, Ldev/nino/squareglass/LinnQueueTransaction;->remote:Ljava/util/List;

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    invoke-static {p1}, Ldev/nino/squareglass/LinnQueueTransaction;->requireCurrent(Ljava/util/function/BooleanSupplier;)V

    iget-object v3, p0, Ldev/nino/squareglass/LinnQueueTransaction;->remote:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    invoke-interface {p2, v3}, Ljava/util/function/IntConsumer;->accept(I)V

    goto :goto_0

    .line 44
    :cond_3
    invoke-direct {p0}, Ldev/nino/squareglass/LinnQueueTransaction;->assertExpected()V

    return-void
.end method

.method verifyRollback()V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 75
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnQueueTransaction;->uncertain:Z

    if-nez v0, :cond_0

    .line 76
    invoke-direct {p0}, Ldev/nino/squareglass/LinnQueueTransaction;->assertExpected()V

    return-void

    .line 75
    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Recovery paused: device write outcome is uncertain"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
