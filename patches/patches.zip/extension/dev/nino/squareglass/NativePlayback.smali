.class public final Ldev/nino/squareglass/NativePlayback;
.super Ljava/lang/Object;
.source "NativePlayback.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/NativePlayback$Entry;
    }
.end annotation


# static fields
.field static context:Landroid/content/Context;

.field private static countedCurrent:Z

.field private static final history:Ljava/util/LinkedHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/Integer;",
            "Ldev/nino/squareglass/NativePlayback$Entry;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile historyGeneration:I

.field private static host:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lbi/e;",
            ">;"
        }
    .end annotation
.end field

.field private static initialized:Z

.field private static lastId:I

.field private static lastPosition:I

.field private static lastTick:J

.field private static listened:I

.field private static final main:Landroid/os/Handler;

.field private static playing:Z

.field private static final storage:Ljava/util/concurrent/ExecutorService;

.field private static final tick:Ljava/lang/Runnable;


# direct methods
.method static bridge synthetic -$$Nest$sfgetcountedCurrent()Z
    .locals 1

    sget-boolean v0, Ldev/nino/squareglass/NativePlayback;->countedCurrent:Z

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgethost()Ljava/lang/ref/WeakReference;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/NativePlayback;->host:Ljava/lang/ref/WeakReference;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetlastId()I
    .locals 1

    sget v0, Ldev/nino/squareglass/NativePlayback;->lastId:I

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgetlastPosition()I
    .locals 1

    sget v0, Ldev/nino/squareglass/NativePlayback;->lastPosition:I

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgetlastTick()J
    .locals 2

    sget-wide v0, Ldev/nino/squareglass/NativePlayback;->lastTick:J

    return-wide v0
.end method

.method static bridge synthetic -$$Nest$sfgetlistened()I
    .locals 1

    sget v0, Ldev/nino/squareglass/NativePlayback;->listened:I

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgetmain()Landroid/os/Handler;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/NativePlayback;->main:Landroid/os/Handler;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetplaying()Z
    .locals 1

    sget-boolean v0, Ldev/nino/squareglass/NativePlayback;->playing:Z

    return v0
.end method

.method static bridge synthetic -$$Nest$sfputcountedCurrent(Z)V
    .locals 0

    sput-boolean p0, Ldev/nino/squareglass/NativePlayback;->countedCurrent:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$sfputlastId(I)V
    .locals 0

    sput p0, Ldev/nino/squareglass/NativePlayback;->lastId:I

    return-void
.end method

.method static bridge synthetic -$$Nest$sfputlastPosition(I)V
    .locals 0

    sput p0, Ldev/nino/squareglass/NativePlayback;->lastPosition:I

    return-void
.end method

.method static bridge synthetic -$$Nest$sfputlastTick(J)V
    .locals 0

    sput-wide p0, Ldev/nino/squareglass/NativePlayback;->lastTick:J

    return-void
.end method

.method static bridge synthetic -$$Nest$sfputlistened(I)V
    .locals 0

    sput p0, Ldev/nino/squareglass/NativePlayback;->listened:I

    return-void
.end method

.method static bridge synthetic -$$Nest$smrecord(Lcom/aspiro/wamp/model/Track;)V
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/NativePlayback;->record(Lcom/aspiro/wamp/model/Track;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 22
    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/NativePlayback;->host:Ljava/lang/ref/WeakReference;

    .line 26
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Ldev/nino/squareglass/NativePlayback;->main:Landroid/os/Handler;

    .line 27
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativePlayback;->history:Ljava/util/LinkedHashMap;

    .line 30
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/NativePlayback;->storage:Ljava/util/concurrent/ExecutorService;

    .line 92
    new-instance v0, Ldev/nino/squareglass/NativePlayback$1;

    invoke-direct {v0}, Ldev/nino/squareglass/NativePlayback$1;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativePlayback;->tick:Ljava/lang/Runnable;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static autoplay(Landroid/content/Context;Z)V
    .locals 1

    const/4 v0, 0x0

    .line 71
    invoke-static {p0, p1, v0}, Ldev/nino/squareglass/NativePlayback;->autoplay(Landroid/content/Context;ZZ)V

    return-void
.end method

.method private static autoplay(Landroid/content/Context;ZZ)V
    .locals 13

    .line 73
    sget-object v0, Ldev/nino/squareglass/NativePlayback;->history:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    const-string p1, "Listen to a few tracks for at least 30 seconds to build your listening profile."

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativePlayback;->message(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    .line 74
    :cond_0
    sget-object v1, Ldev/nino/squareglass/NativePlayback;->host:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lbi/e;

    if-nez v1, :cond_1

    const-string p1, "Open a track first to connect the TIDAL player."

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativePlayback;->message(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    .line 75
    :cond_1
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p0

    const/16 v2, 0xb

    invoke-virtual {p0, v2}, Ljava/util/Calendar;->get(I)I

    move-result p0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    .line 76
    new-instance v4, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-direct {v4, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 77
    new-instance v0, Ldev/nino/squareglass/NativePlayback$2;

    invoke-direct {v0, p0, v2, v3, p1}, Ldev/nino/squareglass/NativePlayback$2;-><init>(IJZ)V

    invoke-interface {v4, v0}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    if-eqz p2, :cond_2

    .line 78
    invoke-static {v4}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    .line 79
    :cond_2
    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 80
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_3
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ldev/nino/squareglass/NativePlayback$Entry;

    .line 81
    iget-object v6, v3, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v6}, Lcom/aspiro/wamp/model/Track;->getAlbum()Lcom/aspiro/wamp/model/Album;

    move-result-object v6

    if-nez v6, :cond_4

    move v6, v5

    goto :goto_1

    :cond_4
    iget-object v6, v3, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v6}, Lcom/aspiro/wamp/model/Track;->getAlbum()Lcom/aspiro/wamp/model/Album;

    move-result-object v6

    invoke-virtual {v6}, Lcom/aspiro/wamp/model/Album;->getId()I

    move-result v6

    :goto_1
    if-eqz v6, :cond_5

    .line 82
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v0, v7, v8}, Ljava/util/Map;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    const/4 v8, 0x3

    if-lt v7, v8, :cond_5

    goto :goto_0

    .line 83
    :cond_5
    iget-object v3, v3, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    invoke-interface {p0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v0, v6, v7}, Ljava/util/Map;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    add-int/2addr v6, v4

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v0, v3, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v3

    const/16 v6, 0x19

    if-ne v3, v6, :cond_3

    .line 86
    :cond_6
    new-instance v0, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;

    if-eqz p2, :cond_7

    const-string p1, "Shuffle history"

    goto :goto_2

    :cond_7
    if-eqz p1, :cond_8

    const-string p1, "Rediscover"

    goto :goto_2

    :cond_8
    const-string p1, "For this time of day"

    :goto_2
    sget-object p2, Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType$None;->INSTANCE:Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType$None;

    const/4 v2, 0x0

    const-string v3, "squareglass-time"

    invoke-direct {v0, v3, p1, p2, v2}, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType;Lcom/tidal/android/navigation/NavigationInfo$Node;)V

    .line 87
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_3
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_9

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/aspiro/wamp/model/Track;

    new-instance p2, Lcom/aspiro/wamp/model/Track;

    invoke-direct {p2, p1}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    invoke-virtual {v0, p2}, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;->addSourceItem(Lcom/aspiro/wamp/model/MediaItem;)V

    goto :goto_3

    .line 88
    :cond_9
    invoke-interface {v1}, Lbi/e;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object p0

    new-instance v6, Lcom/aspiro/wamp/playqueue/w0;

    sget-object v9, Lcom/aspiro/wamp/enums/ShuffleMode;->TURN_OFF:Lcom/aspiro/wamp/enums/ShuffleMode;

    sget-object v10, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    const/4 v11, 0x0

    const/4 v12, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct/range {v6 .. v12}, Lcom/aspiro/wamp/playqueue/w0;-><init>(IZLcom/aspiro/wamp/enums/ShuffleMode;Lcom/aspiro/wamp/enums/RepeatMode;ZZ)V

    invoke-interface {p0, v0, v6}, Lcom/aspiro/wamp/playqueue/y;->prepare(Lcom/aspiro/wamp/playqueue/source/model/Source;Lcom/aspiro/wamp/playqueue/w0;)V

    .line 90
    invoke-interface {v1, v5, v5, v4}, Lbi/e;->b(IZZ)V

    return-void
.end method

.method public static bind(Lbi/e;)V
    .locals 1

    .line 61
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/NativePlayback;->host:Ljava/lang/ref/WeakReference;

    invoke-static {p0}, Ldev/nino/squareglass/SleepTimer;->playerChanged(Lbi/e;)V

    return-void
.end method

.method public static clearHistory()V
    .locals 2

    .line 133
    sget v0, Ldev/nino/squareglass/NativePlayback;->historyGeneration:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Ldev/nino/squareglass/NativePlayback;->historyGeneration:I

    sget-object v0, Ldev/nino/squareglass/NativePlayback;->history:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    const/4 v0, 0x0

    sput-boolean v0, Ldev/nino/squareglass/NativePlayback;->countedCurrent:Z

    sput v0, Ldev/nino/squareglass/NativePlayback;->listened:I

    sget-object v0, Ldev/nino/squareglass/NativePlayback;->context:Landroid/content/Context;

    if-eqz v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/NativePlayback;->storage:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Ldev/nino/squareglass/NativePlayback$0;

    invoke-direct {v1}, Ldev/nino/squareglass/NativePlayback$0;-><init>()V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method

.method public static host()Lbi/e;
    .locals 1

    .line 64
    sget-object v0, Ldev/nino/squareglass/NativePlayback;->host:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lbi/e;

    return-object v0
.end method

.method public static initialize(Landroid/content/Context;)V
    .locals 3

    .line 36
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    sput-object p0, Ldev/nino/squareglass/NativePlayback;->context:Landroid/content/Context;

    .line 37
    sget-boolean p0, Ldev/nino/squareglass/NativePlayback;->initialized:Z

    if-eqz p0, :cond_0

    return-void

    :cond_0
    const/4 p0, 0x1

    .line 38
    sput-boolean p0, Ldev/nino/squareglass/NativePlayback;->initialized:Z

    .line 40
    sget p0, Ldev/nino/squareglass/NativePlayback;->historyGeneration:I

    .line 41
    sget-object v0, Ldev/nino/squareglass/NativePlayback;->storage:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Ldev/nino/squareglass/NativePlayback$6;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/NativePlayback$6;-><init>(I)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 59
    sget-object p0, Ldev/nino/squareglass/NativePlayback;->main:Landroid/os/Handler;

    sget-object v0, Ldev/nino/squareglass/NativePlayback;->tick:Ljava/lang/Runnable;

    const-wide/16 v1, 0x1388

    invoke-virtual {p0, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method static synthetic lambda$autoplay$0(IJZLdev/nino/squareglass/NativePlayback$Entry;Ldev/nino/squareglass/NativePlayback$Entry;)I
    .locals 7

    .line 77
    iget-object v0, p5, Ldev/nino/squareglass/NativePlayback$Entry;->hours:[I

    iget-wide v2, p5, Ldev/nino/squareglass/NativePlayback$Entry;->last:J

    move v1, p0

    move-wide v4, p1

    move v6, p3

    invoke-static/range {v0 .. v6}, Ldev/nino/squareglass/TimeTaste;->score([IIJJZ)D

    move-result-wide p0

    iget-object v0, p4, Ldev/nino/squareglass/NativePlayback$Entry;->hours:[I

    iget-wide v2, p4, Ldev/nino/squareglass/NativePlayback$Entry;->last:J

    invoke-static/range {v0 .. v6}, Ldev/nino/squareglass/TimeTaste;->score([IIJJZ)D

    move-result-wide p2

    invoke-static {p0, p1, p2, p3}, Ljava/lang/Double;->compare(DD)I

    move-result p0

    return p0
.end method

.method static synthetic lambda$clearHistory$0()V
    .locals 3

    .line 133
    sget-object v0, Ldev/nino/squareglass/NativePlayback;->context:Landroid/content/Context;

    const-string v1, "squareglass_taste_v1"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method static synthetic lambda$initialize$0(I)V
    .locals 11

    .line 42
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 44
    :try_start_0
    new-instance v1, Lorg/json/JSONArray;

    sget-object v2, Ldev/nino/squareglass/NativePlayback;->context:Landroid/content/Context;

    const-string v3, "squareglass_taste_v1"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "tracks"

    const-string v5, "[]"

    invoke-interface {v2, v3, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move v2, v4

    .line 45
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/16 v5, 0xa0

    invoke-static {v5, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    if-ge v2, v3, :cond_2

    .line 46
    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    .line 47
    const-string v5, "track"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x2

    invoke-static {v5, v6}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v5

    .line 48
    array-length v6, v5

    const/high16 v7, 0x20000

    if-le v6, v7, :cond_0

    goto :goto_2

    .line 49
    :cond_0
    new-instance v6, Ljava/io/ObjectInputStream;

    new-instance v7, Ljava/io/ByteArrayInputStream;

    invoke-direct {v7, v5}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v6, v7}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 50
    :try_start_1
    new-instance v5, Ldev/nino/squareglass/NativePlayback$Entry;

    invoke-direct {v5}, Ldev/nino/squareglass/NativePlayback$Entry;-><init>()V

    invoke-virtual {v6}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/aspiro/wamp/model/Track;

    iput-object v7, v5, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    const-string v7, "last"

    invoke-virtual {v3, v7}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v7

    iput-wide v7, v5, Ldev/nino/squareglass/NativePlayback$Entry;->last:J

    .line 51
    const-string v7, "hours"

    invoke-virtual {v3, v7}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    move v7, v4

    :goto_1
    const/16 v8, 0x18

    if-ge v7, v8, :cond_1

    .line 52
    iget-object v8, v5, Ldev/nino/squareglass/NativePlayback$Entry;->hours:[I

    invoke-virtual {v3, v7}, Lorg/json/JSONArray;->optInt(I)I

    move-result v9

    const/16 v10, 0x2710

    invoke-static {v10, v9}, Ljava/lang/Math;->min(II)I

    move-result v9

    invoke-static {v4, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    aput v9, v8, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 53
    :cond_1
    iget-object v3, v5, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v3}, Lcom/aspiro/wamp/model/Track;->getId()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v3, v5}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 54
    :try_start_2
    invoke-virtual {v6}, Ljava/io/ObjectInputStream;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception v1

    .line 49
    :try_start_3
    invoke-virtual {v6}, Ljava/io/ObjectInputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_3

    :catchall_1
    move-exception v2

    :try_start_4
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_3
    throw v1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 56
    :catch_0
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    .line 57
    :cond_2
    sget-object v1, Ldev/nino/squareglass/NativePlayback;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/NativePlayback$3;

    invoke-direct {v2, p0, v0}, Ldev/nino/squareglass/NativePlayback$3;-><init>(ILjava/util/LinkedHashMap;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static synthetic lambda$initialize$1(ILjava/util/LinkedHashMap;)V
    .locals 2

    .line 57
    sget v0, Ldev/nino/squareglass/NativePlayback;->historyGeneration:I

    if-ne p0, v0, :cond_0

    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map$Entry;

    sget-object v0, Ldev/nino/squareglass/NativePlayback;->history:Ljava/util/LinkedHashMap;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ldev/nino/squareglass/NativePlayback$Entry;

    invoke-virtual {v0, v1, p1}, Ljava/util/LinkedHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_0
    return-void
.end method

.method static synthetic lambda$logout$0()V
    .locals 1

    .line 134
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->clearHistory()V

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->cancel()V

    sget-object v0, Ldev/nino/squareglass/NativePlayback;->host:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->clear()V

    const/4 v0, 0x0

    sput-boolean v0, Ldev/nino/squareglass/NativePlayback;->playing:Z

    return-void
.end method

.method static synthetic lambda$message$0(Landroid/content/Context;Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x1

    .line 135
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method static synthetic lambda$save$0(Ljava/util/List;I)V
    .locals 8

    .line 122
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 123
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :catch_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldev/nino/squareglass/NativePlayback$Entry;

    .line 124
    :try_start_0
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 125
    new-instance v4, Ljava/io/ObjectOutputStream;

    invoke-direct {v4, v3}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    iget-object v5, v1, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v4, v5}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v4}, Ljava/io/ObjectOutputStream;->close()V

    .line 126
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v4

    const/high16 v5, 0x20000

    if-le v4, v5, :cond_0

    goto :goto_0

    .line 127
    :cond_0
    new-instance v4, Lorg/json/JSONArray;

    invoke-direct {v4}, Lorg/json/JSONArray;-><init>()V

    iget-object v5, v1, Ldev/nino/squareglass/NativePlayback$Entry;->hours:[I

    array-length v6, v5

    :goto_1
    if-ge v2, v6, :cond_1

    aget v7, v5, v2

    invoke-virtual {v4, v7}, Lorg/json/JSONArray;->put(I)Lorg/json/JSONArray;

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 128
    :cond_1
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v5, "track"

    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    const/4 v6, 0x2

    invoke-static {v3, v6}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v5, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "hours"

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "last"

    iget-wide v4, v1, Ldev/nino/squareglass/NativePlayback$Entry;->last:J

    invoke-virtual {v2, v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_0

    :catchall_0
    move-exception v1

    .line 125
    :try_start_3
    invoke-virtual {v4}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v2

    :try_start_4
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw v1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 130
    :cond_2
    sget p0, Ldev/nino/squareglass/NativePlayback;->historyGeneration:I

    if-ne p1, p0, :cond_3

    sget-object p0, Ldev/nino/squareglass/NativePlayback;->context:Landroid/content/Context;

    const-string p1, "squareglass_taste_v1"

    invoke-virtual {p0, p1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string p1, "tracks"

    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_3
    return-void
.end method

.method public static logout()V
    .locals 2

    .line 134
    sget-object v0, Ldev/nino/squareglass/NativePlayback;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/NativePlayback$4;

    invoke-direct {v1}, Ldev/nino/squareglass/NativePlayback$4;-><init>()V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static message(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    .line 135
    sget-object v0, Ldev/nino/squareglass/NativePlayback;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/NativePlayback$7;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/NativePlayback$7;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static next(Z)V
    .locals 2

    .line 66
    sget-object v0, Ldev/nino/squareglass/NativePlayback;->host:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lbi/e;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    if-eqz p0, :cond_1

    .line 67
    invoke-interface {v0}, Lbi/e;->canSkipToPreviousOrRewind()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 p0, 0x1

    invoke-interface {v0, p0}, Lbi/e;->h(Z)V

    return-void

    :cond_1
    if-nez p0, :cond_2

    .line 68
    invoke-interface {v0}, Lbi/e;->hasNext()Z

    move-result p0

    if-eqz p0, :cond_2

    invoke-interface {v0}, Lbi/e;->j()V

    :cond_2
    :goto_0
    return-void
.end method

.method public static observe(Z)V
    .locals 0

    .line 62
    sput-boolean p0, Ldev/nino/squareglass/NativePlayback;->playing:Z

    return-void
.end method

.method public static observeName(Ljava/lang/String;)V
    .locals 1

    .line 63
    const-string v0, "Playing"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    invoke-static {p0}, Ldev/nino/squareglass/NativePlayback;->observe(Z)V

    return-void
.end method

.method private static record(Lcom/aspiro/wamp/model/Track;)V
    .locals 4

    .line 111
    sget-object v0, Ldev/nino/squareglass/NativePlayback;->history:Ljava/util/LinkedHashMap;

    invoke-virtual {p0}, Lcom/aspiro/wamp/model/Track;->getId()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldev/nino/squareglass/NativePlayback$Entry;

    if-nez v1, :cond_0

    .line 112
    new-instance v1, Ldev/nino/squareglass/NativePlayback$Entry;

    invoke-direct {v1}, Ldev/nino/squareglass/NativePlayback$Entry;-><init>()V

    new-instance v2, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v2, p0}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    iput-object v2, v1, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    iget-object v2, v1, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Lcom/aspiro/wamp/model/Track;->setSource(Lcom/aspiro/wamp/playqueue/source/model/Source;)V

    invoke-virtual {p0}, Lcom/aspiro/wamp/model/Track;->getId()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-virtual {v0, p0, v1}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 113
    :cond_0
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p0

    const/16 v0, 0xb

    invoke-virtual {p0, v0}, Ljava/util/Calendar;->get(I)I

    move-result p0

    iget-object v0, v1, Ldev/nino/squareglass/NativePlayback$Entry;->hours:[I

    iget-object v2, v1, Ldev/nino/squareglass/NativePlayback$Entry;->hours:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, 0x1

    const/16 v3, 0x2710

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    aput v2, v0, p0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iput-wide v2, v1, Ldev/nino/squareglass/NativePlayback$Entry;->last:J

    .line 114
    :goto_0
    sget-object p0, Ldev/nino/squareglass/NativePlayback;->history:Ljava/util/LinkedHashMap;

    invoke-virtual {p0}, Ljava/util/LinkedHashMap;->size()I

    move-result v0

    const/16 v1, 0xa0

    if-le v0, v1, :cond_1

    invoke-virtual {p0}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 115
    :cond_1
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->save()V

    return-void
.end method

.method private static save()V
    .locals 6

    .line 118
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 119
    sget-object v1, Ldev/nino/squareglass/NativePlayback;->history:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ldev/nino/squareglass/NativePlayback$Entry;

    new-instance v3, Ldev/nino/squareglass/NativePlayback$Entry;

    invoke-direct {v3}, Ldev/nino/squareglass/NativePlayback$Entry;-><init>()V

    iget-object v4, v2, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    iput-object v4, v3, Ldev/nino/squareglass/NativePlayback$Entry;->track:Lcom/aspiro/wamp/model/Track;

    iget-object v4, v2, Ldev/nino/squareglass/NativePlayback$Entry;->hours:[I

    const/16 v5, 0x18

    invoke-static {v4, v5}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v4

    iput-object v4, v3, Ldev/nino/squareglass/NativePlayback$Entry;->hours:[I

    iget-wide v4, v2, Ldev/nino/squareglass/NativePlayback$Entry;->last:J

    iput-wide v4, v3, Ldev/nino/squareglass/NativePlayback$Entry;->last:J

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 120
    :cond_0
    sget v1, Ldev/nino/squareglass/NativePlayback;->historyGeneration:I

    .line 121
    sget-object v2, Ldev/nino/squareglass/NativePlayback;->storage:Ljava/util/concurrent/ExecutorService;

    new-instance v3, Ldev/nino/squareglass/NativePlayback$5;

    invoke-direct {v3, v0, v1}, Ldev/nino/squareglass/NativePlayback$5;-><init>(Ljava/util/List;I)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static shuffleHistory(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x1

    .line 70
    invoke-static {p0, v0, v1}, Ldev/nino/squareglass/NativePlayback;->autoplay(Landroid/content/Context;ZZ)V

    return-void
.end method
