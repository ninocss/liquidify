.class final Ldev/nino/squareglass/LinnCache$Entry;
.super Ljava/lang/Object;
.source "LinnCache.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/LinnCache;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Entry"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field final created:J

.field final value:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;J)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;J)V"
        }
    .end annotation

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnCache$Entry;->value:Ljava/lang/Object;

    iput-wide p2, p0, Ldev/nino/squareglass/LinnCache$Entry;->created:J

    return-void
.end method
