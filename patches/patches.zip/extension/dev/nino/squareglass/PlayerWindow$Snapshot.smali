.class public final Ldev/nino/squareglass/PlayerWindow$Snapshot;
.super Ljava/lang/Object;
.source "PlayerWindow.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/PlayerWindow;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Snapshot"
.end annotation


# instance fields
.field public final height:I

.field private final node:Landroid/graphics/RenderNode;

.field public final width:I

.field public final x:I

.field public final y:I


# direct methods
.method static bridge synthetic -$$Nest$fgetnode(Ldev/nino/squareglass/PlayerWindow$Snapshot;)Landroid/graphics/RenderNode;
    .locals 0

    iget-object p0, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->node:Landroid/graphics/RenderNode;

    return-object p0
.end method

.method constructor <init>(Landroid/view/View;)V
    .locals 4

    .line 45
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    new-instance v0, Landroid/graphics/RenderNode;

    const-string v1, "SquareGlass player menu source"

    invoke-direct {v0, v1}, Landroid/graphics/RenderNode;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->node:Landroid/graphics/RenderNode;

    const/4 v1, 0x2

    .line 46
    new-array v1, v1, [I

    invoke-virtual {p1, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v2, 0x0

    .line 47
    aget v3, v1, v2

    iput v3, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->x:I

    const/4 v3, 0x1

    aget v1, v1, v3

    iput v1, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->y:I

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v1

    iput v1, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->width:I

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v3

    iput v3, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->height:I

    .line 48
    invoke-virtual {v0, v2, v2, v1, v3}, Landroid/graphics/RenderNode;->setPosition(IIII)Z

    .line 49
    invoke-virtual {v0, v1, v3}, Landroid/graphics/RenderNode;->beginRecording(II)Landroid/graphics/RecordingCanvas;

    move-result-object v1

    .line 50
    :try_start_0
    invoke-virtual {p1, v1}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->endRecording()V

    return-void

    :catchall_0
    move-exception p1

    iget-object p0, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p0}, Landroid/graphics/RenderNode;->endRecording()V

    throw p1
.end method


# virtual methods
.method public release()V
    .locals 0

    .line 64
    iget-object p0, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p0}, Landroid/graphics/RenderNode;->discardDisplayList()V

    return-void
.end method

.method public view(Landroid/content/Context;Z)Landroid/view/View;
    .locals 1

    .line 53
    new-instance v0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;

    invoke-direct {v0, p0, p1, p2}, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;-><init>(Ldev/nino/squareglass/PlayerWindow$Snapshot;Landroid/content/Context;Z)V

    return-object v0
.end method
