.class public final synthetic Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$2;->f$0:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt$2;->f$0:Landroid/content/Context;

    invoke-static {p0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->$r8$lambda$r1CE-W8-0bj0QnwqBXuQLTOFubQ(Landroid/content/Context;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
