.class Ldev/nino/squareglass/SurfaceMotion$1;
.super Ljava/lang/Object;
.source "SurfaceMotion.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/SurfaceMotion;->enter(Landroid/view/View;ZZ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$menu:Z

.field final synthetic val$nativeSlide:Z


# direct methods
.method constructor <init>(ZZ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 14
    iput-boolean p1, p0, Ldev/nino/squareglass/SurfaceMotion$1;->val$menu:Z

    iput-boolean p2, p0, Ldev/nino/squareglass/SurfaceMotion$1;->val$nativeSlide:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    .line 17
    const-string v0, "enter"

    invoke-static {p1, v0}, Ldev/nino/squareglass/LiquidViewMotion;->cancel(Landroid/view/View;Ljava/lang/String;)V

    invoke-static {p1}, Ldev/nino/squareglass/SurfaceMotion;->reset(Landroid/view/View;)V

    iget-boolean v0, p0, Ldev/nino/squareglass/SurfaceMotion$1;->val$menu:Z

    if-nez v0, :cond_0

    iget-boolean v0, p0, Ldev/nino/squareglass/SurfaceMotion$1;->val$nativeSlide:Z

    if-nez v0, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setTranslationY(F)V

    :cond_0
    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method
