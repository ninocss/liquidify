.class public final Ldev/nino/squareglass/DesignEntry;
.super Ljava/lang/Object;
.source "DesignEntry.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDesignEntry.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DesignEntry.kt\ndev/nino/squareglass/DesignEntry\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 9 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 10 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 11 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 12 SnapshotIntState.kt\nandroidx/compose/runtime/SnapshotIntStateKt__SnapshotIntStateKt\n+ 13 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 14 SnapshotFloatState.kt\nandroidx/compose/runtime/PrimitiveSnapshotStateKt__SnapshotFloatStateKt\n*L\n1#1,166:1\n1807#2,3:167\n1924#2,2:495\n1926#2:587\n1915#2:720\n1834#2,4:721\n1916#2:731\n1924#2,2:766\n1926#2:774\n1128#3,6:170\n1128#3,6:213\n1128#3,6:349\n1128#3,6:435\n1128#3,6:445\n1128#3,6:451\n1128#3,6:497\n1128#3,6:592\n1128#3,6:598\n1128#3,6:604\n1128#3,6:648\n1128#3,6:654\n1128#3,6:660\n1128#3,6:708\n1128#3,6:714\n1128#3,6:725\n1128#3,6:732\n1128#3,6:738\n1128#3,6:744\n1128#3,6:750\n1128#3,6:756\n1128#3,6:768\n87#4:176\n84#4,9:177\n94#4:222\n87#4:303\n84#4,9:304\n94#4:344\n87#4:458\n84#4,9:459\n94#4:591\n87#4:611\n84#4,9:612\n94#4:669\n87#4:671\n84#4,9:672\n94#4:765\n80#5,6:186\n87#5,3:201\n90#5,2:210\n94#5:221\n80#5,6:234\n87#5,3:249\n90#5,2:258\n94#5:263\n80#5,6:276\n87#5,3:291\n90#5,2:300\n80#5,6:313\n87#5,3:328\n90#5,2:337\n94#5:343\n94#5:347\n80#5,6:366\n87#5,3:381\n90#5,2:390\n80#5,6:404\n87#5,3:419\n90#5,2:428\n94#5:433\n94#5:443\n80#5,6:468\n87#5,3:483\n90#5,2:492\n80#5,6:514\n87#5,3:529\n90#5,2:538\n80#5,6:552\n87#5,3:567\n90#5,2:576\n94#5:581\n94#5:585\n94#5:590\n80#5,6:621\n87#5,3:636\n90#5,2:645\n94#5:668\n80#5,6:681\n87#5,3:696\n90#5,2:705\n94#5:764\n391#6,9:192\n400#6:212\n401#6,2:219\n391#6,9:240\n400#6,3:260\n391#6,9:282\n400#6:302\n391#6,9:319\n400#6:339\n401#6,2:341\n401#6,2:345\n391#6,9:372\n400#6:392\n391#6,9:410\n400#6,3:430\n401#6,2:441\n391#6,9:474\n400#6:494\n391#6,9:520\n400#6:540\n391#6,9:558\n400#6,3:578\n401#6,2:583\n401#6,2:588\n391#6,9:627\n400#6:647\n401#6,2:666\n391#6,9:687\n400#6:707\n401#6,2:762\n4360#7,6:204\n4360#7,6:252\n4360#7,6:294\n4360#7,6:331\n4360#7,6:384\n4360#7,6:422\n4360#7,6:486\n4360#7,6:532\n4360#7,6:570\n4360#7,6:639\n4360#7,6:699\n113#8:223\n113#8:265\n113#8:340\n113#8:355\n113#8:393\n113#8:457\n113#8:503\n113#8:541\n113#8:610\n70#9:224\n67#9,9:225\n77#9:264\n70#9:394\n67#9,9:395\n77#9:434\n70#9:542\n67#9,9:543\n77#9:582\n99#10:266\n96#10,9:267\n106#10:348\n99#10:356\n96#10,9:357\n106#10:444\n99#10:504\n96#10,9:505\n106#10:586\n75#11:670\n78#12:775\n111#12,2:776\n85#13:778\n117#13,2:779\n85#13:781\n117#13,2:782\n80#14:784\n113#14,2:785\n*S KotlinDebug\n*F\n+ 1 DesignEntry.kt\ndev/nino/squareglass/DesignEntry\n*L\n33#1:167,3\n98#1:495,2\n98#1:587\n136#1:720\n138#1:721,4\n136#1:731\n45#1:766,2\n45#1:774\n41#1:170,6\n53#1:213,6\n85#1:349,6\n88#1:435,6\n95#1:445,6\n96#1:451,6\n99#1:497,6\n111#1:592,6\n112#1:598,6\n113#1:604,6\n115#1:648,6\n118#1:654,6\n122#1:660,6\n130#1:708,6\n133#1:714,6\n140#1:725,6\n149#1:732,6\n151#1:738,6\n160#1:744,6\n161#1:750,6\n162#1:756,6\n46#1:768,6\n43#1:176\n43#1:177,9\n43#1:222\n76#1:303\n76#1:304,9\n76#1:344\n97#1:458\n97#1:459,9\n97#1:591\n114#1:611\n114#1:612,9\n114#1:669\n128#1:671\n128#1:672,9\n128#1:765\n43#1:186,6\n43#1:201,3\n43#1:210,2\n43#1:221\n71#1:234,6\n71#1:249,3\n71#1:258,2\n71#1:263\n74#1:276,6\n74#1:291,3\n74#1:300,2\n76#1:313,6\n76#1:328,3\n76#1:337,2\n76#1:343\n74#1:347\n84#1:366,6\n84#1:381,3\n84#1:390,2\n87#1:404,6\n87#1:419,3\n87#1:428,2\n87#1:433\n84#1:443\n97#1:468,6\n97#1:483,3\n97#1:492,2\n99#1:514,6\n99#1:529,3\n99#1:538,2\n104#1:552,6\n104#1:567,3\n104#1:576,2\n104#1:581\n99#1:585\n97#1:590\n114#1:621,6\n114#1:636,3\n114#1:645,2\n114#1:668\n128#1:681,6\n128#1:696,3\n128#1:705,2\n128#1:764\n43#1:192,9\n43#1:212\n43#1:219,2\n71#1:240,9\n71#1:260,3\n74#1:282,9\n74#1:302\n76#1:319,9\n76#1:339\n76#1:341,2\n74#1:345,2\n84#1:372,9\n84#1:392\n87#1:410,9\n87#1:430,3\n84#1:441,2\n97#1:474,9\n97#1:494\n99#1:520,9\n99#1:540\n104#1:558,9\n104#1:578,3\n99#1:583,2\n97#1:588,2\n114#1:627,9\n114#1:647\n114#1:666,2\n128#1:687,9\n128#1:707\n128#1:762,2\n43#1:204,6\n71#1:252,6\n74#1:294,6\n76#1:331,6\n84#1:384,6\n87#1:422,6\n97#1:486,6\n99#1:532,6\n104#1:570,6\n114#1:639,6\n128#1:699,6\n71#1:223\n75#1:265\n76#1:340\n85#1:355\n87#1:393\n97#1:457\n101#1:503\n104#1:541\n114#1:610\n71#1:224\n71#1:225,9\n71#1:264\n87#1:394\n87#1:395,9\n87#1:434\n104#1:542\n104#1:543,9\n104#1:582\n74#1:266\n74#1:267,9\n74#1:348\n84#1:356\n84#1:357,9\n84#1:444\n99#1:504\n99#1:505,9\n99#1:586\n127#1:670\n41#1:775\n41#1:776,2\n95#1:778\n95#1:779,2\n111#1:781\n111#1:782,2\n112#1:784\n112#1:785,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000d\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u0008\n\u0002\u0008\u000b\n\u0002\u0010\u0007\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003JB\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\t2\u0017\u0010\n\u001a\u0013\u0012\u0004\u0012\u00020\u000c\u0012\u0004\u0012\u00020\u00050\u000b\u00a2\u0006\u0002\u0008\r2\n\u0010\u000e\u001a\u0006\u0012\u0002\u0008\u00030\u000fH\u0007\u00a2\u0006\u0002\u0010\u0010J\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0002J\u001f\u0010\u0015\u001a\u00020\u00052\u0006\u0010\u0016\u001a\u00020\u00172\u0008\u0008\u0002\u0010\u0018\u001a\u00020\u0019H\u0003\u00a2\u0006\u0002\u0010\u001aJ\u0015\u0010\u001b\u001a\u00020\u00052\u0006\u0010\u0016\u001a\u00020\u0017H\u0003\u00a2\u0006\u0002\u0010\u001cJ/\u0010\u001d\u001a\u00020\u00052\u0006\u0010\u001e\u001a\u00020\u00172\n\u0008\u0002\u0010\u001f\u001a\u0004\u0018\u00010\u00172\u000c\u0010 \u001a\u0008\u0012\u0004\u0012\u00020\u00050!H\u0003\u00a2\u0006\u0002\u0010\"J\'\u0010#\u001a\u00020\u00052\u0006\u0010\u001e\u001a\u00020\u00172\u0006\u0010$\u001a\u00020\u00172\u0008\u0008\u0002\u0010%\u001a\u00020\u0019H\u0003\u00a2\u0006\u0002\u0010&J?\u0010\'\u001a\u00020\u00052\u0006\u0010\u001e\u001a\u00020\u00172\u000c\u0010(\u001a\u0008\u0012\u0004\u0012\u00020\u00170\u000f2\u0006\u0010)\u001a\u00020*2\u0012\u0010+\u001a\u000e\u0012\u0004\u0012\u00020*\u0012\u0004\u0012\u00020\u00050\u000bH\u0003\u00a2\u0006\u0002\u0010,J=\u0010-\u001a\u00020\u00052\u0006\u0010\u001e\u001a\u00020\u00172\u0006\u0010$\u001a\u00020\u00172\u0006\u0010.\u001a\u00020*2\u0006\u0010/\u001a\u00020*2\u0006\u0010)\u001a\u00020*2\u0006\u00100\u001a\u00020\u0017H\u0003\u00a2\u0006\u0002\u00101J\r\u00102\u001a\u00020\u0005H\u0003\u00a2\u0006\u0002\u00103\u00a8\u00064\u00b2\u0006\n\u0010)\u001a\u00020*X\u008a\u008e\u0002\u00b2\u0006\n\u00105\u001a\u00020\u0019X\u008a\u008e\u0002\u00b2\u0006\n\u00105\u001a\u00020\u0019X\u008a\u008e\u0002\u00b2\u0006\n\u0010\u001f\u001a\u000206X\u008a\u008e\u0002"
    }
    d2 = {
        "Ldev/nino/squareglass/DesignEntry;",
        "",
        "<init>",
        "()V",
        "Screen",
        "",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "padding",
        "Landroidx/compose/foundation/layout/PaddingValues;",
        "nativeContent",
        "Lkotlin/Function1;",
        "Landroidx/compose/foundation/lazy/LazyListScope;",
        "Lkotlin/ExtensionFunctionType;",
        "items",
        "",
        "(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;Lam0/l;Ljava/util/List;Landroidx/compose/runtime/Composer;I)V",
        "activity",
        "Landroid/app/Activity;",
        "context",
        "Landroid/content/Context;",
        "Label",
        "text",
        "",
        "secondary",
        "",
        "(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V",
        "Section",
        "(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "Row",
        "label",
        "value",
        "onClick",
        "Lkotlin/Function0;",
        "(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V",
        "Toggle",
        "key",
        "fallback",
        "(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V",
        "Choice",
        "values",
        "selected",
        "",
        "select",
        "(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V",
        "Range",
        "low",
        "high",
        "suffix",
        "(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "Entry",
        "(Landroidx/compose/runtime/Composer;I)V",
        "extension_debug",
        "expanded",
        ""
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/DesignEntry;


# direct methods
.method public static synthetic $r8$lambda$7XOjXpdqDudW8-UEgwjTwlAiz0E(Landroid/content/Context;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$0$7$0(Landroid/content/Context;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$9iBCLNkdf4VM-karRp85pGTECCo(Landroid/content/Context;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$0$0$0(Landroid/content/Context;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$A_zw8SiJZCzpOdRk5awONKk8rsQ()Lkotlin/u;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$0$2$1$0()Lkotlin/u;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$EEAno2NmQDfQsjX_JHbpIa4dJfY(Ljava/lang/String;Z)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Toggle$lambda$0$0(Ljava/lang/String;Z)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$FD9d85Mo5TUk0QrMtA5ZVbtIqQI(Ljava/lang/String;Z)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Toggle$lambda$1$1$0(Ljava/lang/String;Z)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$MnaP3g4eyZf0bRQB29BUVX_oRgo(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$5$0$0$1(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$O-wJrYE1dQcHGo6og5jMyhkqKD0(Landroidx/compose/foundation/interaction/MutableInteractionSource;JLandroidx/compose/material3/SliderState;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    invoke-static/range {p0 .. p5}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$7$3(Landroidx/compose/foundation/interaction/MutableInteractionSource;JLandroidx/compose/material3/SliderState;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$X3l6cwUWp2EKAuwfUxjB-wR1QeE(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$6$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ZCOdAMpDnq0rjp2337RTpUltnNA(ILandroidx/compose/runtime/MutableIntState;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$5$0$0$0$0(ILandroidx/compose/runtime/MutableIntState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ZQndfoNbxeFtl2iTlCBqb_0zGbU(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$0$1$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ZtFEC8VzWLCcpI2ivVAB4CHYumg(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$0$5$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$a3mzUCvYQg4B8lZyxFcHuisO67I()Landroidx/compose/runtime/MutableIntState;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$2$0()Landroidx/compose/runtime/MutableIntState;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$jz8S7bRB7uOQ_g7sDJR8cmA2FoI(Landroid/content/Context;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$0$4$0(Landroid/content/Context;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$lCXgeMOjwNkyeBQxbTMqyeNm8Bc(Lam0/l;ILandroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$4$0$0$0(Lam0/l;ILandroidx/compose/runtime/MutableState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$laZFVmNKiS9Tw_FR5B4IMgXL_sI(Landroidx/compose/runtime/MutableIntState;JLandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$5$0(Landroidx/compose/runtime/MutableIntState;JLandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$mc35MTFjyqZEQmUi-cWocs-Ltzg(Landroidx/compose/runtime/MutableFloatState;F)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$7$1$0(Landroidx/compose/runtime/MutableFloatState;F)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$pGULZsODhWJm_uDRrmh5h8Czu8Y(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$7$2$0(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$uRUJdAHfaQzIPIHPkaVusH9IpO0(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$0$3$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wBETY3dBFyYK8GkPv5qBLQ5Hu7s(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$0$6$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wOX49nI7F15HqYBsCr4xg3bNycg(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$3$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$weg0_1bLB_29VIY3mZd0mvT7h3A(Lam0/l;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$5$1$0(Lam0/l;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/DesignEntry;

    invoke-direct {v0}, Ldev/nino/squareglass/DesignEntry;-><init>()V

    sput-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V
    .locals 38
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;I",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v3, p2

    move/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p6

    const v0, 0xc39184e

    move-object/from16 v1, p5

    .line 94
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    const-string v1, "C(Choice)N(label,values,selected,select)94@4870L34,95@4967L22,95@4913L76:DesignEntry.kt#vqphja"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v6, 0x6

    const/4 v2, 0x2

    move-object/from16 v8, p1

    if-nez v1, :cond_1

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    or-int/2addr v1, v6

    goto :goto_1

    :cond_1
    move v1, v6

    :goto_1
    and-int/lit8 v7, v6, 0x30

    if-nez v7, :cond_3

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    const/16 v7, 0x20

    goto :goto_2

    :cond_2
    const/16 v7, 0x10

    :goto_2
    or-int/2addr v1, v7

    :cond_3
    and-int/lit16 v7, v6, 0x180

    if-nez v7, :cond_5

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v7

    if-eqz v7, :cond_4

    const/16 v7, 0x100

    goto :goto_3

    :cond_4
    const/16 v7, 0x80

    :goto_3
    or-int/2addr v1, v7

    :cond_5
    and-int/lit16 v7, v6, 0xc00

    if-nez v7, :cond_7

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_6

    const/16 v7, 0x800

    goto :goto_4

    :cond_6
    const/16 v7, 0x400

    :goto_4
    or-int/2addr v1, v7

    :cond_7
    and-int/lit16 v7, v6, 0x6000

    if-nez v7, :cond_9

    move-object/from16 v7, p0

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_8

    const/16 v9, 0x4000

    goto :goto_5

    :cond_8
    const/16 v9, 0x2000

    :goto_5
    or-int/2addr v1, v9

    goto :goto_6

    :cond_9
    move-object/from16 v7, p0

    :goto_6
    and-int/lit16 v9, v1, 0x2493

    const/16 v11, 0x2492

    const/4 v15, 0x1

    const/4 v12, 0x0

    if-eq v9, v11, :cond_a

    move v9, v15

    goto :goto_7

    :cond_a
    move v9, v12

    :goto_7
    and-int/lit8 v11, v1, 0x1

    invoke-interface {v10, v9, v11}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v9

    if-eqz v9, :cond_22

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v9

    if-eqz v9, :cond_b

    const/4 v9, -0x1

    const-string v11, "dev.nino.squareglass.DesignEntry.Choice (DesignEntry.kt:93)"

    invoke-static {v0, v1, v9, v11}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_b
    const v0, -0x1dabb5b0

    .line 95
    const-string v9, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v10, v0, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 445
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .line 446
    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    const/4 v13, 0x0

    if-ne v0, v11, :cond_c

    .line 95
    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0, v13, v2, v13}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    .line 448
    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 95
    :cond_c
    check-cast v0, Landroidx/compose/runtime/MutableState;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 96
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v11

    sub-int/2addr v11, v15

    invoke-static {v4, v12, v11}, Ldev/nino/squareglass/HostCompat;->coerceIn(III)I

    move-result v11

    invoke-interface {v3, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    const v12, -0x1daba99c

    invoke-static {v10, v12, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 451
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .line 452
    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v12, v13, :cond_d

    .line 96
    new-instance v12, Ldev/nino/squareglass/DesignEntry$26;

    invoke-direct {v12, v0}, Ldev/nino/squareglass/DesignEntry$26;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 454
    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 96
    :cond_d
    check-cast v12, Lam0/a;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    and-int/lit8 v13, v1, 0xe

    or-int/lit16 v13, v13, 0x180

    shr-int/lit8 v14, v1, 0x3

    and-int/lit16 v14, v14, 0x1c00

    or-int/2addr v13, v14

    move-object v14, v9

    move-object v9, v11

    move-object v11, v10

    move-object v10, v12

    move v12, v13

    const/4 v13, 0x0

    move-object/from16 v19, v14

    const/4 v14, 0x0

    invoke-direct/range {v7 .. v13}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    .line 97
    invoke-static {v0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v7

    if-eqz v7, :cond_21

    const v7, -0x1daba115

    invoke-interface {v11, v7}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v7, "96@5032L36,96@5011L797"

    invoke-static {v11, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    const/4 v8, 0x0

    invoke-static {v7, v8, v15, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const/16 v9, 0x36

    invoke-static {v7, v11, v9}, Ldev/nino/squareglass/SquareScreens;->settingsRow(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const/high16 v9, 0x41800000    # 16.0f

    .line 457
    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 97
    invoke-static {v7, v9, v8, v2, v14}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const v7, 0x4ff7456f

    const-string v9, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    .line 458
    invoke-static {v11, v7, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 459
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v7

    .line 460
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    const/4 v10, 0x0

    .line 463
    invoke-static {v7, v9, v11, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    const v9, -0x451e1427

    .line 468
    const-string v12, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v11, v9, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 469
    invoke-static {v11, v10}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->hashCode(J)I

    move-result v10

    .line 470
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 471
    invoke-static {v11, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 473
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v9

    const v8, -0x20f7d59c

    .line 474
    const-string v14, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v11, v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 475
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 476
    :cond_e
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 477
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_f

    .line 478
    invoke-interface {v11, v9}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_8

    .line 480
    :cond_f
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 482
    :goto_8
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .line 483
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v9

    invoke-static {v8, v7, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 484
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v7

    invoke-static {v8, v13, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 485
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v7

    .line 487
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v9

    if-nez v9, :cond_10

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-static {v9, v13}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_11

    .line 488
    :cond_10
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v8, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 489
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v8, v9, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 492
    :cond_11
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v7

    invoke-static {v8, v2, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v2, 0x7cc0ae6e

    .line 494
    const-string v7, "C89@4557L9:Column.kt#2w3rfo"

    .line 465
    invoke-static {v11, v2, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    const v2, 0x4bfa8916    # 3.2838188E7f

    const-string v7, "C:DesignEntry.kt#vqphja"

    .line 98
    invoke-static {v11, v2, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v2, -0x7129769a

    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*98@5277L69,98@5199L585"

    invoke-static {v11, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move-object v2, v3

    check-cast v2, Ljava/lang/Iterable;

    .line 496
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v7, 0x0

    :goto_9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_20

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    add-int/lit8 v22, v7, 0x1

    if-gez v7, :cond_12

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->throwIndexOverflow()V

    :cond_12
    move-object/from16 v23, v8

    check-cast v23, Ljava/lang/String;

    .line 99
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v8, v9, v15, v10}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v24

    if-ne v7, v4, :cond_13

    move/from16 v25, v15

    goto :goto_a

    :cond_13
    const/16 v25, 0x0

    :goto_a
    sget-object v8, Landroidx/compose/ui/semantics/Role;->Companion:Landroidx/compose/ui/semantics/Role$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/semantics/Role$Companion;->getRadioButton-o7Vup1c()I

    move-result v8

    invoke-static {v8}, Landroidx/compose/ui/semantics/Role;->box-impl(I)Landroidx/compose/ui/semantics/Role;

    move-result-object v27

    const v8, 0x293b245c

    move-object/from16 v9, v19

    invoke-static {v11, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit16 v8, v1, 0x1c00

    const/16 v10, 0x800

    if-ne v8, v10, :cond_14

    move v8, v15

    goto :goto_b

    :cond_14
    const/4 v8, 0x0

    :goto_b
    invoke-interface {v11, v7}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v13

    or-int/2addr v8, v13

    .line 497
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    if-nez v8, :cond_15

    .line 498
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v13, v8, :cond_16

    .line 99
    :cond_15
    new-instance v13, Ldev/nino/squareglass/DesignEntry$27;

    invoke-direct {v13, v5, v7, v0}, Ldev/nino/squareglass/DesignEntry$27;-><init>(Lam0/l;ILandroidx/compose/runtime/MutableState;)V

    .line 500
    invoke-interface {v11, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 99
    :cond_16
    move-object/from16 v29, v13

    check-cast v29, Lam0/a;

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v30, 0xa

    const/16 v31, 0x0

    const/16 v26, 0x0

    const/16 v28, 0x0

    invoke-static/range {v24 .. v31}, Landroidx/compose/foundation/selection/SelectableKt;->selectable-oSLSa3U$default(Landroidx/compose/ui/Modifier;ZZLandroidx/compose/ui/semantics/Role;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/high16 v13, 0x40800000    # 4.0f

    .line 503
    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    move-object/from16 v19, v0

    const/4 v0, 0x0

    const/4 v10, 0x0

    .line 101
    invoke-static {v8, v10, v13, v15, v0}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v13

    const v0, 0x3255a44b

    .line 99
    const-string v10, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    .line 504
    invoke-static {v11, v0, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 505
    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v0}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v0

    const/16 v10, 0x30

    .line 509
    invoke-static {v0, v13, v11, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v0

    const v10, -0x451e1427

    .line 514
    invoke-static {v11, v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v13, 0x0

    .line 515
    invoke-static {v11, v13}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v24

    invoke-static/range {v24 .. v25}, Ljava/lang/Long;->hashCode(J)I

    move-result v18

    .line 516
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v10

    .line 517
    invoke-static {v11, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 519
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v13

    const v15, -0x20f7d59c

    .line 520
    invoke-static {v11, v15, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 521
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v15

    instance-of v15, v15, Landroidx/compose/runtime/Applier;

    if-nez v15, :cond_17

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 522
    :cond_17
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 523
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v15

    if-eqz v15, :cond_18

    .line 524
    invoke-interface {v11, v13}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_c

    .line 526
    :cond_18
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 528
    :goto_c
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .line 529
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v15

    invoke-static {v13, v0, v15}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 530
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v0

    invoke-static {v13, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 531
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v0

    .line 533
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v10

    if-nez v10, :cond_19

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-static {v10, v15}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1a

    .line 534
    :cond_19
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v13, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 535
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v13, v10, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 538
    :cond_1a
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v0

    invoke-static {v13, v8, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v0, 0x56ccd6f5

    .line 540
    const-string v8, "C101@5233L9:Row.kt#2w3rfo"

    .line 511
    invoke-static {v11, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    const v0, -0x1e2cbab8

    const-string v8, "C102@5588L4,102@5647L4,101@5506L165,101@5438L234,103@5693L73:DesignEntry.kt#vqphja"

    .line 102
    invoke-static {v11, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    if-ne v7, v4, :cond_1b

    const/4 v0, 0x1

    goto :goto_d

    :cond_1b
    const/4 v0, 0x0

    :goto_d
    sget-object v7, Landroidx/compose/material3/RadioButtonDefaults;->INSTANCE:Landroidx/compose/material3/RadioButtonDefaults;

    .line 103
    sget-object v8, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v10, 0x6

    invoke-virtual {v8, v11, v10}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v8

    invoke-static {v8}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v8

    invoke-static {v8}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v26

    sget-object v8, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    invoke-virtual {v8, v11, v10}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v8

    invoke-static {v8}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v8

    invoke-static {v8}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v28

    const/16 v34, 0xe

    const/16 v35, 0x0

    const v30, 0x3f0ccccd    # 0.55f

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    invoke-static/range {v28 .. v35}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v28

    sget v8, Landroidx/compose/material3/RadioButtonDefaults;->$stable:I

    shl-int/lit8 v8, v8, 0xc

    const/16 v18, 0xc

    move-object v10, v12

    const-wide/16 v12, 0x0

    move-object/from16 v30, v14

    const-wide/16 v14, 0x0

    move/from16 p5, v0

    move/from16 v21, v1

    move-object/from16 v25, v2

    move/from16 v17, v8

    move-object v1, v10

    move-object/from16 v16, v11

    move-wide/from16 v10, v28

    move-object/from16 v0, v30

    const/4 v2, 0x0

    const/16 v20, 0x800

    const/16 v28, 0x0

    const/16 v29, 0x1

    move-wide/from16 v36, v26

    move-object/from16 v26, v9

    move-wide/from16 v8, v36

    const/16 v27, 0x0

    .line 102
    invoke-virtual/range {v7 .. v18}, Landroidx/compose/material3/RadioButtonDefaults;->colors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/RadioButtonColors;

    move-result-object v11

    move-object/from16 v10, v16

    const/16 v14, 0x30

    const/16 v15, 0x2c

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v13, v10

    const/4 v10, 0x0

    const/4 v12, 0x0

    move/from16 v7, p5

    invoke-static/range {v7 .. v15}, Landroidx/compose/material3/RadioButtonKt;->RadioButton(ZLam0/a;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/RadioButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;II)V

    move-object v11, v13

    .line 104
    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v12, v7

    check-cast v12, Landroidx/compose/ui/Modifier;

    const/high16 v7, 0x41400000    # 12.0f

    .line 541
    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v14

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v16

    const/16 v17, 0x4

    const/16 v18, 0x0

    const/4 v15, 0x0

    .line 104
    invoke-static/range {v12 .. v18}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const v8, 0x3e277f0a

    const-string v9, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    .line 542
    invoke-static {v11, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 543
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v8

    .line 547
    invoke-static {v8, v2}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    const v13, -0x451e1427

    .line 552
    invoke-static {v11, v13, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 553
    invoke-static {v11, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v9

    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    move-result v9

    .line 554
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v10

    .line 555
    invoke-static {v11, v7}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 557
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v12

    const v15, -0x20f7d59c

    .line 558
    invoke-static {v11, v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 559
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v14

    instance-of v14, v14, Landroidx/compose/runtime/Applier;

    if-nez v14, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 560
    :cond_1c
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 561
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v14

    if-eqz v14, :cond_1d

    .line 562
    invoke-interface {v11, v12}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_e

    .line 564
    :cond_1d
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 566
    :goto_e
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .line 567
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v14

    invoke-static {v12, v8, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 568
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v8

    invoke-static {v12, v10, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 569
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v8

    .line 571
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v10

    if-nez v10, :cond_1e

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v10, v14}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1f

    .line 572
    :cond_1e
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v12, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 573
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v12, v9, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 576
    :cond_1f
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v8

    invoke-static {v12, v7, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v7, 0x6d423196

    .line 578
    const-string v8, "C72@3469L9:Box.kt#2w3rfo"

    .line 549
    invoke-static {v11, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v7, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    check-cast v7, Landroidx/compose/foundation/layout/BoxScope;

    const v7, 0x5458246b

    const-string v8, "C103@5753L11:DesignEntry.kt#vqphja"

    .line 104
    invoke-static {v11, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v7, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    move-object v10, v11

    const/16 v11, 0x180

    const/4 v12, 0x2

    const/4 v9, 0x0

    move-object/from16 v8, v23

    invoke-direct/range {v7 .. v12}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    move-object v11, v10

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 549
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 579
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 558
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 552
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 542
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 102
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 511
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 583
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 520
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 514
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 504
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object v14, v0

    move-object v12, v1

    move-object/from16 v0, v19

    move/from16 v1, v21

    move/from16 v7, v22

    move-object/from16 v2, v25

    move-object/from16 v19, v26

    move/from16 v15, v29

    goto/16 :goto_9

    .line 106
    :cond_20
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 98
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 465
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 588
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 474
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 468
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 458
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 97
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_f

    :cond_21
    const v0, 0x68432e54

    .line 107
    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_f
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_10

    :cond_22
    move-object v11, v10

    .line 94
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 108
    :cond_23
    :goto_10
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_24

    new-instance v0, Ldev/nino/squareglass/DesignEntry$28;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry$28;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/util/List;ILam0/l;I)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_24
    return-void
.end method

.method private static final Choice$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 95
    check-cast p0, Landroidx/compose/runtime/State;

    .line 778
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private static final Choice$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 95
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 779
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private static final Choice$lambda$3$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 1

    .line 96
    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-static {p0, v0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Choice$lambda$4$0$0$0(Lam0/l;ILandroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 1

    const/4 v0, 0x0

    .line 100
    invoke-static {p2, v0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final Choice$lambda$5(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/util/List;ILam0/l;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 7

    or-int/lit8 p5, p5, 0x1

    invoke-static {p5}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Entry(Landroidx/compose/runtime/Composer;I)V
    .locals 18

    move/from16 v0, p2

    const v1, 0x7d26ac02

    move-object/from16 v2, p1

    .line 125
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v6

    const-string v2, "C(Entry)126@7117L7,127@7133L2597:DesignEntry.kt#vqphja"

    invoke-static {v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v0, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-eqz v2, :cond_0

    move v3, v12

    goto :goto_0

    :cond_0
    move v3, v11

    :goto_0
    invoke-interface {v6, v3, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_17

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v2, -0x1

    const-string v3, "dev.nino.squareglass.DesignEntry.Entry (DesignEntry.kt:124)"

    invoke-static {v1, v0, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 126
    :cond_1
    sget-object v1, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v1}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 127
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalContext()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v1

    check-cast v1, Landroidx/compose/runtime/CompositionLocal;

    const v2, 0x789c5f52

    const-string v3, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    .line 670
    invoke-static {v6, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 127
    check-cast v1, Landroid/content/Context;

    .line 128
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_2

    sget-object v3, Ldev/nino/squareglass/material/LiquidMotion;->INSTANCE:Ldev/nino/squareglass/material/LiquidMotion;

    invoke-virtual {v3}, Ldev/nino/squareglass/material/LiquidMotion;->shape()Landroidx/compose/animation/core/SpringSpec;

    move-result-object v3

    goto :goto_1

    :cond_2
    invoke-static {v11, v12, v4}, Landroidx/compose/animation/core/AnimationSpecKt;->snap$default(IILjava/lang/Object;)Landroidx/compose/animation/core/SnapSpec;

    move-result-object v3

    :goto_1
    check-cast v3, Landroidx/compose/animation/core/FiniteAnimationSpec;

    const/4 v13, 0x2

    invoke-static {v2, v3, v4, v13, v4}, Landroidx/compose/animation/AnimationModifierKt;->animateContentSize$default(Landroidx/compose/ui/Modifier;Landroidx/compose/animation/core/FiniteAnimationSpec;Lam0/p;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const v3, 0x4ff7456f

    const-string v4, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    .line 671
    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 672
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v3}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v3

    .line 673
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v4

    .line 676
    invoke-static {v3, v4, v6, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v3

    const v4, -0x451e1427

    .line 677
    const-string v5, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    .line 681
    invoke-static {v6, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 682
    invoke-static {v6, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 683
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 684
    invoke-static {v6, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 686
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v7

    const v8, -0x20f7d59c

    .line 685
    const-string v9, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    .line 687
    invoke-static {v6, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 688
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 689
    :cond_3
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 690
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_4

    .line 691
    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_2

    .line 693
    :cond_4
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 695
    :goto_2
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .line 696
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v8

    invoke-static {v7, v3, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 697
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v3

    invoke-static {v7, v5, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 698
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v3

    .line 700
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-nez v5, :cond_5

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v5, v8}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_6

    .line 701
    :cond_5
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 702
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v7, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 705
    :cond_6
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v3

    invoke-static {v7, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v2, 0x7cc0ae6e

    .line 707
    const-string v3, "C89@4557L9:Column.kt#2w3rfo"

    .line 678
    invoke-static {v6, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    const v2, 0x427d8d4f

    const-string v3, "C128@7248L21,129@7367L101,129@7286L182,132@7558L29,132@7485L102,133@7604L32,134@7653L26,142@8131L34,143@8182L31,144@8230L44,145@8291L24,146@8332L51,148@8570L40,147@8400L210,149@8627L59,150@8775L148,150@8703L220,153@8940L25,154@8982L65,155@9064L85,156@9166L83,157@9266L25,159@9461L39,159@9388L112,160@9588L38,160@9517L109,161@9663L57,161@9643L77:DesignEntry.kt#vqphja"

    .line 129
    invoke-static {v6, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    const-string v3, "Appearance"

    const/16 v14, 0x36

    invoke-direct {v2, v3, v6, v14}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 130
    const-string v3, "Light"

    const-string v4, "Dark"

    const-string v5, "System"

    filled-new-array {v5, v3, v4}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeMode()I

    move-result v5

    const v3, 0x44359ed1

    const-string v15, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v6, v3, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .line 708
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    if-nez v3, :cond_7

    .line 709
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v7, v3, :cond_8

    .line 130
    :cond_7
    new-instance v7, Ldev/nino/squareglass/DesignEntry$9;

    invoke-direct {v7, v1}, Ldev/nino/squareglass/DesignEntry$9;-><init>(Landroid/content/Context;)V

    .line 711
    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 130
    :cond_8
    check-cast v7, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6036

    const-string v3, "Color theme"

    move-object/from16 v17, v7

    move-object v7, v6

    move-object/from16 v6, v17

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    .line 133
    const-string v3, "Liquid"

    const-string v4, "Frosted"

    const-string v9, "Off"

    filled-new-array {v3, v4, v9}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v5

    const v3, 0x4435b669

    invoke-static {v6, v3, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 714
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 715
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_9

    .line 716
    new-instance v3, Ldev/nino/squareglass/DesignEntry$10;

    invoke-direct {v3}, Ldev/nino/squareglass/DesignEntry$10;-><init>()V

    .line 717
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 133
    :cond_9
    check-cast v3, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6c36

    move-object v7, v6

    move-object v6, v3

    const-string v3, "Glass"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    const/16 v7, 0xc36

    const/4 v8, 0x4

    .line 134
    const-string v3, "Glass navigation"

    const-string v4, "nav"

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 135
    const-string v3, "Navigation tabs"

    invoke-direct {v2, v3, v6, v14}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    const v2, 0x4435cb7b

    .line 136
    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, ""

    invoke-static {v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Ldev/nino/squareglass/NativeTabs;->INSTANCE:Ldev/nino/squareglass/NativeTabs;

    invoke-virtual {v2}, Ldev/nino/squareglass/NativeTabs;->getOptions()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .line 720
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_3
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_f

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ldev/nino/squareglass/NativeTabs$TabOption;

    .line 137
    invoke-virtual {v2}, Ldev/nino/squareglass/NativeTabs$TabOption;->getKey()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v12}, Ldev/nino/squareglass/SquareSettings;->flag(Ljava/lang/String;Z)Z

    move-result v3

    .line 138
    sget-object v4, Ldev/nino/squareglass/NativeTabs;->INSTANCE:Ldev/nino/squareglass/NativeTabs;

    invoke-virtual {v4}, Ldev/nino/squareglass/NativeTabs;->getOptions()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .line 721
    instance-of v5, v4, Ljava/util/Collection;

    if-eqz v5, :cond_a

    move-object v5, v4

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_a

    move v5, v11

    goto :goto_5

    .line 723
    :cond_a
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    move v5, v11

    :cond_b
    :goto_4
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ldev/nino/squareglass/NativeTabs$TabOption;

    .line 138
    invoke-virtual {v7}, Ldev/nino/squareglass/NativeTabs$TabOption;->getKey()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v12}, Ldev/nino/squareglass/SquareSettings;->flag(Ljava/lang/String;Z)Z

    move-result v7

    if-eqz v7, :cond_b

    add-int/lit8 v5, v5, 0x1

    if-gez v5, :cond_b

    .line 723
    invoke-static {}, Ldev/nino/squareglass/HostCompat;->throwCountOverflow()V

    goto :goto_4

    :cond_c
    :goto_5
    if-eqz v3, :cond_e

    if-gt v5, v12, :cond_e

    const v3, 0x70eaa7bc

    .line 139
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "139@8033L3,139@7975L61"

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move-object v3, v2

    .line 140
    sget-object v2, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    invoke-virtual {v3}, Ldev/nino/squareglass/NativeTabs$TabOption;->getLabel()Ljava/lang/String;

    move-result-object v3

    const v4, 0x3a4831c

    invoke-static {v6, v4, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 725
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 726
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_d

    .line 727
    new-instance v4, Ldev/nino/squareglass/DesignEntry$11;

    invoke-direct {v4}, Ldev/nino/squareglass/DesignEntry$11;-><init>()V

    .line 728
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 140
    :cond_d
    move-object v5, v4

    check-cast v5, Lam0/a;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v7, 0xdb0

    const/4 v8, 0x0

    const-string v4, "At least one tab must remain visible"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    .line 139
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_3

    :cond_e
    move-object v3, v2

    const v2, 0x3a48719

    .line 141
    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "140@8064L32"

    invoke-static {v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    move-object v4, v3

    invoke-virtual {v4}, Ldev/nino/squareglass/NativeTabs$TabOption;->getLabel()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4}, Ldev/nino/squareglass/NativeTabs$TabOption;->getKey()Ljava/lang/String;

    move-result-object v4

    const/16 v7, 0xc00

    const/4 v8, 0x4

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_3

    .line 142
    :cond_f
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 143
    sget-object v2, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    const/16 v7, 0xc36

    const/4 v8, 0x4

    const-string v3, "Glass mini-player"

    const-string v4, "mini"

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 144
    const-string v3, "Glass player"

    const-string v4, "player"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    const/16 v7, 0xdb6

    const/4 v8, 0x0

    .line 145
    const-string v3, "Reduce motion"

    const-string v4, "reduceMotion"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 146
    const-string v3, "Player & Home"

    invoke-direct {v2, v3, v6, v14}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    const/16 v7, 0xc36

    const/4 v8, 0x4

    .line 147
    const-string v3, "Mini-player swipe gestures"

    const-string v4, "miniGestures"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 148
    const-string v3, "For You, Staff Picks, Uploads"

    const-string v4, "Autoplay, Rediscover, Shuffle history"

    filled-new-array {v3, v4}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 149
    const-string v3, "homeActions"

    invoke-static {v3, v11, v11, v12}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v5

    const v3, 0x443634f4

    invoke-static {v6, v3, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 732
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 733
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_10

    .line 734
    new-instance v3, Ldev/nino/squareglass/DesignEntry$12;

    invoke-direct {v3}, Ldev/nino/squareglass/DesignEntry$12;-><init>()V

    .line 735
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 149
    :cond_10
    check-cast v3, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6c36

    move-object v7, v6

    move-object v6, v3

    .line 148
    const-string v3, "Home shortcuts"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    const/16 v7, 0xc36

    const/4 v8, 0x4

    .line 150
    const-string v3, "Learn listening habits by time of day"

    const-string v4, "learnTime"

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    const v3, 0x44364f00    # 729.2344f

    .line 151
    invoke-static {v6, v3, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .line 738
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    if-nez v3, :cond_11

    .line 739
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v4, v3, :cond_12

    .line 151
    :cond_11
    new-instance v4, Ldev/nino/squareglass/DesignEntry$13;

    invoke-direct {v4, v1}, Ldev/nino/squareglass/DesignEntry$13;-><init>(Landroid/content/Context;)V

    .line 741
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 151
    :cond_12
    move-object v5, v4

    check-cast v5, Lam0/a;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v7, 0xc36

    const/4 v8, 0x0

    const-string v3, "Clear listening profile"

    const-string v4, "Listening history stays on this device"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    .line 154
    const-string v3, "Advanced glass"

    invoke-direct {v2, v3, v6, v14}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 155
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->blur()F

    move-result v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v7

    const-string v8, "dp"

    const v10, 0x1b0db6

    const-string v3, "Blur"

    const-string v4, "blur"

    const/4 v5, 0x0

    move-object/from16 v16, v9

    move-object v9, v6

    const/16 v6, 0x18

    move-object/from16 v13, v16

    invoke-direct/range {v2 .. v10}, Ldev/nino/squareglass/DesignEntry;->Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v9

    .line 156
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->opacity()F

    move-result v3

    const/high16 v16, 0x42c80000    # 100.0f

    mul-float v3, v3, v16

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v7

    const-string v8, "%"

    const-string v3, "Surface tint"

    const-string v4, "opacity"

    const/16 v5, 0x14

    const/16 v6, 0x5a

    invoke-direct/range {v2 .. v10}, Ldev/nino/squareglass/DesignEntry;->Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v9

    .line 157
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v3

    mul-float v3, v3, v16

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v7

    const-string v8, "%"

    const-string v3, "Refraction"

    const-string v4, "lens"

    const/4 v5, 0x0

    const/16 v6, 0x64

    invoke-direct/range {v2 .. v10}, Ldev/nino/squareglass/DesignEntry;->Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v9

    .line 158
    const-string v3, "Track gestures"

    invoke-direct {v2, v3, v6, v14}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 159
    const-string v3, "Add to queue"

    const-string v4, "Favorite"

    const-string v5, "Play next"

    filled-new-array {v13, v5, v3, v4}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 160
    const-string v3, "swipeRight"

    const/4 v9, 0x3

    invoke-static {v3, v12, v11, v9}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v5

    const v3, 0x4436a453

    invoke-static {v6, v3, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 744
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 745
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_13

    .line 746
    new-instance v3, Ldev/nino/squareglass/DesignEntry$14;

    invoke-direct {v3}, Ldev/nino/squareglass/DesignEntry$14;-><init>()V

    .line 747
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 160
    :cond_13
    check-cast v3, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6c36

    move-object v7, v6

    move-object v6, v3

    const-string v3, "Swipe right"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    .line 161
    const-string v3, "swipeLeft"

    const/4 v5, 0x2

    invoke-static {v3, v5, v11, v9}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v5

    const v3, 0x4436b432

    invoke-static {v6, v3, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 750
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 751
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_14

    .line 752
    new-instance v3, Ldev/nino/squareglass/DesignEntry$15;

    invoke-direct {v3}, Ldev/nino/squareglass/DesignEntry$15;-><init>()V

    .line 753
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 161
    :cond_14
    check-cast v3, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6c36

    move-object v7, v6

    move-object v6, v3

    const-string v3, "Swipe left"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    const v3, 0x4436bda5

    .line 162
    invoke-static {v6, v3, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .line 756
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    if-nez v3, :cond_15

    .line 757
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v4, v3, :cond_16

    .line 162
    :cond_15
    new-instance v4, Ldev/nino/squareglass/DesignEntry$16;

    invoke-direct {v4, v1}, Ldev/nino/squareglass/DesignEntry$16;-><init>(Landroid/content/Context;)V

    .line 759
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 162
    :cond_16
    move-object v5, v4

    check-cast v5, Lam0/a;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v7, 0xc06

    const/4 v8, 0x2

    const-string v3, "Reset design"

    const/4 v4, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    .line 129
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 678
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 762
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 687
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 681
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 671
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 765
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_18

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_6

    .line 125
    :cond_17
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 164
    :cond_18
    :goto_6
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_19

    new-instance v2, Ldev/nino/squareglass/DesignEntry$17;

    move-object/from16 v3, p0

    invoke-direct {v2, v3, v0}, Ldev/nino/squareglass/DesignEntry$17;-><init>(Ldev/nino/squareglass/DesignEntry;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_19
    return-void
.end method

.method private static final Entry$lambda$0$0$0(Landroid/content/Context;I)Lkotlin/u;
    .locals 1

    .line 131
    const-string v0, "theme"

    invoke-static {v0, p1}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p1, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/DesignEntry;->activity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->recreate()V

    .line 132
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$0$1$0(I)Lkotlin/u;
    .locals 0

    .line 133
    invoke-static {p0}, Ldev/nino/squareglass/SquareSettings;->preset(I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$0$2$1$0()Lkotlin/u;
    .locals 1

    .line 140
    sget-object v0, Lkotlin/u;->a:Lkotlin/u;

    return-object v0
.end method

.method private static final Entry$lambda$0$3$0(I)Lkotlin/u;
    .locals 1

    .line 149
    const-string v0, "homeActions"

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$0$4$0(Landroid/content/Context;)Lkotlin/u;
    .locals 2

    .line 152
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->clearHistory()V

    const-string v0, "Listening profile cleared"

    check-cast v0, Ljava/lang/CharSequence;

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 153
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$0$5$0(I)Lkotlin/u;
    .locals 1

    .line 160
    const-string v0, "swipeRight"

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$0$6$0(I)Lkotlin/u;
    .locals 1

    .line 161
    const-string v0, "swipeLeft"

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$0$7$0(Landroid/content/Context;)Lkotlin/u;
    .locals 1

    .line 162
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->reset()V

    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/DesignEntry;->activity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->recreate()V

    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final Entry$lambda$1(Ldev/nino/squareglass/DesignEntry;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    or-int/lit8 p1, p1, 0x1

    invoke-static {p1}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result p1

    invoke-direct {p0, p2, p1}, Ldev/nino/squareglass/DesignEntry;->Entry(Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V
    .locals 29

    const v0, 0x4924224d

    move-object/from16 v1, p3

    .line 65
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v1

    const-string v2, "C(Label)N(text,secondary)65@2963L4,66@2976L174:DesignEntry.kt#vqphja"

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, p4, 0x6

    move-object/from16 v5, p1

    if-nez v2, :cond_1

    invoke-interface {v1, v5}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    :goto_0
    or-int v2, p4, v2

    goto :goto_1

    :cond_1
    move/from16 v2, p4

    :goto_1
    and-int/lit8 v3, p5, 0x2

    const/16 v4, 0x10

    if-eqz v3, :cond_2

    or-int/lit8 v2, v2, 0x30

    goto :goto_3

    :cond_2
    and-int/lit8 v6, p4, 0x30

    if-nez v6, :cond_4

    move/from16 v6, p2

    invoke-interface {v1, v6}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v7

    if-eqz v7, :cond_3

    const/16 v7, 0x20

    goto :goto_2

    :cond_3
    move v7, v4

    :goto_2
    or-int/2addr v2, v7

    goto :goto_4

    :cond_4
    :goto_3
    move/from16 v6, p2

    :goto_4
    and-int/lit8 v7, v2, 0x13

    const/16 v8, 0x12

    const/4 v9, 0x0

    if-eq v7, v8, :cond_5

    const/4 v7, 0x1

    goto :goto_5

    :cond_5
    move v7, v9

    :goto_5
    and-int/lit8 v8, v2, 0x1

    invoke-interface {v1, v7, v8}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v7

    if-eqz v7, :cond_b

    if-eqz v3, :cond_6

    move/from16 v26, v9

    goto :goto_6

    :cond_6
    move/from16 v26, v6

    :goto_6
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_7

    const/4 v3, -0x1

    const-string v6, "dev.nino.squareglass.DesignEntry.Label (DesignEntry.kt:64)"

    invoke-static {v0, v2, v3, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 66
    :cond_7
    sget-object v0, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v3, 0x6

    invoke-virtual {v0, v1, v3}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v0

    .line 67
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v6

    if-eqz v26, :cond_8

    const v0, 0x3f266666    # 0.65f

    goto :goto_7

    :cond_8
    const/high16 v0, 0x3f800000    # 1.0f

    :goto_7
    move v8, v0

    const/16 v12, 0xe

    const/4 v13, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v6 .. v13}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v6

    const/16 v0, 0xe

    if-eqz v26, :cond_9

    .line 68
    invoke-static {v0}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(I)J

    move-result-wide v3

    goto :goto_8

    :cond_9
    invoke-static {v4}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(I)J

    move-result-wide v3

    :goto_8
    sget-object v8, Ldev/nino/squareglass/SquareTypography;->INSTANCE:Ldev/nino/squareglass/SquareTypography;

    invoke-virtual {v8}, Ldev/nino/squareglass/SquareTypography;->getFamily()Landroidx/compose/ui/text/font/FontFamily;

    move-result-object v9

    const/high16 v8, 0x180000

    and-int/2addr v0, v2

    or-int v23, v0, v8

    const/16 v24, 0x0

    const v25, 0x1ffb2

    const/4 v2, 0x0

    move-wide/from16 v27, v6

    move-wide v5, v3

    move-wide/from16 v3, v27

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    move-object/from16 v22, v1

    move-object/from16 v1, p1

    .line 67
    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILam0/l;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_a
    move/from16 v6, v26

    goto :goto_9

    :cond_b
    move-object/from16 v22, v1

    .line 65
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 69
    :goto_9
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_c

    new-instance v3, Ldev/nino/squareglass/DesignEntry$25;

    move-object/from16 v4, p0

    move-object/from16 v5, p1

    move/from16 v7, p4

    move/from16 v8, p5

    invoke-direct/range {v3 .. v8}, Ldev/nino/squareglass/DesignEntry$25;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;ZII)V

    invoke-interface {v0, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_c
    return-void
.end method

.method static final Label$lambda$0(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 6

    or-int/lit8 p3, p3, 0x1

    invoke-static {p3}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v4

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v5, p4

    move-object v3, p5

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 37

    move-object/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move/from16 v6, p5

    move-object/from16 v7, p6

    move/from16 v8, p8

    const v0, 0x1749c7df

    move-object/from16 v1, p7

    .line 110
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v12

    const-string v1, "C(Range)N(label,key,low,high,selected,suffix)110@5994L34,111@6050L79,112@6169L22,112@6138L53:DesignEntry.kt#vqphja"

    invoke-static {v12, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v8, 0x6

    const/4 v2, 0x2

    move-object/from16 v10, p1

    if-nez v1, :cond_1

    invoke-interface {v12, v10}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    or-int/2addr v1, v8

    goto :goto_1

    :cond_1
    move v1, v8

    :goto_1
    and-int/lit8 v9, v8, 0x30

    if-nez v9, :cond_3

    invoke-interface {v12, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2

    const/16 v9, 0x20

    goto :goto_2

    :cond_2
    const/16 v9, 0x10

    :goto_2
    or-int/2addr v1, v9

    :cond_3
    and-int/lit16 v9, v8, 0x180

    if-nez v9, :cond_5

    invoke-interface {v12, v4}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v9

    if-eqz v9, :cond_4

    const/16 v9, 0x100

    goto :goto_3

    :cond_4
    const/16 v9, 0x80

    :goto_3
    or-int/2addr v1, v9

    :cond_5
    and-int/lit16 v9, v8, 0xc00

    if-nez v9, :cond_7

    invoke-interface {v12, v5}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v9

    if-eqz v9, :cond_6

    const/16 v9, 0x800

    goto :goto_4

    :cond_6
    const/16 v9, 0x400

    :goto_4
    or-int/2addr v1, v9

    :cond_7
    and-int/lit16 v9, v8, 0x6000

    if-nez v9, :cond_9

    invoke-interface {v12, v6}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v9

    if-eqz v9, :cond_8

    const/16 v9, 0x4000

    goto :goto_5

    :cond_8
    const/16 v9, 0x2000

    :goto_5
    or-int/2addr v1, v9

    :cond_9
    const/high16 v9, 0x30000

    and-int/2addr v9, v8

    if-nez v9, :cond_b

    invoke-interface {v12, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_a

    const/high16 v9, 0x20000

    goto :goto_6

    :cond_a
    const/high16 v9, 0x10000

    :goto_6
    or-int/2addr v1, v9

    :cond_b
    const/high16 v9, 0x180000

    and-int/2addr v9, v8

    if-nez v9, :cond_d

    move-object/from16 v9, p0

    invoke-interface {v12, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v16

    if-eqz v16, :cond_c

    const/high16 v16, 0x100000

    goto :goto_7

    :cond_c
    const/high16 v16, 0x80000

    :goto_7
    or-int v1, v1, v16

    goto :goto_8

    :cond_d
    move-object/from16 v9, p0

    :goto_8
    const v16, 0x92493

    and-int v11, v1, v16

    const v13, 0x92492

    if-eq v11, v13, :cond_e

    const/4 v11, 0x1

    goto :goto_9

    :cond_e
    const/4 v11, 0x0

    :goto_9
    and-int/lit8 v13, v1, 0x1

    invoke-interface {v12, v11, v13}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v11

    if-eqz v11, :cond_22

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v11

    if-eqz v11, :cond_f

    const/4 v11, -0x1

    const-string v13, "dev.nino.squareglass.DesignEntry.Range (DesignEntry.kt:109)"

    invoke-static {v0, v1, v11, v13}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_f
    const v0, 0x6bf75a21

    .line 111
    const-string v11, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v12, v0, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 592
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .line 593
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    const/16 v19, 0x0

    const/4 v15, 0x0

    if-ne v0, v13, :cond_10

    .line 111
    invoke-static/range {v19 .. v19}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0, v15, v2, v15}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    .line 595
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 111
    :cond_10
    check-cast v0, Landroidx/compose/runtime/MutableState;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v2, 0x6bf7614e

    .line 112
    invoke-static {v12, v2, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v2, 0xe000

    and-int/2addr v2, v1

    const/16 v13, 0x4000

    if-ne v2, v13, :cond_11

    const/4 v2, 0x1

    goto :goto_a

    :cond_11
    move/from16 v2, v19

    .line 598
    :goto_a
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    if-nez v2, :cond_12

    .line 599
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v13, v2, :cond_13

    :cond_12
    sub-int v2, v6, v4

    int-to-float v2, v2

    sub-int v13, v5, v4

    int-to-float v13, v13

    div-float/2addr v2, v13

    .line 112
    invoke-static {v2}, Landroidx/compose/runtime/PrimitiveSnapshotStateKt;->mutableFloatStateOf(F)Landroidx/compose/runtime/MutableFloatState;

    move-result-object v13

    .line 601
    invoke-interface {v12, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 112
    :cond_13
    move-object v2, v13

    check-cast v2, Landroidx/compose/runtime/MutableFloatState;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 113
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v15, " "

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    const v14, 0x6bf76ff5

    invoke-static {v12, v14, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 604
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .line 605
    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v14, v6, :cond_14

    .line 113
    new-instance v14, Ldev/nino/squareglass/DesignEntry$0;

    invoke-direct {v14, v0}, Ldev/nino/squareglass/DesignEntry$0;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 607
    invoke-interface {v12, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 113
    :cond_14
    check-cast v14, Lam0/a;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    and-int/lit8 v6, v1, 0xe

    or-int/lit16 v6, v6, 0x180

    move-object/from16 v21, v0

    shr-int/lit8 v0, v1, 0x9

    and-int/lit16 v0, v0, 0x1c00

    or-int/2addr v0, v6

    move-object v6, v15

    const/4 v15, 0x0

    move-object/from16 v34, v11

    move-object v11, v13

    const/4 v8, 0x0

    move-object v13, v12

    move-object v12, v14

    move v14, v0

    const/4 v0, 0x1

    invoke-direct/range {v9 .. v15}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    move-object v12, v13

    .line 114
    invoke-static/range {v21 .. v21}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v9

    if-eqz v9, :cond_21

    const v9, 0x6bf7787c

    invoke-interface {v12, v9}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v9, "113@6234L36,113@6213L797"

    invoke-static {v12, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/4 v10, 0x0

    invoke-static {v9, v10, v0, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/16 v15, 0x36

    invoke-static {v8, v12, v15}, Ldev/nino/squareglass/SquareScreens;->settingsRow(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/high16 v9, 0x41a00000    # 20.0f

    .line 610
    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    const/high16 v10, 0x41400000    # 12.0f

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 114
    invoke-static {v8, v9, v10}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const v9, 0x4ff7456f

    const-string v10, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    .line 611
    invoke-static {v12, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 612
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v9

    .line 613
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v10

    const/4 v11, 0x0

    .line 616
    invoke-static {v9, v10, v12, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    const v10, -0x451e1427

    .line 617
    const-string v13, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    .line 621
    invoke-static {v12, v10, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 622
    invoke-static {v12, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v10

    .line 623
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 624
    invoke-static {v12, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 626
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v14

    const v11, -0x20f7d59c

    .line 625
    const-string v15, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    .line 627
    invoke-static {v12, v11, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 628
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v11

    instance-of v11, v11, Landroidx/compose/runtime/Applier;

    if-nez v11, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 629
    :cond_15
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 630
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v11

    if-eqz v11, :cond_16

    .line 631
    invoke-interface {v12, v14}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_b

    .line 633
    :cond_16
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 635
    :goto_b
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .line 636
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v14

    invoke-static {v11, v9, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 637
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v9

    invoke-static {v11, v13, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 638
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v9

    .line 640
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v13

    if-nez v13, :cond_17

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v13, v14}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_18

    .line 641
    :cond_17
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-interface {v11, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 642
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v11, v10, v9}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 645
    :cond_18
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v9

    invoke-static {v11, v8, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v8, 0x7cc0ae6e

    .line 647
    const-string v9, "C89@4557L9:Column.kt#2w3rfo"

    .line 618
    invoke-static {v12, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    check-cast v8, Landroidx/compose/foundation/layout/ColumnScope;

    const v8, 0x321f7154

    const-string v9, "C114@6344L37,115@6438L4,116@6457L60,118@6638L83,117@6557L10,121@6938L61,119@6745L153,117@6530L470:DesignEntry.kt#vqphja"

    .line 115
    invoke-static {v12, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v8, 0x5c74a033

    move-object/from16 v15, v34

    invoke-static {v12, v8, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 648
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .line 649
    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v8, v9, :cond_19

    .line 115
    invoke-static {}, Landroidx/compose/foundation/interaction/InteractionSourceKt;->MutableInteractionSource()Landroidx/compose/foundation/interaction/MutableInteractionSource;

    move-result-object v8

    .line 651
    invoke-interface {v12, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 115
    :cond_19
    check-cast v8, Landroidx/compose/foundation/interaction/MutableInteractionSource;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 116
    sget-object v9, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v10, 0x6

    invoke-virtual {v9, v12, v10}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v9

    invoke-static {v9}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v9

    invoke-static {v9}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v20

    .line 117
    sget-object v9, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    int-to-float v10, v4

    invoke-static {v2}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$4(Landroidx/compose/runtime/MutableFloatState;)F

    move-result v11

    sub-int v13, v5, v4

    int-to-float v13, v13

    mul-float/2addr v11, v13

    add-float/2addr v10, v11

    invoke-static {v10}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const/16 v13, 0x1b0

    const/4 v14, 0x0

    const/4 v11, 0x1

    const/16 v35, 0x0

    invoke-direct/range {v9 .. v14}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 118
    invoke-static {v2}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$4(Landroidx/compose/runtime/MutableFloatState;)F

    move-result v6

    .line 119
    sget-object v9, Landroidx/compose/material3/SliderDefaults;->INSTANCE:Landroidx/compose/material3/SliderDefaults;

    const/16 v26, 0xe

    const/16 v27, 0x0

    const v22, 0x3e19999a    # 0.15f

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    invoke-static/range {v20 .. v27}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v16

    move-wide/from16 v10, v20

    const/16 v32, 0x6

    const/16 v33, 0x3f4

    move-object/from16 v34, v15

    const-wide/16 v14, 0x0

    const-wide/16 v18, 0x0

    const-wide/16 v20, 0x0

    const-wide/16 v22, 0x0

    const-wide/16 v24, 0x0

    const-wide/16 v26, 0x0

    const-wide/16 v28, 0x0

    const/16 v31, 0x0

    move-object/from16 v30, v12

    move-wide v12, v10

    move/from16 v36, v6

    move-object/from16 v0, v34

    const/16 v6, 0x36

    invoke-virtual/range {v9 .. v33}, Landroidx/compose/material3/SliderDefaults;->colors-q0g_0yA(JJJJJJJJJJLandroidx/compose/runtime/Composer;III)Landroidx/compose/material3/SliderColors;

    move-result-object v14

    move-object/from16 v12, v30

    const v9, 0x5c74bab8

    .line 118
    invoke-static {v12, v9, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    .line 654
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    if-nez v9, :cond_1a

    .line 655
    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v13, v9, :cond_1b

    .line 118
    :cond_1a
    new-instance v13, Ldev/nino/squareglass/DesignEntry$1;

    invoke-direct {v13, v2}, Ldev/nino/squareglass/DesignEntry$1;-><init>(Landroidx/compose/runtime/MutableFloatState;)V

    .line 657
    invoke-interface {v12, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 118
    :cond_1b
    check-cast v13, Lam0/l;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v9, 0x5c74ea8b

    .line 122
    invoke-static {v12, v9, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v0, v1, 0x70

    const/16 v9, 0x20

    if-ne v0, v9, :cond_1c

    const/4 v15, 0x1

    goto :goto_c

    :cond_1c
    move/from16 v15, v35

    :goto_c
    and-int/lit16 v0, v1, 0x380

    const/16 v9, 0x100

    if-ne v0, v9, :cond_1d

    const/4 v0, 0x1

    goto :goto_d

    :cond_1d
    move/from16 v0, v35

    :goto_d
    or-int/2addr v0, v15

    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    or-int/2addr v0, v9

    and-int/lit16 v1, v1, 0x1c00

    const/16 v9, 0x800

    if-ne v1, v9, :cond_1e

    const/4 v15, 0x1

    goto :goto_e

    :cond_1e
    move/from16 v15, v35

    :goto_e
    or-int/2addr v0, v15

    .line 660
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_1f

    .line 661
    sget-object v0, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v0}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v1, v0, :cond_20

    .line 122
    :cond_1f
    new-instance v1, Ldev/nino/squareglass/DesignEntry$2;

    invoke-direct {v1, v3, v4, v5, v2}, Ldev/nino/squareglass/DesignEntry$2;-><init>(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)V

    .line 663
    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 122
    :cond_20
    check-cast v1, Lam0/a;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 120
    new-instance v0, Ldev/nino/squareglass/DesignEntry$3;

    invoke-direct {v0, v8, v10, v11}, Ldev/nino/squareglass/DesignEntry$3;-><init>(Landroidx/compose/foundation/interaction/MutableInteractionSource;J)V

    const v2, 0x4e8de2f2

    const/4 v9, 0x1

    invoke-static {v2, v9, v0, v12, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lkotlin/jvm/functions/Function3;

    const/16 v22, 0x0

    const/16 v23, 0x68c

    const/4 v11, 0x0

    move-object/from16 v30, v12

    const/4 v12, 0x0

    const/16 v16, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/high16 v21, 0x6180000

    move-object v15, v8

    move-object v10, v13

    move-object/from16 v20, v30

    move/from16 v9, v36

    move-object v13, v1

    .line 118
    invoke-static/range {v9 .. v23}, Landroidx/compose/material3/SliderKt;->Slider(FLam0/l;Landroidx/compose/ui/Modifier;ZLam0/a;Landroidx/compose/material3/SliderColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;ILkotlin/jvm/functions/Function3;Lkotlin/jvm/functions/Function3;Lfm0/d;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v12, v20

    .line 115
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 618
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 666
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 627
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 621
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 611
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 114
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_f

    :cond_21
    const v0, 0x130346e3

    .line 123
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_f
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_10

    .line 110
    :cond_22
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 124
    :cond_23
    :goto_10
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v9

    if-eqz v9, :cond_24

    new-instance v0, Ldev/nino/squareglass/DesignEntry$4;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v6, p5

    move/from16 v8, p8

    invoke-direct/range {v0 .. v8}, Ldev/nino/squareglass/DesignEntry$4;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;I)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_24
    return-void
.end method

.method private static final Range$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 111
    check-cast p0, Landroidx/compose/runtime/State;

    .line 781
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private static final Range$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 111
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 782
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private static final Range$lambda$4(Landroidx/compose/runtime/MutableFloatState;)F
    .locals 0

    .line 112
    check-cast p0, Landroidx/compose/runtime/FloatState;

    .line 784
    invoke-interface {p0}, Landroidx/compose/runtime/FloatState;->getFloatValue()F

    move-result p0

    return p0
.end method

.method private static final Range$lambda$5(Landroidx/compose/runtime/MutableFloatState;F)V
    .locals 0

    .line 785
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableFloatState;->setFloatValue(F)V

    return-void
.end method

.method private static final Range$lambda$6$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 1

    .line 113
    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-static {p0, v0}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Range$lambda$7$1$0(Landroidx/compose/runtime/MutableFloatState;F)Lkotlin/u;
    .locals 0

    .line 118
    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$5(Landroidx/compose/runtime/MutableFloatState;F)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Range$lambda$7$2$0(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)Lkotlin/u;
    .locals 1

    int-to-float v0, p1

    .line 122
    invoke-static {p3}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$4(Landroidx/compose/runtime/MutableFloatState;)F

    move-result p3

    sub-int/2addr p2, p1

    int-to-float p1, p2

    mul-float/2addr p3, p1

    add-float/2addr v0, p3

    invoke-static {v0}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result p1

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Range$lambda$7$3(Landroidx/compose/foundation/interaction/MutableInteractionSource;JLandroidx/compose/material3/SliderState;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 27

    move-object/from16 v7, p4

    move/from16 v0, p5

    const-string v1, "it"

    move-object/from16 v2, p3

    invoke-static {v2, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "CN(it)119@6802L28,120@6874L22,119@6761L136:DesignEntry.kt#vqphja"

    invoke-static {v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v2, 0x10

    if-eq v1, v2, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    and-int/lit8 v2, v0, 0x1

    invoke-interface {v7, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, -0x1

    const-string v2, "dev.nino.squareglass.DesignEntry.Range.<anonymous>.<anonymous> (DesignEntry.kt:119)"

    const v3, 0x4e8de2f2

    invoke-static {v3, v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 120
    :cond_1
    sget-object v0, Landroidx/compose/material3/SliderDefaults;->INSTANCE:Landroidx/compose/material3/SliderDefaults;

    sget-object v1, Ldev/nino/squareglass/SliderMotion;->INSTANCE:Ldev/nino/squareglass/SliderMotion;

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x1b6

    move-object/from16 v4, p0

    invoke-virtual {v1, v2, v4, v7, v3}, Ldev/nino/squareglass/SliderMotion;->thumb(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v26

    .line 121
    sget-object v1, Landroidx/compose/material3/SliderDefaults;->INSTANCE:Landroidx/compose/material3/SliderDefaults;

    const/16 v24, 0x6

    const/16 v25, 0x3fe

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v14, 0x0

    const-wide/16 v16, 0x0

    const-wide/16 v18, 0x0

    const-wide/16 v20, 0x0

    const/16 v23, 0x0

    move-wide/from16 v2, p1

    move-object/from16 v22, p4

    invoke-virtual/range {v1 .. v25}, Landroidx/compose/material3/SliderDefaults;->colors-q0g_0yA(JJJJJJJJJJLandroidx/compose/runtime/Composer;III)Landroidx/compose/material3/SliderColors;

    move-result-object v3

    const v8, 0x30006

    const/16 v9, 0x18

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    move-object/from16 v1, p0

    move-object/from16 v7, p4

    move-object/from16 v2, v26

    .line 120
    invoke-virtual/range {v0 .. v9}, Landroidx/compose/material3/SliderDefaults;->Thumb-9LiSoMs(Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/ui/Modifier;Landroidx/compose/material3/SliderColors;ZJLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    :cond_2
    invoke-interface/range {p4 .. p4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 121
    :cond_3
    :goto_1
    sget-object v0, Lkotlin/u;->a:Lkotlin/u;

    return-object v0
.end method

.method static final Range$lambda$8(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 10

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move v5, p4

    move v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p8

    invoke-direct/range {v1 .. v9}, Ldev/nino/squareglass/DesignEntry;->Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move/from16 v5, p5

    const v0, 0x3b6458ba

    move-object/from16 v1, p4

    .line 73
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    const-string v1, "C(Row)N(label,value,onClick)73@3462L36,73@3444L339:DesignEntry.kt#vqphja"

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v5, 0x6

    move-object/from16 v2, p1

    if-nez v1, :cond_1

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    :goto_0
    or-int/2addr v1, v5

    goto :goto_1

    :cond_1
    move v1, v5

    :goto_1
    and-int/lit8 v3, p6, 0x2

    if-eqz v3, :cond_2

    or-int/lit8 v1, v1, 0x30

    goto :goto_3

    :cond_2
    and-int/lit8 v4, v5, 0x30

    if-nez v4, :cond_4

    move-object/from16 v4, p2

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    const/16 v6, 0x20

    goto :goto_2

    :cond_3
    const/16 v6, 0x10

    :goto_2
    or-int/2addr v1, v6

    goto :goto_4

    :cond_4
    :goto_3
    move-object/from16 v4, p2

    :goto_4
    and-int/lit16 v6, v5, 0x180

    move-object/from16 v15, p3

    if-nez v6, :cond_6

    invoke-interface {v9, v15}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5

    const/16 v6, 0x100

    goto :goto_5

    :cond_5
    const/16 v6, 0x80

    :goto_5
    or-int/2addr v1, v6

    :cond_6
    and-int/lit16 v6, v1, 0x93

    const/16 v7, 0x92

    const/4 v8, 0x1

    const/4 v10, 0x0

    if-eq v6, v7, :cond_7

    move v6, v8

    goto :goto_6

    :cond_7
    move v6, v10

    :goto_6
    and-int/lit8 v7, v1, 0x1

    invoke-interface {v9, v6, v7}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v6

    if-eqz v6, :cond_13

    const/4 v6, 0x0

    if-eqz v3, :cond_8

    move-object v4, v6

    :cond_8
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_9

    const/4 v3, -0x1

    const-string v7, "dev.nino.squareglass.DesignEntry.Row (DesignEntry.kt:72)"

    invoke-static {v0, v1, v3, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 74
    :cond_9
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    invoke-static {v0, v3, v8, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v3, 0x36

    invoke-static {v0, v9, v3}, Ldev/nino/squareglass/SquareScreens;->settingsRow(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 75
    sget-object v3, Landroidx/compose/ui/semantics/Role;->Companion:Landroidx/compose/ui/semantics/Role$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/semantics/Role$Companion;->getButton-o7Vup1c()I

    move-result v3

    invoke-static {v3}, Landroidx/compose/ui/semantics/Role;->box-impl(I)Landroidx/compose/ui/semantics/Role;

    move-result-object v13

    const/16 v16, 0xb

    const/16 v17, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v14, 0x0

    move/from16 v21, v10

    move-object v10, v0

    move/from16 v0, v21

    invoke-static/range {v10 .. v17}, Landroidx/compose/foundation/ClickableKt;->clickable-oSLSa3U$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/high16 v6, 0x41a00000    # 20.0f

    .line 265
    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 75
    invoke-static {v3, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v6

    const v7, 0x3255a44b

    .line 74
    const-string v8, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    .line 266
    invoke-static {v9, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 267
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v7

    const/16 v8, 0x30

    .line 271
    invoke-static {v7, v6, v9, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    const v7, -0x451e1427

    .line 276
    const-string v8, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v9, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 277
    invoke-static {v9, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    move-result v10

    .line 278
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 279
    invoke-static {v9, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 281
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v12

    const v13, -0x20f7d59c

    .line 282
    const-string v14, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v9, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 283
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v15

    instance-of v15, v15, Landroidx/compose/runtime/Applier;

    if-nez v15, :cond_a

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 284
    :cond_a
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 285
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v15

    if-eqz v15, :cond_b

    .line 286
    invoke-interface {v9, v12}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_7

    .line 288
    :cond_b
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 290
    :goto_7
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .line 291
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v15

    invoke-static {v12, v6, v15}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 292
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v6

    invoke-static {v12, v11, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 293
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v6

    .line 295
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v11

    if-nez v11, :cond_c

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-static {v11, v15}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_d

    .line 296
    :cond_c
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v12, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 297
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v12, v10, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 300
    :cond_d
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v6

    invoke-static {v12, v3, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v3, 0x56ccd6f5

    .line 302
    const-string v6, "C101@5233L9:Row.kt#2w3rfo"

    .line 273
    invoke-static {v9, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    move-object v15, v3

    check-cast v15, Landroidx/compose/foundation/layout/RowScope;

    const v3, 0x6e473697

    const-string v6, "C75@3631L114,76@3758L15:DesignEntry.kt#vqphja"

    .line 76
    invoke-static {v9, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v16, v3

    check-cast v16, Landroidx/compose/ui/Modifier;

    const/16 v19, 0x2

    const/16 v20, 0x0

    const/high16 v17, 0x3f800000    # 1.0f

    const/16 v18, 0x0

    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const v6, 0x4ff7456f

    const-string v10, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    .line 303
    invoke-static {v9, v6, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 304
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v6

    .line 305
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v10

    .line 308
    invoke-static {v6, v10, v9, v0}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 313
    invoke-static {v9, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 314
    invoke-static {v9, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    .line 315
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 316
    invoke-static {v9, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 318
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v8

    .line 319
    invoke-static {v9, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 320
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v10

    instance-of v10, v10, Landroidx/compose/runtime/Applier;

    if-nez v10, :cond_e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 321
    :cond_e
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 322
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v10

    if-eqz v10, :cond_f

    .line 323
    invoke-interface {v9, v8}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_8

    .line 325
    :cond_f
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 327
    :goto_8
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .line 328
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v10

    invoke-static {v8, v6, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 329
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v6

    invoke-static {v8, v7, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 330
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v6

    .line 332
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v7

    if-nez v7, :cond_10

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v7, v10}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_11

    .line 333
    :cond_10
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v8, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 334
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v8, v0, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 337
    :cond_11
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v0

    invoke-static {v8, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v0, 0x7cc0ae6e

    .line 339
    const-string v3, "C89@4557L9:Column.kt#2w3rfo"

    .line 310
    invoke-static {v9, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    const v0, 0x7ccf959d

    const-string v3, "C75@3661L12:DesignEntry.kt#vqphja"

    .line 76
    invoke-static {v9, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v6, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    and-int/lit8 v0, v1, 0xe

    or-int/lit16 v10, v0, 0x180

    const/4 v11, 0x2

    const/4 v8, 0x0

    move-object v7, v2

    invoke-direct/range {v6 .. v11}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    if-eqz v4, :cond_12

    const v0, 0x7cd0063a

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "75@3693L29,75@3724L17"

    invoke-static {v9, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/high16 v2, 0x40800000    # 4.0f

    .line 340
    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 76
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v2, 0x6

    invoke-static {v0, v9, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    shr-int/lit8 v0, v1, 0x3

    and-int/lit8 v0, v0, 0xe

    or-int/lit16 v10, v0, 0x1b0

    const/4 v11, 0x0

    const/4 v8, 0x1

    move-object v7, v4

    invoke-direct/range {v6 .. v11}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_9

    :cond_12
    const v0, 0x7cd0c96e

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_9
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 310
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 341
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 319
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 313
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 303
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v10, 0x1b6

    const/4 v11, 0x0

    .line 77
    const-string v7, "\u203a"

    const/4 v8, 0x1

    invoke-direct/range {v6 .. v11}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 76
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 273
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 345
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 282
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 276
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 266
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 348
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_14

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_a

    .line 73
    :cond_13
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_14
    :goto_a
    move-object v3, v4

    .line 79
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_15

    new-instance v0, Ldev/nino/squareglass/DesignEntry$5;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v4, p3

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry$5;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Lam0/a;II)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_15
    return-void
.end method

.method static final Row$lambda$1(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Lam0/a;IILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 7

    or-int/lit8 p4, p4, 0x1

    invoke-static {p4}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move v6, p5

    move-object v4, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method public static final Screen(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;Lam0/l;Ljava/util/List;Landroidx/compose/runtime/Composer;I)V
    .locals 28
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/Modifier;",
            "Landroidx/compose/foundation/layout/PaddingValues;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/foundation/lazy/LazyListScope;",
            "Lkotlin/u;",
            ">;",
            "Ljava/util/List<",
            "*>;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v0, p2

    move-object/from16 v15, p3

    move/from16 v3, p5

    const-string v4, "modifier"

    invoke-static {v1, v4}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "padding"

    invoke-static {v2, v4}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "nativeContent"

    invoke-static {v0, v4}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "items"

    invoke-static {v15, v4}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const v4, -0x2a19b671

    move-object/from16 v5, p4

    .line 32
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    const-string v5, "C(Screen)N(modifier,padding,nativeContent,items)40@1716L24,40@1699L41,41@1795L4,42@1810L859:DesignEntry.kt#vqphja"

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v5, v3, 0x6

    if-nez v5, :cond_1

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v5, v3

    goto :goto_1

    :cond_1
    move v5, v3

    :goto_1
    and-int/lit8 v6, v3, 0x30

    if-nez v6, :cond_3

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    const/16 v6, 0x20

    goto :goto_2

    :cond_2
    const/16 v6, 0x10

    :goto_2
    or-int/2addr v5, v6

    :cond_3
    and-int/lit16 v6, v3, 0x180

    if-nez v6, :cond_5

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4

    const/16 v6, 0x100

    goto :goto_3

    :cond_4
    const/16 v6, 0x80

    :goto_3
    or-int/2addr v5, v6

    :cond_5
    and-int/lit16 v6, v3, 0xc00

    if-nez v6, :cond_7

    invoke-interface {v10, v15}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_6

    const/16 v6, 0x800

    goto :goto_4

    :cond_6
    const/16 v6, 0x400

    :goto_4
    or-int/2addr v5, v6

    :cond_7
    and-int/lit16 v6, v5, 0x493

    const/16 v8, 0x492

    const/4 v9, 0x0

    const/4 v11, 0x1

    if-eq v6, v8, :cond_8

    move v6, v11

    goto :goto_5

    :cond_8
    move v6, v9

    :goto_5
    and-int/lit8 v8, v5, 0x1

    invoke-interface {v10, v6, v8}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v6

    if-eqz v6, :cond_17

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_9

    const/4 v6, -0x1

    const-string v8, "dev.nino.squareglass.DesignEntry.Screen (DesignEntry.kt:31)"

    invoke-static {v4, v5, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 33
    :cond_9
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v4

    if-eqz v4, :cond_15

    move-object v4, v15

    check-cast v4, Ljava/lang/Iterable;

    .line 167
    instance-of v6, v4, Ljava/util/Collection;

    if-eqz v6, :cond_a

    move-object v6, v4

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_a

    goto/16 :goto_a

    .line 168
    :cond_a
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_6
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_15

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 34
    instance-of v8, v6, Ljm/f$a;

    if-eqz v8, :cond_14

    check-cast v6, Ljm/f$a;

    iget-object v6, v6, Ljm/f$a;->e:Lam0/a;

    const/4 v8, 0x0

    if-eqz v6, :cond_b

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    if-eqz v6, :cond_b

    invoke-virtual {v6}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v6

    goto :goto_7

    :cond_b
    move-object v6, v8

    .line 35
    :goto_7
    const-string v12, "com.aspiro.wamp.settings.items.profile.SettingsItemOfflineMode$viewState$1"

    .line 34
    invoke-static {v6, v12}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_14

    const v4, -0x462e9c2d

    .line 40
    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-array v4, v9, [Ljava/lang/Object;

    const v6, -0xa859c99

    .line 41
    const-string v12, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v10, v6, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 170
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .line 171
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v6, v13, :cond_c

    .line 172
    new-instance v6, Ldev/nino/squareglass/DesignEntry$19;

    invoke-direct {v6}, Ldev/nino/squareglass/DesignEntry$19;-><init>()V

    .line 173
    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 41
    :cond_c
    check-cast v6, Lam0/a;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v13, 0x30

    invoke-static {v4, v6, v10, v13}, Landroidx/compose/runtime/saveable/RememberSaveableKt;->rememberSaveable([Ljava/lang/Object;Lam0/a;Landroidx/compose/runtime/Composer;I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/compose/runtime/MutableIntState;

    .line 42
    sget-object v6, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v13, 0x6

    invoke-virtual {v6, v10, v13}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v6

    invoke-static {v6}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v6

    invoke-static {v6}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v13

    const/4 v6, 0x0

    .line 43
    invoke-static {v1, v6, v11, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const v6, 0x4ff7456f

    const-string v8, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    .line 176
    invoke-static {v10, v6, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 177
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v6

    .line 178
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 181
    invoke-static {v6, v8, v10, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    const v8, -0x451e1427

    .line 182
    const-string v11, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    .line 186
    invoke-static {v10, v8, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 187
    invoke-static {v10, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->hashCode(J)I

    move-result v8

    .line 188
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 189
    invoke-static {v10, v7}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 191
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v9

    const v1, -0x20f7d59c

    .line 190
    const-string v2, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    .line 192
    invoke-static {v10, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 193
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 194
    :cond_d
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 195
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_e

    .line 196
    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_8

    .line 198
    :cond_e
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 200
    :goto_8
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .line 201
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v2

    invoke-static {v1, v6, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 202
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v2

    invoke-static {v1, v11, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 203
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v2

    .line 205
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v6

    if-nez v6, :cond_f

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v6, v9}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_10

    .line 206
    :cond_f
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v1, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 207
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v1, v6, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 210
    :cond_10
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v2

    invoke-static {v1, v7, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v1, 0x7cc0ae6e

    .line 212
    const-string v2, "C89@4557L9:Column.kt#2w3rfo"

    .line 183
    invoke-static {v10, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    const v2, 0x1a6ec6a6

    const-string v6, "C43@1947L346,43@1855L438:DesignEntry.kt#vqphja"

    .line 44
    invoke-static {v10, v2, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {v4}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$3(Landroidx/compose/runtime/MutableIntState;)I

    move-result v16

    sget-object v2, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/graphics/Color$Companion;->getTransparent-0d7_KjU()J

    move-result-wide v18

    new-instance v2, Ldev/nino/squareglass/DesignEntry$20;

    invoke-direct {v2, v4, v13, v14}, Ldev/nino/squareglass/DesignEntry$20;-><init>(Landroidx/compose/runtime/MutableIntState;J)V

    const/16 v6, 0x36

    const v7, 0x3a01b9c1

    const/4 v8, 0x1

    invoke-static {v7, v8, v2, v10, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object/from16 v24, v2

    check-cast v24, Lam0/p;

    const v26, 0x180180

    const/16 v27, 0x32

    const/16 v17, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    move-object/from16 v25, v10

    move-wide/from16 v20, v13

    invoke-static/range {v16 .. v27}, Landroidx/compose/material3/TabRowKt;->TabRow-pAZo6Ak(ILandroidx/compose/ui/Modifier;JJLkotlin/jvm/functions/Function3;Lam0/p;Lam0/p;Landroidx/compose/runtime/Composer;II)V

    .line 52
    invoke-static {v4}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$3(Landroidx/compose/runtime/MutableIntState;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const v6, 0x91c99a7

    invoke-interface {v10, v6, v2}, Landroidx/compose/runtime/Composer;->startMovableGroup(ILjava/lang/Object;)V

    const-string v2, "52@2494L151,52@2421L224"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 53
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v17, v2

    check-cast v17, Landroidx/compose/ui/Modifier;

    const/16 v20, 0x2

    const/16 v21, 0x0

    const/high16 v18, 0x3f800000    # 1.0f

    const/16 v19, 0x0

    move-object/from16 v16, v1

    invoke-static/range {v16 .. v21}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x1

    invoke-static {v1, v2, v8, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const v1, 0x91ca650

    invoke-static {v10, v1, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    and-int/lit16 v6, v5, 0x380

    const/16 v7, 0x100

    if-ne v6, v7, :cond_11

    move v9, v8

    goto :goto_9

    :cond_11
    const/4 v9, 0x0

    :goto_9
    or-int/2addr v1, v9

    .line 213
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    if-nez v1, :cond_12

    .line 214
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v6, v1, :cond_13

    .line 53
    :cond_12
    new-instance v6, Ldev/nino/squareglass/DesignEntry$21;

    invoke-direct {v6, v0, v4}, Ldev/nino/squareglass/DesignEntry$21;-><init>(Lam0/l;Landroidx/compose/runtime/MutableIntState;)V

    .line 216
    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 53
    :cond_13
    move-object v11, v6

    check-cast v11, Lam0/l;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    shl-int/lit8 v1, v5, 0x3

    and-int/lit16 v13, v1, 0x380

    const/16 v14, 0x1fa

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v12, v10

    const/4 v10, 0x0

    move-object/from16 v4, p1

    invoke-static/range {v2 .. v14}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLandroidx/compose/foundation/OverscrollEffect;Lam0/l;Landroidx/compose/runtime/Composer;II)V

    move-object v10, v12

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endMovableGroup()V

    .line 44
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 183
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 219
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 192
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 186
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 176
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 222
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_18

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_c

    :cond_14
    move v8, v11

    const/16 v7, 0x100

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p5

    move v11, v8

    const/4 v9, 0x0

    goto/16 :goto_6

    :cond_15
    :goto_a
    const v1, -0x4630481f

    .line 37
    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "37@1574L71"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v5, 0xe

    shl-int/lit8 v2, v5, 0x3

    and-int/lit16 v2, v2, 0x380

    or-int/2addr v1, v2

    shl-int/lit8 v2, v5, 0x15

    const/high16 v3, 0x70000000

    and-int/2addr v2, v3

    or-int v11, v1, v2

    const/16 v12, 0x1fa

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v2, p1

    move-object v9, v0

    move-object/from16 v0, p0

    .line 38
    invoke-static/range {v0 .. v12}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLandroidx/compose/foundation/OverscrollEffect;Lam0/l;Landroidx/compose/runtime/Composer;II)V

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_16

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 59
    :cond_16
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_19

    new-instance v0, Ldev/nino/squareglass/DesignEntry$18;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v5, p5

    move-object v4, v15

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/DesignEntry$18;-><init>(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;Lam0/l;Ljava/util/List;I)V

    :goto_b
    invoke-interface {v6, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    return-void

    .line 31
    :cond_17
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 59
    :cond_18
    :goto_c
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_19

    new-instance v0, Ldev/nino/squareglass/DesignEntry$22;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v5, p5

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/DesignEntry$22;-><init>(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;Lam0/l;Ljava/util/List;I)V

    goto :goto_b

    :cond_19
    return-void
.end method

.method static final Screen$lambda$1(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;Lam0/l;Ljava/util/List;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 6

    or-int/lit8 p4, p4, 0x1

    invoke-static {p4}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p5

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/DesignEntry;->Screen(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;Lam0/l;Ljava/util/List;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Screen$lambda$2$0()Landroidx/compose/runtime/MutableIntState;
    .locals 1

    const/4 v0, 0x0

    .line 41
    invoke-static {v0}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v0

    return-object v0
.end method

.method private static final Screen$lambda$3(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 41
    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 775
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method

.method private static final Screen$lambda$4(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 0

    .line 776
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method

.method private static final Screen$lambda$5$0(Landroidx/compose/runtime/MutableIntState;JLandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 26

    move-object/from16 v0, p0

    move-object/from16 v12, p3

    move/from16 v1, p4

    const-string v2, "C*45@2091L20,46@2144L16,45@2047L214:DesignEntry.kt#vqphja"

    invoke-static {v12, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    const/4 v15, 0x0

    const/4 v4, 0x1

    if-eq v2, v3, :cond_0

    move v2, v4

    goto :goto_0

    :cond_0
    move v2, v15

    :goto_0
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v12, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v2, -0x1

    const-string v3, "dev.nino.squareglass.DesignEntry.Screen.<anonymous>.<anonymous> (DesignEntry.kt:44)"

    const v5, 0x3a01b9c1

    invoke-static {v5, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 45
    :cond_1
    const-string v1, "TIDAL"

    const-string v2, "Liquidify"

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .line 767
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v16

    move v1, v15

    :goto_1
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    add-int/lit8 v17, v1, 0x1

    if-gez v1, :cond_2

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->throwIndexOverflow()V

    :cond_2
    check-cast v2, Ljava/lang/String;

    .line 46
    invoke-static {v0}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$3(Landroidx/compose/runtime/MutableIntState;)I

    move-result v3

    if-ne v3, v1, :cond_3

    move v3, v4

    goto :goto_2

    :cond_3
    move v3, v15

    :goto_2
    const v5, 0x6196f52f

    const-string v6, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v12, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v6

    or-int/2addr v5, v6

    .line 768
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    if-nez v5, :cond_4

    .line 769
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v6, v5, :cond_5

    .line 46
    :cond_4
    new-instance v6, Ldev/nino/squareglass/DesignEntry$23;

    invoke-direct {v6, v1, v0}, Ldev/nino/squareglass/DesignEntry$23;-><init>(ILandroidx/compose/runtime/MutableIntState;)V

    .line 771
    invoke-interface {v12, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 46
    :cond_5
    check-cast v6, Lam0/a;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 47
    new-instance v1, Ldev/nino/squareglass/DesignEntry$24;

    invoke-direct {v1, v2}, Ldev/nino/squareglass/DesignEntry$24;-><init>(Ljava/lang/String;)V

    const/16 v2, 0x36

    const v5, -0x2ea9f90b

    invoke-static {v5, v4, v1, v12, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object v5, v1

    check-cast v5, Lam0/p;

    const/16 v24, 0xe

    const/16 v25, 0x0

    const v20, 0x3f19999a    # 0.6f

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    move-wide/from16 v18, p1

    .line 48
    invoke-static/range {v18 .. v25}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v9

    const/16 v13, 0x6000

    const/16 v14, 0x12c

    move v1, v3

    const/4 v3, 0x0

    move v2, v4

    const/4 v4, 0x0

    move v7, v2

    move-object v2, v6

    const/4 v6, 0x0

    const/4 v11, 0x0

    move/from16 v18, v7

    move-wide/from16 v7, p1

    .line 46
    invoke-static/range {v1 .. v14}, Landroidx/compose/material3/TabKt;->Tab-wqdebIU(ZLam0/a;Landroidx/compose/ui/Modifier;ZLam0/p;Lam0/p;JJLandroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v12, p3

    move/from16 v1, v17

    move/from16 v4, v18

    goto/16 :goto_1

    .line 774
    :cond_6
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_3

    .line 44
    :cond_7
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 50
    :cond_8
    :goto_3
    sget-object v0, Lkotlin/u;->a:Lkotlin/u;

    return-object v0
.end method

.method private static final Screen$lambda$5$0$0$0$0(ILandroidx/compose/runtime/MutableIntState;)Lkotlin/u;
    .locals 0

    .line 46
    invoke-static {p1, p0}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$4(Landroidx/compose/runtime/MutableIntState;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Screen$lambda$5$0$0$1(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 9

    const-string v0, "C46@2146L12:DesignEntry.kt#vqphja"

    invoke-static {p1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p2, 0x3

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    and-int/lit8 v1, p2, 0x1

    invoke-interface {p1, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, -0x1

    const-string v1, "dev.nino.squareglass.DesignEntry.Screen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DesignEntry.kt:46)"

    const v2, -0x2ea9f90b

    invoke-static {v2, p2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 47
    :cond_1
    sget-object v3, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    const/16 v7, 0x180

    const/4 v8, 0x2

    const/4 v5, 0x0

    move-object v4, p0

    move-object v6, p1

    invoke-direct/range {v3 .. v8}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    :cond_2
    move-object v6, p1

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_3
    :goto_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Screen$lambda$5$1$0(Lam0/l;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/u;
    .locals 6

    const-string v0, "$this$LazyColumn"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    invoke-static {p1}, Ldev/nino/squareglass/DesignEntry;->Screen$lambda$3(Landroidx/compose/runtime/MutableIntState;)I

    move-result p1

    if-nez p1, :cond_0

    invoke-interface {p0, p2}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 55
    :cond_0
    sget-object p0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->INSTANCE:Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;

    invoke-virtual {p0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->getLambda$-1675151681$extension_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v1, "liquidify.preferences"

    const/4 v2, 0x0

    move-object v0, p2

    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 56
    :goto_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final Screen$lambda$6(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;Lam0/l;Ljava/util/List;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 6

    or-int/lit8 p4, p4, 0x1

    invoke-static {p4}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p5

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/DesignEntry;->Screen(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;Lam0/l;Ljava/util/List;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 8

    const v0, -0x3d750320

    .line 70
    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    const-string p2, "C(Section)N(text)70@3217L90:DesignEntry.kt#vqphja"

    invoke-static {v4, p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 p2, p3, 0x6

    const/4 v1, 0x2

    if-nez p2, :cond_1

    invoke-interface {v4, p1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    const/4 p2, 0x4

    goto :goto_0

    :cond_0
    move p2, v1

    :goto_0
    or-int/2addr p2, p3

    goto :goto_1

    :cond_1
    move p2, p3

    :goto_1
    and-int/lit8 v2, p2, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x0

    if-eq v2, v1, :cond_2

    move v1, v3

    goto :goto_2

    :cond_2
    move v1, v5

    :goto_2
    and-int/lit8 v2, p2, 0x1

    invoke-interface {v4, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, -0x1

    const-string v2, "dev.nino.squareglass.DesignEntry.Section (DesignEntry.kt:69)"

    invoke-static {v0, p2, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 71
    :cond_3
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0, v1, v3, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/high16 v1, 0x42100000    # 36.0f

    .line 223
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    const/high16 v2, 0x41800000    # 16.0f

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 71
    invoke-static {v0, v1, v2}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const v1, 0x3e277f0a

    const-string v2, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    .line 224
    invoke-static {v4, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 225
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v1

    .line 229
    invoke-static {v1, v5}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v1

    const v2, -0x451e1427

    .line 230
    const-string v3, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    .line 234
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 235
    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    .line 236
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 237
    invoke-static {v4, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 239
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v5

    const v6, -0x20f7d59c

    .line 238
    const-string v7, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    .line 240
    invoke-static {v4, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 241
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v6

    instance-of v6, v6, Landroidx/compose/runtime/Applier;

    if-nez v6, :cond_4

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 242
    :cond_4
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 243
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v6

    if-eqz v6, :cond_5

    .line 244
    invoke-interface {v4, v5}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_3

    .line 246
    :cond_5
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 248
    :goto_3
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .line 249
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v6

    invoke-static {v5, v1, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 250
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v1

    invoke-static {v5, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 251
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v1

    .line 253
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-nez v3, :cond_6

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v3, v6}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7

    .line 254
    :cond_6
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 255
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v5, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 258
    :cond_7
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v1

    invoke-static {v5, v0, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v0, 0x6d423196

    .line 260
    const-string v1, "C72@3469L9:Box.kt#2w3rfo"

    .line 231
    invoke-static {v4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    const v0, -0x1782227

    const-string v1, "C70@3289L16:DesignEntry.kt#vqphja"

    .line 71
    invoke-static {v4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    and-int/lit8 p2, p2, 0xe

    or-int/lit16 v5, p2, 0x1b0

    const/4 v6, 0x0

    const/4 v3, 0x1

    move-object v2, p1

    invoke-direct/range {v1 .. v6}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 231
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 261
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 240
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 234
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 224
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 264
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_4

    :cond_8
    move-object v2, p1

    .line 70
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 72
    :cond_9
    :goto_4
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object p1

    if-eqz p1, :cond_a

    new-instance p2, Ldev/nino/squareglass/DesignEntry$29;

    invoke-direct {p2, p0, v2, p3}, Ldev/nino/squareglass/DesignEntry$29;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;I)V

    invoke-interface {p1, p2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_a
    return-void
.end method

.method static final Section$lambda$1(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    or-int/lit8 p2, p2, 0x1

    invoke-static {p2}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result p2

    invoke-direct {p0, p1, p3, p2}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V
    .locals 46

    move-object/from16 v3, p2

    move/from16 v5, p5

    const v0, 0x2296a220

    move-object/from16 v1, p4

    .line 80
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    const-string v1, "C(Toggle)N(label,key,fallback)82@3989L4,83@4095L36,84@4173L36,83@4077L655:DesignEntry.kt#vqphja"

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v5, 0x6

    move-object/from16 v2, p1

    if-nez v1, :cond_1

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    :goto_0
    or-int/2addr v1, v5

    goto :goto_1

    :cond_1
    move v1, v5

    :goto_1
    and-int/lit8 v4, v5, 0x30

    const/16 v12, 0x20

    if-nez v4, :cond_3

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    move v4, v12

    goto :goto_2

    :cond_2
    const/16 v4, 0x10

    :goto_2
    or-int/2addr v1, v4

    :cond_3
    and-int/lit8 v4, p6, 0x4

    if-eqz v4, :cond_4

    or-int/lit16 v1, v1, 0x180

    goto :goto_4

    :cond_4
    and-int/lit16 v6, v5, 0x180

    if-nez v6, :cond_6

    move/from16 v6, p3

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v7

    if-eqz v7, :cond_5

    const/16 v7, 0x100

    goto :goto_3

    :cond_5
    const/16 v7, 0x80

    :goto_3
    or-int/2addr v1, v7

    goto :goto_5

    :cond_6
    :goto_4
    move/from16 v6, p3

    :goto_5
    and-int/lit16 v7, v1, 0x93

    const/16 v8, 0x92

    const/4 v13, 0x1

    const/4 v14, 0x0

    if-eq v7, v8, :cond_7

    move v7, v13

    goto :goto_6

    :cond_7
    move v7, v14

    :goto_6
    and-int/lit8 v8, v1, 0x1

    invoke-interface {v9, v7, v8}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v7

    if-eqz v7, :cond_18

    if-eqz v4, :cond_8

    move v4, v13

    goto :goto_7

    :cond_8
    move v4, v6

    :goto_7
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_9

    const/4 v6, -0x1

    const-string v7, "dev.nino.squareglass.DesignEntry.Toggle (DesignEntry.kt:79)"

    invoke-static {v0, v1, v6, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 81
    :cond_9
    sget-object v0, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v0}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 82
    invoke-static {v3, v4}, Ldev/nino/squareglass/SquareSettings;->flag(Ljava/lang/String;Z)Z

    move-result v0

    .line 83
    sget-object v6, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v7, 0x6

    invoke-virtual {v6, v9, v7}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v6

    invoke-static {v6}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v6

    invoke-static {v6}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v15

    .line 84
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v6, v7, v13, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const/16 v7, 0x36

    invoke-static {v6, v9, v7}, Ldev/nino/squareglass/SquareScreens;->settingsRow(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v17

    .line 85
    sget-object v6, Landroidx/compose/ui/semantics/Role;->Companion:Landroidx/compose/ui/semantics/Role$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/semantics/Role$Companion;->getSwitch-o7Vup1c()I

    move-result v6

    invoke-static {v6}, Landroidx/compose/ui/semantics/Role;->box-impl(I)Landroidx/compose/ui/semantics/Role;

    move-result-object v20

    const v6, -0x288938dc

    const-string v7, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v9, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v6, v1, 0x70

    if-ne v6, v12, :cond_a

    move v8, v13

    goto :goto_8

    :cond_a
    move v8, v14

    :goto_8
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v10

    or-int/2addr v8, v10

    .line 349
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    if-nez v8, :cond_b

    .line 350
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v10, v8, :cond_c

    .line 85
    :cond_b
    new-instance v10, Ldev/nino/squareglass/DesignEntry$6;

    invoke-direct {v10, v3, v0}, Ldev/nino/squareglass/DesignEntry$6;-><init>(Ljava/lang/String;Z)V

    .line 352
    invoke-interface {v9, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 85
    :cond_c
    move-object/from16 v22, v10

    check-cast v22, Lam0/a;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v23, 0xb

    const/16 v24, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v21, 0x0

    invoke-static/range {v17 .. v24}, Landroidx/compose/foundation/ClickableKt;->clickable-oSLSa3U$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/high16 v10, 0x41a00000    # 20.0f

    .line 355
    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    const/high16 v11, 0x40c00000    # 6.0f

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 85
    invoke-static {v8, v10, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 86
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v10

    const v11, 0x3255a44b

    .line 84
    const-string v13, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    .line 356
    invoke-static {v9, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 357
    sget-object v11, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v11}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v11

    const/16 v13, 0x30

    .line 361
    invoke-static {v11, v10, v9, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    const v11, -0x451e1427

    .line 366
    const-string v13, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v9, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 367
    invoke-static {v9, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->hashCode(J)I

    move-result v17

    .line 368
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 369
    invoke-static {v9, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 371
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v11

    const v14, -0x20f7d59c

    move/from16 v43, v0

    .line 372
    const-string v0, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v9, v14, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 373
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v14

    instance-of v14, v14, Landroidx/compose/runtime/Applier;

    if-nez v14, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 374
    :cond_d
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 375
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v14

    if-eqz v14, :cond_e

    .line 376
    invoke-interface {v9, v11}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_9

    .line 378
    :cond_e
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 380
    :goto_9
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .line 381
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v14

    invoke-static {v11, v10, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 382
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v10

    invoke-static {v11, v12, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 383
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v10

    .line 385
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v12

    if-nez v12, :cond_f

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v12, v14}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_10

    .line 386
    :cond_f
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v11, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 387
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v11, v12, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 390
    :cond_10
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v10

    invoke-static {v11, v8, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v8, 0x56ccd6f5

    .line 392
    const-string v10, "C101@5233L9:Row.kt#2w3rfo"

    .line 363
    invoke-static {v9, v8, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    move-object/from16 v21, v8

    check-cast v21, Landroidx/compose/foundation/layout/RowScope;

    const v8, -0x59c16628

    const-string v10, "C86@4323L60,87@4427L28,87@4478L243,87@4396L326:DesignEntry.kt#vqphja"

    .line 87
    invoke-static {v9, v8, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v22, v8

    check-cast v22, Landroidx/compose/ui/Modifier;

    const/16 v25, 0x2

    const/16 v26, 0x0

    const/high16 v23, 0x3f800000    # 1.0f

    const/16 v24, 0x0

    invoke-static/range {v21 .. v26}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v27

    const/high16 v8, 0x41400000    # 12.0f

    .line 393
    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v30

    const/16 v32, 0xb

    const/16 v33, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v31, 0x0

    .line 87
    invoke-static/range {v27 .. v33}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const v10, 0x3e277f0a

    const-string v11, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    .line 394
    invoke-static {v9, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 395
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v10

    const/4 v12, 0x0

    .line 399
    invoke-static {v10, v12}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    const v11, -0x451e1427

    .line 404
    invoke-static {v9, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 405
    invoke-static {v9, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v11

    .line 406
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 407
    invoke-static {v9, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 409
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v14

    const v12, -0x20f7d59c

    .line 410
    invoke-static {v9, v12, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 411
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 412
    :cond_11
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 413
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_12

    .line 414
    invoke-interface {v9, v14}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_a

    .line 416
    :cond_12
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 418
    :goto_a
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .line 419
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v12

    invoke-static {v0, v10, v12}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 420
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v10

    invoke-static {v0, v13, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 421
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v10

    .line 423
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v12

    if-nez v12, :cond_13

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-static {v12, v13}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_14

    .line 424
    :cond_13
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v0, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 425
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v0, v11, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 428
    :cond_14
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v10

    invoke-static {v0, v8, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v0, 0x6d423196

    .line 430
    const-string v8, "C72@3469L9:Box.kt#2w3rfo"

    .line 401
    invoke-static {v9, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    const v0, 0x35bcfc81

    const-string v8, "C86@4369L12:DesignEntry.kt#vqphja"

    .line 87
    invoke-static {v9, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move v0, v6

    sget-object v6, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    and-int/lit8 v1, v1, 0xe

    or-int/lit16 v10, v1, 0x180

    const/4 v11, 0x2

    const/4 v8, 0x0

    move-object v1, v7

    move-object v7, v2

    invoke-direct/range {v6 .. v11}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 401
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 431
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 410
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 404
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 394
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v2, -0x3cb39ce8

    .line 88
    invoke-static {v9, v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/16 v1, 0x20

    if-ne v0, v1, :cond_15

    const/4 v13, 0x1

    goto :goto_b

    :cond_15
    const/4 v13, 0x0

    .line 435
    :goto_b
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    if-nez v13, :cond_16

    .line 436
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_17

    .line 88
    :cond_16
    new-instance v0, Ldev/nino/squareglass/DesignEntry$7;

    invoke-direct {v0, v3}, Ldev/nino/squareglass/DesignEntry$7;-><init>(Ljava/lang/String;)V

    .line 438
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 88
    :cond_17
    check-cast v0, Lam0/l;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget-object v6, Landroidx/compose/material3/SwitchDefaults;->INSTANCE:Landroidx/compose/material3/SwitchDefaults;

    const/16 v21, 0xe

    const/16 v22, 0x0

    const v17, 0x3e99999a    # 0.3f

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    .line 89
    invoke-static/range {v15 .. v22}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v1

    const v17, 0x3f266666    # 0.65f

    .line 90
    invoke-static/range {v15 .. v22}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v7

    const v17, 0x3dcccccd    # 0.1f

    invoke-static/range {v15 .. v22}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v10

    const/high16 v17, 0x3e800000    # 0.25f

    .line 91
    invoke-static/range {v15 .. v22}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v19

    sget v12, Landroidx/compose/material3/SwitchDefaults;->$stable:I

    shl-int/lit8 v41, v12, 0x12

    const v42, 0xff8c

    move-wide/from16 v17, v10

    const-wide/16 v11, 0x0

    const-wide/16 v13, 0x0

    const-wide/16 v21, 0x0

    const-wide/16 v23, 0x0

    const-wide/16 v25, 0x0

    const-wide/16 v27, 0x0

    const-wide/16 v29, 0x0

    const-wide/16 v31, 0x0

    const-wide/16 v33, 0x0

    const-wide/16 v35, 0x0

    const-wide/16 v37, 0x0

    const/16 v40, 0x0

    move-wide/from16 v44, v15

    move-wide v15, v7

    move-wide/from16 v7, v44

    move-object/from16 v39, v9

    move-wide v9, v1

    .line 88
    invoke-virtual/range {v6 .. v42}, Landroidx/compose/material3/SwitchDefaults;->colors-V1nXRL4(JJJJJJJJJJJJJJJJLandroidx/compose/runtime/Composer;III)Landroidx/compose/material3/SwitchColors;

    move-result-object v11

    move-object/from16 v9, v39

    const/4 v14, 0x0

    const/16 v15, 0x5c

    const/4 v8, 0x0

    move-object v13, v9

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v12, 0x0

    move-object v7, v0

    move/from16 v6, v43

    invoke-static/range {v6 .. v15}, Landroidx/compose/material3/SwitchKt;->Switch(ZLam0/l;Landroidx/compose/ui/Modifier;Lam0/p;ZLandroidx/compose/material3/SwitchColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;II)V

    move-object v9, v13

    .line 87
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 363
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 441
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 372
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 366
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 356
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 444
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_c

    .line 80
    :cond_18
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v4, v6

    .line 93
    :cond_19
    :goto_c
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_1a

    new-instance v0, Ldev/nino/squareglass/DesignEntry$8;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry$8;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;ZII)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_1a
    return-void
.end method

.method private static final Toggle$lambda$0$0(Ljava/lang/String;Z)Lkotlin/u;
    .locals 0

    xor-int/lit8 p1, p1, 0x1

    .line 85
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;Z)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Toggle$lambda$1$1$0(Ljava/lang/String;Z)Lkotlin/u;
    .locals 0

    .line 88
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;Z)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final Toggle$lambda$2(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 7

    or-int/lit8 p4, p4, 0x1

    invoke-static {p4}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v6, p5

    move-object v4, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method public static final synthetic access$Entry(Ldev/nino/squareglass/DesignEntry;Landroidx/compose/runtime/Composer;I)V
    .locals 0

    .line 29
    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/DesignEntry;->Entry(Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method private final activity(Landroid/content/Context;)Landroid/app/Activity;
    .locals 1

    .line 61
    instance-of v0, p1, Landroid/app/Activity;

    if-eqz v0, :cond_0

    check-cast p1, Landroid/app/Activity;

    return-object p1

    .line 62
    :cond_0
    instance-of v0, p1, Landroid/content/ContextWrapper;

    if-eqz v0, :cond_1

    check-cast p1, Landroid/content/ContextWrapper;

    invoke-virtual {p1}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p1

    const-string v0, "getBaseContext(...)"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, Ldev/nino/squareglass/DesignEntry;->activity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method
