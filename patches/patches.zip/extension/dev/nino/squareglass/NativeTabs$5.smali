.class public final synthetic Ldev/nino/squareglass/NativeTabs$5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:I

.field public final synthetic f$2:Lam0/l;

.field public final synthetic f$3:J

.field public final synthetic f$4:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$5:J


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;ILam0/l;JLandroidx/compose/runtime/MutableState;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeTabs$5;->f$0:Ljava/util/List;

    iput p2, p0, Ldev/nino/squareglass/NativeTabs$5;->f$1:I

    iput-object p3, p0, Ldev/nino/squareglass/NativeTabs$5;->f$2:Lam0/l;

    iput-wide p4, p0, Ldev/nino/squareglass/NativeTabs$5;->f$3:J

    iput-object p6, p0, Ldev/nino/squareglass/NativeTabs$5;->f$4:Landroidx/compose/runtime/MutableState;

    iput-wide p7, p0, Ldev/nino/squareglass/NativeTabs$5;->f$5:J

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeTabs$5;->f$0:Ljava/util/List;

    iget v1, p0, Ldev/nino/squareglass/NativeTabs$5;->f$1:I

    iget-object v2, p0, Ldev/nino/squareglass/NativeTabs$5;->f$2:Lam0/l;

    iget-wide v3, p0, Ldev/nino/squareglass/NativeTabs$5;->f$3:J

    iget-object v5, p0, Ldev/nino/squareglass/NativeTabs$5;->f$4:Landroidx/compose/runtime/MutableState;

    iget-wide v6, p0, Ldev/nino/squareglass/NativeTabs$5;->f$5:J

    move-object v8, p1

    check-cast v8, Landroidx/compose/foundation/layout/RowScope;

    move-object v9, p2

    check-cast v9, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v10

    invoke-static/range {v0 .. v10}, Ldev/nino/squareglass/NativeTabs;->$r8$lambda$R2HQUSJjqdVVEGfijF6xk_D3r0U(Ljava/util/List;ILam0/l;JLandroidx/compose/runtime/MutableState;JLandroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
