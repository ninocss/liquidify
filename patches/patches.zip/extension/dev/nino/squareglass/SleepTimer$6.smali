.class Ldev/nino/squareglass/SleepTimer$6;
.super Ljava/lang/Object;
.source "SleepTimer.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/SleepTimer;->content(Landroid/content/Context;Ldev/nino/squareglass/LiquidMenuSurface;Ljava/lang/Runnable;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$panel:Ldev/nino/squareglass/GlassFrame;

.field final synthetic val$refresh:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Ljava/lang/Runnable;Ldev/nino/squareglass/GlassFrame;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 151
    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$6;->val$refresh:Ljava/lang/Runnable;

    iput-object p2, p0, Ldev/nino/squareglass/SleepTimer$6;->val$panel:Ldev/nino/squareglass/GlassFrame;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    .line 152
    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$6;->val$refresh:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    invoke-virtual {p1}, Landroid/view/View;->requestApplyInsets()V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    .line 153
    iget-object p1, p0, Ldev/nino/squareglass/SleepTimer$6;->val$panel:Ldev/nino/squareglass/GlassFrame;

    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$6;->val$refresh:Ljava/lang/Runnable;

    invoke-virtual {p1, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void
.end method
