.class final Ldev/nino/squareglass/IconMotion$decorate$3$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "IconMotion.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $fire:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $lastTap$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $liked:Ljava/lang/Boolean;

.field final synthetic $previousLike$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field label:I


# direct methods
.method constructor <init>(Ljava/lang/Boolean;Lam0/l;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Boolean;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/IconMotion$decorate$3$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$liked:Ljava/lang/Boolean;

    iput-object p2, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$fire:Lam0/l;

    iput-object p3, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$previousLike$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$lastTap$delegate:Landroidx/compose/runtime/MutableState;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/IconMotion$decorate$3$1;

    iget-object v1, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$liked:Ljava/lang/Boolean;

    iget-object v2, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$fire:Lam0/l;

    iget-object v3, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$previousLike$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v4, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$lastTap$delegate:Landroidx/compose/runtime/MutableState;

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/IconMotion$decorate$3$1;-><init>(Ljava/lang/Boolean;Lam0/l;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$3$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$3$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/IconMotion$decorate$3$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 114
    iget v0, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->label:I

    if-nez v0, :cond_3

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 115
    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$previousLike$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$11(Landroidx/compose/runtime/MutableState;)Ljava/lang/Boolean;

    move-result-object p1

    iget-object v0, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$liked:Ljava/lang/Boolean;

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_2

    .line 116
    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$previousLike$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v0, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$liked:Ljava/lang/Boolean;

    invoke-static {p1, v0}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$12(Landroidx/compose/runtime/MutableState;Ljava/lang/Boolean;)V

    .line 117
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$lastTap$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$8(Landroidx/compose/runtime/MutableState;)J

    move-result-wide v2

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x2710

    cmp-long p1, v0, v2

    if-gez p1, :cond_1

    .line 118
    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$fire:Lam0/l;

    iget-object v0, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$liked:Ljava/lang/Boolean;

    const/4 v1, 0x1

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->boxBoolean(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v0, v2}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x2

    goto :goto_0

    :cond_0
    const/4 v0, 0x3

    :goto_0
    invoke-static {v0}, Ldev/nino/squareglass/HostCompat;->boxInt(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p1, v0}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$liked:Ljava/lang/Boolean;

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->boxBoolean(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    sget p1, Ldev/nino/squareglass/ProbeDiagnostics;->likeAnimations:I

    add-int/2addr p1, v1

    sput p1, Ldev/nino/squareglass/ProbeDiagnostics;->likeAnimations:I

    .line 121
    :cond_1
    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$decorate$3$1;->$lastTap$delegate:Landroidx/compose/runtime/MutableState;

    const-wide/16 v0, -0x4e20

    invoke-static {p0, v0, v1}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$9(Landroidx/compose/runtime/MutableState;J)V

    .line 123
    :cond_2
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0

    .line 114
    :cond_3
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
