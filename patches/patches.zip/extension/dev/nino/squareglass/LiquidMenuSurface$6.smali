.class public final synthetic Ldev/nino/squareglass/LiquidMenuSurface$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/platform/ComposeView;

.field public final synthetic f$1:[I

.field public final synthetic f$2:[I

.field public final synthetic f$3:Ldev/nino/squareglass/LiquidMenuSurface;

.field public final synthetic f$4:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/platform/ComposeView;[I[ILdev/nino/squareglass/LiquidMenuSurface;Landroidx/compose/runtime/MutableState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$0:Landroidx/compose/ui/platform/ComposeView;

    iput-object p2, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$1:[I

    iput-object p3, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$2:[I

    iput-object p4, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$3:Ldev/nino/squareglass/LiquidMenuSurface;

    iput-object p5, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$4:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final onPreDraw()Z
    .locals 4

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$0:Landroidx/compose/ui/platform/ComposeView;

    iget-object v1, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$1:[I

    iget-object v2, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$2:[I

    iget-object v3, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$3:Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object p0, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$4:Landroidx/compose/runtime/MutableState;

    invoke-static {v0, v1, v2, v3, p0}, Ldev/nino/squareglass/LiquidMenuSurface;->paint$lambda$2(Landroidx/compose/ui/platform/ComposeView;[I[ILdev/nino/squareglass/LiquidMenuSurface;Landroidx/compose/runtime/MutableState;)Z

    move-result p0

    return p0
.end method
