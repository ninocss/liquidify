.class public final synthetic Ldev/nino/squareglass/LiquidMenuSurface$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:J

.field public final synthetic f$1:F

.field public final synthetic f$2:Z

.field public final synthetic f$3:Z


# direct methods
.method public synthetic constructor <init>(JFZZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$0:J

    iput p3, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$1:F

    iput-boolean p4, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$2:Z

    iput-boolean p5, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$3:Z

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget-wide v0, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$0:J

    iget v2, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$1:F

    iget-boolean v3, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$2:Z

    iget-boolean v4, p0, Ldev/nino/squareglass/LiquidMenuSurface$6;->f$3:Z

    move-object v5, p1

    check-cast v5, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/LiquidMenuSurface;->$r8$lambda$dNcuHXncjURjmFYuukeXFiyJR_E(JFZZLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
