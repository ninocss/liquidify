.class final Ldev/nino/squareglass/MiniProgress$decorate$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "MiniProgress.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/MiniProgress;->decorate(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $fraction$delegate:Landroidx/compose/runtime/MutableFloatState;

.field final synthetic $lifecycle:Landroidx/lifecycle/Lifecycle;

.field final synthetic $view:Landroid/view/View;

.field label:I


# direct methods
.method constructor <init>(Landroidx/lifecycle/Lifecycle;Landroid/view/View;Landroidx/compose/runtime/MutableFloatState;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/Lifecycle;",
            "Landroid/view/View;",
            "Landroidx/compose/runtime/MutableFloatState;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/MiniProgress$decorate$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->$lifecycle:Landroidx/lifecycle/Lifecycle;

    iput-object p2, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->$view:Landroid/view/View;

    iput-object p3, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->$fraction$delegate:Landroidx/compose/runtime/MutableFloatState;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance p1, Ldev/nino/squareglass/MiniProgress$decorate$1$1;

    iget-object v0, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->$lifecycle:Landroidx/lifecycle/Lifecycle;

    iget-object v1, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->$view:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->$fraction$delegate:Landroidx/compose/runtime/MutableFloatState;

    invoke-direct {p1, v0, v1, p0, p2}, Ldev/nino/squareglass/MiniProgress$decorate$1$1;-><init>(Landroidx/lifecycle/Lifecycle;Landroid/view/View;Landroidx/compose/runtime/MutableFloatState;Lkotlin/coroutines/e;)V

    check-cast p1, Lkotlin/coroutines/e;

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 21
    iget v1, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->label:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 23
    :cond_2
    iget-object p1, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->$fraction$delegate:Landroidx/compose/runtime/MutableFloatState;

    iget-object v1, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->$lifecycle:Landroidx/lifecycle/Lifecycle;

    invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle;->getCurrentState()Landroidx/lifecycle/Lifecycle$State;

    move-result-object v1

    sget-object v3, Landroidx/lifecycle/Lifecycle$State;->RESUMED:Landroidx/lifecycle/Lifecycle$State;

    invoke-virtual {v1, v3}, Landroidx/lifecycle/Lifecycle$State;->isAtLeast(Landroidx/lifecycle/Lifecycle$State;)Z

    move-result v1

    const/high16 v3, -0x40800000    # -1.0f

    if-eqz v1, :cond_5

    iget-object v1, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->$view:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_5

    .line 25
    :try_start_0
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->host()Lbi/e;

    move-result-object v1

    if-eqz v1, :cond_3

    .line 26
    invoke-interface {v1}, Lbi/e;->getCurrentMediaDuration()I

    move-result v4

    goto :goto_1

    :cond_3
    const/4 v4, 0x0

    :goto_1
    if-lez v4, :cond_5

    if-eqz v1, :cond_4

    .line 27
    invoke-interface {v1}, Lbi/e;->getCurrentItem()Lcom/aspiro/wamp/playqueue/u0;

    move-result-object v5

    goto :goto_2

    :cond_4
    const/4 v5, 0x0

    :goto_2
    if-eqz v5, :cond_5

    .line 28
    invoke-interface {v1}, Lbi/e;->getCurrentMediaPosition()I

    move-result v1

    invoke-static {v1, v4}, Ldev/nino/squareglass/PlaybackProgress;->fraction(II)F

    move-result v3
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    :catch_0
    :cond_5
    invoke-static {p1, v3}, Ldev/nino/squareglass/MiniProgress;->access$decorate$lambda$2(Landroidx/compose/runtime/MutableFloatState;F)V

    .line 31
    move-object p1, p0

    check-cast p1, Lkotlin/coroutines/e;

    iput v2, p0, Ldev/nino/squareglass/MiniProgress$decorate$1$1;->label:I

    const-wide/16 v3, 0xfa

    invoke-static {v3, v4, p1}, Lkotlinx/coroutines/DelayKt;->delay(JLkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_2

    return-object v0
.end method
