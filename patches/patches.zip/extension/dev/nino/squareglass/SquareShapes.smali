.class public final Ldev/nino/squareglass/SquareShapes;
.super Ljava/lang/Object;
.source "SquareShapes.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSquareShapes.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SquareShapes.kt\ndev/nino/squareglass/SquareShapes\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n*L\n1#1,15:1\n113#2:16\n113#2:17\n113#2:18\n*S KotlinDebug\n*F\n+ 1 SquareShapes.kt\ndev/nino/squareglass/SquareShapes\n*L\n8#1:16\n9#1:17\n10#1:18\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0007\n\u0002\u0008\u0002\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0008\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\nH\u0007J\u0010\u0010\u000b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\nH\u0007J\u0010\u0010\u0007\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\nH\u0007R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000c"
    }
    d2 = {
        "Ldev/nino/squareglass/SquareShapes;",
        "",
        "<init>",
        "()V",
        "cover",
        "Landroidx/compose/foundation/shape/RoundedCornerShape;",
        "playerCover",
        "shortcut",
        "artwork",
        "original",
        "",
        "playerArtwork",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/SquareShapes;

.field private static final cover:Landroidx/compose/foundation/shape/RoundedCornerShape;

.field private static final playerCover:Landroidx/compose/foundation/shape/RoundedCornerShape;

.field private static final shortcut:Landroidx/compose/foundation/shape/RoundedCornerShape;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/SquareShapes;

    invoke-direct {v0}, Ldev/nino/squareglass/SquareShapes;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareShapes;->INSTANCE:Ldev/nino/squareglass/SquareShapes;

    const/high16 v0, 0x41200000    # 10.0f

    .line 16
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 8
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/SquareShapes;->cover:Landroidx/compose/foundation/shape/RoundedCornerShape;

    const/4 v0, 0x0

    .line 17
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 9
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/SquareShapes;->playerCover:Landroidx/compose/foundation/shape/RoundedCornerShape;

    const/high16 v0, 0x41a00000    # 20.0f

    .line 18
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 10
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/SquareShapes;->shortcut:Landroidx/compose/foundation/shape/RoundedCornerShape;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final artwork(F)Landroidx/compose/foundation/shape/RoundedCornerShape;
    .locals 0

    .line 11
    sget-object p0, Ldev/nino/squareglass/SquareShapes;->cover:Landroidx/compose/foundation/shape/RoundedCornerShape;

    return-object p0
.end method

.method public static final playerArtwork(F)Landroidx/compose/foundation/shape/RoundedCornerShape;
    .locals 0

    .line 12
    sget-object p0, Ldev/nino/squareglass/SquareShapes;->playerCover:Landroidx/compose/foundation/shape/RoundedCornerShape;

    return-object p0
.end method

.method public static final shortcut(F)Landroidx/compose/foundation/shape/RoundedCornerShape;
    .locals 0

    .line 13
    sget-object p0, Ldev/nino/squareglass/SquareShapes;->shortcut:Landroidx/compose/foundation/shape/RoundedCornerShape;

    return-object p0
.end method
