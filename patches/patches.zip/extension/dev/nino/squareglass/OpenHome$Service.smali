.class final Ldev/nino/squareglass/OpenHome$Service;
.super Ljava/lang/Object;
.source "OpenHome.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/OpenHome;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Service"
.end annotation


# instance fields
.field cacheKey:Ljava/lang/String;

.field control:Ljava/lang/String;

.field event:Ljava/lang/String;

.field volatile inputs:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field scpd:Ljava/lang/String;

.field type:Ljava/lang/String;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 62
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method declared-synchronized load()V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    monitor-enter p0

    .line 66
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/OpenHome$Service;->inputs:Ljava/util/Map;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    monitor-exit p0

    return-void

    .line 67
    :cond_0
    :try_start_1
    sget-object v0, Ldev/nino/squareglass/OpenHome;->actionDescriptions:Ldev/nino/squareglass/LinnCache;

    iget-object v1, p0, Ldev/nino/squareglass/OpenHome$Service;->cacheKey:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/LinnCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    if-eqz v0, :cond_1

    .line 68
    iput-object v0, p0, Ldev/nino/squareglass/OpenHome$Service;->inputs:Ljava/util/Map;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-void

    .line 69
    :cond_1
    :try_start_2
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 70
    iget-object v1, p0, Ldev/nino/squareglass/OpenHome$Service;->scpd:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-static {v1, v2, v2}, Ldev/nino/squareglass/OpenHome;->fetch(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object v1

    invoke-static {v1}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object v1

    const-string v2, "*"

    const-string v3, "action"

    invoke-interface {v1, v2, v3}, Lorg/w3c/dom/Document;->getElementsByTagNameNS(Ljava/lang/String;Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object v1

    const/4 v2, 0x0

    move v3, v2

    .line 71
    :goto_0
    invoke-interface {v1}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result v4

    if-ge v3, v4, :cond_4

    .line 72
    invoke-interface {v1, v3}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object v4

    check-cast v4, Lorg/w3c/dom/Element;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 73
    const-string v6, "*"

    const-string v7, "argument"

    invoke-interface {v4, v6, v7}, Lorg/w3c/dom/Element;->getElementsByTagNameNS(Ljava/lang/String;Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object v6

    move v7, v2

    .line 74
    :goto_1
    invoke-interface {v6}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result v8

    if-ge v7, v8, :cond_3

    .line 75
    invoke-interface {v6, v7}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object v8

    check-cast v8, Lorg/w3c/dom/Element;

    .line 76
    const-string v9, "in"

    const-string v10, "direction"

    invoke-static {v8, v10}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2

    const-string v9, "name"

    invoke-static {v8, v9}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v5, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 78
    :cond_3
    const-string v6, "name"

    invoke-static {v4, v6}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v5}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v0, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 80
    :cond_4
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/OpenHome$Service;->inputs:Ljava/util/Map;

    sget-object v0, Ldev/nino/squareglass/OpenHome;->actionDescriptions:Ldev/nino/squareglass/LinnCache;

    iget-object v1, p0, Ldev/nino/squareglass/OpenHome$Service;->cacheKey:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/OpenHome$Service;->inputs:Ljava/util/Map;

    invoke-virtual {v0, v1, v2}, Ldev/nino/squareglass/LinnCache;->put(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 81
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw v0
.end method
