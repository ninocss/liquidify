.class public final Ldev/nino/squareglass/SquareOutput;
.super Ljava/lang/Object;
.source "SquareOutput.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/SquareOutput$Request;,
        Ldev/nino/squareglass/SquareOutput$Session;
    }
.end annotation


# static fields
.field private static final anchors:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Landroid/graphics/Rect;",
            ">;"
        }
    .end annotation
.end field

.field private static current:Ldev/nino/squareglass/SquareOutput$Session;

.field private static final linnProgressQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final main:Landroid/os/Handler;

.field private static volatile pendingLinnMessage:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$sfgetcurrent()Ldev/nino/squareglass/SquareOutput$Session;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetmain()Landroid/os/Handler;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->main:Landroid/os/Handler;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfputcurrent(Ldev/nino/squareglass/SquareOutput$Session;)V
    .locals 0

    sput-object p0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 28
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Ldev/nino/squareglass/SquareOutput;->main:Landroid/os/Handler;

    .line 29
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareOutput;->anchors:Ljava/util/WeakHashMap;

    .line 36
    const-string v0, ""

    sput-object v0, Ldev/nino/squareglass/SquareOutput;->pendingLinnMessage:Ljava/lang/String;

    .line 37
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareOutput;->linnProgressQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static anchor(Landroid/view/View;IIII)V
    .locals 2

    .line 32
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->anchors:Ljava/util/WeakHashMap;

    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1, p1, p2, p3, p4}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {v0, p0, v1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static changed()V
    .locals 2

    .line 34
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/SquareOutput$2;

    invoke-direct {v1}, Ldev/nino/squareglass/SquareOutput$2;-><init>()V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static clearAnchor(Landroid/view/View;)V
    .locals 1

    .line 33
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->anchors:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static dismissed(Landroid/app/Dialog;)V
    .locals 0

    .line 51
    invoke-static {p0}, Ldev/nino/squareglass/SquareOutput;->showing(Landroid/app/Dialog;)Z

    move-result p0

    if-eqz p0, :cond_0

    sget-object p0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->close()V

    :cond_0
    return-void
.end method

.method static synthetic lambda$changed$0()V
    .locals 1

    .line 34
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->linnSnapshot()V

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->fit()V

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->schedule()V

    :cond_0
    return-void
.end method

.method static synthetic lambda$linnDevicesChanged$0()V
    .locals 1

    .line 35
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->linnSnapshot()V

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->fit()V

    :cond_0
    return-void
.end method

.method static synthetic lambda$linnFailure$0(Ljava/lang/String;)V
    .locals 1

    .line 38
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    if-eqz v0, :cond_0

    iget-object v0, v0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/OutputSelection;->failed()V

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    iput-object p0, v0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    sget-object p0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    sget-object p0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->fit()V

    :cond_0
    return-void
.end method

.method static synthetic lambda$linnProgress$0()V
    .locals 2

    .line 42
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->linnProgressQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 43
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    if-eqz v0, :cond_0

    iget-object v0, v0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/OutputSelection;->target()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    sget-object v1, Ldev/nino/squareglass/SquareOutput;->pendingLinnMessage:Ljava/lang/String;

    iput-object v1, v0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->linnSnapshot()V

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->fit()V

    :cond_0
    return-void
.end method

.method static synthetic lambda$result$0(Ldev/nino/squareglass/SquareOutput$Request;Ljava/lang/Object;Z)V
    .locals 1

    .line 48
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Request;->session:Ldev/nino/squareglass/SquareOutput$Session;

    iget p0, p0, Ldev/nino/squareglass/SquareOutput$Request;->revision:I

    invoke-virtual {v0, p0, p1, p2}, Ldev/nino/squareglass/SquareOutput$Session;->received(ILjava/lang/Object;Z)V

    return-void
.end method

.method public static linnDevicesChanged()V
    .locals 2

    .line 35
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/SquareOutput$4;

    invoke-direct {v1}, Ldev/nino/squareglass/SquareOutput$4;-><init>()V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static linnFailure(Ljava/lang/String;)V
    .locals 2

    .line 38
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/SquareOutput$3;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SquareOutput$3;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static linnProgress(Ljava/lang/String;)V
    .locals 3

    .line 40
    sput-object p0, Ldev/nino/squareglass/SquareOutput;->pendingLinnMessage:Ljava/lang/String;

    .line 41
    sget-object p0, Ldev/nino/squareglass/SquareOutput;->linnProgressQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p0

    if-eqz p0, :cond_0

    sget-object p0, Ldev/nino/squareglass/SquareOutput;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/SquareOutput$0;

    invoke-direct {v0}, Ldev/nino/squareglass/SquareOutput$0;-><init>()V

    const-wide/16 v1, 0x50

    invoke-virtual {p0, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-void
.end method

.method public static result(Ljava/lang/Object;Ljava/lang/Object;Z)V
    .locals 2

    .line 47
    check-cast p0, Ldev/nino/squareglass/SquareOutput$Request;

    .line 48
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/SquareOutput$1;

    invoke-direct {v1, p0, p1, p2}, Ldev/nino/squareglass/SquareOutput$1;-><init>(Ldev/nino/squareglass/SquareOutput$Request;Ljava/lang/Object;Z)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static show(Landroid/app/Dialog;)Z
    .locals 9

    .line 65
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    .line 66
    :cond_0
    invoke-virtual {p0}, Landroid/app/Dialog;->getOwnerActivity()Landroid/app/Activity;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_7

    .line 67
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_7

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-eqz v2, :cond_1

    goto/16 :goto_1

    .line 68
    :cond_1
    sget-object v2, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ldev/nino/squareglass/SquareOutput$Session;->close()V

    .line 70
    :cond_2
    invoke-static {v0}, Ldev/nino/squareglass/PlayerWindow;->source(Landroid/app/Activity;)Landroid/view/View;

    move-result-object v2

    .line 71
    sget-object v3, Ldev/nino/squareglass/SquareOutput;->anchors:Ljava/util/WeakHashMap;

    invoke-virtual {v3}, Ljava/util/WeakHashMap;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    const/4 v4, 0x0

    :cond_3
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map$Entry;

    .line 72
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/view/View;

    .line 73
    invoke-virtual {v6}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-virtual {v6}, Landroid/view/View;->isShown()Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-virtual {v6}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v7

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v8

    if-eq v7, v8, :cond_4

    .line 74
    invoke-virtual {v6}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v7

    invoke-static {v0}, Ldev/nino/squareglass/PlayerWindow;->source(Landroid/app/Activity;)Landroid/view/View;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v8

    if-ne v7, v8, :cond_3

    .line 75
    :cond_4
    new-instance v2, Landroid/graphics/Rect;

    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/graphics/Rect;

    invoke-direct {v2, v4}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    move-object v4, v2

    move-object v2, v6

    goto :goto_0

    :cond_5
    if-nez v4, :cond_6

    .line 80
    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 81
    new-instance v4, Landroid/graphics/Rect;

    iget v5, v3, Landroid/graphics/Rect;->right:I

    add-int/lit8 v5, v5, -0x30

    iget v6, v3, Landroid/graphics/Rect;->top:I

    add-int/lit8 v6, v6, 0x30

    iget v7, v3, Landroid/graphics/Rect;->right:I

    add-int/lit8 v7, v7, -0x18

    iget v3, v3, Landroid/graphics/Rect;->top:I

    add-int/lit8 v3, v3, 0x48

    invoke-direct {v4, v5, v6, v7, v3}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 82
    :cond_6
    new-instance v3, Ldev/nino/squareglass/SquareOutput$Session;

    invoke-direct {v3, p0, v0, v4, v2}, Ldev/nino/squareglass/SquareOutput$Session;-><init>(Landroid/app/Dialog;Landroid/app/Activity;Landroid/graphics/Rect;Landroid/view/View;)V

    sput-object v3, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    .line 83
    :try_start_0
    invoke-virtual {v3}, Ldev/nino/squareglass/SquareOutput$Session;->open()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    :catch_0
    move-exception p0

    invoke-virtual {v3}, Ldev/nino/squareglass/SquareOutput$Session;->close()V

    throw p0

    :cond_7
    :goto_1
    return v1
.end method

.method public static showFromSettings(Landroid/app/Activity;)V
    .locals 9

    if-eqz p0, :cond_2

    .line 54
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 55
    :cond_0
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareOutput$Session;->close()V

    .line 56
    :cond_1
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    .line 57
    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v0, v1}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 58
    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    .line 59
    new-instance v3, Landroid/graphics/Rect;

    iget v4, v1, Landroid/graphics/Rect;->right:I

    const/high16 v5, 0x42400000    # 48.0f

    mul-float/2addr v5, v2

    float-to-int v5, v5

    sub-int/2addr v4, v5

    iget v6, v1, Landroid/graphics/Rect;->top:I

    iget v7, v1, Landroid/graphics/Rect;->right:I

    const/high16 v8, 0x41c00000    # 24.0f

    mul-float/2addr v2, v8

    float-to-int v2, v2

    sub-int/2addr v7, v2

    iget v1, v1, Landroid/graphics/Rect;->top:I

    add-int/2addr v1, v5

    invoke-direct {v3, v4, v6, v7, v1}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 61
    new-instance v1, Ldev/nino/squareglass/SquareOutput$Session;

    const/4 v2, 0x0

    invoke-direct {v1, v2, p0, v3, v0}, Ldev/nino/squareglass/SquareOutput$Session;-><init>(Landroid/app/Dialog;Landroid/app/Activity;Landroid/graphics/Rect;Landroid/view/View;)V

    sput-object v1, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    .line 62
    :try_start_0
    invoke-virtual {v1}, Ldev/nino/squareglass/SquareOutput$Session;->open()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p0

    invoke-virtual {v1}, Ldev/nino/squareglass/SquareOutput$Session;->close()V

    throw p0

    :cond_2
    :goto_0
    return-void
.end method

.method public static showing(Landroid/app/Dialog;)Z
    .locals 1

    if-eqz p0, :cond_0

    .line 50
    sget-object v0, Ldev/nino/squareglass/SquareOutput;->current:Ldev/nino/squareglass/SquareOutput$Session;

    if-eqz v0, :cond_0

    iget-object v0, v0, Ldev/nino/squareglass/SquareOutput$Session;->dialog:Landroid/app/Dialog;

    if-ne v0, p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method
