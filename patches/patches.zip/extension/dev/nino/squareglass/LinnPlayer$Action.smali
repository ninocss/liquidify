.class interface abstract Ldev/nino/squareglass/LinnPlayer$Action;
.super Ljava/lang/Object;
.source "LinnPlayer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/LinnPlayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "Action"
.end annotation


# virtual methods
.method public abstract run()V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation
.end method
