.class final Ldev/nino/squareglass/LinnEvents;
.super Ljava/lang/Object;
.source "LinnEvents.java"

# interfaces
.implements Ljava/lang/AutoCloseable;


# instance fields
.field callback:Ljava/lang/String;

.field final changed:Ljava/lang/Runnable;

.field volatile closed:Z

.field final executor:Ljava/util/concurrent/ScheduledExecutorService;

.field volatile lastEvent:J

.field final pendingSubscriptions:Ljava/util/concurrent/atomic/AtomicInteger;

.field final received:Ljava/util/function/Consumer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/function/Consumer<",
            "Ldev/nino/squareglass/LinnEvent;",
            ">;"
        }
    .end annotation
.end field

.field final sequences:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field server:Ljava/net/ServerSocket;

.field final subscriptions:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final transport:Ldev/nino/squareglass/OpenHome;


# direct methods
.method public static synthetic $r8$lambda$tV-62RjFeDoTbHSWaYQBrAgIT5o(Ldev/nino/squareglass/LinnEvents;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnEvents;->lambda$close$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$vbTwhzk3gfcf3z7636Tj79d8cZ8(Ldev/nino/squareglass/LinnEvents;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnEvents;->lambda$start$0()V

    return-void
.end method

.method constructor <init>(Ldev/nino/squareglass/OpenHome;Ljava/lang/Runnable;)V
    .locals 1

    .line 22
    new-instance v0, Ldev/nino/squareglass/LinnEvents$0;

    invoke-direct {v0, p2}, Ldev/nino/squareglass/LinnEvents$0;-><init>(Ljava/lang/Runnable;)V

    invoke-direct {p0, p1, p2, v0}, Ldev/nino/squareglass/LinnEvents;-><init>(Ldev/nino/squareglass/OpenHome;Ljava/lang/Runnable;Ljava/util/function/Consumer;)V

    return-void
.end method

.method constructor <init>(Ldev/nino/squareglass/OpenHome;Ljava/lang/Runnable;Ljava/util/function/Consumer;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/OpenHome;",
            "Ljava/lang/Runnable;",
            "Ljava/util/function/Consumer<",
            "Ldev/nino/squareglass/LinnEvent;",
            ">;)V"
        }
    .end annotation

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    .line 14
    invoke-static {v0}, Ljava/util/concurrent/Executors;->newScheduledThreadPool(I)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnEvents;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    .line 15
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnEvents;->subscriptions:Ljava/util/Map;

    .line 16
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnEvents;->sequences:Ljava/util/Map;

    .line 17
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnEvents;->pendingSubscriptions:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 23
    iput-object p1, p0, Ldev/nino/squareglass/LinnEvents;->transport:Ldev/nino/squareglass/OpenHome;

    iput-object p2, p0, Ldev/nino/squareglass/LinnEvents;->changed:Ljava/lang/Runnable;

    iput-object p3, p0, Ldev/nino/squareglass/LinnEvents;->received:Ljava/util/function/Consumer;

    return-void
.end method

.method static headers(Ljava/io/InputStream;)Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/InputStream;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 59
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    const/16 v3, 0x40

    if-ge v2, v3, :cond_2

    .line 60
    invoke-static {p0}, Ldev/nino/squareglass/LinnEvents;->line(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_0

    return-object v0

    :cond_0
    const/16 v4, 0x3a

    invoke-virtual {v3, v4}, Ljava/lang/String;->indexOf(I)I

    move-result v4

    if-lez v4, :cond_1

    invoke-virtual {v3, v1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    sget-object v6, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v5, v6}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v5

    add-int/lit8 v4, v4, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v5, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 61
    :cond_2
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Too many headers"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private synthetic lambda$close$0()V
    .locals 5

    .line 108
    iget-object v0, p0, Ldev/nino/squareglass/LinnEvents;->subscriptions:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :catch_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 109
    :try_start_0
    const-string v2, "UNSUBSCRIBE"

    iget-object v3, p0, Ldev/nino/squareglass/LinnEvents;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v3, v3, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ldev/nino/squareglass/OpenHome$Service;

    iget-object v3, v3, Ldev/nino/squareglass/OpenHome$Service;->event:Ljava/lang/String;

    const-string v4, "SID"

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v4, v1}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    move-result-object v1

    invoke-static {v2, v3, v1}, Ldev/nino/squareglass/LinnEvents;->request(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/util/Map;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 110
    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnEvents;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {p0}, Ljava/util/concurrent/ScheduledExecutorService;->shutdown()V

    return-void
.end method

.method static synthetic lambda$new$0(Ljava/lang/Runnable;Ldev/nino/squareglass/LinnEvent;)V
    .locals 0

    .line 22
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method private synthetic lambda$start$0()V
    .locals 9

    const-string v0, "http://"

    .line 27
    :try_start_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnEvents;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v1, v1, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    const-string v2, "Playlist"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldev/nino/squareglass/OpenHome$Service;

    iget-object v1, v1, Ldev/nino/squareglass/OpenHome$Service;->control:Ljava/lang/String;

    invoke-static {v1}, Ldev/nino/squareglass/OpenHome;->local(Ljava/lang/String;)Ljava/net/URL;

    move-result-object v1

    .line 29
    new-instance v2, Ljava/net/DatagramSocket;

    invoke-direct {v2}, Ljava/net/DatagramSocket;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-virtual {v1}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v3

    sget-object v4, Ldev/nino/squareglass/OpenHome;->network:Ldev/nino/squareglass/OpenHome$NetworkBinding;

    if-eqz v4, :cond_0

    sget-object v4, Ldev/nino/squareglass/OpenHome;->network:Ldev/nino/squareglass/OpenHome$NetworkBinding;

    invoke-interface {v4, v2, v3}, Ldev/nino/squareglass/OpenHome$NetworkBinding;->bind(Ljava/net/DatagramSocket;Ljava/net/InetAddress;)V

    :cond_0
    invoke-virtual {v1}, Ljava/net/URL;->getPort()I

    move-result v4

    if-gez v4, :cond_1

    const/16 v1, 0x50

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Ljava/net/URL;->getPort()I

    move-result v1

    :goto_0
    invoke-virtual {v2, v3, v1}, Ljava/net/DatagramSocket;->connect(Ljava/net/InetAddress;I)V

    invoke-virtual {v2}, Ljava/net/DatagramSocket;->getLocalAddress()Ljava/net/InetAddress;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v2}, Ljava/net/DatagramSocket;->close()V

    .line 30
    new-instance v2, Ljava/net/ServerSocket;

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v2, v3, v4, v1}, Ljava/net/ServerSocket;-><init>(IILjava/net/InetAddress;)V

    iput-object v2, p0, Ldev/nino/squareglass/LinnEvents;->server:Ljava/net/ServerSocket;

    const/16 v3, 0x3e8

    invoke-virtual {v2, v3}, Ljava/net/ServerSocket;->setSoTimeout(I)V

    .line 31
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ":"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Ldev/nino/squareglass/LinnEvents;->server:Ljava/net/ServerSocket;

    invoke-virtual {v0}, Ljava/net/ServerSocket;->getLocalPort()I

    move-result v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, "/events"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnEvents;->callback:Ljava/lang/String;

    .line 32
    iget-object v0, p0, Ldev/nino/squareglass/LinnEvents;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnEvents$3;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnEvents$3;-><init>(Ldev/nino/squareglass/LinnEvents;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 33
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnEvents;->renew()V

    iget-object v2, p0, Ldev/nino/squareglass/LinnEvents;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v3, Ldev/nino/squareglass/LinnEvents$4;

    invoke-direct {v3, p0}, Ldev/nino/squareglass/LinnEvents$4;-><init>(Ldev/nino/squareglass/LinnEvents;)V

    sget-object v8, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v4, 0x78

    const-wide/16 v6, 0x78

    invoke-interface/range {v2 .. v8}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    return-void

    :catchall_0
    move-exception v0

    move-object p0, v0

    .line 29
    :try_start_3
    invoke-virtual {v2}, Ljava/net/DatagramSocket;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception v0

    :try_start_4
    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1
    throw p0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    return-void
.end method

.method static line(Ljava/io/InputStream;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 54
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 55
    :cond_0
    :goto_0
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_3

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v3

    const/16 v4, 0x2000

    if-ge v3, v4, :cond_2

    const/16 v3, 0xa

    if-ne v1, v3, :cond_1

    goto :goto_1

    :cond_1
    const/16 v2, 0xd

    if-eq v1, v2, :cond_0

    invoke-virtual {v0, v1}, Ljava/io/ByteArrayOutputStream;->write(I)V

    goto :goto_0

    :cond_2
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Header too long"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    :goto_1
    if-ne v1, v2, :cond_5

    .line 56
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result p0

    if-eqz p0, :cond_4

    goto :goto_2

    :cond_4
    new-instance p0, Ljava/io/EOFException;

    invoke-direct {p0}, Ljava/io/EOFException;-><init>()V

    throw p0

    :cond_5
    :goto_2
    const-string p0, "ISO-8859-1"

    invoke-virtual {v0, p0}, Ljava/io/ByteArrayOutputStream;->toString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static request(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/util/Map;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 64
    invoke-static {p1}, Ldev/nino/squareglass/OpenHome;->local(Ljava/lang/String;)Ljava/net/URL;

    move-result-object p1

    invoke-virtual {p1}, Ljava/net/URL;->getPort()I

    move-result v0

    if-gez v0, :cond_0

    const/16 v0, 0x50

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Ljava/net/URL;->getPort()I

    move-result v0

    .line 65
    :goto_0
    new-instance v1, Ljava/net/Socket;

    invoke-direct {v1}, Ljava/net/Socket;-><init>()V

    .line 66
    :try_start_0
    sget-object v2, Ldev/nino/squareglass/OpenHome;->network:Ldev/nino/squareglass/OpenHome$NetworkBinding;

    if-eqz v2, :cond_1

    sget-object v2, Ldev/nino/squareglass/OpenHome;->network:Ldev/nino/squareglass/OpenHome$NetworkBinding;

    invoke-virtual {p1}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v3

    invoke-interface {v2, v1, v3}, Ldev/nino/squareglass/OpenHome$NetworkBinding;->bind(Ljava/net/Socket;Ljava/net/InetAddress;)V

    :cond_1
    const/4 v2, 0x1

    .line 67
    invoke-virtual {v1, v2}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    .line 68
    new-instance v2, Ljava/net/InetSocketAddress;

    invoke-virtual {p1}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3, v0}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    const/16 v3, 0xbb8

    invoke-virtual {v1, v2, v3}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    invoke-virtual {v1, v3}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 69
    new-instance v2, Ljava/lang/StringBuilder;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " "

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/net/URL;->getFile()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " HTTP/1.1\r\nHOST: "

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ":"

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, "\r\nConnection: close\r\n"

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v2, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 70
    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-string p2, "\r\n"

    if-eqz p1, :cond_2

    :try_start_1
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map$Entry;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ": "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 71
    :cond_2
    invoke-virtual {v1}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p0

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sget-object p2, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-virtual {p1, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/io/OutputStream;->write([B)V

    .line 72
    new-instance p0, Ljava/io/BufferedInputStream;

    invoke-virtual {v1}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-static {p0}, Ldev/nino/squareglass/LinnEvents;->line(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object p1

    .line 73
    const-string p2, "HTTP/1\\.[01] 200.*"

    invoke-virtual {p1, p2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_3

    invoke-static {p0}, Ldev/nino/squareglass/LinnEvents;->headers(Ljava/io/InputStream;)Ljava/util/Map;

    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 74
    invoke-virtual {v1}, Ljava/net/Socket;->close()V

    return-object p0

    .line 73
    :cond_3
    :try_start_2
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Event subscription rejected"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catchall_0
    move-exception p0

    .line 65
    :try_start_3
    invoke-virtual {v1}, Ljava/net/Socket;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception p1

    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw p0
.end method

.method private serviceForSid(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 103
    iget-object p0, p0, Ldev/nino/squareglass/LinnEvents;->subscriptions:Ljava/util/Map;

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public declared-synchronized close()V
    .locals 2

    monitor-enter p0

    .line 105
    :try_start_0
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnEvents;->closed:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    monitor-exit p0

    return-void

    :cond_0
    const/4 v0, 0x1

    .line 106
    :try_start_1
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnEvents;->closed:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnEvents;->server:Ljava/net/ServerSocket;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/net/ServerSocket;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 108
    :catch_0
    :cond_1
    :try_start_3
    iget-object v0, p0, Ldev/nino/squareglass/LinnEvents;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnEvents$2;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnEvents$2;-><init>(Ldev/nino/squareglass/LinnEvents;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 111
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_4
    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw v0
.end method

.method healthy()Z
    .locals 4

    .line 24
    iget-object v0, p0, Ldev/nino/squareglass/LinnEvents;->subscriptions:Ljava/util/Map;

    const-string v1, "Playlist"

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-wide v0, p0, Ldev/nino/squareglass/LinnEvents;->lastEvent:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-eqz v0, :cond_0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    iget-wide v2, p0, Ldev/nino/squareglass/LinnEvents;->lastEvent:J

    sub-long/2addr v0, v2

    sget-object p0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v2, 0x2540be400L

    cmp-long p0, v0, v2

    if-gez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method listen()V
    .locals 13

    .line 77
    const-string v0, "0"

    :catch_0
    :cond_0
    :goto_0
    iget-boolean v1, p0, Ldev/nino/squareglass/LinnEvents;->closed:Z

    if-nez v1, :cond_11

    :try_start_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnEvents;->server:Ljava/net/ServerSocket;

    invoke-virtual {v1}, Ljava/net/ServerSocket;->accept()Ljava/net/Socket;

    move-result-object v1
    :try_end_0
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/16 v2, 0x7d0

    .line 78
    :try_start_1
    invoke-virtual {v1, v2}, Ljava/net/Socket;->setSoTimeout(I)V

    new-instance v2, Ljava/io/BufferedInputStream;

    invoke-virtual {v1}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-static {v2}, Ldev/nino/squareglass/LinnEvents;->line(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2}, Ldev/nino/squareglass/LinnEvents;->headers(Ljava/io/InputStream;)Ljava/util/Map;

    move-result-object v4

    .line 79
    const-string v5, "sid"

    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-direct {p0, v5}, Ldev/nino/squareglass/LinnEvents;->serviceForSid(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 82
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v7

    sget-object v9, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/32 v9, 0x1dcd6500

    add-long/2addr v7, v9

    :goto_1
    if-nez v6, :cond_1

    .line 83
    iget-object v9, p0, Ldev/nino/squareglass/LinnEvents;->pendingSubscriptions:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v9}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v9

    if-lez v9, :cond_1

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v9

    cmp-long v9, v9, v7

    if-gez v9, :cond_1

    iget-boolean v9, p0, Ldev/nino/squareglass/LinnEvents;->closed:Z

    if-nez v9, :cond_1

    const-wide/16 v9, 0x5

    invoke-static {v9, v10}, Ljava/lang/Thread;->sleep(J)V

    invoke-direct {p0, v5}, Ldev/nino/squareglass/LinnEvents;->serviceForSid(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    :cond_1
    if-nez v6, :cond_2

    .line 84
    invoke-direct {p0, v5}, Ldev/nino/squareglass/LinnEvents;->serviceForSid(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 85
    :cond_2
    const-string v7, "NOTIFY /events HTTP/1.1"

    invoke-virtual {v3, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v3, :cond_3

    if-eqz v6, :cond_3

    const-string v3, "upnp:event"

    const-string v9, "nt"

    .line 86
    invoke-interface {v4, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    const-string v3, "upnp:propchange"

    const-string v9, "nts"

    invoke-interface {v4, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    move v3, v7

    goto :goto_2

    :cond_3
    move v3, v8

    .line 89
    :goto_2
    invoke-virtual {v1}, Ljava/net/Socket;->getInetAddress()Ljava/net/InetAddress;

    move-result-object v9

    invoke-virtual {v9}, Ljava/net/InetAddress;->isSiteLocalAddress()Z

    move-result v9

    if-eqz v9, :cond_4

    invoke-virtual {v1}, Ljava/net/Socket;->getInetAddress()Ljava/net/InetAddress;

    move-result-object v9

    invoke-virtual {v9}, Ljava/net/InetAddress;->isLoopbackAddress()Z

    move-result v9

    if-nez v9, :cond_4

    move v9, v7

    goto :goto_3

    :cond_4
    move v9, v8

    :goto_3
    if-eqz v3, :cond_5

    if-eqz v9, :cond_5

    move v3, v7

    goto :goto_4

    :cond_5
    move v3, v8

    :goto_4
    if-nez v3, :cond_7

    .line 91
    sget-object v10, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "event_rejected sid_known="

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v6, :cond_6

    goto :goto_5

    :cond_6
    move v7, v8

    :goto_5
    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v7, " source_matches="

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-interface {v10, v7}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    .line 92
    :cond_7
    const-string v7, "content-length"

    invoke-interface {v4, v7, v0}, Ljava/util/Map;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    if-ltz v7, :cond_8

    const/high16 v9, 0x20000

    if-le v7, v9, :cond_9

    :cond_8
    move v3, v8

    :cond_9
    if-eqz v3, :cond_e

    .line 94
    new-array v9, v7, [B

    :goto_6
    if-ge v8, v7, :cond_a

    sub-int v10, v7, v8

    invoke-virtual {v2, v9, v8, v10}, Ljava/io/InputStream;->read([BII)I

    move-result v10

    if-lez v10, :cond_a

    add-int/2addr v8, v10

    goto :goto_6

    :cond_a
    if-ne v8, v7, :cond_d

    .line 95
    invoke-static {v6, v9}, Ldev/nino/squareglass/LinnEvent;->parse(Ljava/lang/String;[B)Ldev/nino/squareglass/LinnEvent;

    move-result-object v2

    .line 96
    const-string v6, "seq"

    invoke-interface {v4, v6, v0}, Ljava/util/Map;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Long;->parseUnsignedLong(Ljava/lang/String;)J

    move-result-wide v6

    iget-object v4, p0, Ldev/nino/squareglass/LinnEvents;->sequences:Ljava/util/Map;

    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Long;

    const-wide v8, 0xffffffffL

    cmp-long v8, v6, v8

    if-gtz v8, :cond_c

    if-eqz v4, :cond_b

    .line 98
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    invoke-static {v8, v9, v6, v7}, Ldev/nino/squareglass/LinnQueuePlan;->sequenceNewer(JJ)Z

    move-result v4

    if-eqz v4, :cond_e

    :cond_b
    iget-object v4, p0, Ldev/nino/squareglass/LinnEvents;->sequences:Ljava/util/Map;

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    iput-wide v4, p0, Ldev/nino/squareglass/LinnEvents;->lastEvent:J

    iget-object v4, p0, Ldev/nino/squareglass/LinnEvents;->received:Ljava/util/function/Consumer;

    invoke-interface {v4, v2}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    goto :goto_7

    .line 97
    :cond_c
    new-instance v2, Ljava/io/IOException;

    const-string v3, "Invalid event sequence"

    invoke-direct {v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 95
    :cond_d
    new-instance v2, Ljava/io/EOFException;

    invoke-direct {v2}, Ljava/io/EOFException;-><init>()V

    throw v2

    .line 100
    :cond_e
    :goto_7
    invoke-virtual {v1}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v2

    if-eqz v3, :cond_f

    const-string v3, "HTTP/1.1 200 OK\r\n"

    goto :goto_8

    :cond_f
    const-string v3, "HTTP/1.1 412 Precondition Failed\r\n"

    :goto_8
    const-string v4, "Content-Length: 0\r\nConnection: close\r\n\r\n"

    invoke-virtual {v3, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    sget-object v4, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-virtual {v3, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/io/OutputStream;->write([B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v1, :cond_0

    .line 101
    :try_start_2
    invoke-virtual {v1}, Ljava/net/Socket;->close()V
    :try_end_2
    .catch Ljava/net/SocketTimeoutException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto/16 :goto_0

    :catchall_0
    move-exception v2

    if-eqz v1, :cond_10

    .line 77
    :try_start_3
    invoke-virtual {v1}, Ljava/net/Socket;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_9

    :catchall_1
    move-exception v1

    :try_start_4
    invoke-virtual {v2, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_10
    :goto_9
    throw v2
    :try_end_4
    .catch Ljava/net/SocketTimeoutException; {:try_start_4 .. :try_end_4} :catch_0
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    :cond_11
    return-void
.end method

.method renew()V
    .locals 8

    .line 37
    const-string v0, "sid"

    const-string v1, "Volume"

    const-string v2, "Product"

    const-string v3, "Playlist"

    const-string v4, "Time"

    filled-new-array {v3, v4, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 38
    iget-boolean v3, p0, Ldev/nino/squareglass/LinnEvents;->closed:Z

    if-eqz v3, :cond_0

    goto/16 :goto_2

    .line 40
    :cond_0
    :try_start_0
    iget-object v3, p0, Ldev/nino/squareglass/LinnEvents;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v3, v3, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ldev/nino/squareglass/OpenHome$Service;

    if-nez v3, :cond_1

    goto :goto_0

    .line 41
    :cond_1
    iget-object v4, p0, Ldev/nino/squareglass/LinnEvents;->subscriptions:Ljava/util/Map;

    invoke-interface {v4, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 42
    new-instance v5, Ljava/util/LinkedHashMap;

    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    const-string v6, "TIMEOUT"

    const-string v7, "Second-300"

    invoke-interface {v5, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-nez v4, :cond_2

    .line 43
    const-string v4, "CALLBACK"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "<"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v7, p0, Ldev/nino/squareglass/LinnEvents;->callback:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, ">"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v5, v4, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v4, "NT"

    const-string v6, "upnp:event"

    invoke-interface {v5, v4, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    .line 44
    :cond_2
    const-string v6, "SID"

    invoke-interface {v5, v6, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    :goto_1
    iget-object v4, p0, Ldev/nino/squareglass/LinnEvents;->pendingSubscriptions:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    :try_start_1
    const-string v4, "SUBSCRIBE"

    iget-object v3, v3, Ldev/nino/squareglass/OpenHome$Service;->event:Ljava/lang/String;

    invoke-static {v4, v3, v5}, Ldev/nino/squareglass/LinnEvents;->request(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/util/Map;

    move-result-object v3

    .line 48
    invoke-interface {v3, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    iget-object v4, p0, Ldev/nino/squareglass/LinnEvents;->subscriptions:Ljava/util/Map;

    invoke-interface {v3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v4, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 49
    :cond_3
    :try_start_2
    iget-object v3, p0, Ldev/nino/squareglass/LinnEvents;->pendingSubscriptions:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    goto/16 :goto_0

    :catchall_0
    move-exception v3

    iget-object v4, p0, Ldev/nino/squareglass/LinnEvents;->pendingSubscriptions:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    throw v3
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 50
    :catch_0
    iget-object v3, p0, Ldev/nino/squareglass/LinnEvents;->subscriptions:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_0

    :cond_4
    :goto_2
    return-void
.end method

.method start()V
    .locals 2

    .line 25
    iget-object v0, p0, Ldev/nino/squareglass/LinnEvents;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnEvents$1;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnEvents$1;-><init>(Ldev/nino/squareglass/LinnEvents;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
