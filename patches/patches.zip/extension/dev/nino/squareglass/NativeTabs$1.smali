.class public final synthetic Ldev/nino/squareglass/NativeTabs$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeTabs$1;->f$0:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/NativeTabs$1;->f$0:Ljava/util/List;

    invoke-static {p0}, Ldev/nino/squareglass/NativeTabs;->$r8$lambda$xakV59iKFD-44hxo9GcxBmAofR0(Ljava/util/List;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
