.class final Ldev/nino/squareglass/LinnProvider$Device;
.super Lp2/a;
.source "LinnProvider.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/LinnProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Device"
.end annotation


# instance fields
.field volatile bootId:Ljava/lang/String;

.field volatile configId:Ljava/lang/String;

.field volatile expires:J

.field final location:Ljava/lang/String;

.field volatile transport:Ldev/nino/squareglass/OpenHome;

.field final uuid:Ljava/lang/String;

.field volatile verified:Z


# direct methods
.method constructor <init>(Ldev/nino/squareglass/OpenHome;)V
    .locals 3

    .line 50
    iget-object v0, p1, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    iget-object v1, p1, Ldev/nino/squareglass/OpenHome;->name:Ljava/lang/String;

    iget-object v2, p1, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    invoke-direct {p0, v0, v1, v2}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 p1, 0x1

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnProvider$Device;->verified:Z

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    .line 51
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "LINN_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-direct {p0, v0, p2, v1}, Lp2/a;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 49
    const-string p2, ""

    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider$Device;->bootId:Ljava/lang/String;

    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider$Device;->configId:Ljava/lang/String;

    .line 51
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider$Device;->location:Ljava/lang/String;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide p1

    sget-object p3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v0, 0x6fc23ac00L

    add-long/2addr p1, v0

    iput-wide p1, p0, Ldev/nino/squareglass/LinnProvider$Device;->expires:J

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method resolve()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 53
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider$Device;->verified:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider$Device;->location:Ljava/lang/String;

    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->cached(Ljava/lang/String;)Ldev/nino/squareglass/OpenHome;

    move-result-object v0

    goto :goto_0

    :cond_0
    new-instance v0, Ldev/nino/squareglass/OpenHome;

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider$Device;->location:Ljava/lang/String;

    invoke-direct {v0, v1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    .line 54
    :goto_0
    iget-object v1, v0, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider$Device;->uuid:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 55
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v1, 0x1

    iput-boolean v1, p0, Ldev/nino/squareglass/LinnProvider$Device;->verified:Z

    .line 56
    sget-object v1, Ldev/nino/squareglass/OpenHome;->descriptions:Ldev/nino/squareglass/LinnCache;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->location:Ljava/lang/String;

    invoke-virtual {v1, p0, v0}, Ldev/nino/squareglass/LinnCache;->put(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    .line 54
    :cond_1
    new-instance p0, Ljava/io/IOException;

    const-string v0, "A different renderer now uses this address. Refresh outputs."

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
