.class public final synthetic Ldev/nino/squareglass/LiquidMenuSurface$7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LiquidMenuSurface;

.field public final synthetic f$1:F

.field public final synthetic f$2:Z

.field public final synthetic f$3:Z

.field public final synthetic f$4:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LiquidMenuSurface;FZZLandroidx/compose/runtime/MutableState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$0:Ldev/nino/squareglass/LiquidMenuSurface;

    iput p2, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$1:F

    iput-boolean p3, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$2:Z

    iput-boolean p4, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$3:Z

    iput-object p5, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$4:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$0:Ldev/nino/squareglass/LiquidMenuSurface;

    iget v1, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$1:F

    iget-boolean v2, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$2:Z

    iget-boolean v3, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$3:Z

    iget-object v4, p0, Ldev/nino/squareglass/LiquidMenuSurface$7;->f$4:Landroidx/compose/runtime/MutableState;

    move-object v5, p1

    check-cast v5, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-static/range {v0 .. v6}, Ldev/nino/squareglass/LiquidMenuSurface;->paint$lambda$3(Ldev/nino/squareglass/LiquidMenuSurface;FZZLandroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
