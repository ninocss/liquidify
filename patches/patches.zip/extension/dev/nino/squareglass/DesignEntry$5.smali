.class public final synthetic Ldev/nino/squareglass/DesignEntry$5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/DesignEntry;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Lam0/a;

.field public final synthetic f$4:I

.field public final synthetic f$5:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Lam0/a;II)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$5;->f$0:Ldev/nino/squareglass/DesignEntry;

    iput-object p2, p0, Ldev/nino/squareglass/DesignEntry$5;->f$1:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/DesignEntry$5;->f$2:Ljava/lang/String;

    iput-object p4, p0, Ldev/nino/squareglass/DesignEntry$5;->f$3:Lam0/a;

    iput p5, p0, Ldev/nino/squareglass/DesignEntry$5;->f$4:I

    iput p6, p0, Ldev/nino/squareglass/DesignEntry$5;->f$5:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$5;->f$0:Ldev/nino/squareglass/DesignEntry;

    iget-object v1, p0, Ldev/nino/squareglass/DesignEntry$5;->f$1:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/DesignEntry$5;->f$2:Ljava/lang/String;

    iget-object v3, p0, Ldev/nino/squareglass/DesignEntry$5;->f$3:Lam0/a;

    iget v4, p0, Ldev/nino/squareglass/DesignEntry$5;->f$4:I

    iget v5, p0, Ldev/nino/squareglass/DesignEntry$5;->f$5:I

    move-object v6, p1

    check-cast v6, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/DesignEntry;->Row$lambda$1(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Lam0/a;IILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
