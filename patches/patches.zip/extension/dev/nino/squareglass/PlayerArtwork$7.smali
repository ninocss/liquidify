.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroid/view/View;

.field public final synthetic f$1:Ldev/nino/squareglass/PlayerArtwork$Frame;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;Ldev/nino/squareglass/PlayerArtwork$Frame;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$7;->f$0:Landroid/view/View;

    iput-object p2, p0, Ldev/nino/squareglass/PlayerArtwork$7;->f$1:Ldev/nino/squareglass/PlayerArtwork$Frame;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/PlayerArtwork$7;->f$0:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$7;->f$1:Ldev/nino/squareglass/PlayerArtwork$Frame;

    check-cast p1, Landroidx/compose/runtime/DisposableEffectScope;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$XFkIqM1IsojOHja5qN7HE8rqqfI(Landroid/view/View;Ldev/nino/squareglass/PlayerArtwork$Frame;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method
