.class public final Ldev/nino/squareglass/PageMaterial;
.super Ljava/lang/Object;
.source "PageMaterial.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static background(Landroid/view/View;II)Landroid/graphics/drawable/Drawable;
    .locals 8

    .line 9
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    if-nez p1, :cond_0

    .line 10
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result p1

    .line 11
    :cond_0
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    sget-object v2, Landroid/graphics/drawable/GradientDrawable$Orientation;->TL_BR:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/4 v3, -0x1

    if-eqz v0, :cond_1

    const v4, -0xaaa79b

    goto :goto_0

    :cond_1
    move v4, v3

    :goto_0
    const v5, 0x3f147ae1    # 0.58f

    .line 12
    invoke-static {p1, v4, v5}, Ldev/nino/squareglass/CoverColors;->blend(IIF)I

    move-result v4

    const v5, 0xffffff

    and-int/2addr v4, v5

    const/high16 v6, -0x27000000

    or-int/2addr v4, v6

    if-eqz v0, :cond_2

    const v3, -0xd7d4cb

    :cond_2
    const v6, 0x3e99999a    # 0.3f

    invoke-static {p1, v3, v6}, Ldev/nino/squareglass/CoverColors;->blend(IIF)I

    move-result v3

    and-int/2addr v3, v5

    const/high16 v6, -0x48000000

    or-int/2addr v3, v6

    filled-new-array {v4, v3}, [I

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    int-to-float p2, p2

    mul-float/2addr p2, p0

    .line 13
    invoke-virtual {v1, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result v2

    const/4 v3, 0x1

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    if-eqz v0, :cond_3

    const v4, 0x38ffffff

    goto :goto_1

    :cond_3
    const v4, -0x19000001

    :goto_1
    invoke-virtual {v1, v2, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 14
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v2

    const/4 v4, 0x2

    if-ne v2, v4, :cond_4

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 15
    :cond_4
    new-instance v2, Landroid/graphics/drawable/StateListDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    .line 16
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v6

    const v7, 0x3e19999a    # 0.15f

    invoke-static {p1, v6, v7}, Ldev/nino/squareglass/CoverColors;->blend(IIF)I

    move-result p1

    invoke-virtual {v4, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 17
    invoke-virtual {v4, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    invoke-static {v3, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    if-eqz v0, :cond_5

    const p1, -0x7f000001

    goto :goto_2

    :cond_5
    const p1, -0x33000001    # -1.3421772E8f

    :goto_2
    invoke-virtual {v4, p0, p1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    const p0, 0x10100a1

    .line 18
    filled-new-array {p0}, [I

    move-result-object p0

    invoke-virtual {v2, p0, v4}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    const p0, 0x10102fe

    .line 19
    filled-new-array {p0}, [I

    move-result-object p0

    invoke-virtual {v2, p0, v4}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    const p0, 0x10100a0

    .line 20
    filled-new-array {p0}, [I

    move-result-object p0

    invoke-virtual {v2, p0, v4}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    const/4 p0, 0x0

    .line 21
    new-array p0, p0, [I

    invoke-virtual {v2, p0, v1}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 22
    new-instance p0, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p1

    and-int/2addr p1, v5

    const/high16 p2, 0x18000000

    or-int/2addr p1, p2

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 p2, 0x0

    invoke-direct {p0, p1, v2, p2}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    return-object p0
.end method
