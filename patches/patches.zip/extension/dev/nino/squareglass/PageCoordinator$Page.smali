.class final Ldev/nino/squareglass/PageCoordinator$Page;
.super Ljava/lang/Object;
.source "PageCoordinator.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;
.implements Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/PageCoordinator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Page"
.end annotation


# instance fields
.field chromeItems:I

.field chromeSurface:Landroid/view/View;

.field chromeTone:I

.field dark:Z

.field final detail:Z

.field hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

.field heroView:Landroid/view/View;

.field inset:I

.field final lists:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/recyclerview/widget/RecyclerView;",
            ">;"
        }
    .end annotation
.end field

.field final materials:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation
.end field

.field movingAction:Landroid/view/View;

.field primary:Landroidx/recyclerview/widget/RecyclerView;

.field final root:Landroid/view/View;

.field final search:Z

.field final snapshot:Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;

.field final title:Ljava/lang/String;

.field tone:I

.field watching:Z

.field final xy:[I


# direct methods
.method public static synthetic $r8$lambda$eXc0LG_whJWgiVr3oeU2VJrHn00(Ldev/nino/squareglass/PageCoordinator$Page;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/PageCoordinator$Page;->lambda$onChildViewAttachedToWindow$0(Landroid/view/View;)V

    return-void
.end method

.method constructor <init>(Landroid/view/View;Ljava/lang/String;ZZLdev/nino/squareglass/PageCoordinator$HeroSnapshot;)V
    .locals 1

    .line 114
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 109
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->lists:Ljava/util/ArrayList;

    .line 110
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->materials:Ljava/util/WeakHashMap;

    const/4 v0, 0x2

    .line 111
    new-array v0, v0, [I

    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->xy:[I

    const/4 v0, -0x1

    .line 113
    iput v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->inset:I

    iput v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->chromeItems:I

    .line 114
    iput-object p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    iput-object p2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    iput-boolean p3, p0, Ldev/nino/squareglass/PageCoordinator$Page;->search:Z

    iput-boolean p4, p0, Ldev/nino/squareglass/PageCoordinator$Page;->detail:Z

    iput-object p5, p0, Ldev/nino/squareglass/PageCoordinator$Page;->snapshot:Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;

    return-void
.end method

.method private synthetic lambda$onChildViewAttachedToWindow$0(Landroid/view/View;)V
    .locals 1

    .line 320
    invoke-virtual {p1}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/PageCoordinator$Page;->row(Landroid/view/View;)V

    iget-boolean v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->search:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    if-eqz v0, :cond_1

    :cond_0
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/PageCoordinator$Page;->scan(Landroid/view/View;)V

    :cond_1
    return-void
.end method


# virtual methods
.method collectionControls()V
    .locals 5

    .line 196
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    const v1, 0x7f0b0334

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    goto/16 :goto_1

    :cond_0
    const v1, 0x7f0b0568

    const v2, 0x7f0b065c

    .line 198
    invoke-static {v0, v1, v2}, Ldev/nino/squareglass/SquareDetails;->controls(Landroid/view/View;II)V

    .line 199
    const-string v1, "My Tracks"

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    const v1, 0x7f0b026b

    .line 202
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_1

    const/16 v2, 0x8

    .line 203
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 206
    :cond_1
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_2
    move-object v1, v0

    .line 207
    :goto_0
    iget-object v3, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    if-eq v1, v3, :cond_4

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    instance-of v3, v3, Landroid/view/View;

    if-eqz v3, :cond_4

    .line 210
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    const-string v4, "com.google.android.material.appbar.AppBarLayout"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    .line 211
    invoke-virtual {v1, v2}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Landroid/view/View;->setElevation(F)V

    invoke-virtual {v1, v3}, Landroid/view/View;->setTranslationZ(F)V

    .line 207
    :cond_3
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    goto :goto_0

    :cond_4
    const v1, 0x7f0b04c6

    .line 214
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const v2, 0x7f0b027a

    .line 215
    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 216
    instance-of v2, v0, Landroid/widget/TextView;

    if-eqz v2, :cond_5

    check-cast v0, Landroid/widget/TextView;

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v2

    invoke-static {v2}, Ldev/nino/squareglass/SquarePalette;->secondary(Z)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_5
    if-eqz v1, :cond_7

    .line 217
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v0, :cond_7

    .line 218
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    const/high16 v2, 0x41800000    # 16.0f

    .line 220
    invoke-virtual {p0, v2}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result p0

    .line 221
    iget v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    const/4 v3, -0x1

    if-ne v2, v3, :cond_6

    iget v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    if-ne v2, v3, :cond_6

    iget v2, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    if-eq v2, p0, :cond_7

    .line 222
    :cond_6
    iput v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToTop:I

    iput v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->bottomToBottom:I

    iput p0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 223
    invoke-virtual {v1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_7
    :goto_1
    return-void
.end method

.method configureHero()V
    .locals 11

    .line 144
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    const v1, 0x7f0b0334

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 145
    instance-of v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/high16 v2, 0x40000000    # 2.0f

    const-string v3, "createButton"

    const/4 v4, 0x1

    const/4 v5, -0x1

    const/4 v6, 0x0

    if-eqz v1, :cond_7

    const v1, 0x7f0b0568

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_7

    .line 146
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 147
    new-instance v1, Ldev/nino/squareglass/PageCoordinator$HeroView;

    iget-object v7, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    iget-object v8, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    invoke-direct {v1, v7, v8}, Ldev/nino/squareglass/PageCoordinator$HeroView;-><init>(Landroid/view/View;Ldev/nino/squareglass/PageCoordinator$HeroDecoration;)V

    iput-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->heroView:Landroid/view/View;

    invoke-static {}, Landroid/view/View;->generateViewId()I

    move-result v7

    invoke-virtual {v1, v7}, Landroid/view/View;->setId(I)V

    .line 148
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    const/high16 v7, 0x42900000    # 72.0f

    invoke-virtual {p0, v7}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result v7

    add-int/2addr v1, v7

    move v7, v6

    .line 149
    :goto_0
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v8

    if-ge v7, v8, :cond_1

    .line 150
    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v8

    .line 151
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    instance-of v9, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v9, :cond_0

    .line 152
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 153
    iget v10, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    if-nez v10, :cond_0

    iput v5, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iget-object v10, p0, Ldev/nino/squareglass/PageCoordinator$Page;->heroView:Landroid/view/View;

    invoke-virtual {v10}, Landroid/view/View;->getId()I

    move-result v10

    iput v10, v9, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    .line 156
    :cond_1
    new-instance v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    invoke-direct {v7, v6, v1}, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;-><init>(II)V

    .line 157
    iput v6, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v6, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->startToStart:I

    iput v6, v7, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->endToEnd:I

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->heroView:Landroid/view/View;

    invoke-virtual {v0, v1, v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 158
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v7, -0x2

    iput v7, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 159
    instance-of v8, v1, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v8, :cond_2

    move-object v8, v1

    check-cast v8, Landroid/view/ViewGroup$MarginLayoutParams;

    iput v6, v8, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 160
    :cond_2
    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 161
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/View;

    if-eqz v1, :cond_3

    .line 162
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    .line 163
    iput v7, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 165
    :cond_3
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    const v1, 0x7f0b06f0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_6

    .line 166
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/ViewGroup;

    if-eqz v1, :cond_6

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    instance-of v1, v1, Landroid/view/ViewGroup;

    if-eqz v1, :cond_6

    .line 167
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    invoke-virtual {v1, v6}, Landroid/view/View;->setMinimumHeight(I)V

    .line 168
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    move-result-object v7

    instance-of v7, v7, Landroid/view/View;

    if-eqz v7, :cond_4

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    move-result-object v7

    check-cast v7, Landroid/view/View;

    invoke-virtual {v7, v6}, Landroid/view/View;->setMinimumHeight(I)V

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    move-result-object v7

    check-cast v7, Landroid/view/View;

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Landroid/view/View;->setElevation(F)V

    .line 169
    :cond_4
    invoke-static {v1}, Ldev/nino/squareglass/NativeArtworkBridge;->continuousScroll(Landroid/view/View;)V

    .line 170
    new-instance v1, Landroid/widget/FrameLayout;

    iget-object v7, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v7}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-direct {v1, v7}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 171
    iget-object v7, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v7}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object v7

    if-nez v7, :cond_5

    move v7, v6

    goto :goto_1

    :cond_5
    iget-object v7, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v7}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object v7

    invoke-static {}, Landroid/view/WindowInsets$Type;->statusBars()I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/view/WindowInsets;->getInsets(I)Landroid/graphics/Insets;

    move-result-object v7

    iget v7, v7, Landroid/graphics/Insets;->top:I

    .line 172
    :goto_1
    invoke-virtual {v1, v6, v7, v6, v6}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    new-instance v8, Landroid/widget/FrameLayout$LayoutParams;

    const/high16 v9, 0x42600000    # 56.0f

    invoke-virtual {p0, v9}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result v10

    invoke-direct {v8, v5, v10}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v8}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 173
    iget-object v8, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    check-cast v8, Landroid/view/ViewGroup;

    new-instance v10, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v9}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result v9

    add-int/2addr v7, v9

    invoke-direct {v10, v5, v7}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v1, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v5, 0x40800000    # 4.0f

    .line 174
    invoke-virtual {p0, v5}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v1, v5}, Landroid/widget/FrameLayout;->setElevation(F)V

    invoke-virtual {v0, v6}, Landroid/view/View;->setBackgroundColor(I)V

    iput-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->chromeSurface:Landroid/view/View;

    .line 176
    :cond_6
    invoke-virtual {p0}, Ldev/nino/squareglass/PageCoordinator$Page;->collectionControls()V

    .line 177
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p0, v0, v3}, Ldev/nino/squareglass/PageCoordinator$Page;->findNamed(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_8

    .line 178
    invoke-virtual {p0, v2}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result p0

    int-to-float p0, p0

    invoke-virtual {v0, p0}, Landroid/view/View;->setElevation(F)V

    invoke-static {v0, v4}, Ldev/nino/squareglass/SquareDetails;->control(Landroid/view/View;Z)V

    return-void

    .line 180
    :cond_7
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->addItemDecoration(Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;)V

    .line 181
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    if-eqz v0, :cond_8

    .line 182
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 183
    iput v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToTop:I

    iput v5, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;->topToBottom:I

    iput v6, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 184
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 185
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p0, v0, v3}, Ldev/nino/squareglass/PageCoordinator$Page;->findNamed(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->movingAction:Landroid/view/View;

    if-eqz v0, :cond_8

    .line 186
    invoke-virtual {p0, v2}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setElevation(F)V

    iget-object p0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->movingAction:Landroid/view/View;

    invoke-static {p0, v4}, Ldev/nino/squareglass/SquareDetails;->control(Landroid/view/View;Z)V

    :cond_8
    return-void
.end method

.method destroy()V
    .locals 2

    .line 319
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/PageCoordinator$Page;->onViewDetachedFromWindow(Landroid/view/View;)V

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_0

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    if-eqz v1, :cond_0

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->removeItemDecoration(Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;)V

    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method

.method dp(F)I
    .locals 0

    .line 115
    iget-object p0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method findNamed(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;
    .locals 2

    .line 191
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_0

    :try_start_0
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v0, :cond_0

    return-object p1

    .line 192
    :catch_0
    :cond_0
    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_2

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1, p2}, Ldev/nino/squareglass/PageCoordinator$Page;->findNamed(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_1

    return-object v1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method header()V
    .locals 7

    .line 287
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    const v1, 0x7f0b06ef

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    const v1, 0x7f0b06f0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    :cond_0
    if-nez v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    const v1, 0x7f0b0302

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    :cond_1
    if-nez v0, :cond_2

    goto/16 :goto_3

    :cond_2
    const/high16 v1, 0x40800000    # 4.0f

    .line 289
    invoke-virtual {p0, v1}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setElevation(F)V

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->chromeSurface:Landroid/view/View;

    if-nez v1, :cond_3

    iget v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->inset:I

    if-ltz v1, :cond_3

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    const-string v2, "Downloads"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    iget v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->inset:I

    invoke-static {v0, v1}, Ldev/nino/squareglass/PageCoordinator;->toolbarInset(Landroid/view/View;I)V

    .line 290
    :cond_3
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->chromeSurface:Landroid/view/View;

    if-nez v1, :cond_4

    move-object v1, v0

    .line 291
    :cond_4
    invoke-virtual {v1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    instance-of v2, v2, Ldev/nino/squareglass/HeaderFade;

    if-eqz v2, :cond_5

    invoke-virtual {v1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    check-cast v2, Ldev/nino/squareglass/HeaderFade;

    goto :goto_0

    :cond_5
    new-instance v2, Ldev/nino/squareglass/HeaderFade;

    iget v3, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    invoke-direct {v2, v3}, Ldev/nino/squareglass/HeaderFade;-><init>(I)V

    .line 292
    :goto_0
    instance-of v3, v0, Landroidx/appcompat/widget/Toolbar;

    if-eqz v3, :cond_7

    .line 293
    move-object v3, v0

    check-cast v3, Landroidx/appcompat/widget/Toolbar;

    .line 294
    iget-boolean v4, p0, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-static {v4}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v4

    invoke-virtual {v3}, Landroidx/appcompat/widget/Toolbar;->getMenu()Landroid/view/Menu;

    move-result-object v3

    invoke-interface {v3}, Landroid/view/Menu;->size()I

    move-result v3

    .line 295
    iget v5, p0, Ldev/nino/squareglass/PageCoordinator$Page;->chromeTone:I

    if-ne v5, v4, :cond_6

    iget v5, p0, Ldev/nino/squareglass/PageCoordinator$Page;->chromeItems:I

    if-eq v5, v3, :cond_7

    :cond_6
    iput v4, p0, Ldev/nino/squareglass/PageCoordinator$Page;->chromeTone:I

    iput v3, p0, Ldev/nino/squareglass/PageCoordinator$Page;->chromeItems:I

    invoke-static {v0}, Ldev/nino/squareglass/SquareDetails;->chrome(Landroid/view/View;)V

    .line 297
    :cond_7
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, -0x1

    invoke-virtual {v0, v3}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    const/4 v3, 0x0

    if-eqz v0, :cond_8

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollOffset()I

    move-result v0

    goto :goto_1

    :cond_8
    move v0, v3

    .line 298
    :goto_1
    iget-object v4, p0, Ldev/nino/squareglass/PageCoordinator$Page;->heroView:Landroid/view/View;

    if-eqz v4, :cond_a

    :goto_2
    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    instance-of v5, v5, Landroid/view/View;

    if-eqz v5, :cond_a

    iget-object v5, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    if-eq v4, v5, :cond_a

    .line 299
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const-string v6, "com.google.android.material.appbar.AppBarLayout"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_9

    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    move-result v5

    neg-int v5, v5

    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    add-int/2addr v0, v5

    .line 298
    :cond_9
    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    check-cast v4, Landroid/view/View;

    goto :goto_2

    .line 300
    :cond_a
    iget v3, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    int-to-float v0, v0

    const/high16 v4, 0x42c00000    # 96.0f

    invoke-virtual {p0, v4}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result p0

    int-to-float p0, p0

    invoke-static {v0, p0}, Ldev/nino/squareglass/HeaderProgress;->opacity(FF)F

    move-result p0

    const v0, 0x3f70a3d7    # 0.94f

    mul-float/2addr p0, v0

    invoke-virtual {v2, v3, p0}, Ldev/nino/squareglass/HeaderFade;->update(IF)V

    invoke-virtual {v1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    if-eq p0, v2, :cond_b

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_b
    :goto_3
    return-void
.end method

.method public onChildViewAttachedToWindow(Landroid/view/View;)V
    .locals 1

    .line 320
    new-instance v0, Ldev/nino/squareglass/PageCoordinator$Page$0;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/PageCoordinator$Page$0;-><init>(Ldev/nino/squareglass/PageCoordinator$Page;Landroid/view/View;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onChildViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onPreDraw()Z
    .locals 3

    .line 267
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    return v1

    .line 268
    :cond_0
    iget-boolean v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->detail:Z

    if-eqz v0, :cond_1

    return v1

    .line 269
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Ldev/nino/squareglass/PageCoordinator$Page;->collectionControls()V

    .line 270
    :cond_2
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    .line 271
    iget-boolean v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    if-ne v0, v2, :cond_3

    iget v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    if-nez v2, :cond_5

    .line 272
    :cond_3
    iput-boolean v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    if-nez v2, :cond_4

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v0

    goto :goto_0

    :cond_4
    invoke-virtual {v2, v0}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->surface(Z)I

    move-result v0

    :goto_0
    iput v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->materials:Ljava/util/WeakHashMap;

    invoke-virtual {v0}, Ljava/util/WeakHashMap;->clear()V

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/PageCoordinator$Page;->scan(Landroid/view/View;)V

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    iget v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 273
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_5

    iget v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 275
    :cond_5
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    if-eqz v0, :cond_7

    .line 276
    iget-boolean v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-virtual {v0, v2}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->surface(Z)I

    move-result v0

    .line 277
    iget v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    if-eq v2, v0, :cond_6

    iput v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v2, v0}, Landroid/view/View;->setBackgroundColor(I)V

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    iget v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 278
    :cond_6
    invoke-virtual {p0}, Ldev/nino/squareglass/PageCoordinator$Page;->topEdge()V

    invoke-virtual {p0}, Ldev/nino/squareglass/PageCoordinator$Page;->header()V

    .line 280
    :cond_7
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    if-eqz v0, :cond_8

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    if-nez v0, :cond_8

    invoke-virtual {p0}, Ldev/nino/squareglass/PageCoordinator$Page;->topEdge()V

    invoke-virtual {p0}, Ldev/nino/squareglass/PageCoordinator$Page;->header()V

    .line 281
    :cond_8
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    if-eqz v0, :cond_9

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v0

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    if-eq v0, v2, :cond_9

    .line 282
    invoke-virtual {v2}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v0

    iget-boolean p0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-static {p0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result p0

    invoke-virtual {v0, p0}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_9
    return v1
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 1

    .line 303
    iget-boolean p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->watching:Z

    if-nez p1, :cond_4

    .line 304
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p1

    .line 305
    iget-boolean v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    if-eq p1, v0, :cond_0

    const/4 v0, 0x0

    iput v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->materials:Ljava/util/WeakHashMap;

    invoke-virtual {v0}, Ljava/util/WeakHashMap;->clear()V

    .line 306
    :cond_0
    iput-boolean p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    .line 307
    iget v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    if-nez v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    if-nez v0, :cond_1

    invoke-static {p1}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result p1

    goto :goto_0

    :cond_1
    invoke-virtual {v0, p1}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->surface(Z)I

    move-result p1

    :goto_0
    iput p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    .line 308
    :cond_2
    iget-boolean p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->detail:Z

    if-nez p1, :cond_3

    iget-object p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    iget v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundColor(I)V

    .line 309
    :cond_3
    iget-object p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->watching:Z

    iget-object p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/PageCoordinator$Page;->scan(Landroid/view/View;)V

    .line 310
    invoke-virtual {p0}, Ldev/nino/squareglass/PageCoordinator$Page;->onPreDraw()Z

    :cond_4
    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    .line 314
    iget-boolean p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->watching:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    :cond_0
    const/4 p1, 0x0

    .line 315
    iput-boolean p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->watching:Z

    .line 316
    iget-object p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->lists:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->removeOnChildAttachStateChangeListener(Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;)V

    goto :goto_0

    .line 317
    :cond_1
    iget-object p0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->lists:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method row(Landroid/view/View;)V
    .locals 2

    .line 254
    invoke-static {p1}, Ldev/nino/squareglass/SquareDetails;->track(Landroid/view/View;)V

    .line 255
    const-string v0, "My Tracks"

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Ldev/nino/squareglass/SquareDetails;->collectionTrack(Landroid/view/View;)V

    .line 257
    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->isLongClickable()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Landroid/view/View;->hasOnClickListeners()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {p1}, Ldev/nino/squareglass/SquareGestures;->bind(Landroid/view/View;)V

    .line 258
    :cond_1
    iget-boolean v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->search:Z

    if-eqz v0, :cond_3

    invoke-virtual {p1}, Landroid/view/View;->isClickable()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v0

    const/high16 v1, 0x41e00000    # 28.0f

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result v1

    if-lt v0, v1, :cond_3

    .line 259
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->materials:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_2

    .line 260
    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-eq v1, v0, :cond_3

    .line 261
    :cond_2
    iget v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    const/16 v1, 0x10

    invoke-static {p1, v0, v1}, Ldev/nino/squareglass/PageMaterial;->background(Landroid/view/View;II)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->materials:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 264
    :cond_3
    iget-object p0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    if-eqz p0, :cond_4

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->collect(Landroid/view/View;)V

    :cond_4
    return-void
.end method

.method scan(Landroid/view/View;)V
    .locals 4

    .line 117
    instance-of v0, p1, Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    .line 118
    move-object v0, p1

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 119
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "ViewPager2"

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_1

    .line 120
    :cond_0
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->lists:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    .line 121
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->lists:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->addOnChildAttachStateChangeListener(Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;)V

    .line 122
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    if-eqz v2, :cond_2

    iget-object v3, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    if-nez v3, :cond_2

    .line 123
    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    .line 124
    const-string v3, "Playlists"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    new-instance v2, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;-><init>(Ldev/nino/squareglass/PageCoordinator$Page;)V

    iput-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    invoke-virtual {p0}, Ldev/nino/squareglass/PageCoordinator$Page;->configureHero()V

    .line 125
    :cond_1
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setClipToPadding(Z)V

    :cond_2
    move v2, v1

    .line 127
    :goto_0
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    if-ge v2, v3, :cond_3

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/PageCoordinator$Page;->onChildViewAttachedToWindow(Landroid/view/View;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 130
    :cond_3
    :goto_1
    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_4

    .line 131
    move-object v0, p1

    check-cast v0, Landroid/view/ViewGroup;

    .line 132
    :goto_2
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    if-ge v1, v2, :cond_4

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v2}, Ldev/nino/squareglass/PageCoordinator$Page;->scan(Landroid/view/View;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 134
    :cond_4
    instance-of v0, p1, Landroidx/appcompat/widget/Toolbar;

    if-eqz v0, :cond_5

    invoke-static {p1}, Ldev/nino/squareglass/SquareDetails;->chrome(Landroid/view/View;)V

    .line 135
    :cond_5
    iget-boolean v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->search:Z

    if-eqz v0, :cond_7

    instance-of v0, p1, Landroid/widget/ImageView;

    if-eqz v0, :cond_7

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    const-string v1, "backIcon"

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/PageCoordinator$Page;->findNamed(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eq p1, v0, :cond_6

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    const-string v1, "searchIcon"

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/PageCoordinator$Page;->findNamed(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-ne p1, v0, :cond_7

    .line 136
    :cond_6
    move-object v0, p1

    check-cast v0, Landroid/widget/ImageView;

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 137
    :cond_7
    instance-of v0, p1, Landroid/widget/TextView;

    if-eqz v0, :cond_9

    .line 138
    move-object v0, p1

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getCurrentTextColor()I

    move-result v1

    const v2, 0xffffff

    and-int v3, v1, v2

    if-eq v3, v2, :cond_8

    if-eqz v3, :cond_8

    const v2, -0xefeff0

    if-ne v1, v2, :cond_9

    .line 139
    :cond_8
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 141
    :cond_9
    iget-boolean v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->search:Z

    if-eqz v0, :cond_a

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/PageCoordinator$Page;->searchMaterial(Landroid/view/View;)V

    :cond_a
    return-void
.end method

.method searchMaterial(Landroid/view/View;)V
    .locals 4

    .line 240
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 241
    instance-of v1, p1, Landroidx/appcompat/widget/SearchView;

    const-string v2, "Chip"

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    instance-of v2, p1, Landroid/widget/Button;

    if-nez v1, :cond_0

    if-nez v0, :cond_0

    if-nez v2, :cond_0

    goto :goto_2

    :cond_0
    if-eqz v1, :cond_1

    .line 243
    invoke-static {p1}, Ldev/nino/squareglass/SquareExplore;->search(Landroid/view/View;)V

    return-void

    .line 244
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->materials:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iget-object v3, p0, Ldev/nino/squareglass/PageCoordinator$Page;->materials:Ljava/util/WeakHashMap;

    invoke-virtual {v3, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-ne v0, v3, :cond_2

    goto :goto_2

    .line 245
    :cond_2
    iget v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->tone:I

    if-eqz v1, :cond_3

    const/16 v3, 0x1c

    goto :goto_0

    :cond_3
    const/16 v3, 0x14

    :goto_0
    invoke-static {p1, v0, v3}, Ldev/nino/squareglass/PageMaterial;->background(Landroid/view/View;II)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 246
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v3, p0, Ldev/nino/squareglass/PageCoordinator$Page;->materials:Ljava/util/WeakHashMap;

    invoke-virtual {v3, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-nez v1, :cond_4

    if-eqz v2, :cond_6

    :cond_4
    if-eqz v1, :cond_5

    const/high16 v0, 0x41e00000    # 28.0f

    goto :goto_1

    :cond_5
    const/high16 v0, 0x41a00000    # 20.0f

    .line 247
    :goto_1
    invoke-static {p1, v0}, Ldev/nino/squareglass/PageGlass;->install(Landroid/view/View;F)V

    .line 248
    :cond_6
    instance-of v0, p1, Landroid/widget/TextView;

    if-eqz v0, :cond_7

    .line 249
    check-cast p1, Landroid/widget/TextView;

    iget-boolean v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 250
    iget-boolean p0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-static {p0}, Ldev/nino/squareglass/SquarePalette;->secondary(Z)I

    move-result p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setHintTextColor(I)V

    :cond_7
    :goto_2
    return-void
.end method

.method topEdge()V
    .locals 3

    .line 229
    iget v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->inset:I

    const/4 v1, 0x0

    if-gez v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object v0

    if-nez v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    invoke-static {}, Landroid/view/WindowInsets$Type;->statusBars()I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/WindowInsets;->getInsets(I)Landroid/graphics/Insets;

    move-result-object v0

    iget v0, v0, Landroid/graphics/Insets;->top:I

    :goto_0
    iput v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->inset:I

    .line 230
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    if-eqz v0, :cond_2

    const-string v2, "Downloads"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 231
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    iget v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->inset:I

    invoke-static {v0, v2}, Ldev/nino/squareglass/PageInsets;->top(Landroid/view/View;I)V

    .line 233
    :cond_2
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->movingAction:Landroid/view/View;

    if-eqz v0, :cond_5

    .line 234
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$LayoutManager;

    move-result-object v0

    if-nez v0, :cond_3

    const/4 v0, 0x0

    goto :goto_1

    :cond_3
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$LayoutManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->findViewByPosition(I)Landroid/view/View;

    move-result-object v0

    :goto_1
    if-nez v0, :cond_4

    .line 235
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->height(Landroidx/recyclerview/widget/RecyclerView;)I

    move-result v0

    neg-int v0, v0

    goto :goto_2

    :cond_4
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v0

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v2}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->height(Landroidx/recyclerview/widget/RecyclerView;)I

    move-result v1

    sub-int/2addr v0, v1

    :goto_2
    int-to-float v0, v0

    .line 236
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->movingAction:Landroid/view/View;

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v2, v2

    add-float/2addr v0, v2

    const/high16 v2, 0x42700000    # 60.0f

    invoke-virtual {p0, v2}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result p0

    int-to-float p0, p0

    add-float/2addr v0, p0

    invoke-virtual {v1, v0}, Landroid/view/View;->setY(F)V

    :cond_5
    return-void
.end method
