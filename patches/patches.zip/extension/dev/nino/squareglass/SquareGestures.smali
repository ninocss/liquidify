.class public final Ldev/nino/squareglass/SquareGestures;
.super Ljava/lang/Object;
.source "SquareGestures.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/SquareGestures$Preview;
    }
.end annotation


# static fields
.field private static final bindings:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ldev/nino/squareglass/SquareGestures;",
            ">;"
        }
    .end annotation
.end field

.field private static requestingAction:I

.field private static requestingActivity:Landroid/app/Activity;


# instance fields
.field private armed:Z

.field private downX:F

.field private downY:F

.field private dragging:Z

.field private preview:Ldev/nino/squareglass/SquareGestures$Preview;

.field private previewAction:I

.field private restingX:F

.field private returning:Landroid/animation/ValueAnimator;

.field private final slop:I

.field private surface:Landroid/view/ViewGroup;

.field private vertical:Z


# direct methods
.method public static synthetic $r8$lambda$hLGAnOrDFGFNXKGG9buX5i20YoE(Ldev/nino/squareglass/SquareGestures;Landroid/view/View;Landroid/animation/ValueAnimator;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/SquareGestures;->lambda$reset$0(Landroid/view/View;Landroid/animation/ValueAnimator;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fputreturning(Ldev/nino/squareglass/SquareGestures;Landroid/animation/ValueAnimator;)V
    .locals 0

    iput-object p1, p0, Ldev/nino/squareglass/SquareGestures;->returning:Landroid/animation/ValueAnimator;

    return-void
.end method

.method static bridge synthetic -$$Nest$mclear(Ldev/nino/squareglass/SquareGestures;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareGestures;->clear(Landroid/view/View;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 25
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareGestures;->bindings:Ljava/util/WeakHashMap;

    return-void
.end method

.method private constructor <init>(Landroid/view/View;)V
    .locals 0

    .line 38
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/SquareGestures;->slop:I

    return-void
.end method

.method private static activity(Landroid/content/Context;)Landroid/app/Activity;
    .locals 1

    .line 45
    :goto_0
    instance-of v0, p0, Landroid/content/ContextWrapper;

    if-eqz v0, :cond_0

    instance-of v0, p0, Landroid/app/Activity;

    if-nez v0, :cond_0

    check-cast p0, Landroid/content/ContextWrapper;

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p0

    goto :goto_0

    .line 46
    :cond_0
    instance-of v0, p0, Landroid/app/Activity;

    if-eqz v0, :cond_1

    check-cast p0, Landroid/app/Activity;

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public static bind(Landroid/view/View;)V
    .locals 2

    .line 40
    sget-object v0, Ldev/nino/squareglass/SquareGestures;->bindings:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    .line 41
    :cond_0
    new-instance v1, Ldev/nino/squareglass/SquareGestures;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SquareGestures;-><init>(Landroid/view/View;)V

    invoke-virtual {v0, p0, v1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    invoke-virtual {p0, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    invoke-virtual {p0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method

.method private clear(Landroid/view/View;)V
    .locals 1

    .line 116
    iget v0, p0, Ldev/nino/squareglass/SquareGestures;->restingX:F

    invoke-virtual {p1, v0}, Landroid/view/View;->setTranslationX(F)V

    .line 117
    iget-object p1, p0, Ldev/nino/squareglass/SquareGestures;->surface:Landroid/view/ViewGroup;

    if-eqz p1, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/SquareGestures;->preview:Ldev/nino/squareglass/SquareGestures$Preview;

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getOverlay()Landroid/view/ViewGroupOverlay;

    move-result-object p1

    iget-object v0, p0, Ldev/nino/squareglass/SquareGestures;->preview:Ldev/nino/squareglass/SquareGestures$Preview;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroupOverlay;->remove(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 p1, 0x0

    .line 118
    iput-object p1, p0, Ldev/nino/squareglass/SquareGestures;->preview:Ldev/nino/squareglass/SquareGestures$Preview;

    iput-object p1, p0, Ldev/nino/squareglass/SquareGestures;->surface:Landroid/view/ViewGroup;

    return-void
.end method

.method public static label(I)Ljava/lang/String;
    .locals 1

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    .line 51
    const-string p0, "Play next"

    return-object p0

    :cond_0
    const/4 v0, 0x2

    if-ne p0, v0, :cond_1

    const-string p0, "Add to queue"

    return-object p0

    :cond_1
    const/4 v0, 0x3

    if-ne p0, v0, :cond_2

    const-string p0, "Favorite"

    return-object p0

    :cond_2
    const-string p0, ""

    return-object p0
.end method

.method private synthetic lambda$reset$0(Landroid/view/View;Landroid/animation/ValueAnimator;)V
    .locals 1

    .line 128
    invoke-virtual {p2}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Float;

    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    move-result p2

    invoke-virtual {p1, p2}, Landroid/view/View;->setTranslationX(F)V

    .line 129
    iget-object p2, p0, Ldev/nino/squareglass/SquareGestures;->preview:Ldev/nino/squareglass/SquareGestures$Preview;

    if-eqz p2, :cond_0

    iget v0, p2, Ldev/nino/squareglass/SquareGestures$Preview;->action:I

    iget-object p0, p0, Ldev/nino/squareglass/SquareGestures;->preview:Ldev/nino/squareglass/SquareGestures$Preview;

    iget p0, p0, Ldev/nino/squareglass/SquareGestures$Preview;->progress:F

    invoke-virtual {p2, p1, v0, p0}, Ldev/nino/squareglass/SquareGestures$Preview;->update(Landroid/view/View;IF)V

    :cond_0
    return-void
.end method

.method private static openNativeActions(Landroid/view/View;)Z
    .locals 2

    .line 109
    invoke-virtual {p0}, Landroid/view/View;->performLongClick()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    const v0, 0x7f0b04de

    .line 110
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_1

    .line 111
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_1

    .line 112
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->hasOnClickListeners()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->performClick()Z

    move-result p0

    if-eqz p0, :cond_1

    return v1

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public static request(Landroid/app/Activity;)I
    .locals 1

    .line 49
    sget-object v0, Ldev/nino/squareglass/SquareGestures;->requestingActivity:Landroid/app/Activity;

    if-ne p0, v0, :cond_0

    sget p0, Ldev/nino/squareglass/SquareGestures;->requestingAction:I

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private reset(Landroid/view/View;Z)V
    .locals 4

    .line 121
    iget-object v0, p0, Ldev/nino/squareglass/SquareGestures;->returning:Landroid/animation/ValueAnimator;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    const/4 v0, 0x0

    iput-object v0, p0, Ldev/nino/squareglass/SquareGestures;->returning:Landroid/animation/ValueAnimator;

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareGestures;->clear(Landroid/view/View;)V

    .line 122
    :cond_0
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareGestures;->dragging:Z

    const/4 v1, 0x0

    .line 123
    iput-boolean v1, p0, Ldev/nino/squareglass/SquareGestures;->dragging:Z

    iput-boolean v1, p0, Ldev/nino/squareglass/SquareGestures;->armed:Z

    iput v1, p0, Ldev/nino/squareglass/SquareGestures;->previewAction:I

    if-eqz v0, :cond_1

    if-eqz p2, :cond_1

    .line 124
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p2

    if-eqz p2, :cond_1

    .line 125
    invoke-virtual {p1}, Landroid/view/View;->getTranslationX()F

    move-result p2

    iget v0, p0, Ldev/nino/squareglass/SquareGestures;->restingX:F

    const/4 v2, 0x2

    new-array v2, v2, [F

    aput p2, v2, v1

    const/4 p2, 0x1

    aput v0, v2, p2

    invoke-static {v2}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object p2

    iput-object p2, p0, Ldev/nino/squareglass/SquareGestures;->returning:Landroid/animation/ValueAnimator;

    const-wide/16 v2, 0xc8

    .line 126
    invoke-virtual {p2, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object p2, p0, Ldev/nino/squareglass/SquareGestures;->returning:Landroid/animation/ValueAnimator;

    new-instance v0, Landroid/view/animation/DecelerateInterpolator;

    const/high16 v2, 0x3fc00000    # 1.5f

    invoke-direct {v0, v2}, Landroid/view/animation/DecelerateInterpolator;-><init>(F)V

    invoke-virtual {p2, v0}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 127
    iget-object p2, p0, Ldev/nino/squareglass/SquareGestures;->returning:Landroid/animation/ValueAnimator;

    new-instance v0, Ldev/nino/squareglass/SquareGestures$0;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/SquareGestures$0;-><init>(Ldev/nino/squareglass/SquareGestures;Landroid/view/View;)V

    invoke-virtual {p2, v0}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 131
    iget-object p2, p0, Ldev/nino/squareglass/SquareGestures;->returning:Landroid/animation/ValueAnimator;

    new-instance v0, Ldev/nino/squareglass/SquareGestures$1;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/SquareGestures$1;-><init>(Ldev/nino/squareglass/SquareGestures;Landroid/view/View;)V

    invoke-virtual {p2, v0}, Landroid/animation/ValueAnimator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 133
    iget-object p0, p0, Ldev/nino/squareglass/SquareGestures;->returning:Landroid/animation/ValueAnimator;

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->start()V

    goto :goto_0

    :cond_1
    if-eqz v0, :cond_2

    .line 134
    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareGestures;->clear(Landroid/view/View;)V

    .line 135
    :cond_2
    :goto_0
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    if-eqz p0, :cond_3

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    invoke-interface {p0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_3
    return-void
.end method

.method private threshold(Landroid/view/View;)F
    .locals 1

    .line 114
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    const/high16 v0, 0x42900000    # 72.0f

    mul-float/2addr p0, v0

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    int-to-float p1, p1

    const v0, 0x3e851eb8    # 0.26f

    mul-float/2addr p1, v0

    invoke-static {p0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p0

    return p0
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 10

    .line 54
    invoke-virtual {p1}, Landroid/view/View;->isEnabled()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1a

    invoke-virtual {p1}, Landroid/view/View;->isLongClickable()Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-virtual {p1}, Landroid/view/View;->hasOnClickListeners()Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_7

    .line 55
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_19

    const-string v3, "swipeRight"

    const-string v4, "swipeLeft"

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eq v0, v2, :cond_12

    if-eq v0, v7, :cond_3

    if-eq v0, v6, :cond_2

    .line 104
    iget-boolean p2, p0, Ldev/nino/squareglass/SquareGestures;->dragging:Z

    const/4 v3, 0x5

    if-eq v0, v3, :cond_1

    return p2

    :cond_1
    invoke-direct {p0, p1, v1}, Ldev/nino/squareglass/SquareGestures;->reset(Landroid/view/View;Z)V

    iput-boolean v2, p0, Ldev/nino/squareglass/SquareGestures;->vertical:Z

    return p2

    .line 102
    :cond_2
    iget-boolean p2, p0, Ldev/nino/squareglass/SquareGestures;->dragging:Z

    invoke-direct {p0, p1, v2}, Ldev/nino/squareglass/SquareGestures;->reset(Landroid/view/View;Z)V

    return p2

    .line 60
    :cond_3
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iget v8, p0, Ldev/nino/squareglass/SquareGestures;->downX:F

    sub-float/2addr v0, v8

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p2

    iget v8, p0, Ldev/nino/squareglass/SquareGestures;->downY:F

    sub-float/2addr p2, v8

    .line 61
    iget-boolean v8, p0, Ldev/nino/squareglass/SquareGestures;->dragging:Z

    if-nez v8, :cond_4

    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    move-result v8

    iget v9, p0, Ldev/nino/squareglass/SquareGestures;->slop:I

    int-to-float v9, v9

    cmpl-float v8, v8, v9

    if-lez v8, :cond_4

    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    move-result p2

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v8

    cmpl-float p2, p2, v8

    if-ltz p2, :cond_4

    iput-boolean v2, p0, Ldev/nino/squareglass/SquareGestures;->vertical:Z

    .line 62
    :cond_4
    iget-boolean p2, p0, Ldev/nino/squareglass/SquareGestures;->vertical:Z

    if-nez p2, :cond_11

    iget-boolean p2, p0, Ldev/nino/squareglass/SquareGestures;->dragging:Z

    if-nez p2, :cond_5

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result p2

    iget v8, p0, Ldev/nino/squareglass/SquareGestures;->slop:I

    mul-int/2addr v8, v7

    int-to-float v8, v8

    cmpg-float p2, p2, v8

    if-gtz p2, :cond_5

    goto/16 :goto_2

    :cond_5
    cmpl-float p2, v0, v5

    if-lez p2, :cond_6

    goto :goto_0

    :cond_6
    move-object v3, v4

    :goto_0
    if-lez p2, :cond_7

    move v7, v2

    .line 63
    :cond_7
    invoke-static {v3, v7, v1, v6}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result p2

    .line 68
    iget-boolean v3, p0, Ldev/nino/squareglass/SquareGestures;->dragging:Z

    if-nez p2, :cond_9

    if-eqz v3, :cond_8

    .line 65
    invoke-direct {p0, p1, v2}, Ldev/nino/squareglass/SquareGestures;->reset(Landroid/view/View;Z)V

    iput-boolean v2, p0, Ldev/nino/squareglass/SquareGestures;->vertical:Z

    return v2

    :cond_8
    return v1

    :cond_9
    if-nez v3, :cond_b

    .line 69
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    instance-of v3, v3, Landroid/view/ViewGroup;

    if-nez v3, :cond_a

    return v1

    .line 70
    :cond_a
    iput-boolean v2, p0, Ldev/nino/squareglass/SquareGestures;->dragging:Z

    invoke-virtual {p1}, Landroid/view/View;->cancelLongPress()V

    invoke-virtual {p1, v1}, Landroid/view/View;->setPressed(Z)V

    .line 71
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    check-cast v3, Landroid/view/ViewGroup;

    iput-object v3, p0, Ldev/nino/squareglass/SquareGestures;->surface:Landroid/view/ViewGroup;

    new-instance v3, Ldev/nino/squareglass/SquareGestures$Preview;

    invoke-direct {v3, p1}, Ldev/nino/squareglass/SquareGestures$Preview;-><init>(Landroid/view/View;)V

    iput-object v3, p0, Ldev/nino/squareglass/SquareGestures;->preview:Ldev/nino/squareglass/SquareGestures$Preview;

    .line 72
    iget-object v3, p0, Ldev/nino/squareglass/SquareGestures;->surface:Landroid/view/ViewGroup;

    invoke-virtual {v3}, Landroid/view/ViewGroup;->getOverlay()Landroid/view/ViewGroupOverlay;

    move-result-object v3

    iget-object v4, p0, Ldev/nino/squareglass/SquareGestures;->preview:Ldev/nino/squareglass/SquareGestures$Preview;

    invoke-virtual {v3, v4}, Landroid/view/ViewGroupOverlay;->add(Landroid/graphics/drawable/Drawable;)V

    .line 74
    :cond_b
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    if-eqz v3, :cond_c

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    invoke-interface {v3, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 75
    :cond_c
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v3

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareGestures;->threshold(Landroid/view/View;)F

    move-result v4

    div-float/2addr v3, v4

    const/high16 v4, 0x3f800000    # 1.0f

    invoke-static {v4, v3}, Ljava/lang/Math;->min(FF)F

    move-result v3

    cmpl-float v4, v3, v4

    if-ltz v4, :cond_d

    move v1, v2

    :cond_d
    if-eqz v1, :cond_f

    .line 77
    iget-boolean v4, p0, Ldev/nino/squareglass/SquareGestures;->armed:Z

    if-eqz v4, :cond_e

    iget v4, p0, Ldev/nino/squareglass/SquareGestures;->previewAction:I

    if-eq p2, v4, :cond_f

    :cond_e
    const/16 v4, 0xc

    invoke-virtual {p1, v4}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 78
    :cond_f
    iput-boolean v1, p0, Ldev/nino/squareglass/SquareGestures;->armed:Z

    iput p2, p0, Ldev/nino/squareglass/SquareGestures;->previewAction:I

    .line 79
    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareGestures;->threshold(Landroid/view/View;)F

    move-result v1

    .line 80
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpg-float v4, v4, v1

    if-gtz v4, :cond_10

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v1

    goto :goto_1

    :cond_10
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v4

    sub-float/2addr v4, v1

    const v5, 0x3ea3d70a    # 0.32f

    mul-float/2addr v4, v5

    add-float/2addr v1, v4

    .line 81
    :goto_1
    iget v4, p0, Ldev/nino/squareglass/SquareGestures;->restingX:F

    invoke-static {v0}, Ljava/lang/Math;->signum(F)F

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v5

    int-to-float v5, v5

    const v6, 0x3ee66666    # 0.45f

    mul-float/2addr v5, v6

    invoke-static {v1, v5}, Ljava/lang/Math;->min(FF)F

    move-result v1

    mul-float/2addr v0, v1

    add-float/2addr v4, v0

    invoke-virtual {p1, v4}, Landroid/view/View;->setTranslationX(F)V

    .line 82
    iget-object p0, p0, Ldev/nino/squareglass/SquareGestures;->preview:Ldev/nino/squareglass/SquareGestures$Preview;

    invoke-virtual {p0, p1, p2, v3}, Ldev/nino/squareglass/SquareGestures$Preview;->update(Landroid/view/View;IF)V

    return v2

    :cond_11
    :goto_2
    return v1

    .line 85
    :cond_12
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareGestures;->dragging:Z

    if-nez v0, :cond_13

    return v1

    .line 86
    :cond_13
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result p2

    iget v0, p0, Ldev/nino/squareglass/SquareGestures;->downX:F

    sub-float/2addr p2, v0

    .line 87
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    move-result v0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareGestures;->threshold(Landroid/view/View;)F

    move-result v8

    cmpl-float v0, v0, v8

    if-ltz v0, :cond_14

    move v0, v2

    goto :goto_3

    :cond_14
    move v0, v1

    :goto_3
    cmpl-float p2, p2, v5

    if-lez p2, :cond_15

    goto :goto_4

    :cond_15
    move-object v3, v4

    :goto_4
    if-lez p2, :cond_16

    move v7, v2

    .line 88
    :cond_16
    invoke-static {v3, v7, v1, v6}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result p2

    .line 89
    invoke-direct {p0, p1, v2}, Ldev/nino/squareglass/SquareGestures;->reset(Landroid/view/View;Z)V

    if-eqz v0, :cond_18

    if-eqz p2, :cond_18

    .line 91
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->gestureCommits:I

    add-int/2addr p0, v2

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->gestureCommits:I

    .line 92
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/SquareGestures;->activity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    sput-object p0, Ldev/nino/squareglass/SquareGestures;->requestingActivity:Landroid/app/Activity;

    sput p2, Ldev/nino/squareglass/SquareGestures;->requestingAction:I

    const/4 p0, 0x0

    .line 96
    :try_start_0
    invoke-static {p1}, Ldev/nino/squareglass/SquareGestures;->openNativeActions(Landroid/view/View;)Z

    move-result p2

    if-eqz p2, :cond_17

    sget p1, Ldev/nino/squareglass/ProbeDiagnostics;->gestureRequests:I

    add-int/2addr p1, v2

    sput p1, Ldev/nino/squareglass/ProbeDiagnostics;->gestureRequests:I

    goto :goto_5

    .line 97
    :cond_17
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const-string p2, "Unavailable for this track"

    invoke-static {p1, p2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 98
    :goto_5
    sput-object p0, Ldev/nino/squareglass/SquareGestures;->requestingActivity:Landroid/app/Activity;

    sput v1, Ldev/nino/squareglass/SquareGestures;->requestingAction:I

    goto :goto_6

    :catchall_0
    move-exception p1

    sput-object p0, Ldev/nino/squareglass/SquareGestures;->requestingActivity:Landroid/app/Activity;

    sput v1, Ldev/nino/squareglass/SquareGestures;->requestingAction:I

    throw p1

    :cond_18
    :goto_6
    return v2

    .line 57
    :cond_19
    sget v0, Ldev/nino/squareglass/ProbeDiagnostics;->gestureStarts:I

    add-int/2addr v0, v2

    sput v0, Ldev/nino/squareglass/ProbeDiagnostics;->gestureStarts:I

    .line 58
    invoke-direct {p0, p1, v1}, Ldev/nino/squareglass/SquareGestures;->reset(Landroid/view/View;Z)V

    invoke-virtual {p1}, Landroid/view/View;->getTranslationX()F

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/SquareGestures;->restingX:F

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/SquareGestures;->downX:F

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/SquareGestures;->downY:F

    iput-boolean v1, p0, Ldev/nino/squareglass/SquareGestures;->vertical:Z

    :cond_1a
    :goto_7
    return v1
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    const/4 v0, 0x0

    .line 138
    invoke-direct {p0, p1, v0}, Ldev/nino/squareglass/SquareGestures;->reset(Landroid/view/View;Z)V

    return-void
.end method
