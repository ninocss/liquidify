.class final Ldev/nino/squareglass/LinnQueueTransaction$Track;
.super Ljava/lang/Object;
.source "LinnQueueTransaction.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/LinnQueueTransaction;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Track"
.end annotation


# instance fields
.field final key:Ljava/lang/String;

.field final metadata:Ljava/lang/String;

.field final uri:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnQueueTransaction$Track;->key:Ljava/lang/String;

    iput-object p2, p0, Ldev/nino/squareglass/LinnQueueTransaction$Track;->uri:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/LinnQueueTransaction$Track;->metadata:Ljava/lang/String;

    return-void
.end method
