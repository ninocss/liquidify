.class final Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;
.super Landroid/view/View;
.source "SquareOutput.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareOutput$Session;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "OutputGlyph"
.end annotation


# instance fields
.field final paint:Landroid/graphics/Paint;

.field final phone:Z

.field final synthetic this$0:Ldev/nino/squareglass/SquareOutput$Session;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/SquareOutput$Session;Z)V
    .locals 1
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 185
    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->this$0:Ldev/nino/squareglass/SquareOutput$Session;

    iget-object p1, p1, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 184
    new-instance p1, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    .line 185
    iput-boolean p2, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->phone:Z

    const/4 p1, 0x2

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->setImportantForAccessibility(I)V

    return-void
.end method


# virtual methods
.method line(Landroid/graphics/Canvas;FFFF)V
    .locals 1

    .line 186
    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    move v0, p5

    move-object p5, p0

    move-object p0, p1

    move p1, p2

    move p2, p3

    move p3, p4

    move p4, v0

    invoke-virtual/range {p0 .. p5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 10

    .line 188
    invoke-super/range {p0 .. p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 189
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    .line 190
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->getWidth()I

    move-result v3

    int-to-float v3, v3

    const/high16 v4, 0x42000000    # 32.0f

    mul-float/2addr v4, v2

    sub-float/2addr v3, v4

    const/high16 v4, 0x40000000    # 2.0f

    div-float/2addr v3, v4

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->getHeight()I

    move-result v5

    int-to-float v5, v5

    const/high16 v6, 0x42200000    # 40.0f

    mul-float/2addr v6, v2

    sub-float/2addr v5, v6

    div-float/2addr v5, v4

    invoke-virtual {p1, v3, v5}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p1, v2, v2}, Landroid/graphics/Canvas;->scale(FF)V

    .line 191
    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v3

    invoke-static {v3}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 192
    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    const v3, 0x3fe66666    # 1.8f

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 193
    iget-boolean v2, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->phone:Z

    .line 198
    iget-object v7, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    const v9, 0x3f4ccccd    # 0.8f

    if-eqz v2, :cond_0

    const/high16 v6, 0x40600000    # 3.5f

    move-object v8, v7

    const/high16 v7, 0x40600000    # 3.5f

    const/high16 v2, 0x41000000    # 8.0f

    const/high16 v3, 0x40800000    # 4.0f

    const/high16 v4, 0x41c00000    # 24.0f

    const/high16 v5, 0x42100000    # 36.0f

    move-object v1, p1

    .line 194
    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    const/high16 v4, 0x41980000    # 19.0f

    const/high16 v5, 0x41000000    # 8.0f

    const/high16 v2, 0x41500000    # 13.0f

    const/high16 v3, 0x41000000    # 8.0f

    move-object v0, p0

    .line 195
    invoke-virtual/range {v0 .. v5}, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->line(Landroid/graphics/Canvas;FFFF)V

    const/high16 v0, 0x41fc0000    # 31.5f

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    const/high16 v3, 0x41800000    # 16.0f

    invoke-virtual {p1, v3, v0, v9, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    goto :goto_0

    :cond_0
    const/high16 v5, 0x40400000    # 3.0f

    const/high16 v6, 0x40400000    # 3.0f

    const/high16 v1, 0x40000000    # 2.0f

    const/high16 v2, 0x41100000    # 9.0f

    const/high16 v3, 0x41f00000    # 30.0f

    const/high16 v4, 0x41f80000    # 31.0f

    move-object v0, p1

    .line 198
    invoke-virtual/range {v0 .. v7}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    const/high16 v6, 0x3f800000    # 1.0f

    .line 199
    iget-object v7, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    const/high16 v1, 0x40c00000    # 6.0f

    const/high16 v2, 0x41500000    # 13.0f

    const/high16 v3, 0x41880000    # 17.0f

    const/high16 v4, 0x41980000    # 19.0f

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-virtual/range {v0 .. v7}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    const/high16 v4, 0x41500000    # 13.0f

    const/high16 v5, 0x41c00000    # 24.0f

    const/high16 v2, 0x40e00000    # 7.0f

    const/high16 v3, 0x41c00000    # 24.0f

    move-object v0, p0

    move-object v1, p1

    .line 200
    invoke-virtual/range {v0 .. v5}, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->line(Landroid/graphics/Canvas;FFFF)V

    const/high16 v5, 0x41d80000    # 27.0f

    const/high16 v3, 0x41d80000    # 27.0f

    invoke-virtual/range {v0 .. v5}, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->line(Landroid/graphics/Canvas;FFFF)V

    const v2, 0x40466666    # 3.1f

    .line 201
    iget-object v3, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    const/high16 v4, 0x41b00000    # 22.0f

    const/high16 v5, 0x41a00000    # 20.0f

    invoke-virtual {p1, v4, v5, v2, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v5, v9, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/high16 v2, 0x41700000    # 15.0f

    .line 202
    iget-object v3, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    const/high16 v4, 0x41d80000    # 27.0f

    const v5, 0x3f333333    # 0.7f

    invoke-virtual {p1, v4, v2, v5, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/high16 v2, 0x41c80000    # 25.0f

    iget-object v3, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v2, v5, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 204
    :goto_0
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session$OutputGlyph;->paint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method
