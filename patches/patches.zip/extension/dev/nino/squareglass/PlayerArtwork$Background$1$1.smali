.class final Ldev/nino/squareglass/PlayerArtwork$Background$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "PlayerArtwork.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/PlayerArtwork;->Background(JILjava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $albumId:I

.field final synthetic $context:Landroid/content/Context;

.field final synthetic $coverId:Ljava/lang/String;

.field final synthetic $loader:Lcom/tidal/android/image/coil/base/CoilImageLoader;

.field final synthetic $sampled$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;ILcom/tidal/android/image/coil/base/CoilImageLoader;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Landroid/content/Context;",
            "I",
            "Lcom/tidal/android/image/coil/base/CoilImageLoader;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/PlayerArtwork$Background$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$coverId:Ljava/lang/String;

    iput-object p2, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$context:Landroid/content/Context;

    iput p3, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$albumId:I

    iput-object p4, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$loader:Lcom/tidal/android/image/coil/base/CoilImageLoader;

    iput-object p5, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$sampled$delegate:Landroidx/compose/runtime/MutableState;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;

    iget-object v1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$coverId:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$context:Landroid/content/Context;

    iget v3, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$albumId:I

    iget-object v4, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$loader:Lcom/tidal/android/image/coil/base/CoilImageLoader;

    iget-object v5, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$sampled$delegate:Landroidx/compose/runtime/MutableState;

    move-object v6, p2

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;-><init>(Ljava/lang/String;Landroid/content/Context;ILcom/tidal/android/image/coil/base/CoilImageLoader;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 144
    iget v1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->label:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_2

    if-eq v1, v3, :cond_1

    if-ne v1, v2, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->L$2:Ljava/lang/Object;

    check-cast v0, Landroidx/compose/runtime/MutableState;

    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->L$0:Ljava/lang/Object;

    check-cast p0, Lxd0/g$a;

    :try_start_0
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_2

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    iget-object v1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->L$0:Ljava/lang/Object;

    check-cast v1, Lxd0/g$a;

    :try_start_1
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :cond_2
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 145
    iget-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$coverId:Ljava/lang/String;

    check-cast p1, Ljava/lang/CharSequence;

    if-eqz p1, :cond_6

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p1

    if-nez p1, :cond_3

    goto :goto_3

    .line 146
    :cond_3
    :try_start_2
    new-instance v1, Lxd0/g$a;

    iget-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$context:Landroid/content/Context;

    invoke-direct {v1, p1}, Lxd0/g$a;-><init>(Landroid/content/Context;)V

    .line 147
    iget p1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$albumId:I

    iget-object v4, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$coverId:Ljava/lang/String;

    invoke-virtual {v1, p1, v4}, Lxd0/g$a;->a(ILjava/lang/String;)V

    .line 148
    iget-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$loader:Lcom/tidal/android/image/coil/base/CoilImageLoader;

    invoke-virtual {v1}, Lxd0/g$a;->c()Lxd0/g;

    move-result-object v4

    move-object v5, p0

    check-cast v5, Lkotlin/coroutines/e;

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    iput-object v6, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->L$0:Ljava/lang/Object;

    iput v3, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->label:I

    invoke-virtual {p1, v4, v5}, Lcom/tidal/android/image/coil/base/CoilImageLoader;->a(Lxd0/g;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_4

    goto :goto_1

    .line 149
    :cond_4
    :goto_0
    instance-of v3, p1, Lcom/tidal/android/image/core/a$b;

    if-eqz v3, :cond_6

    .line 150
    iget-object v3, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->$sampled$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {}, Lkotlinx/coroutines/Dispatchers;->getDefault()Lkotlinx/coroutines/CoroutineDispatcher;

    move-result-object v4

    check-cast v4, Lkotlin/coroutines/h;

    new-instance v5, Ldev/nino/squareglass/PlayerArtwork$Background$1$1$1;

    const/4 v6, 0x0

    invoke-direct {v5, p1, v6}, Ldev/nino/squareglass/PlayerArtwork$Background$1$1$1;-><init>(Ljava/lang/Object;Lkotlin/coroutines/e;)V

    check-cast v5, Lam0/p;

    move-object v6, p0

    check-cast v6, Lkotlin/coroutines/e;

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->L$0:Ljava/lang/Object;

    invoke-static {p1}, Ldev/nino/squareglass/HostCompat;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->L$1:Ljava/lang/Object;

    iput-object v3, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->L$2:Ljava/lang/Object;

    iput v2, p0, Ldev/nino/squareglass/PlayerArtwork$Background$1$1;->label:I

    invoke-static {v4, v5, v6}, Lkotlinx/coroutines/BuildersKt;->withContext(Lkotlin/coroutines/h;Lam0/p;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_5

    :goto_1
    return-object v0

    :cond_5
    move-object v0, v3

    :goto_2
    check-cast p1, Ljava/lang/Integer;

    invoke-static {v0, p1}, Ldev/nino/squareglass/PlayerArtwork;->access$Background$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/Integer;)V
    :try_end_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_3

    .line 153
    :catch_0
    const-string p0, "SquareGlass"

    const-string p1, "Cover palette unavailable"

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_3

    :catch_1
    move-exception p0

    .line 152
    throw p0

    .line 154
    :cond_6
    :goto_3
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
