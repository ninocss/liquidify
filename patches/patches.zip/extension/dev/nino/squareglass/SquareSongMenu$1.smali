.class Ldev/nino/squareglass/SquareSongMenu$1;
.super Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;
.source "SquareSongMenu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareSongMenu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/SquareSongMenu;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/SquareSongMenu;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 34
    iput-object p1, p0, Ldev/nino/squareglass/SquareSongMenu$1;->this$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;-><init>()V

    return-void
.end method


# virtual methods
.method public onChanged()V
    .locals 0

    .line 35
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu$1;->this$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-static {p0}, Ldev/nino/squareglass/SquareSongMenu;->-$$Nest$mschedule(Ldev/nino/squareglass/SquareSongMenu;)V

    return-void
.end method

.method public onItemRangeChanged(II)V
    .locals 0

    .line 38
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu$1;->this$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-static {p0}, Ldev/nino/squareglass/SquareSongMenu;->-$$Nest$mschedule(Ldev/nino/squareglass/SquareSongMenu;)V

    return-void
.end method

.method public onItemRangeInserted(II)V
    .locals 0

    .line 36
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu$1;->this$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-static {p0}, Ldev/nino/squareglass/SquareSongMenu;->-$$Nest$mschedule(Ldev/nino/squareglass/SquareSongMenu;)V

    return-void
.end method

.method public onItemRangeMoved(III)V
    .locals 0

    .line 39
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu$1;->this$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-static {p0}, Ldev/nino/squareglass/SquareSongMenu;->-$$Nest$mschedule(Ldev/nino/squareglass/SquareSongMenu;)V

    return-void
.end method

.method public onItemRangeRemoved(II)V
    .locals 0

    .line 37
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu$1;->this$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-static {p0}, Ldev/nino/squareglass/SquareSongMenu;->-$$Nest$mschedule(Ldev/nino/squareglass/SquareSongMenu;)V

    return-void
.end method
