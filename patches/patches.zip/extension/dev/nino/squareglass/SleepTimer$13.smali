.class public final synthetic Ldev/nino/squareglass/SleepTimer$13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/content/Context;

.field public final synthetic f$1:I

.field public final synthetic f$2:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;ILjava/lang/Runnable;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$13;->f$0:Landroid/content/Context;

    iput p2, p0, Ldev/nino/squareglass/SleepTimer$13;->f$1:I

    iput-object p3, p0, Ldev/nino/squareglass/SleepTimer$13;->f$2:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SleepTimer$13;->f$0:Landroid/content/Context;

    iget v1, p0, Ldev/nino/squareglass/SleepTimer$13;->f$1:I

    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$13;->f$2:Ljava/lang/Runnable;

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/SleepTimer;->lambda$content$1(Landroid/content/Context;ILjava/lang/Runnable;)V

    return-void
.end method
