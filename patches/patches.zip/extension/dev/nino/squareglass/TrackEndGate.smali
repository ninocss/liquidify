.class public final Ldev/nino/squareglass/TrackEndGate;
.super Ljava/lang/Object;
.source "TrackEndGate.java"


# instance fields
.field private active:Z

.field private id:I

.field private previous:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public active()Z
    .locals 0

    .line 8
    iget-boolean p0, p0, Ldev/nino/squareglass/TrackEndGate;->active:Z

    return p0
.end method

.method public cancel()V
    .locals 1

    const/4 v0, 0x0

    .line 7
    iput-boolean v0, p0, Ldev/nino/squareglass/TrackEndGate;->active:Z

    return-void
.end method

.method public consume(III)Z
    .locals 3

    .line 10
    iget-boolean v0, p0, Ldev/nino/squareglass/TrackEndGate;->active:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 11
    :cond_0
    iget v0, p0, Ldev/nino/squareglass/TrackEndGate;->id:I

    const/4 v2, 0x1

    if-ne p1, v0, :cond_3

    if-lez p3, :cond_1

    if-ge p2, p3, :cond_3

    :cond_1
    if-lez p3, :cond_2

    iget p1, p0, Ldev/nino/squareglass/TrackEndGate;->previous:I

    add-int/lit16 p3, p3, -0x1f4

    if-lt p1, p3, :cond_2

    add-int/lit16 p1, p1, -0x1f4

    if-ge p2, p1, :cond_2

    goto :goto_0

    :cond_2
    move p1, v1

    goto :goto_1

    :cond_3
    :goto_0
    move p1, v2

    .line 13
    :goto_1
    iput p2, p0, Ldev/nino/squareglass/TrackEndGate;->previous:I

    if-eqz p1, :cond_4

    .line 14
    iput-boolean v1, p0, Ldev/nino/squareglass/TrackEndGate;->active:Z

    return v2

    :cond_4
    return v1
.end method

.method public start(II)V
    .locals 0

    .line 6
    iput p1, p0, Ldev/nino/squareglass/TrackEndGate;->id:I

    iput p2, p0, Ldev/nino/squareglass/TrackEndGate;->previous:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Ldev/nino/squareglass/TrackEndGate;->active:Z

    return-void
.end method
