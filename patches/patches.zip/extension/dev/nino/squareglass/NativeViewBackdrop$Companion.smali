.class final Ldev/nino/squareglass/NativeViewBackdrop$Companion;
.super Ljava/lang/Object;
.source "NativeViewBackdrop.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/NativeViewBackdrop;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u0082\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003R\u0017\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008\u00a8\u0006\t"
    }
    d2 = {
        "Ldev/nino/squareglass/NativeViewBackdrop$Companion;",
        "",
        "<init>",
        "()V",
        "fragmentTransitionFields",
        "",
        "Ljava/lang/reflect/Field;",
        "getFragmentTransitionFields",
        "()Ljava/util/List;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 106
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/NativeViewBackdrop$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final getFragmentTransitionFields()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/reflect/Field;",
            ">;"
        }
    .end annotation

    .line 109
    invoke-static {}, Ldev/nino/squareglass/NativeViewBackdrop;->access$getFragmentTransitionFields$cp()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method
