.class Ldev/nino/squareglass/SleepTimer$1;
.super Ljava/lang/Object;
.source "SleepTimer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/SleepTimer;->endOfTrack(Landroid/content/Context;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 67
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    .line 68
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgettrackEnd()Ldev/nino/squareglass/TrackEndGate;

    move-result-object v0

    invoke-virtual {v0}, Ldev/nino/squareglass/TrackEndGate;->active()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgetplayer()Lbi/e;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_2

    :cond_0
    const-wide/16 v0, 0xfa

    .line 70
    :try_start_0
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgetplayer()Lbi/e;

    move-result-object v2

    invoke-interface {v2}, Lbi/e;->getCurrentItem()Lcom/aspiro/wamp/playqueue/u0;

    move-result-object v2

    if-nez v2, :cond_1

    const/4 v2, -0x1

    goto :goto_0

    :cond_1
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgetplayer()Lbi/e;

    move-result-object v2

    invoke-interface {v2}, Lbi/e;->getCurrentItem()Lcom/aspiro/wamp/playqueue/u0;

    move-result-object v2

    invoke-interface {v2}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v2

    invoke-virtual {v2}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v2

    .line 71
    :goto_0
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgetplayer()Lbi/e;

    move-result-object v3

    invoke-interface {v3}, Lbi/e;->getCurrentMediaPosition()I

    move-result v3

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgetplayer()Lbi/e;

    move-result-object v4

    invoke-interface {v4}, Lbi/e;->getCurrentMediaDuration()I

    move-result v4

    .line 72
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgettrackEnd()Ldev/nino/squareglass/TrackEndGate;

    move-result-object v5

    invoke-virtual {v5, v2, v3, v4}, Ldev/nino/squareglass/TrackEndGate;->consume(III)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$smpause()V

    return-void

    .line 73
    :cond_2
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v2

    if-lez v4, :cond_3

    sub-int/2addr v4, v3

    const/16 v3, 0x3e8

    if-ge v4, v3, :cond_3

    const-wide/16 v3, 0x28

    goto :goto_1

    :cond_3
    move-wide v3, v0

    :goto_1
    invoke-virtual {v2, p0, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 74
    :catch_0
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgettrackEnd()Ldev/nino/squareglass/TrackEndGate;

    move-result-object v2

    invoke-virtual {v2}, Ldev/nino/squareglass/TrackEndGate;->active()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v2

    invoke-virtual {v2, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_4
    :goto_2
    return-void
.end method
