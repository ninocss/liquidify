.class final Ldev/nino/squareglass/NativeIconMotion$State;
.super Ljava/lang/Object;
.source "NativeIconMotion.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/NativeIconMotion;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "State"
.end annotation


# instance fields
.field animator:Landroid/animation/ValueAnimator;

.field kind:I

.field moved:Z

.field progress:F

.field selected:Z

.field tap:J

.field token:Ljava/lang/Object;

.field final view:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field x:F

.field y:F


# direct methods
.method public static synthetic $r8$lambda$AACN_lCz5yuuEjiyK81Srtk9_EQ(Ldev/nino/squareglass/NativeIconMotion$State;Landroid/animation/ValueAnimator;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/NativeIconMotion$State;->lambda$fire$0(Landroid/animation/ValueAnimator;)V

    return-void
.end method

.method constructor <init>(Landroid/view/View;)V
    .locals 2

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 v0, 0x3f800000    # 1.0f

    .line 20
    iput v0, p0, Ldev/nino/squareglass/NativeIconMotion$State;->progress:F

    const-wide/16 v0, -0x4e20

    .line 21
    iput-wide v0, p0, Ldev/nino/squareglass/NativeIconMotion$State;->tap:J

    .line 22
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ldev/nino/squareglass/NativeIconMotion$State;->view:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Landroid/view/View;->isSelected()Z

    move-result p1

    iput-boolean p1, p0, Ldev/nino/squareglass/NativeIconMotion$State;->selected:Z

    return-void
.end method

.method private synthetic lambda$fire$0(Landroid/animation/ValueAnimator;)V
    .locals 0

    .line 27
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/NativeIconMotion$State;->progress:F

    iget-object p0, p0, Ldev/nino/squareglass/NativeIconMotion$State;->view:Ljava/lang/ref/WeakReference;

    invoke-virtual {p0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_0
    return-void
.end method


# virtual methods
.method fire(I)V
    .locals 4

    .line 24
    iget-object v0, p0, Ldev/nino/squareglass/NativeIconMotion$State;->view:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    if-eqz v0, :cond_3

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    .line 25
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/NativeIconMotion$State;->animator:Landroid/animation/ValueAnimator;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_1
    iput p1, p0, Ldev/nino/squareglass/NativeIconMotion$State;->kind:I

    const/4 v0, 0x2

    .line 26
    new-array v1, v0, [F

    fill-array-data v1, :array_0

    invoke-static {v1}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/NativeIconMotion$State;->animator:Landroid/animation/ValueAnimator;

    if-ne p1, v0, :cond_2

    const-wide/16 v2, 0x26c

    goto :goto_0

    :cond_2
    const-wide/16 v2, 0x1cc

    :goto_0
    invoke-virtual {v1, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 27
    iget-object p1, p0, Ldev/nino/squareglass/NativeIconMotion$State;->animator:Landroid/animation/ValueAnimator;

    new-instance v0, Ldev/nino/squareglass/NativeIconMotion$State$0;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/NativeIconMotion$State$0;-><init>(Ldev/nino/squareglass/NativeIconMotion$State;)V

    invoke-virtual {p1, v0}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 28
    iget-object p0, p0, Ldev/nino/squareglass/NativeIconMotion$State;->animator:Landroid/animation/ValueAnimator;

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->start()V

    :cond_3
    :goto_1
    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method
