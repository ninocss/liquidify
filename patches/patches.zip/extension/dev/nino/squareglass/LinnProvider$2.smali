.class public final synthetic Ldev/nino/squareglass/LinnProvider$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnProvider;

.field public final synthetic f$1:I

.field public final synthetic f$2:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$3:Ldev/nino/squareglass/LinnProvider$Device;

.field public final synthetic f$4:Z


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$2;->f$0:Ldev/nino/squareglass/LinnProvider;

    iput p2, p0, Ldev/nino/squareglass/LinnProvider$2;->f$1:I

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider$2;->f$2:Ldev/nino/squareglass/LinnPlayer;

    iput-object p4, p0, Ldev/nino/squareglass/LinnProvider$2;->f$3:Ldev/nino/squareglass/LinnProvider$Device;

    iput-boolean p5, p0, Ldev/nino/squareglass/LinnProvider$2;->f$4:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider$2;->f$0:Ldev/nino/squareglass/LinnProvider;

    iget v1, p0, Ldev/nino/squareglass/LinnProvider$2;->f$1:I

    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider$2;->f$2:Ldev/nino/squareglass/LinnPlayer;

    iget-object v3, p0, Ldev/nino/squareglass/LinnProvider$2;->f$3:Ldev/nino/squareglass/LinnProvider$Device;

    iget-boolean p0, p0, Ldev/nino/squareglass/LinnProvider$2;->f$4:Z

    invoke-static {v0, v1, v2, v3, p0}, Ldev/nino/squareglass/LinnProvider;->$r8$lambda$ax5556ZbJkfwpna-pNfxocxZ3RA(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V

    return-void
.end method
