.class public final synthetic Ldev/nino/squareglass/LinnProvider$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnProvider;

.field public final synthetic f$1:I

.field public final synthetic f$2:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$3:Ljava/lang/Throwable;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ljava/lang/Throwable;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$2;->f$0:Ldev/nino/squareglass/LinnProvider;

    iput p2, p0, Ldev/nino/squareglass/LinnProvider$2;->f$1:I

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider$2;->f$2:Ldev/nino/squareglass/LinnPlayer;

    iput-object p4, p0, Ldev/nino/squareglass/LinnProvider$2;->f$3:Ljava/lang/Throwable;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider$2;->f$0:Ldev/nino/squareglass/LinnProvider;

    iget v1, p0, Ldev/nino/squareglass/LinnProvider$2;->f$1:I

    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider$2;->f$2:Ldev/nino/squareglass/LinnPlayer;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$2;->f$3:Ljava/lang/Throwable;

    invoke-static {v0, v1, v2, p0}, Ldev/nino/squareglass/LinnProvider;->$r8$lambda$UwK1_pduPgaEwNWpgtl4UTwLCjQ(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ljava/lang/Throwable;)V

    return-void
.end method
