.class public final Ldev/nino/squareglass/NativePlayerPaint;
.super Ljava/lang/Object;
.source "NativePlayerPaint.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static background(J)J
    .locals 5

    const/16 v0, 0x20

    ushr-long/2addr p0, v0

    long-to-int p0, p0

    .line 17
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p1

    .line 18
    invoke-static {p1}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v0

    if-eqz p1, :cond_0

    const p1, 0x3f333333    # 0.7f

    goto :goto_0

    :cond_0
    const p1, 0x3f6b851f    # 0.92f

    :goto_0
    ushr-int/lit8 v1, p0, 0x10

    and-int/lit16 v1, v1, 0xff

    int-to-float v1, v1

    const/high16 v2, 0x3f800000    # 1.0f

    sub-float/2addr v2, p1

    mul-float/2addr v1, v2

    ushr-int/lit8 v3, v0, 0x10

    and-int/lit16 v3, v3, 0xff

    int-to-float v3, v3

    mul-float/2addr v3, p1

    add-float/2addr v1, v3

    .line 20
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    ushr-int/lit8 v3, p0, 0x8

    and-int/lit16 v3, v3, 0xff

    int-to-float v3, v3

    mul-float/2addr v3, v2

    ushr-int/lit8 v4, v0, 0x8

    and-int/lit16 v4, v4, 0xff

    int-to-float v4, v4

    mul-float/2addr v4, p1

    add-float/2addr v3, v4

    .line 21
    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    and-int/lit16 p0, p0, 0xff

    int-to-float p0, p0

    mul-float/2addr p0, v2

    and-int/lit16 v0, v0, 0xff

    int-to-float v0, v0

    mul-float/2addr v0, p1

    add-float/2addr p0, v0

    .line 22
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    const/high16 p1, -0x1000000

    shl-int/lit8 v0, v1, 0x10

    or-int/2addr p1, v0

    shl-int/lit8 v0, v3, 0x8

    or-int/2addr p1, v0

    or-int/2addr p0, p1

    .line 23
    invoke-static {p0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide p0

    return-wide p0
.end method

.method public static base()J
    .locals 2

    .line 25
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    return-wide v0
.end method

.method public static film()J
    .locals 2

    .line 26
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    if-eqz v0, :cond_0

    const/high16 v0, -0x1000000

    goto :goto_0

    :cond_0
    const/4 v0, -0x1

    :goto_0
    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    return-wide v0
.end method

.method public static foreground(J)J
    .locals 1

    const/16 v0, 0x38

    ushr-long/2addr p0, v0

    long-to-int p0, p0

    const/16 p1, 0x61

    if-le p0, p1, :cond_0

    const/16 p1, 0xb3

    .line 31
    invoke-static {p0, p1}, Ljava/lang/Math;->max(II)I

    move-result p0

    .line 32
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p1

    invoke-static {p1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p1

    const v0, 0xffffff

    and-int/2addr p1, v0

    shl-int/lit8 p0, p0, 0x18

    or-int/2addr p0, p1

    invoke-static {p0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide p0

    return-wide p0
.end method

.method public static ink()J
    .locals 2

    .line 27
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    return-wide v0
.end method

.method public static style(Lcom/tidal/android/feature/playerscreen/ui/model/PlayerBackgroundStyle;)Lcom/tidal/android/feature/playerscreen/ui/model/PlayerBackgroundStyle;
    .locals 0

    .line 11
    const-string p0, "player"

    invoke-static {p0}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_0

    .line 12
    sget-object p0, Lcom/tidal/android/feature/playerscreen/ui/model/PlayerBackgroundStyle;->DARK_BLUR:Lcom/tidal/android/feature/playerscreen/ui/model/PlayerBackgroundStyle;

    return-object p0

    .line 13
    :cond_0
    sget-object p0, Lcom/tidal/android/feature/playerscreen/ui/model/PlayerBackgroundStyle;->FILLED_COLOR:Lcom/tidal/android/feature/playerscreen/ui/model/PlayerBackgroundStyle;

    return-object p0
.end method
