.class public final synthetic Ldev/nino/squareglass/NativeIconGlass$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/IntConsumer;


# instance fields
.field public final synthetic f$0:Landroid/view/View;

.field public final synthetic f$1:Ldev/nino/squareglass/NativeIconGlass$State;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;Ldev/nino/squareglass/NativeIconGlass$State;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeIconGlass$1;->f$0:Landroid/view/View;

    iput-object p2, p0, Ldev/nino/squareglass/NativeIconGlass$1;->f$1:Ldev/nino/squareglass/NativeIconGlass$State;

    return-void
.end method


# virtual methods
.method public final accept(I)V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeIconGlass$1;->f$0:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$1;->f$1:Ldev/nino/squareglass/NativeIconGlass$State;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/NativeIconGlass;->attach$lambda$0(Landroid/view/View;Ldev/nino/squareglass/NativeIconGlass$State;I)V

    return-void
.end method
