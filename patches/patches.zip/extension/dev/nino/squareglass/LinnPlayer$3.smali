.class public final synthetic Ldev/nino/squareglass/LinnPlayer$3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:J

.field public final synthetic f$2:J

.field public final synthetic f$3:Ldev/nino/squareglass/LinnPlayer$Action;

.field public final synthetic f$4:J


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;JJLdev/nino/squareglass/LinnPlayer$Action;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput-wide p2, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$1:J

    iput-wide p4, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$2:J

    iput-object p6, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$3:Ldev/nino/squareglass/LinnPlayer$Action;

    iput-wide p7, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$4:J

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget-wide v1, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$1:J

    iget-wide v3, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$2:J

    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$3:Ldev/nino/squareglass/LinnPlayer$Action;

    iget-wide v6, p0, Ldev/nino/squareglass/LinnPlayer$3;->f$4:J

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$bOllUWf6NMqJgkHwtx8mNxfQoOs(Ldev/nino/squareglass/LinnPlayer;JJLdev/nino/squareglass/LinnPlayer$Action;J)V

    return-void
.end method
