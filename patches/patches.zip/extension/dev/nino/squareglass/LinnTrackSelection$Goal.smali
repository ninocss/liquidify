.class final Ldev/nino/squareglass/LinnTrackSelection$Goal;
.super Ljava/lang/Object;
.source "LinnTrackSelection.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/LinnTrackSelection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Goal"
.end annotation


# instance fields
.field appliedPlay:Ljava/lang/Boolean;

.field appliedSeek:I

.field final end:J

.field final id:J

.field volatile millis:I

.field next:Ljava/util/concurrent/ScheduledFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation
.end field

.field phase:I

.field volatile play:Z

.field volatile preserveTransport:Z

.field final selectStream:Z


# direct methods
.method constructor <init>(JIZZ)V
    .locals 1

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 21
    iput v0, p0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I

    .line 24
    iput-wide p1, p0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->id:J

    iput p3, p0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->millis:I

    iput-boolean p4, p0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->play:Z

    iput-boolean p5, p0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->selectStream:Z

    xor-int/lit8 p1, p5, 0x1

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->preserveTransport:Z

    xor-int/lit8 p1, p5, 0x1

    iput p1, p0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide p1

    sget-object p3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    if-eqz p5, :cond_0

    const-wide/16 p4, 0x14

    goto :goto_0

    :cond_0
    const-wide/16 p4, 0x5

    :goto_0
    invoke-virtual {p3, p4, p5}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide p3

    add-long/2addr p1, p3

    iput-wide p1, p0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->end:J

    return-void
.end method
