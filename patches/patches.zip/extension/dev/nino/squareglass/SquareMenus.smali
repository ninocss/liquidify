.class public final Ldev/nino/squareglass/SquareMenus;
.super Ljava/lang/Object;
.source "SquareMenus.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/SquareMenus$Presentation;
    }
.end annotation


# static fields
.field private static completedTap:Z

.field private static moved:Z

.field private static final open:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/app/Dialog;",
            "Ldev/nino/squareglass/SquareMenus$Presentation;",
            ">;"
        }
    .end annotation
.end field

.field private static touchX:F

.field private static touchY:F

.field private static touchedActivity:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field private static touchedAt:J


# direct methods
.method static bridge synthetic -$$Nest$sfgetcompletedTap()Z
    .locals 1

    sget-boolean v0, Ldev/nino/squareglass/SquareMenus;->completedTap:Z

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgetmoved()Z
    .locals 1

    sget-boolean v0, Ldev/nino/squareglass/SquareMenus;->moved:Z

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgettouchX()F
    .locals 1

    sget v0, Ldev/nino/squareglass/SquareMenus;->touchX:F

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgettouchY()F
    .locals 1

    sget v0, Ldev/nino/squareglass/SquareMenus;->touchY:F

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgettouchedActivity()Ljava/lang/ref/WeakReference;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/SquareMenus;->touchedActivity:Ljava/lang/ref/WeakReference;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgettouchedAt()J
    .locals 2

    sget-wide v0, Ldev/nino/squareglass/SquareMenus;->touchedAt:J

    return-wide v0
.end method

.method static bridge synthetic -$$Nest$sfputtouchedAt(J)V
    .locals 0

    sput-wide p0, Ldev/nino/squareglass/SquareMenus;->touchedAt:J

    return-void
.end method

.method static bridge synthetic -$$Nest$smdp(Landroid/view/View;F)I
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareMenus;->dp(Landroid/view/View;F)I

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$smheader(Landroid/view/View;)V
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/SquareMenus;->header(Landroid/view/View;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 33
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareMenus;->open:Ljava/util/WeakHashMap;

    .line 34
    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/SquareMenus;->touchedActivity:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static actionColor(Landroid/view/View;II)I
    .locals 3

    const/4 v0, -0x1

    if-eq p1, v0, :cond_0

    .line 135
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p0

    .line 137
    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result p1

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v0

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    .line 138
    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v1

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    sub-int/2addr p1, v0

    const/16 v0, 0x2d

    if-le p1, v0, :cond_0

    return p0

    :cond_0
    return p2
.end method

.method public static dismissed(Landroid/app/Dialog;)V
    .locals 1

    .line 79
    sget-object v0, Ldev/nino/squareglass/SquareMenus;->open:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/SquareMenus$Presentation;

    if-eqz p0, :cond_0

    .line 80
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->release()V

    :cond_0
    return-void
.end method

.method private static dp(Landroid/view/View;F)I
    .locals 0

    .line 89
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method public static hasOpenMenu()Z
    .locals 1

    .line 38
    sget-object v0, Ldev/nino/squareglass/SquareMenus;->open:Ljava/util/WeakHashMap;

    invoke-virtual {v0}, Ljava/util/WeakHashMap;->isEmpty()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method private static header(Landroid/view/View;)V
    .locals 2

    .line 101
    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_0

    .line 102
    check-cast p0, Landroid/widget/TextView;

    .line 103
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextColor(I)V

    return-void

    .line 104
    :cond_0
    instance-of v0, p0, Landroid/widget/ImageView;

    if-eqz v0, :cond_1

    .line 105
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const/high16 v1, 0x41200000    # 10.0f

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    .line 106
    new-instance v1, Ldev/nino/squareglass/SquareMenus$1;

    invoke-direct {v1, v0}, Ldev/nino/squareglass/SquareMenus$1;-><init>(I)V

    invoke-virtual {p0, v1}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    const/4 v0, 0x1

    .line 111
    invoke-virtual {p0, v0}, Landroid/view/View;->setClipToOutline(Z)V

    return-void

    .line 112
    :cond_1
    instance-of v1, p0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_2

    .line 113
    check-cast p0, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    .line 115
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setBackgroundColor(I)V

    .line 116
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, Ldev/nino/squareglass/SquareMenus;->header(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    if-nez v0, :cond_3

    .line 117
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v0, v0, Landroid/graphics/drawable/ColorDrawable;

    if-eqz v0, :cond_3

    .line 118
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    const v1, 0xffffff

    and-int/2addr v0, v1

    const/high16 v1, 0x1f000000

    or-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_3
    return-void
.end method

.method public static row(Landroid/view/View;IIZ)V
    .locals 2

    .line 124
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 125
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    .line 126
    invoke-static {p0, p1, v0}, Ldev/nino/squareglass/SquareMenus;->actionColor(Landroid/view/View;II)I

    move-result p1

    invoke-static {p0, p2, v0}, Ldev/nino/squareglass/SquareMenus;->actionColor(Landroid/view/View;II)I

    move-result p2

    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/SquareMenus;->styleChildren(Landroid/view/View;IIZ)V

    const/high16 p1, 0x42500000    # 52.0f

    .line 127
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareMenus;->dp(Landroid/view/View;F)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setMinimumHeight(I)V

    const/high16 p1, 0x41000000    # 8.0f

    .line 128
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareMenus;->dp(Landroid/view/View;F)I

    move-result p2

    const/high16 p3, 0x40000000    # 2.0f

    invoke-static {p0, p3}, Ldev/nino/squareglass/SquareMenus;->dp(Landroid/view/View;F)I

    move-result v1

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareMenus;->dp(Landroid/view/View;F)I

    move-result p1

    invoke-static {p0, p3}, Ldev/nino/squareglass/SquareMenus;->dp(Landroid/view/View;F)I

    move-result p3

    invoke-virtual {p0, p2, v1, p1, p3}, Landroid/view/View;->setPaddingRelative(IIII)V

    .line 129
    new-instance p1, Landroid/graphics/drawable/RippleDrawable;

    const p2, 0xffffff

    and-int/2addr p2, v0

    const/high16 p3, 0x16000000

    or-int/2addr p2, p3

    invoke-static {p2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p2

    const/4 p3, -0x1

    .line 130
    invoke-static {p0, p3}, Ldev/nino/squareglass/SquareMenus;->surface(Landroid/view/View;I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p3

    const/4 v0, 0x0

    invoke-direct {p1, p2, v0, p3}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 129
    invoke-virtual {p0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public static show(Landroid/app/Dialog;Landroid/app/Activity;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$Adapter;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Dialog;",
            "Landroid/app/Activity;",
            "Landroid/view/View;",
            "Landroidx/recyclerview/widget/RecyclerView$Adapter<",
            "*>;)V"
        }
    .end annotation

    .line 59
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroid/app/Dialog;->show()V

    return-void

    .line 60
    :cond_0
    new-instance v0, Ldev/nino/squareglass/SquareMenus$Presentation;

    invoke-direct {v0, p0, p1, p2, p3}, Ldev/nino/squareglass/SquareMenus$Presentation;-><init>(Landroid/app/Dialog;Landroid/app/Activity;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 61
    sget-object p1, Ldev/nino/squareglass/SquareMenus;->open:Ljava/util/WeakHashMap;

    invoke-virtual {p1, p0, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    invoke-virtual {v0}, Ldev/nino/squareglass/SquareMenus$Presentation;->start()V

    return-void
.end method

.method public static showing(Landroid/app/Dialog;)Z
    .locals 1

    .line 84
    sget-object v0, Ldev/nino/squareglass/SquareMenus;->open:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/SquareMenus$Presentation;

    .line 85
    invoke-virtual {p0}, Landroid/app/Dialog;->isShowing()Z

    move-result p0

    if-nez p0, :cond_1

    if-eqz v0, :cond_0

    iget-boolean p0, v0, Ldev/nino/squareglass/SquareMenus$Presentation;->released:Z

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 p0, 0x1

    return p0
.end method

.method public static sleepTimer(Landroid/view/View;)Z
    .locals 4

    .line 66
    new-instance v0, Ljava/util/ArrayList;

    sget-object v1, Ldev/nino/squareglass/SquareMenus;->open:Ljava/util/WeakHashMap;

    invoke-virtual {v1}, Ljava/util/WeakHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldev/nino/squareglass/SquareMenus$Presentation;

    .line 67
    iget-boolean v2, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->released:Z

    if-nez v2, :cond_0

    iget-object v2, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    if-eqz v2, :cond_0

    iget-object v2, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    invoke-virtual {v2}, Landroid/widget/FrameLayout;->getRootView()Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v3

    if-ne v2, v3, :cond_0

    .line 68
    iget-object p0, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->songMenu:Ldev/nino/squareglass/SquareSongMenu;

    if-eqz p0, :cond_1

    iget-object p0, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->songMenu:Ldev/nino/squareglass/SquareSongMenu;

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareSongMenu;->release()V

    const/4 p0, 0x0

    iput-object p0, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->songMenu:Ldev/nino/squareglass/SquareSongMenu;

    .line 69
    :cond_1
    iget-object p0, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object v0, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LiquidMenuSurface;->clearWithin(Landroid/view/ViewGroup;)V

    iget-object p0, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->removeAllViews()V

    .line 70
    iget-object p0, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    iget-object v0, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    iget-object v2, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object v1, v1, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, Ldev/nino/squareglass/SleepTimer$9;

    invoke-direct {v3, v1}, Ldev/nino/squareglass/SleepTimer$9;-><init>(Landroid/app/Dialog;)V

    invoke-static {v0, v2, v3}, Ldev/nino/squareglass/SleepTimer;->content(Landroid/content/Context;Ldev/nino/squareglass/LiquidMenuSurface;Ljava/lang/Runnable;)Landroid/view/View;

    move-result-object v0

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x1

    const/4 v3, -0x2

    invoke-direct {v1, v2, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, v0, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p0, 0x1

    return p0

    :cond_2
    const/4 p0, 0x0

    return p0
.end method

.method private static styleChildren(Landroid/view/View;IIZ)V
    .locals 3

    .line 145
    instance-of v0, p0, Landroid/widget/TextView;

    const/high16 v1, 0x3f800000    # 1.0f

    const v2, 0x3ee66666    # 0.45f

    if-eqz v0, :cond_1

    .line 146
    move-object p2, p0

    check-cast p2, Landroid/widget/TextView;

    .line 147
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setTextColor(I)V

    if-eqz p3, :cond_0

    goto :goto_0

    :cond_0
    move v1, v2

    .line 148
    :goto_0
    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setAlpha(F)V

    .line 149
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const p1, 0x7f090005

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getFont(I)Landroid/graphics/Typeface;

    move-result-object p0

    invoke-virtual {p2, p0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    return-void

    .line 150
    :cond_1
    instance-of v0, p0, Landroid/widget/ImageView;

    if-eqz v0, :cond_3

    .line 151
    move-object p1, p0

    check-cast p1, Landroid/widget/ImageView;

    invoke-static {p2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    if-eqz p3, :cond_2

    goto :goto_1

    :cond_2
    move v1, v2

    .line 152
    :goto_1
    invoke-virtual {p0, v1}, Landroid/view/View;->setAlpha(F)V

    return-void

    .line 153
    :cond_3
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_4

    .line 154
    check-cast p0, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    .line 155
    :goto_2
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_4

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1, p1, p2, p3}, Ldev/nino/squareglass/SquareMenus;->styleChildren(Landroid/view/View;IIZ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_4
    return-void
.end method

.method private static surface(Landroid/view/View;I)Landroid/graphics/drawable/GradientDrawable;
    .locals 1

    .line 93
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 94
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 p1, 0x41b00000    # 22.0f

    .line 95
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareMenus;->dp(Landroid/view/View;F)I

    move-result p1

    int-to-float p1, p1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/high16 p1, 0x3f800000    # 1.0f

    .line 96
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareMenus;->dp(Landroid/view/View;F)I

    move-result p0

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p1

    if-eqz p1, :cond_0

    const p1, 0x24ffffff

    goto :goto_0

    :cond_0
    const p1, 0x1f15161a

    :goto_0
    invoke-virtual {v0, p0, p1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    return-object v0
.end method

.method public static touch(Landroid/app/Activity;Landroid/view/MotionEvent;)V
    .locals 6

    .line 41
    invoke-static {p1}, Ldev/nino/squareglass/IconMotion;->touch(Landroid/view/MotionEvent;)V

    .line 42
    invoke-static {p0, p1}, Ldev/nino/squareglass/PageCoordinator;->touch(Landroid/app/Activity;Landroid/view/MotionEvent;)V

    .line 43
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 44
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/SquareMenus;->touchedActivity:Ljava/lang/ref/WeakReference;

    .line 45
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result p0

    sput p0, Ldev/nino/squareglass/SquareMenus;->touchX:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result p0

    sput p0, Ldev/nino/squareglass/SquareMenus;->touchY:F

    .line 46
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide p0

    sput-wide p0, Ldev/nino/squareglass/SquareMenus;->touchedAt:J

    .line 47
    sput-boolean v1, Ldev/nino/squareglass/SquareMenus;->moved:Z

    sput-boolean v1, Ldev/nino/squareglass/SquareMenus;->completedTap:Z

    return-void

    .line 48
    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-ne v0, v2, :cond_2

    .line 49
    invoke-static {p0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result p0

    .line 50
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    sget v1, Ldev/nino/squareglass/SquareMenus;->touchX:F

    sub-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    int-to-float p0, p0

    cmpl-float v0, v0, p0

    if-gtz v0, :cond_1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    sget v0, Ldev/nino/squareglass/SquareMenus;->touchY:F

    sub-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    cmpl-float p0, p1, p0

    if-lez p0, :cond_5

    :cond_1
    sput-boolean v3, Ldev/nino/squareglass/SquareMenus;->moved:Z

    return-void

    .line 51
    :cond_2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p0

    const/4 v0, 0x3

    if-eq p0, v0, :cond_6

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p0

    const/4 v0, 0x5

    if-ne p0, v0, :cond_3

    goto :goto_0

    .line 53
    :cond_3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p0

    if-ne p0, v3, :cond_5

    .line 54
    sget-boolean p0, Ldev/nino/squareglass/SquareMenus;->moved:Z

    if-nez p0, :cond_4

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide p0

    sget-wide v4, Ldev/nino/squareglass/SquareMenus;->touchedAt:J

    sub-long/2addr p0, v4

    invoke-static {}, Landroid/view/ViewConfiguration;->getLongPressTimeout()I

    move-result v0

    int-to-long v4, v0

    cmp-long p0, p0, v4

    if-gez p0, :cond_4

    move v1, v3

    :cond_4
    sput-boolean v1, Ldev/nino/squareglass/SquareMenus;->completedTap:Z

    :cond_5
    return-void

    .line 52
    :cond_6
    :goto_0
    sput-boolean v3, Ldev/nino/squareglass/SquareMenus;->moved:Z

    sput-boolean v1, Ldev/nino/squareglass/SquareMenus;->completedTap:Z

    return-void
.end method
