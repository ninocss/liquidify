.class public final synthetic Ldev/nino/squareglass/SurfaceMotion$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/view/View;

.field public final synthetic f$1:Z

.field public final synthetic f$2:Z


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;ZZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SurfaceMotion$2;->f$0:Landroid/view/View;

    iput-boolean p2, p0, Ldev/nino/squareglass/SurfaceMotion$2;->f$1:Z

    iput-boolean p3, p0, Ldev/nino/squareglass/SurfaceMotion$2;->f$2:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SurfaceMotion$2;->f$0:Landroid/view/View;

    iget-boolean v1, p0, Ldev/nino/squareglass/SurfaceMotion$2;->f$1:Z

    iget-boolean p0, p0, Ldev/nino/squareglass/SurfaceMotion$2;->f$2:Z

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/SurfaceMotion;->lambda$enter$1(Landroid/view/View;ZZ)V

    return-void
.end method
