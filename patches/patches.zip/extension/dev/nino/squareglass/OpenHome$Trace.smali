.class interface abstract Ldev/nino/squareglass/OpenHome$Trace;
.super Ljava/lang/Object;
.source "OpenHome.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/OpenHome;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "Trace"
.end annotation


# virtual methods
.method public abstract record(Ljava/lang/String;)V
.end method
