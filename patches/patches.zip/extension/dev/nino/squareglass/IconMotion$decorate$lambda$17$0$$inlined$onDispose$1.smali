.class public final Ldev/nino/squareglass/IconMotion$decorate$lambda$17$0$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source "Effects.kt"

# interfaces
.implements Landroidx/compose/runtime/DisposableEffectResult;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEffects.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Effects.kt\nandroidx/compose/runtime/DisposableEffectScope$onDispose$1\n+ 2 IconMotion.kt\ndev/nino/squareglass/IconMotion\n*L\n1#1,603:1\n109#2:604\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016\u00a8\u0006\u0004\u00b8\u0006\u0000"
    }
    d2 = {
        "androidx/compose/runtime/DisposableEffectScope$onDispose$1",
        "Landroidx/compose/runtime/DisposableEffectResult;",
        "dispose",
        "",
        "runtime"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $entry$inlined:Ldev/nino/squareglass/IconMotion$Entry;


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/IconMotion$Entry;)V
    .locals 0

    iput-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$lambda$17$0$$inlined$onDispose$1;->$entry$inlined:Ldev/nino/squareglass/IconMotion$Entry;

    .line 66
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public dispose()V
    .locals 1

    .line 604
    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getEntries$p()Ljava/util/ArrayList;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$decorate$lambda$17$0$$inlined$onDispose$1;->$entry$inlined:Ldev/nino/squareglass/IconMotion$Entry;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getEntries$p()Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getHandler$p()Landroid/os/Handler;

    move-result-object p0

    invoke-static {}, Ldev/nino/squareglass/IconMotion;->access$getTick$p()Ldev/nino/squareglass/IconMotion$tick$1;

    move-result-object v0

    check-cast v0, Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method
