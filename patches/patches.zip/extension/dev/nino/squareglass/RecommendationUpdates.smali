.class public final Ldev/nino/squareglass/RecommendationUpdates;
.super Ljava/lang/Object;
.source "RecommendationUpdates.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/RecommendationUpdates$Pending;,
        Ldev/nino/squareglass/RecommendationUpdates$Revision;
    }
.end annotation


# static fields
.field private static final main:Landroid/os/Handler;

.field private static final pending:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Ljava/lang/Object;",
            "Ldev/nino/squareglass/RecommendationUpdates$Pending;",
            ">;"
        }
    .end annotation
.end field

.field private static final recent:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Ljava/lang/Object;",
            "Ldev/nino/squareglass/RecommendationUpdates$Revision;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static bridge synthetic -$$Nest$sfgetmain()Landroid/os/Handler;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->main:Landroid/os/Handler;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetpending()Ljava/util/WeakHashMap;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->pending:Ljava/util/WeakHashMap;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetrecent()Ljava/util/WeakHashMap;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->recent:Ljava/util/WeakHashMap;

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 12
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Ldev/nino/squareglass/RecommendationUpdates;->main:Landroid/os/Handler;

    .line 13
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/RecommendationUpdates;->pending:Ljava/util/WeakHashMap;

    .line 14
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/RecommendationUpdates;->recent:Ljava/util/WeakHashMap;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static active(Ljava/lang/Object;)Z
    .locals 1

    .line 40
    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->pending:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public static added(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 42
    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->pending:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;

    if-eqz p0, :cond_0

    invoke-static {p1}, Ldev/nino/squareglass/NativePlaylistBridge;->revision(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->revision:Ljava/lang/String;

    :cond_0
    return-void
.end method

.method public static begin(Ljava/lang/Object;)V
    .locals 5

    .line 21
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-eqz v0, :cond_3

    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->pending:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 22
    :cond_0
    invoke-static {p0}, Ldev/nino/squareglass/NativePlaylistBridge;->view(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v1

    .line 23
    instance-of v2, v1, Landroidx/recyclerview/widget/RecyclerView;

    if-nez v2, :cond_1

    goto :goto_0

    .line 24
    :cond_1
    new-instance v2, Ldev/nino/squareglass/RecommendationUpdates$Pending;

    move-object v3, v1

    check-cast v3, Landroidx/recyclerview/widget/RecyclerView;

    invoke-static {p0}, Ldev/nino/squareglass/NativePlaylistBridge;->items(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-direct {v2, p0, v3, v4}, Ldev/nino/squareglass/RecommendationUpdates$Pending;-><init>(Ljava/lang/Object;Landroidx/recyclerview/widget/RecyclerView;Ljava/util/List;)V

    .line 25
    invoke-virtual {v0, p0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    invoke-static {}, Ldev/nino/squareglass/PageCoordinator;->lastClick()Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_2

    .line 27
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {p0, v1}, Ldev/nino/squareglass/RecommendationUpdates;->inside(Landroid/view/View;Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 28
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, v2, Ldev/nino/squareglass/RecommendationUpdates$Pending;->button:Ljava/lang/ref/WeakReference;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setEnabled(Z)V

    .line 30
    :cond_2
    invoke-virtual {v1, v2}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 31
    sget-object p0, Ldev/nino/squareglass/RecommendationUpdates;->main:Landroid/os/Handler;

    const-wide/16 v0, 0x2710

    invoke-virtual {p0, v2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_3
    :goto_0
    return-void
.end method

.method public static completed(Ljava/lang/Object;Z)V
    .locals 2

    .line 72
    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->pending:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;

    if-nez p0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    .line 73
    iput-boolean v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->completed:Z

    iput-boolean p1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->success:Z

    if-eqz p1, :cond_2

    iget-boolean p1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->event:Z

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    const-wide/16 v0, 0x2ee

    goto :goto_1

    :cond_2
    :goto_0
    const-wide/16 v0, 0x64

    :goto_1
    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/RecommendationUpdates$Pending;->schedule(J)V

    return-void
.end method

.method public static handle(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 3

    .line 56
    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->pending:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/RecommendationUpdates$Pending;

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    .line 58
    :cond_0
    sget-boolean v1, Ldev/nino/squareglass/ProbeDiagnostics;->enabled:Z

    if-eqz v1, :cond_1

    const-string v1, "SquareGlass"

    const-string v2, "Recommendation model coalesced"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 59
    :cond_1
    invoke-static {p0, p1}, Ldev/nino/squareglass/NativePlaylistBridge;->model(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p0, 0x1

    iput-boolean p0, v0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->changed:Z

    .line 60
    iget-boolean p1, v0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->completed:Z

    if-eqz p1, :cond_2

    const-wide/16 v1, 0x64

    invoke-virtual {v0, v1, v2}, Ldev/nino/squareglass/RecommendationUpdates$Pending;->schedule(J)V

    :cond_2
    return p0
.end method

.method private static inside(Landroid/view/View;Landroid/view/View;)Z
    .locals 1

    :goto_0
    if-eqz p0, :cond_2

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    return p0

    .line 36
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Landroid/view/View;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    return p0
.end method

.method public static manual(Ljava/lang/Object;)V
    .locals 1

    .line 44
    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->recent:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static preserve(Ljava/lang/Object;)Z
    .locals 3

    .line 65
    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->pending:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    .line 66
    :cond_0
    sget-boolean v0, Ldev/nino/squareglass/ProbeDiagnostics;->enabled:Z

    if-eqz v0, :cond_1

    const-string v0, "SquareGlass"

    const-string v1, "Recommendation matching event/reload retained"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v0, 0x1

    .line 67
    iput-boolean v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->event:Z

    .line 68
    iget-boolean v1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending;->completed:Z

    if-eqz v1, :cond_2

    const-wide/16 v1, 0x64

    invoke-virtual {p0, v1, v2}, Ldev/nino/squareglass/RecommendationUpdates$Pending;->schedule(J)V

    :cond_2
    return v0
.end method

.method public static reuse(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 9

    .line 46
    sget-object v0, Ldev/nino/squareglass/RecommendationUpdates;->pending:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/RecommendationUpdates$Pending;

    sget-object v1, Ldev/nino/squareglass/RecommendationUpdates;->recent:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ldev/nino/squareglass/RecommendationUpdates$Revision;

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    .line 47
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    iget-wide v7, v2, Ldev/nino/squareglass/RecommendationUpdates$Revision;->time:J

    sub-long/2addr v5, v7

    const-wide/16 v7, 0x3a98

    cmp-long v5, v5, v7

    if-gez v5, :cond_0

    iget-object v5, v2, Ldev/nino/squareglass/RecommendationUpdates$Revision;->view:Ljava/lang/ref/WeakReference;

    .line 48
    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v5

    invoke-static {p0}, Ldev/nino/squareglass/NativePlaylistBridge;->view(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v6

    if-ne v5, v6, :cond_0

    iget-object v2, v2, Ldev/nino/squareglass/RecommendationUpdates$Revision;->value:Ljava/lang/String;

    invoke-static {p1}, Ldev/nino/squareglass/NativePlaylistBridge;->revision(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    move v2, v4

    :goto_0
    if-nez v0, :cond_1

    if-nez v2, :cond_1

    .line 49
    invoke-virtual {v1, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return v4

    .line 50
    :cond_1
    invoke-static {p0, p1}, Ldev/nino/squareglass/NativePlaylistBridge;->metadata(Ljava/lang/Object;Ljava/lang/Object;)V

    if-eqz v0, :cond_2

    .line 51
    invoke-static {p0}, Ldev/nino/squareglass/RecommendationUpdates;->preserve(Ljava/lang/Object;)Z

    .line 52
    :cond_2
    sget-boolean p0, Ldev/nino/squareglass/ProbeDiagnostics;->enabled:Z

    if-eqz p0, :cond_3

    const-string p0, "SquareGlass"

    const-string p1, "Recommendation duplicate rebind retained"

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    return v3
.end method
