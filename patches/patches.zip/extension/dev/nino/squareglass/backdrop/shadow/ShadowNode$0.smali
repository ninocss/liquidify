.class public final synthetic Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:F

.field public final synthetic f$1:F

.field public final synthetic f$2:F

.field public final synthetic f$3:Landroidx/compose/ui/graphics/Outline;

.field public final synthetic f$4:Ldev/nino/squareglass/backdrop/shadow/ShadowNode;


# direct methods
.method public synthetic constructor <init>(FFFLandroidx/compose/ui/graphics/Outline;Ldev/nino/squareglass/backdrop/shadow/ShadowNode;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$0:F

    iput p2, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$1:F

    iput p3, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$2:F

    iput-object p4, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$3:Landroidx/compose/ui/graphics/Outline;

    iput-object p5, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$4:Ldev/nino/squareglass/backdrop/shadow/ShadowNode;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget v0, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$0:F

    iget v1, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$1:F

    iget v2, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$2:F

    iget-object v3, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$3:Landroidx/compose/ui/graphics/Outline;

    iget-object v4, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;->f$4:Ldev/nino/squareglass/backdrop/shadow/ShadowNode;

    move-object v5, p1

    check-cast v5, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->draw$lambda$0(FFFLandroidx/compose/ui/graphics/Outline;Ldev/nino/squareglass/backdrop/shadow/ShadowNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
