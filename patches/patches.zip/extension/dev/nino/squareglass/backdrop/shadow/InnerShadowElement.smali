.class public final Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;
.super Landroidx/compose/ui/node/ModifierNodeElement;
.source "InnerShadowModifier.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/compose/ui/node/ModifierNodeElement<",
        "Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\u0008\u0001\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00020\u0001B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u000e\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u0008\u0010\u000e\u001a\u00020\u0002H\u0016J\u0010\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0002H\u0016J\u000c\u0010\u0012\u001a\u00020\u0010*\u00020\u0013H\u0016J\u0013\u0010\u0014\u001a\u00020\u00152\u0008\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0096\u0002J\u0008\u0010\u0018\u001a\u00020\u0019H\u0016R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000bR\u0019\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\r\u00a8\u0006\u001a"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;",
        "Landroidx/compose/ui/node/ModifierNodeElement;",
        "Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;",
        "shapeProvider",
        "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "shadow",
        "Lkotlin/Function0;",
        "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V",
        "getShapeProvider",
        "()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "getShadow",
        "()Lam0/a;",
        "create",
        "update",
        "",
        "node",
        "inspectableProperties",
        "Landroidx/compose/ui/platform/InspectorInfo;",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final shadow:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
            ">;"
        }
    .end annotation
.end field

.field private final shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
            ">;)V"
        }
    .end annotation

    const-string v0, "shapeProvider"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shadow"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    invoke-direct {p0}, Landroidx/compose/ui/node/ModifierNodeElement;-><init>()V

    .line 36
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    .line 37
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shadow:Lam0/a;

    return-void
.end method


# virtual methods
.method public bridge synthetic create()Landroidx/compose/ui/Modifier$Node;
    .locals 0

    .line 35
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->create()Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/Modifier$Node;

    return-object p0
.end method

.method public create()Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;
    .locals 2

    .line 41
    new-instance v0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shadow:Lam0/a;

    invoke-direct {v0, v1, p0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;-><init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    .line 58
    :cond_0
    instance-of v1, p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    .line 60
    :cond_1
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    check-cast p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    .line 61
    :cond_2
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shadow:Lam0/a;

    iget-object p1, p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shadow:Lam0/a;

    invoke-static {p0, p1}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    return v2

    :cond_3
    return v0
.end method

.method public final getShadow()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
            ">;"
        }
    .end annotation

    .line 37
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shadow:Lam0/a;

    return-object p0
.end method

.method public final getShapeProvider()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;
    .locals 0

    .line 36
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-object p0
.end method

.method public hashCode()I
    .locals 1

    .line 67
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    .line 68
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shadow:Lam0/a;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public inspectableProperties(Landroidx/compose/ui/platform/InspectorInfo;)V
    .locals 3

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    const-string v0, "innerShadow"

    invoke-virtual {p1, v0}, Landroidx/compose/ui/platform/InspectorInfo;->setName(Ljava/lang/String;)V

    .line 52
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object v0

    const-string v1, "shapeProvider"

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    .line 53
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object p1

    const-string v0, "shadow"

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shadow:Lam0/a;

    invoke-virtual {p1, v0, p0}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    return-void
.end method

.method public bridge synthetic update(Landroidx/compose/ui/Modifier$Node;)V
    .locals 0

    .line 35
    check-cast p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->update(Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;)V

    return-void
.end method

.method public update(Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;)V
    .locals 1

    const-string v0, "node"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {p1, v0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->setShapeProvider(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V

    .line 46
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;->shadow:Lam0/a;

    invoke-virtual {p1, p0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->setShadow(Lam0/a;)V

    .line 47
    check-cast p1, Landroidx/compose/ui/node/DrawModifierNode;

    invoke-static {p1}, Landroidx/compose/ui/node/DrawModifierNodeKt;->invalidateDraw(Landroidx/compose/ui/node/DrawModifierNode;)V

    return-void
.end method
