.class public final synthetic Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/graphics/Outline;

.field public final synthetic f$1:Landroidx/compose/ui/graphics/Path;

.field public final synthetic f$2:Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;

.field public final synthetic f$3:F

.field public final synthetic f$4:F


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;FF)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$0:Landroidx/compose/ui/graphics/Outline;

    iput-object p2, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$1:Landroidx/compose/ui/graphics/Path;

    iput-object p3, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$2:Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;

    iput p4, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$3:F

    iput p5, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$4:F

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$0:Landroidx/compose/ui/graphics/Outline;

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$1:Landroidx/compose/ui/graphics/Path;

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$2:Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;

    iget v3, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$3:F

    iget v4, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$0;->f$4:F

    move-object v5, p1

    check-cast v5, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->draw$lambda$1(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;FFLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
