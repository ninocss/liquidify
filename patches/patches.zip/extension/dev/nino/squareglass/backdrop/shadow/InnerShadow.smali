.class public final Ldev/nino/squareglass/backdrop/shadow/InnerShadow;
.super Ljava/lang/Object;
.source "InnerShadow.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/backdrop/shadow/InnerShadow$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInnerShadow.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InnerShadow.kt\ndev/nino/squareglass/backdrop/shadow/InnerShadow\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n*L\n1#1,51:1\n123#2:52\n123#2:53\n188#2:54\n53#3,3:55\n*S KotlinDebug\n*F\n+ 1 InnerShadow.kt\ndev/nino/squareglass/backdrop/shadow/InnerShadow\n*L\n27#1:52\n28#1:53\n28#1:54\n28#1:55,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u001a\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0002\u0008\u0087\u0008\u0018\u0000 ,2\u00020\u0001:\u0001,B9\u0012\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u0008\u0008\u0003\u0010\u0008\u001a\u00020\t\u0012\u0008\u0008\u0002\u0010\n\u001a\u00020\u000b\u00a2\u0006\u0004\u0008\u000c\u0010\rJ\u0010\u0010\u0019\u001a\u00020\u0003H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001a\u0010\u000fJ\u0010\u0010\u001b\u001a\u00020\u0005H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001c\u0010\u0012J\u0010\u0010\u001d\u001a\u00020\u0007H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001e\u0010\u0012J\t\u0010\u001f\u001a\u00020\tH\u00c6\u0003J\u0010\u0010 \u001a\u00020\u000bH\u00c6\u0003\u00a2\u0006\u0004\u0008!\u0010\u0017JB\u0010\"\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00052\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u00072\u0008\u0008\u0003\u0010\u0008\u001a\u00020\t2\u0008\u0008\u0002\u0010\n\u001a\u00020\u000bH\u00c6\u0001\u00a2\u0006\u0004\u0008#\u0010$J\u0014\u0010%\u001a\u00020&2\u0008\u0010\'\u001a\u0004\u0018\u00010\u0001H\u00d6\u0083\u0004J\n\u0010(\u001a\u00020)H\u00d6\u0081\u0004J\n\u0010*\u001a\u00020+H\u00d6\u0081\u0004R\u0013\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\n\n\u0002\u0010\u0010\u001a\u0004\u0008\u000e\u0010\u000fR\u0013\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\n\n\u0002\u0010\u0013\u001a\u0004\u0008\u0011\u0010\u0012R\u0013\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\n\n\u0002\u0010\u0013\u001a\u0004\u0008\u0014\u0010\u0012R\u0011\u0010\u0008\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0015\u0010\u000fR\u0013\u0010\n\u001a\u00020\u000b\u00a2\u0006\n\n\u0002\u0010\u0018\u001a\u0004\u0008\u0016\u0010\u0017\u00a8\u0006-"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
        "",
        "radius",
        "Landroidx/compose/ui/unit/Dp;",
        "offset",
        "Landroidx/compose/ui/unit/DpOffset;",
        "color",
        "Landroidx/compose/ui/graphics/Color;",
        "alpha",
        "",
        "blendMode",
        "Landroidx/compose/ui/graphics/BlendMode;",
        "<init>",
        "(FJJFILkotlin/jvm/internal/DefaultConstructorMarker;)V",
        "getRadius-D9Ej5fM",
        "()F",
        "F",
        "getOffset-RKDOV3M",
        "()J",
        "J",
        "getColor-0d7_KjU",
        "getAlpha",
        "getBlendMode-0nO6VwU",
        "()I",
        "I",
        "component1",
        "component1-D9Ej5fM",
        "component2",
        "component2-RKDOV3M",
        "component3",
        "component3-0d7_KjU",
        "component4",
        "component5",
        "component5-0nO6VwU",
        "copy",
        "copy-Qp58iTY",
        "(FJJFI)Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "",
        "Companion",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Ldev/nino/squareglass/backdrop/shadow/InnerShadow$Companion;

.field private static final Default:Ldev/nino/squareglass/backdrop/shadow/InnerShadow;


# instance fields
.field private final alpha:F

.field private final blendMode:I

.field private final color:J

.field private final offset:J

.field private final radius:F


# direct methods
.method static constructor <clinit>()V
    .locals 12

    new-instance v0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->Companion:Ldev/nino/squareglass/backdrop/shadow/InnerShadow$Companion;

    .line 37
    new-instance v2, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;

    const/16 v10, 0x1f

    const/4 v11, 0x0

    const/4 v3, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct/range {v2 .. v11}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;-><init>(FJJFIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v2, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->Default:Ldev/nino/squareglass/backdrop/shadow/InnerShadow;

    return-void
.end method

.method private constructor <init>(FJJFI)V
    .locals 0

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    iput p1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->radius:F

    .line 28
    iput-wide p2, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->offset:J

    .line 29
    iput-wide p4, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->color:J

    .line 30
    iput p6, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->alpha:F

    .line 31
    iput p7, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->blendMode:I

    return-void
.end method

.method public synthetic constructor <init>(FJJFIILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 12

    and-int/lit8 v0, p8, 0x1

    if-eqz v0, :cond_0

    const/high16 p1, 0x41c00000    # 24.0f

    .line 52
    invoke-static {p1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result p1

    :cond_0
    move v1, p1

    and-int/lit8 p1, p8, 0x2

    if-eqz p1, :cond_1

    const/4 p1, 0x0

    .line 53
    invoke-static {p1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result p1

    .line 55
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p1

    int-to-long p1, p1

    .line 56
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p3

    int-to-long v2, p3

    const/16 p3, 0x20

    shl-long/2addr p1, p3

    const-wide v4, 0xffffffffL

    and-long/2addr v2, v4

    or-long/2addr p1, v2

    .line 54
    invoke-static {p1, p2}, Landroidx/compose/ui/unit/DpOffset;->constructor-impl(J)J

    move-result-wide p2

    :cond_1
    move-wide v2, p2

    and-int/lit8 p1, p8, 0x4

    if-eqz p1, :cond_2

    .line 29
    sget-object p1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {p1}, Landroidx/compose/ui/graphics/Color$Companion;->getBlack-0d7_KjU()J

    move-result-wide v4

    const/16 v10, 0xe

    const/4 v11, 0x0

    const v6, 0x3e19999a    # 0.15f

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v4 .. v11}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide p1

    move-wide v4, p1

    goto :goto_0

    :cond_2
    move-wide/from16 v4, p4

    :goto_0
    and-int/lit8 p1, p8, 0x8

    if-eqz p1, :cond_3

    const/high16 p1, 0x3f800000    # 1.0f

    move v6, p1

    goto :goto_1

    :cond_3
    move/from16 v6, p6

    :goto_1
    and-int/lit8 p1, p8, 0x10

    if-eqz p1, :cond_4

    .line 31
    sget-object p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;->Companion:Landroidx/compose/ui/graphics/drawscope/DrawScope$Companion;

    invoke-virtual {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope$Companion;->getDefaultBlendMode-0nO6VwU()I

    move-result p1

    move v7, p1

    goto :goto_2

    :cond_4
    move/from16 v7, p7

    :goto_2
    const/4 v8, 0x0

    move-object v0, p0

    .line 26
    invoke-direct/range {v0 .. v8}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;-><init>(FJJFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public synthetic constructor <init>(FJJFILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct/range {p0 .. p7}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;-><init>(FJJFI)V

    return-void
.end method

.method public static final synthetic access$getDefault$cp()Ldev/nino/squareglass/backdrop/shadow/InnerShadow;
    .locals 1

    .line 25
    sget-object v0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->Default:Ldev/nino/squareglass/backdrop/shadow/InnerShadow;

    return-object v0
.end method

.method public static synthetic copy-Qp58iTY$default(Ldev/nino/squareglass/backdrop/shadow/InnerShadow;FJJFIILjava/lang/Object;)Ldev/nino/squareglass/backdrop/shadow/InnerShadow;
    .locals 0

    and-int/lit8 p9, p8, 0x1

    if-eqz p9, :cond_0

    iget p1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->radius:F

    :cond_0
    and-int/lit8 p9, p8, 0x2

    if-eqz p9, :cond_1

    iget-wide p2, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->offset:J

    :cond_1
    and-int/lit8 p9, p8, 0x4

    if-eqz p9, :cond_2

    iget-wide p4, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->color:J

    :cond_2
    and-int/lit8 p9, p8, 0x8

    if-eqz p9, :cond_3

    iget p6, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->alpha:F

    :cond_3
    and-int/lit8 p8, p8, 0x10

    if-eqz p8, :cond_4

    iget p7, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->blendMode:I

    :cond_4
    move p8, p6

    move p9, p7

    move-wide p6, p4

    move-wide p4, p2

    move-object p2, p0

    move p3, p1

    invoke-virtual/range {p2 .. p9}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->copy-Qp58iTY(FJJFI)Ldev/nino/squareglass/backdrop/shadow/InnerShadow;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1-D9Ej5fM()F
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->radius:F

    return p0
.end method

.method public final component2-RKDOV3M()J
    .locals 2

    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->offset:J

    return-wide v0
.end method

.method public final component3-0d7_KjU()J
    .locals 2

    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->color:J

    return-wide v0
.end method

.method public final component4()F
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->alpha:F

    return p0
.end method

.method public final component5-0nO6VwU()I
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->blendMode:I

    return p0
.end method

.method public final copy-Qp58iTY(FJJFI)Ldev/nino/squareglass/backdrop/shadow/InnerShadow;
    .locals 9

    new-instance v0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;

    const/4 v8, 0x0

    move v1, p1

    move-wide v2, p2

    move-wide v4, p4

    move v6, p6

    move/from16 v7, p7

    invoke-direct/range {v0 .. v8}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;-><init>(FJJFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;

    iget v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->radius:F

    iget v3, p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->radius:F

    invoke-static {v1, v3}, Landroidx/compose/ui/unit/Dp;->equals-impl0(FF)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget-wide v3, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->offset:J

    iget-wide v5, p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->offset:J

    invoke-static {v3, v4, v5, v6}, Landroidx/compose/ui/unit/DpOffset;->equals-impl0(JJ)Z

    move-result v1

    if-nez v1, :cond_3

    return v2

    :cond_3
    iget-wide v3, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->color:J

    iget-wide v5, p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->color:J

    invoke-static {v3, v4, v5, v6}, Landroidx/compose/ui/graphics/Color;->equals-impl0(JJ)Z

    move-result v1

    if-nez v1, :cond_4

    return v2

    :cond_4
    iget v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->alpha:F

    iget v3, p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->alpha:F

    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_5

    return v2

    :cond_5
    iget p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->blendMode:I

    iget p1, p1, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->blendMode:I

    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/BlendMode;->equals-impl0(II)Z

    move-result p0

    if-nez p0, :cond_6

    return v2

    :cond_6
    return v0
.end method

.method public final getAlpha()F
    .locals 0

    .line 30
    iget p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->alpha:F

    return p0
.end method

.method public final getBlendMode-0nO6VwU()I
    .locals 0

    .line 31
    iget p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->blendMode:I

    return p0
.end method

.method public final getColor-0d7_KjU()J
    .locals 2

    .line 29
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->color:J

    return-wide v0
.end method

.method public final getOffset-RKDOV3M()J
    .locals 2

    .line 28
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->offset:J

    return-wide v0
.end method

.method public final getRadius-D9Ej5fM()F
    .locals 0

    .line 27
    iget p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->radius:F

    return p0
.end method

.method public hashCode()I
    .locals 3

    iget v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->radius:F

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->hashCode-impl(F)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->offset:J

    invoke-static {v1, v2}, Landroidx/compose/ui/unit/DpOffset;->hashCode-impl(J)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->color:J

    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/Color;->hashCode-impl(J)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->alpha:F

    invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->blendMode:I

    invoke-static {p0}, Landroidx/compose/ui/graphics/BlendMode;->hashCode-impl(I)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 6

    iget v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->radius:F

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->toString-impl(F)Ljava/lang/String;

    move-result-object v0

    iget-wide v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->offset:J

    invoke-static {v1, v2}, Landroidx/compose/ui/unit/DpOffset;->toString-impl(J)Ljava/lang/String;

    move-result-object v1

    iget-wide v2, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->color:J

    invoke-static {v2, v3}, Landroidx/compose/ui/graphics/Color;->toString-impl(J)Ljava/lang/String;

    move-result-object v2

    iget v3, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->alpha:F

    iget p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->blendMode:I

    invoke-static {p0}, Landroidx/compose/ui/graphics/BlendMode;->toString-impl(I)Ljava/lang/String;

    move-result-object p0

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "InnerShadow(radius="

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", offset="

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", color="

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", alpha="

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v0, ", blendMode="

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
