.class public final Ldev/nino/squareglass/backdrop/shadow/InnerShadowKt;
.super Ljava/lang/Object;
.source "InnerShadow.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0010\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0000\u001a \u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0005H\u0007\u00a8\u0006\u0006"
    }
    d2 = {
        "lerp",
        "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
        "start",
        "stop",
        "fraction",
        "",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final lerp(Ldev/nino/squareglass/backdrop/shadow/InnerShadow;Ldev/nino/squareglass/backdrop/shadow/InnerShadow;F)Ldev/nino/squareglass/backdrop/shadow/InnerShadow;
    .locals 10

    const-string v0, "start"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "stop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    new-instance v1, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;

    .line 44
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getRadius-D9Ej5fM()F

    move-result v0

    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getRadius-D9Ej5fM()F

    move-result v2

    invoke-static {v0, v2, p2}, Landroidx/compose/ui/unit/DpKt;->lerp-Md-fbLM(FFF)F

    move-result v2

    .line 45
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getOffset-RKDOV3M()J

    move-result-wide v3

    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getOffset-RKDOV3M()J

    move-result-wide v5

    invoke-static {v3, v4, v5, v6, p2}, Landroidx/compose/ui/unit/DpKt;->lerp-xhh869w(JJF)J

    move-result-wide v3

    .line 46
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getColor-0d7_KjU()J

    move-result-wide v5

    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getColor-0d7_KjU()J

    move-result-wide v7

    invoke-static {v5, v6, v7, v8, p2}, Landroidx/compose/ui/graphics/ColorKt;->lerp-jxsXWHM(JJF)J

    move-result-wide v5

    .line 47
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getAlpha()F

    move-result v0

    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getAlpha()F

    move-result v7

    invoke-static {v0, v7, p2}, Landroidx/compose/ui/util/MathHelpersKt;->lerp(FFF)F

    move-result v7

    const/high16 v0, 0x3f000000    # 0.5f

    cmpg-float p2, p2, v0

    if-gez p2, :cond_0

    .line 48
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getBlendMode-0nO6VwU()I

    move-result p0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getBlendMode-0nO6VwU()I

    move-result p0

    :goto_0
    move v8, p0

    const/4 v9, 0x0

    .line 43
    invoke-direct/range {v1 .. v9}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;-><init>(FJJFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v1
.end method
