.class public final Ldev/nino/squareglass/backdrop/shadow/Shadow$Companion;
.super Ljava/lang/Object;
.source "Shadow.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/backdrop/shadow/Shadow;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003R\u001c\u0010\u0004\u001a\u00020\u00058\u0006X\u0087\u0004\u00a2\u0006\u000e\n\u0000\u0012\u0004\u0008\u0006\u0010\u0003\u001a\u0004\u0008\u0007\u0010\u0008\u00a8\u0006\t"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/shadow/Shadow$Companion;",
        "",
        "<init>",
        "()V",
        "Default",
        "Ldev/nino/squareglass/backdrop/shadow/Shadow;",
        "getDefault$annotations",
        "getDefault",
        "()Ldev/nino/squareglass/backdrop/shadow/Shadow;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/shadow/Shadow$Companion;-><init>()V

    return-void
.end method

.method public static synthetic getDefault$annotations()V
    .locals 0

    return-void
.end method


# virtual methods
.method public final getDefault()Ldev/nino/squareglass/backdrop/shadow/Shadow;
    .locals 0

    .line 34
    invoke-static {}, Ldev/nino/squareglass/backdrop/shadow/Shadow;->access$getDefault$cp()Ldev/nino/squareglass/backdrop/shadow/Shadow;

    move-result-object p0

    return-object p0
.end method
