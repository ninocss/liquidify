.class public final Ldev/nino/squareglass/backdrop/shadow/InnerShadowModifierKt;
.super Ljava/lang/Object;
.source "InnerShadowModifier.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0008\n\u0000\n\u0002\u0018\u0002\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0002"
    }
    d2 = {
        "ShadowMaskPaint",
        "Landroidx/compose/ui/graphics/Paint;",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final ShadowMaskPaint:Landroidx/compose/ui/graphics/Paint;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 165
    invoke-static {}, Landroidx/compose/ui/graphics/AndroidPaint_androidKt;->Paint()Landroidx/compose/ui/graphics/Paint;

    move-result-object v0

    .line 166
    sget-object v1, Landroidx/compose/ui/graphics/BlendMode;->Companion:Landroidx/compose/ui/graphics/BlendMode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/BlendMode$Companion;->getClear-0nO6VwU()I

    move-result v1

    invoke-interface {v0, v1}, Landroidx/compose/ui/graphics/Paint;->setBlendMode-s9anfk8(I)V

    .line 165
    sput-object v0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowModifierKt;->ShadowMaskPaint:Landroidx/compose/ui/graphics/Paint;

    return-void
.end method

.method public static final synthetic access$getShadowMaskPaint$p()Landroidx/compose/ui/graphics/Paint;
    .locals 1

    .line 1
    sget-object v0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowModifierKt;->ShadowMaskPaint:Landroidx/compose/ui/graphics/Paint;

    return-object v0
.end method
