.class public final Ldev/nino/squareglass/backdrop/shadow/ShadowNode;
.super Landroidx/compose/ui/Modifier$Node;
.source "ShadowModifier.kt"

# interfaces
.implements Landroidx/compose/ui/node/DrawModifierNode;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nShadowModifier.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ShadowModifier.kt\ndev/nino/squareglass/backdrop/shadow/ShadowNode\n+ 2 Size.kt\nandroidx/compose/ui/geometry/Size\n+ 3 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 4 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n+ 5 IntSize.kt\nandroidx/compose/ui/unit/IntSizeKt\n+ 6 DrawScope.kt\nandroidx/compose/ui/graphics/drawscope/DrawScopeKt\n*L\n1#1,147:1\n57#2:148\n61#2:151\n60#3:149\n70#3:152\n80#3:155\n22#4:150\n22#4:153\n30#5:154\n120#6,7:156\n120#6,7:163\n*S KotlinDebug\n*F\n+ 1 ShadowModifier.kt\ndev/nino/squareglass/backdrop/shadow/ShadowNode\n*L\n95#1:148\n96#1:151\n95#1:149\n96#1:152\n94#1:155\n95#1:150\n96#1:153\n94#1:154\n114#1:156,7\n105#1:163,7\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u000b\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\u0008\u0001\u0018\u00002\u00020\u00012\u00020\u0002B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u000e\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u000c\u0010\u001a\u001a\u00020\u001b*\u00020\u001cH\u0016J\u0008\u0010\u001d\u001a\u00020\u001bH\u0016J\u0008\u0010\u001e\u001a\u00020\u001bH\u0016J\u0014\u0010\u001f\u001a\u00020\u001b*\u00020 2\u0006\u0010\u0005\u001a\u00020\u0007H\u0002R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\n\u0010\u000b\"\u0004\u0008\u000c\u0010\rR\"\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000e\u0010\u000f\"\u0004\u0008\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\u00020\u0013X\u0096D\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006!"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/shadow/ShadowNode;",
        "Landroidx/compose/ui/node/DrawModifierNode;",
        "Landroidx/compose/ui/Modifier$Node;",
        "shapeProvider",
        "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "shadow",
        "Lkotlin/Function0;",
        "Ldev/nino/squareglass/backdrop/shadow/Shadow;",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V",
        "getShapeProvider",
        "()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "setShapeProvider",
        "(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V",
        "getShadow",
        "()Lam0/a;",
        "setShadow",
        "(Lam0/a;)V",
        "shouldAutoInvalidate",
        "",
        "getShouldAutoInvalidate",
        "()Z",
        "shadowLayer",
        "Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
        "paint",
        "Landroidx/compose/ui/graphics/Paint;",
        "draw",
        "",
        "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
        "onAttach",
        "onDetach",
        "configurePaint",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final paint:Landroidx/compose/ui/graphics/Paint;

.field private shadow:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/Shadow;",
            ">;"
        }
    .end annotation
.end field

.field private shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

.field private shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

.field private final shouldAutoInvalidate:Z


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/Shadow;",
            ">;)V"
        }
    .end annotation

    const-string v0, "shapeProvider"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shadow"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    invoke-direct {p0}, Landroidx/compose/ui/Modifier$Node;-><init>()V

    .line 72
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    .line 73
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shadow:Lam0/a;

    .line 80
    invoke-static {}, Landroidx/compose/ui/graphics/AndroidPaint_androidKt;->Paint()Landroidx/compose/ui/graphics/Paint;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->paint:Landroidx/compose/ui/graphics/Paint;

    return-void
.end method

.method private final configurePaint(Landroidx/compose/ui/graphics/drawscope/DrawScope;Ldev/nino/squareglass/backdrop/shadow/Shadow;)V
    .locals 3

    .line 139
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-virtual {p2}, Ldev/nino/squareglass/backdrop/shadow/Shadow;->getColor-0d7_KjU()J

    move-result-wide v1

    invoke-interface {v0, v1, v2}, Landroidx/compose/ui/graphics/Paint;->setColor-8_81llA(J)V

    .line 140
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-virtual {p2}, Ldev/nino/squareglass/backdrop/shadow/Shadow;->getRadius-D9Ej5fM()F

    move-result p2

    invoke-interface {p1, p2}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result p1

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/internal/PaintKt;->blur(Landroidx/compose/ui/graphics/Paint;F)V

    return-void
.end method

.method static final draw$lambda$0(FFFLandroidx/compose/ui/graphics/Outline;Ldev/nino/squareglass/backdrop/shadow/ShadowNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 3

    const-string v0, "$this$record"

    invoke-static {p5, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v0, 0x40000000    # 2.0f

    mul-float/2addr p0, v0

    add-float v0, p0, p1

    add-float/2addr p0, p2

    .line 163
    invoke-interface {p5}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v1

    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v1

    invoke-interface {v1, v0, p0}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    .line 106
    :try_start_0
    invoke-interface {p5}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v1

    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v1

    .line 107
    iget-object p4, p4, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-static {v1, p3, p4}, Landroidx/compose/ui/graphics/OutlineKt;->drawOutline(Landroidx/compose/ui/graphics/Canvas;Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Paint;)V

    neg-float p4, p1

    neg-float v2, p2

    .line 108
    invoke-interface {v1, p4, v2}, Landroidx/compose/ui/graphics/Canvas;->translate(FF)V

    .line 109
    invoke-static {}, Ldev/nino/squareglass/backdrop/shadow/ShadowModifierKt;->access$getShadowMaskPaint$p()Landroidx/compose/ui/graphics/Paint;

    move-result-object p4

    invoke-static {v1, p3, p4}, Landroidx/compose/ui/graphics/OutlineKt;->drawOutline(Landroidx/compose/ui/graphics/Canvas;Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Paint;)V

    .line 110
    invoke-interface {v1, p1, p2}, Landroidx/compose/ui/graphics/Canvas;->translate(FF)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 167
    invoke-interface {p5}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p1

    neg-float p2, v0

    neg-float p0, p0

    invoke-interface {p1, p2, p0}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    .line 112
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0

    :catchall_0
    move-exception p1

    .line 167
    invoke-interface {p5}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p2

    invoke-interface {p2}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p2

    neg-float p3, v0

    neg-float p0, p0

    invoke-interface {p2, p3, p0}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    throw p1
.end method


# virtual methods
.method public draw(Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)V
    .locals 18

    move-object/from16 v5, p0

    move-object/from16 v6, p1

    const-string v0, "<this>"

    invoke-static {v6, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    iget-object v0, v5, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shadow:Lam0/a;

    invoke-interface {v0}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/backdrop/shadow/Shadow;

    if-nez v0, :cond_0

    invoke-interface {v6}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V

    return-void

    .line 85
    :cond_0
    iget-object v7, v5, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-eqz v7, :cond_1

    .line 87
    invoke-interface {v6}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getSize-NH-jbRc()J

    move-result-wide v1

    .line 88
    move-object v3, v6

    check-cast v3, Landroidx/compose/ui/unit/Density;

    .line 89
    invoke-interface {v6}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    move-result-object v4

    .line 91
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/Shadow;->getRadius-D9Ej5fM()F

    move-result v8

    invoke-interface {v6, v8}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->toPx-0680j_4(F)F

    move-result v8

    .line 92
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/Shadow;->getOffset-RKDOV3M()J

    move-result-wide v9

    invoke-static {v9, v10}, Landroidx/compose/ui/unit/DpOffset;->getX-D9Ej5fM(J)F

    move-result v9

    invoke-interface {v6, v9}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->toPx-0680j_4(F)F

    move-result v9

    .line 93
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/Shadow;->getOffset-RKDOV3M()J

    move-result-wide v10

    invoke-static {v10, v11}, Landroidx/compose/ui/unit/DpOffset;->getY-D9Ej5fM(J)F

    move-result v10

    invoke-interface {v6, v10}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->toPx-0680j_4(F)F

    move-result v10

    const/16 v11, 0x20

    shr-long v12, v1, v11

    long-to-int v12, v12

    .line 150
    invoke-static {v12}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v12

    const/high16 v13, 0x40800000    # 4.0f

    mul-float/2addr v13, v8

    add-float/2addr v12, v13

    add-float/2addr v12, v9

    float-to-double v14, v12

    .line 95
    invoke-static {v14, v15}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v14

    double-to-float v12, v14

    float-to-int v12, v12

    const-wide v16, 0xffffffffL

    and-long v14, v1, v16

    long-to-int v14, v14

    .line 153
    invoke-static {v14}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v14

    add-float/2addr v14, v13

    add-float/2addr v14, v10

    float-to-double v13, v14

    .line 96
    invoke-static {v13, v14}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v13

    double-to-float v13, v13

    float-to-int v13, v13

    int-to-long v14, v12

    shl-long v11, v14, v11

    int-to-long v13, v13

    and-long v13, v13, v16

    or-long/2addr v11, v13

    .line 154
    invoke-static {v11, v12}, Landroidx/compose/ui/unit/IntSize;->constructor-impl(J)J

    move-result-wide v11

    .line 98
    iget-object v13, v5, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {v13}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->getShape()Landroidx/compose/ui/graphics/Shape;

    move-result-object v13

    invoke-interface {v13, v1, v2, v4, v3}, Landroidx/compose/ui/graphics/Shape;->createOutline-Pq9zytI(JLandroidx/compose/ui/unit/LayoutDirection;Landroidx/compose/ui/unit/Density;)Landroidx/compose/ui/graphics/Outline;

    move-result-object v4

    .line 100
    move-object v13, v6

    check-cast v13, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-direct {v5, v13, v0}, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->configurePaint(Landroidx/compose/ui/graphics/drawscope/DrawScope;Ldev/nino/squareglass/backdrop/shadow/Shadow;)V

    .line 102
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/Shadow;->getAlpha()F

    move-result v1

    invoke-virtual {v7, v1}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setAlpha(F)V

    .line 103
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/Shadow;->getBlendMode-0nO6VwU()I

    move-result v0

    invoke-virtual {v7, v0}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setBlendMode-s9anfk8(I)V

    .line 104
    new-instance v0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;

    move v1, v8

    move v2, v9

    move v3, v10

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/backdrop/shadow/ShadowNode$0;-><init>(FFFLandroidx/compose/ui/graphics/Outline;Ldev/nino/squareglass/backdrop/shadow/ShadowNode;)V

    invoke-interface {v6, v7, v11, v12, v0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->record-JVtK1S4(Landroidx/compose/ui/graphics/layer/GraphicsLayer;JLam0/l;)V

    neg-float v0, v1

    const/high16 v1, 0x40000000    # 2.0f

    mul-float/2addr v1, v0

    .line 156
    invoke-interface {v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v0

    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v0

    invoke-interface {v0, v1, v1}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    .line 115
    :try_start_0
    invoke-static {v13, v7}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 160
    invoke-interface {v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v0

    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v0

    neg-float v1, v1

    invoke-interface {v0, v1, v1}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    goto :goto_0

    :catchall_0
    move-exception v0

    invoke-interface {v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v2

    invoke-interface {v2}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v2

    neg-float v1, v1

    invoke-interface {v2, v1, v1}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    throw v0

    .line 119
    :cond_1
    :goto_0
    invoke-interface {v6}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V

    return-void
.end method

.method public final getShadow()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/Shadow;",
            ">;"
        }
    .end annotation

    .line 73
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shadow:Lam0/a;

    return-object p0
.end method

.method public final getShapeProvider()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;
    .locals 0

    .line 72
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-object p0
.end method

.method public getShouldAutoInvalidate()Z
    .locals 0

    .line 76
    iget-boolean p0, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shouldAutoInvalidate:Z

    return p0
.end method

.method public onAttach()V
    .locals 2

    .line 123
    move-object v0, p0

    check-cast v0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v0

    .line 125
    invoke-interface {v0}, Landroidx/compose/ui/graphics/GraphicsContext;->createGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object v0

    .line 126
    sget-object v1, Landroidx/compose/ui/graphics/layer/CompositingStrategy;->Companion:Landroidx/compose/ui/graphics/layer/CompositingStrategy$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/layer/CompositingStrategy$Companion;->getOffscreen-ke2Ky5w()I

    move-result v1

    invoke-virtual {v0, v1}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setCompositingStrategy-Wpw9cng(I)V

    .line 124
    iput-object v0, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    return-void
.end method

.method public onDetach()V
    .locals 2

    .line 131
    move-object v0, p0

    check-cast v0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v0

    .line 132
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-eqz v1, :cond_0

    .line 133
    invoke-interface {v0, v1}, Landroidx/compose/ui/graphics/GraphicsContext;->releaseGraphicsLayer(Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    const/4 v0, 0x0

    .line 134
    iput-object v0, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    :cond_0
    return-void
.end method

.method public bridge onMeasureResultChanged()V
    .locals 0

    .line 71
    invoke-super {p0}, Landroidx/compose/ui/node/DrawModifierNode;->onMeasureResultChanged()V

    return-void
.end method

.method public final setShadow(Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/Shadow;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shadow:Lam0/a;

    return-void
.end method

.method public final setShapeProvider(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V
    .locals 1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/ShadowNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-void
.end method
