.class public final Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;
.super Ljava/lang/Object;
.source "HighlightStyle.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Default"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHighlightStyle.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HighlightStyle.kt\ndev/nino/squareglass/backdrop/highlight/HighlightStyle$Default\n+ 2 Size.kt\nandroidx/compose/ui/geometry/Size\n+ 3 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 4 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n*L\n1#1,148:1\n57#2:149\n61#2:152\n60#3:150\n70#3:153\n22#4:151\n*S KotlinDebug\n*F\n+ 1 HighlightStyle.kt\ndev/nino/squareglass/backdrop/highlight/HighlightStyle$Default\n*L\n70#1:149\n70#1:152\n70#1:150\n70#1:153\n70#1:151\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\r\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\n\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0000\u0008\u0087\u0008\u0018\u00002\u00020\u0001B/\u0012\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u0008\u0008\u0003\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\t\u0010\nJ\u001e\u0010\u0014\u001a\u0004\u0018\u00010\u0015*\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J\u0010\u0010\u001b\u001a\u00020\u0003H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001c\u0010\u000cJ\u0010\u0010\u001d\u001a\u00020\u0005H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001e\u0010\u000fJ\t\u0010\u001f\u001a\u00020\u0007H\u00c6\u0003J\t\u0010 \u001a\u00020\u0007H\u00c6\u0003J8\u0010!\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00052\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u00072\u0008\u0008\u0003\u0010\u0008\u001a\u00020\u0007H\u00c6\u0001\u00a2\u0006\u0004\u0008\"\u0010#J\u0014\u0010$\u001a\u00020%2\u0008\u0010&\u001a\u0004\u0018\u00010\'H\u00d6\u0083\u0004J\n\u0010(\u001a\u00020)H\u00d6\u0081\u0004J\n\u0010*\u001a\u00020+H\u00d6\u0081\u0004R\u0016\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\n\n\u0002\u0010\r\u001a\u0004\u0008\u000b\u0010\u000cR\u0016\u0010\u0004\u001a\u00020\u0005X\u0096\u0004\u00a2\u0006\n\n\u0002\u0010\u0010\u001a\u0004\u0008\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012R\u0011\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0012\u00a8\u0006,"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;",
        "Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;",
        "color",
        "Landroidx/compose/ui/graphics/Color;",
        "blendMode",
        "Landroidx/compose/ui/graphics/BlendMode;",
        "angle",
        "",
        "falloff",
        "<init>",
        "(JIFFLkotlin/jvm/internal/DefaultConstructorMarker;)V",
        "getColor-0d7_KjU",
        "()J",
        "J",
        "getBlendMode-0nO6VwU",
        "()I",
        "I",
        "getAngle",
        "()F",
        "getFalloff",
        "createShader",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "runtimeShaderCache",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCache;",
        "component1",
        "component1-0d7_KjU",
        "component2",
        "component2-0nO6VwU",
        "component3",
        "component4",
        "copy",
        "copy-UVf8vpc",
        "(JIFF)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "toString",
        "",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final angle:F

.field private final blendMode:I

.field private final color:J

.field private final falloff:F


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method private constructor <init>(JIFF)V
    .locals 0

    .line 53
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 55
    iput-wide p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->color:J

    .line 56
    iput p3, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->blendMode:I

    .line 57
    iput p4, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->angle:F

    .line 58
    iput p5, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->falloff:F

    return-void
.end method

.method public synthetic constructor <init>(JIFFILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 8

    and-int/lit8 p7, p6, 0x1

    if-eqz p7, :cond_0

    .line 55
    sget-object p1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {p1}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v0

    const/16 v6, 0xe

    const/4 v7, 0x0

    const/high16 v2, 0x3f000000    # 0.5f

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v7}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide p1

    :cond_0
    move-wide v1, p1

    and-int/lit8 p1, p6, 0x2

    if-eqz p1, :cond_1

    .line 56
    sget-object p1, Landroidx/compose/ui/graphics/BlendMode;->Companion:Landroidx/compose/ui/graphics/BlendMode$Companion;

    invoke-virtual {p1}, Landroidx/compose/ui/graphics/BlendMode$Companion;->getPlus-0nO6VwU()I

    move-result p3

    :cond_1
    move v3, p3

    and-int/lit8 p1, p6, 0x4

    if-eqz p1, :cond_2

    const/high16 p4, 0x42340000    # 45.0f

    :cond_2
    move v4, p4

    and-int/lit8 p1, p6, 0x8

    if-eqz p1, :cond_3

    const/high16 p5, 0x3f800000    # 1.0f

    :cond_3
    move v5, p5

    const/4 v6, 0x0

    move-object v0, p0

    .line 54
    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;-><init>(JIFFLkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public synthetic constructor <init>(JIFFLkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct/range {p0 .. p5}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;-><init>(JIFF)V

    return-void
.end method

.method public static synthetic copy-UVf8vpc$default(Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;JIFFILjava/lang/Object;)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;
    .locals 6

    and-int/lit8 p7, p6, 0x1

    if-eqz p7, :cond_0

    iget-wide p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->color:J

    :cond_0
    move-wide v1, p1

    and-int/lit8 p1, p6, 0x2

    if-eqz p1, :cond_1

    iget p3, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->blendMode:I

    :cond_1
    move v3, p3

    and-int/lit8 p1, p6, 0x4

    if-eqz p1, :cond_2

    iget p4, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->angle:F

    :cond_2
    move v4, p4

    and-int/lit8 p1, p6, 0x8

    if-eqz p1, :cond_3

    iget p5, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->falloff:F

    :cond_3
    move-object v0, p0

    move v5, p5

    invoke-virtual/range {v0 .. v5}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->copy-UVf8vpc(JIFF)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1-0d7_KjU()J
    .locals 2

    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->color:J

    return-wide v0
.end method

.method public final component2-0nO6VwU()I
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->blendMode:I

    return p0
.end method

.method public final component3()F
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->angle:F

    return p0
.end method

.method public final component4()F
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->falloff:F

    return p0
.end method

.method public final copy-UVf8vpc(JIFF)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;
    .locals 7

    new-instance v0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;

    const/4 v6, 0x0

    move-wide v1, p1

    move v3, p3

    move v4, p4

    move v5, p5

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;-><init>(JIFFLkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method public createShader(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;Ldev/nino/squareglass/backdrop/RuntimeShaderCache;)Ldev/nino/squareglass/backdrop/RuntimeShader;
    .locals 9

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shape"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "runtimeShaderCache"

    invoke-static {p3, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 65
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRuntimeShaderSupported()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 67
    const-string v0, "Default"

    .line 68
    const-string v1, "\nuniform float2 size;\nuniform float4 cornerRadii;\nlayout(color) uniform half4 color;\nuniform float angle;\nuniform float falloff;\n\n\nfloat radiusAt(float2 coord, float4 radii) {\n    if (coord.x >= 0.0) {\n        if (coord.y <= 0.0) return radii.y;\n        else return radii.z;\n    } else {\n        if (coord.y <= 0.0) return radii.x;\n        else return radii.w;\n    }\n}\n\nfloat sdRoundedRect(float2 coord, float2 halfSize, float radius) {\n    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n    float outside = length(max(cornerCoord, 0.0)) - radius;\n    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);\n    return outside + inside;\n}\n\nfloat2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {\n    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {\n        return sign(coord) * normalize(max(cornerCoord, 0.0));\n    } else {\n        float gradX = step(cornerCoord.y, cornerCoord.x);\n        return sign(coord) * float2(gradX, 1.0 - gradX);\n    }\n}\n\nhalf4 main(float2 coord) {\n    float2 halfSize = size * 0.5;\n    float2 centeredCoord = coord - halfSize;\n    float radius = radiusAt(coord, cornerRadii);\n    \n    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n    float2 grad = gradSdRoundedRect(centeredCoord, halfSize, gradRadius);\n    float2 normal = float2(cos(angle), sin(angle));\n    float d = dot(grad, normal);\n    float intensity = pow(abs(d), falloff);\n    return color * intensity;\n}"

    .line 66
    invoke-interface {p3, v0, v1}, Ldev/nino/squareglass/backdrop/RuntimeShaderCache;->obtainRuntimeShader(Ljava/lang/String;Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;

    move-result-object p3

    .line 70
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    const/16 v2, 0x20

    shr-long/2addr v0, v2

    long-to-int v0, v0

    .line 151
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    .line 70
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v1

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    long-to-int v1, v1

    .line 151
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    .line 70
    const-string v2, "size"

    invoke-interface {p3, v2, v0, v1}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;FF)V

    .line 71
    const-string v0, "cornerRadii"

    invoke-static {p1, p2}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyleKt;->access$getCornerRadii(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;)[F

    move-result-object p1

    invoke-interface {p3, v0, p1}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;[F)V

    .line 72
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->getColor-0d7_KjU()J

    move-result-wide v1

    const/16 v7, 0xe

    const/4 v8, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v1 .. v8}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide p1

    const-string v0, "color"

    invoke-interface {p3, v0, p1, p2}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setColorUniform-4WTKRHQ(Ljava/lang/String;J)V

    .line 73
    iget p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->angle:F

    const p2, 0x3c8efa35

    mul-float/2addr p1, p2

    const-string p2, "angle"

    invoke-interface {p3, p2, p1}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V

    .line 74
    const-string p1, "falloff"

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->falloff:F

    invoke-interface {p3, p1, p0}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V

    return-object p3

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;

    iget-wide v3, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->color:J

    iget-wide v5, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->color:J

    invoke-static {v3, v4, v5, v6}, Landroidx/compose/ui/graphics/Color;->equals-impl0(JJ)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->blendMode:I

    iget v3, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->blendMode:I

    invoke-static {v1, v3}, Landroidx/compose/ui/graphics/BlendMode;->equals-impl0(II)Z

    move-result v1

    if-nez v1, :cond_3

    return v2

    :cond_3
    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->angle:F

    iget v3, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->angle:F

    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_4

    return v2

    :cond_4
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->falloff:F

    iget p1, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->falloff:F

    invoke-static {p0, p1}, Ljava/lang/Float;->compare(FF)I

    move-result p0

    if-eqz p0, :cond_5

    return v2

    :cond_5
    return v0
.end method

.method public final getAngle()F
    .locals 0

    .line 57
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->angle:F

    return p0
.end method

.method public getBlendMode-0nO6VwU()I
    .locals 0

    .line 56
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->blendMode:I

    return p0
.end method

.method public getColor-0d7_KjU()J
    .locals 2

    .line 55
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->color:J

    return-wide v0
.end method

.method public final getFalloff()F
    .locals 0

    .line 58
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->falloff:F

    return p0
.end method

.method public hashCode()I
    .locals 2

    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->color:J

    invoke-static {v0, v1}, Landroidx/compose/ui/graphics/Color;->hashCode-impl(J)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->blendMode:I

    invoke-static {v1}, Landroidx/compose/ui/graphics/BlendMode;->hashCode-impl(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->angle:F

    invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->falloff:F

    invoke-static {p0}, Ljava/lang/Float;->hashCode(F)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->color:J

    invoke-static {v0, v1}, Landroidx/compose/ui/graphics/Color;->toString-impl(J)Ljava/lang/String;

    move-result-object v0

    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->blendMode:I

    invoke-static {v1}, Landroidx/compose/ui/graphics/BlendMode;->toString-impl(I)Ljava/lang/String;

    move-result-object v1

    iget v2, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->angle:F

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;->falloff:F

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Default(color="

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", blendMode="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", angle="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v0, ", falloff="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
