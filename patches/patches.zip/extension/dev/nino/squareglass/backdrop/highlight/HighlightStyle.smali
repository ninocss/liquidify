.class public interface abstract Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;
.super Ljava/lang/Object;
.source "HighlightStyle.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;,
        Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;,
        Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;,
        Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0008g\u0018\u0000 \u00142\u00020\u0001:\u0004\u0011\u0012\u0013\u0014J\u001e\u0010\n\u001a\u0004\u0018\u00010\u000b*\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H&R\u0012\u0010\u0002\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0004\u0010\u0005R\u0012\u0010\u0006\u001a\u00020\u0007X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0008\u0010\t\u00a8\u0006\u0015\u00c0\u0006\u0003"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;",
        "",
        "color",
        "Landroidx/compose/ui/graphics/Color;",
        "getColor-0d7_KjU",
        "()J",
        "blendMode",
        "Landroidx/compose/ui/graphics/BlendMode;",
        "getBlendMode-0nO6VwU",
        "()I",
        "createShader",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "runtimeShaderCache",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCache;",
        "Plain",
        "Default",
        "Ambient",
        "Companion",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;->$$INSTANCE:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;

    sput-object v0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;->Companion:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;

    return-void
.end method


# virtual methods
.method public abstract createShader(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;Ldev/nino/squareglass/backdrop/RuntimeShaderCache;)Ldev/nino/squareglass/backdrop/RuntimeShader;
.end method

.method public abstract getBlendMode-0nO6VwU()I
.end method

.method public abstract getColor-0d7_KjU()J
.end method
