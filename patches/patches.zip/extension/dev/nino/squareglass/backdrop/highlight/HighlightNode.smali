.class public final Ldev/nino/squareglass/backdrop/highlight/HighlightNode;
.super Landroidx/compose/ui/Modifier$Node;
.source "HighlightModifier.kt"

# interfaces
.implements Landroidx/compose/ui/node/DrawModifierNode;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHighlightModifier.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HighlightModifier.kt\ndev/nino/squareglass/backdrop/highlight/HighlightNode\n+ 2 Size.kt\nandroidx/compose/ui/geometry/Size\n+ 3 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 4 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n+ 5 IntSize.kt\nandroidx/compose/ui/unit/IntSizeKt\n+ 6 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 7 DrawScope.kt\nandroidx/compose/ui/graphics/drawscope/DrawScopeKt\n+ 8 MathHelpers.kt\nandroidx/compose/ui/util/MathHelpersKt\n*L\n1#1,176:1\n57#2:177\n61#2:180\n60#3:178\n70#3:181\n80#3:184\n22#4:179\n22#4:182\n30#5:183\n1#6:185\n120#7,7:186\n120#7,7:194\n74#8:193\n*S KotlinDebug\n*F\n+ 1 HighlightModifier.kt\ndev/nino/squareglass/backdrop/highlight/HighlightNode\n*L\n112#1:177\n113#1:180\n112#1:178\n113#1:181\n111#1:184\n112#1:179\n113#1:182\n111#1:183\n138#1:186,7\n129#1:194,7\n162#1:193\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u000b\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\u0008\u0001\u0018\u00002\u00020\u00012\u00020\u0002B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u000e\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u000c\u0010 \u001a\u00020!*\u00020\"H\u0016J\u0008\u0010#\u001a\u00020!H\u0016J\u0008\u0010$\u001a\u00020!H\u0016J\u0014\u0010%\u001a\u00020!*\u00020&2\u0006\u0010\u0005\u001a\u00020\u0007H\u0002R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\n\u0010\u000b\"\u0004\u0008\u000c\u0010\rR\"\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000e\u0010\u000f\"\u0004\u0008\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\u00020\u0013X\u0096D\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u001bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\'"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/highlight/HighlightNode;",
        "Landroidx/compose/ui/node/DrawModifierNode;",
        "Landroidx/compose/ui/Modifier$Node;",
        "shapeProvider",
        "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "highlight",
        "Lkotlin/Function0;",
        "Ldev/nino/squareglass/backdrop/highlight/Highlight;",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V",
        "getShapeProvider",
        "()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "setShapeProvider",
        "(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V",
        "getHighlight",
        "()Lam0/a;",
        "setHighlight",
        "(Lam0/a;)V",
        "shouldAutoInvalidate",
        "",
        "getShouldAutoInvalidate",
        "()Z",
        "highlightLayer",
        "Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
        "paint",
        "Landroidx/compose/ui/graphics/Paint;",
        "clipPath",
        "Landroidx/compose/ui/graphics/Path;",
        "runtimeShaderCache",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;",
        "prevStyle",
        "Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;",
        "draw",
        "",
        "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
        "onAttach",
        "onDetach",
        "configurePaint",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private clipPath:Landroidx/compose/ui/graphics/Path;

.field private highlight:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/highlight/Highlight;",
            ">;"
        }
    .end annotation
.end field

.field private highlightLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

.field private final paint:Landroidx/compose/ui/graphics/Paint;

.field private prevStyle:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

.field private final runtimeShaderCache:Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

.field private shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

.field private final shouldAutoInvalidate:Z


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/highlight/Highlight;",
            ">;)V"
        }
    .end annotation

    const-string v0, "shapeProvider"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "highlight"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    invoke-direct {p0}, Landroidx/compose/ui/Modifier$Node;-><init>()V

    .line 78
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    .line 79
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->highlight:Lam0/a;

    .line 87
    invoke-static {}, Landroidx/compose/ui/graphics/AndroidPaint_androidKt;->Paint()Landroidx/compose/ui/graphics/Paint;

    move-result-object p1

    .line 88
    sget-object p2, Landroidx/compose/ui/graphics/PaintingStyle;->Companion:Landroidx/compose/ui/graphics/PaintingStyle$Companion;

    invoke-virtual {p2}, Landroidx/compose/ui/graphics/PaintingStyle$Companion;->getStroke-TiuSbCo()I

    move-result p2

    invoke-interface {p1, p2}, Landroidx/compose/ui/graphics/Paint;->setStyle-k9PVt8s(I)V

    .line 87
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->paint:Landroidx/compose/ui/graphics/Paint;

    .line 92
    new-instance p1, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

    invoke-direct {p1}, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->runtimeShaderCache:Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

    return-void
.end method

.method private final configurePaint(Landroidx/compose/ui/graphics/drawscope/DrawScope;Ldev/nino/squareglass/backdrop/highlight/Highlight;)V
    .locals 5

    .line 161
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-virtual {p2}, Ldev/nino/squareglass/backdrop/highlight/Highlight;->getStyle()Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    move-result-object v1

    invoke-interface {v1}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;->getColor-0d7_KjU()J

    move-result-wide v1

    invoke-interface {v0, v1, v2}, Landroidx/compose/ui/graphics/Paint;->setColor-8_81llA(J)V

    .line 162
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-virtual {p2}, Ldev/nino/squareglass/backdrop/highlight/Highlight;->getWidth-D9Ej5fM()F

    move-result v1

    invoke-interface {p1, v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    invoke-static {v2, v3}, Landroidx/compose/ui/geometry/Size;->getMinDimension-impl(J)F

    move-result v2

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    cmpl-float v4, v1, v2

    if-lez v4, :cond_0

    move v1, v2

    :cond_0
    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v1

    double-to-float v1, v1

    mul-float/2addr v1, v3

    invoke-interface {v0, v1}, Landroidx/compose/ui/graphics/Paint;->setStrokeWidth(F)V

    .line 163
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-virtual {p2}, Ldev/nino/squareglass/backdrop/highlight/Highlight;->getBlurRadius-D9Ej5fM()F

    move-result v1

    invoke-interface {p1, v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v1

    invoke-static {v0, v1}, Ldev/nino/squareglass/backdrop/internal/PaintKt;->blur(Landroidx/compose/ui/graphics/Paint;F)V

    .line 164
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRuntimeShaderSupported()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 166
    invoke-virtual {p2}, Ldev/nino/squareglass/backdrop/highlight/Highlight;->getStyle()Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    move-result-object p2

    .line 168
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->getShape()Landroidx/compose/ui/graphics/Shape;

    move-result-object v0

    .line 169
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->runtimeShaderCache:Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

    check-cast v1, Ldev/nino/squareglass/backdrop/RuntimeShaderCache;

    .line 167
    invoke-interface {p2, p1, v0, v1}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;->createShader(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;Ldev/nino/squareglass/backdrop/RuntimeShaderCache;)Ldev/nino/squareglass/backdrop/RuntimeShader;

    move-result-object p1

    .line 172
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/internal/PaintKt;->setRuntimeShader(Landroidx/compose/ui/graphics/Paint;Ldev/nino/squareglass/backdrop/RuntimeShader;)V

    :cond_1
    return-void
.end method

.method static final draw$lambda$1(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/highlight/HighlightNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 2

    const-string v0, "$this$record"

    invoke-static {p3, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 194
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v0

    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v0

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-interface {v0, v1, v1}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    const/high16 v0, -0x40800000    # -1.0f

    .line 130
    :try_start_0
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v1

    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v1

    .line 131
    invoke-interface {v1}, Landroidx/compose/ui/graphics/Canvas;->save()V

    .line 132
    invoke-static {v1, p0, p1}, Ldev/nino/squareglass/backdrop/internal/OutlineKt;->clipOutline(Landroidx/compose/ui/graphics/Canvas;Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;)V

    .line 133
    iget-object p1, p2, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-static {v1, p0, p1}, Landroidx/compose/ui/graphics/OutlineKt;->drawOutline(Landroidx/compose/ui/graphics/Canvas;Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Paint;)V

    .line 134
    invoke-interface {v1}, Landroidx/compose/ui/graphics/Canvas;->restore()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 198
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p0

    invoke-interface {p0, v0, v0}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    .line 136
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0

    :catchall_0
    move-exception p0

    .line 198
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p1

    invoke-interface {p1, v0, v0}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    throw p0
.end method


# virtual methods
.method public draw(Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)V
    .locals 13

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 97
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->highlight:Lam0/a;

    invoke-interface {v0}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;

    if-eqz v0, :cond_4

    .line 98
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/Highlight;->getWidth-D9Ej5fM()F

    move-result v1

    const/4 v2, 0x0

    cmpg-float v1, v1, v2

    if-gtz v1, :cond_0

    goto/16 :goto_1

    .line 102
    :cond_0
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V

    .line 104
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->highlightLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-eqz v1, :cond_3

    .line 106
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    .line 107
    move-object v4, p1

    check-cast v4, Landroidx/compose/ui/unit/Density;

    .line 108
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    move-result-object v5

    const/16 v6, 0x20

    shr-long v7, v2, v6

    long-to-int v7, v7

    .line 179
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v7

    float-to-double v7, v7

    .line 112
    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v7

    double-to-float v7, v7

    float-to-int v7, v7

    add-int/lit8 v7, v7, 0x2

    const-wide v8, 0xffffffffL

    and-long v10, v2, v8

    long-to-int v10, v10

    .line 182
    invoke-static {v10}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v10

    float-to-double v10, v10

    .line 113
    invoke-static {v10, v11}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v10

    double-to-float v10, v10

    float-to-int v10, v10

    add-int/lit8 v10, v10, 0x2

    int-to-long v11, v7

    shl-long v6, v11, v6

    int-to-long v10, v10

    and-long/2addr v8, v10

    or-long/2addr v6, v8

    .line 183
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/IntSize;->constructor-impl(J)J

    move-result-wide v6

    .line 116
    iget-object v8, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {v8}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->getShape()Landroidx/compose/ui/graphics/Shape;

    move-result-object v8

    invoke-interface {v8, v2, v3, v5, v4}, Landroidx/compose/ui/graphics/Shape;->createOutline-Pq9zytI(JLandroidx/compose/ui/unit/LayoutDirection;Landroidx/compose/ui/unit/Density;)Landroidx/compose/ui/graphics/Outline;

    move-result-object v2

    .line 118
    instance-of v3, v2, Landroidx/compose/ui/graphics/Outline$Rounded;

    if-eqz v3, :cond_1

    .line 119
    iget-object v3, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->clipPath:Landroidx/compose/ui/graphics/Path;

    if-nez v3, :cond_2

    invoke-static {}, Landroidx/compose/ui/graphics/AndroidPath_androidKt;->Path()Landroidx/compose/ui/graphics/Path;

    move-result-object v3

    iput-object v3, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->clipPath:Landroidx/compose/ui/graphics/Path;

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    .line 124
    :cond_2
    :goto_0
    move-object v4, p1

    check-cast v4, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-direct {p0, v4, v0}, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->configurePaint(Landroidx/compose/ui/graphics/drawscope/DrawScope;Ldev/nino/squareglass/backdrop/highlight/Highlight;)V

    .line 126
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/Highlight;->getAlpha()F

    move-result v5

    invoke-virtual {v1, v5}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setAlpha(F)V

    .line 127
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/Highlight;->getStyle()Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    move-result-object v0

    invoke-interface {v0}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;->getBlendMode-0nO6VwU()I

    move-result v0

    invoke-virtual {v1, v0}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setBlendMode-s9anfk8(I)V

    .line 128
    new-instance v0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode$0;

    invoke-direct {v0, v2, v3, p0}, Ldev/nino/squareglass/backdrop/highlight/HighlightNode$0;-><init>(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/highlight/HighlightNode;)V

    invoke-interface {p1, v1, v6, v7, v0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->record-JVtK1S4(Landroidx/compose/ui/graphics/layer/GraphicsLayer;JLam0/l;)V

    .line 186
    invoke-interface {v4}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p0

    const/high16 p1, -0x40800000    # -1.0f

    invoke-interface {p0, p1, p1}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    const/high16 p0, 0x3f800000    # 1.0f

    .line 139
    :try_start_0
    invoke-static {v4, v1}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 190
    invoke-interface {v4}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p1

    invoke-interface {p1, p0, p0}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    return-void

    :catchall_0
    move-exception p1

    invoke-interface {v4}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v0

    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v0

    invoke-interface {v0, p0, p0}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    throw p1

    :cond_3
    return-void

    .line 99
    :cond_4
    :goto_1
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V

    return-void
.end method

.method public final getHighlight()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/highlight/Highlight;",
            ">;"
        }
    .end annotation

    .line 79
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->highlight:Lam0/a;

    return-object p0
.end method

.method public final getShapeProvider()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;
    .locals 0

    .line 78
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-object p0
.end method

.method public getShouldAutoInvalidate()Z
    .locals 0

    .line 82
    iget-boolean p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->shouldAutoInvalidate:Z

    return p0
.end method

.method public onAttach()V
    .locals 1

    .line 145
    move-object v0, p0

    check-cast v0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v0

    .line 146
    invoke-interface {v0}, Landroidx/compose/ui/graphics/GraphicsContext;->createGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->highlightLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    return-void
.end method

.method public onDetach()V
    .locals 3

    .line 150
    move-object v0, p0

    check-cast v0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v0

    .line 151
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->highlightLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    .line 152
    invoke-interface {v0, v1}, Landroidx/compose/ui/graphics/GraphicsContext;->releaseGraphicsLayer(Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    .line 153
    iput-object v2, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->highlightLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    .line 155
    :cond_0
    iput-object v2, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->clipPath:Landroidx/compose/ui/graphics/Path;

    .line 156
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->runtimeShaderCache:Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;->clear()V

    .line 157
    iput-object v2, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->prevStyle:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    return-void
.end method

.method public bridge onMeasureResultChanged()V
    .locals 0

    .line 77
    invoke-super {p0}, Landroidx/compose/ui/node/DrawModifierNode;->onMeasureResultChanged()V

    return-void
.end method

.method public final setHighlight(Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/highlight/Highlight;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->highlight:Lam0/a;

    return-void
.end method

.method public final setShapeProvider(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V
    .locals 1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-void
.end method
