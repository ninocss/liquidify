.class public final Ldev/nino/squareglass/backdrop/effects/RenderEffectKt;
.super Ljava/lang/Object;
.source "RenderEffect.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0000\u001a\u00020\u0003\u001a=\u0010\u0004\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00062\u0008\u0008\u0001\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u00062\u0017\u0010\t\u001a\u0013\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00010\n\u00a2\u0006\u0002\u0008\u000c\u00a8\u0006\r"
    }
    d2 = {
        "effect",
        "",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "Landroidx/compose/ui/graphics/RenderEffect;",
        "runtimeShaderEffect",
        "key",
        "",
        "shaderString",
        "uniformShaderName",
        "block",
        "Lkotlin/Function1;",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "Lkotlin/ExtensionFunctionType;",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final effect(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Landroidx/compose/ui/graphics/RenderEffect;)V
    .locals 1

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "effect"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRenderEffectSupported()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 25
    :cond_0
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object v0

    invoke-static {v0, p1}, Ldev/nino/squareglass/backdrop/internal/RenderEffectKt;->chain(Landroidx/compose/ui/graphics/RenderEffect;Landroidx/compose/ui/graphics/RenderEffect;)Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p1

    invoke-interface {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    return-void
.end method

.method public static final runtimeShaderEffect(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lam0/l;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/backdrop/RuntimeShader;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shaderString"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "uniformShaderName"

    invoke-static {p3, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "block"

    invoke-static {p4, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRuntimeShaderSupported()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 39
    :cond_0
    invoke-interface {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->obtainRuntimeShader(Ljava/lang/String;Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;

    move-result-object p1

    invoke-interface {p4, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    invoke-static {p1, p3}, Ldev/nino/squareglass/backdrop/internal/RenderEffectKt;->RuntimeShaderEffect(Ldev/nino/squareglass/backdrop/RuntimeShader;Ljava/lang/String;)Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p1

    .line 42
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p2

    invoke-static {p2, p1}, Ldev/nino/squareglass/backdrop/internal/RenderEffectKt;->chain(Landroidx/compose/ui/graphics/RenderEffect;Landroidx/compose/ui/graphics/RenderEffect;)Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p1

    invoke-interface {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    return-void
.end method
