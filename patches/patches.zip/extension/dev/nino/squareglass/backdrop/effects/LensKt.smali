.class public final Ldev/nino/squareglass/backdrop/effects/LensKt;
.super Ljava/lang/Object;
.source "Lens.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLens.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Lens.kt\ndev/nino/squareglass/backdrop/effects/LensKt\n+ 2 MathHelpers.kt\nandroidx/compose/ui/util/MathHelpersKt\n+ 3 Size.kt\nandroidx/compose/ui/geometry/Size\n+ 4 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 5 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n*L\n1#1,129:1\n69#2:130\n74#2:136\n74#2:137\n74#2:138\n74#2:139\n74#2:140\n74#2:141\n74#2:142\n74#2:143\n57#3:131\n61#3:134\n60#4:132\n70#4:135\n22#5:133\n*S KotlinDebug\n*F\n+ 1 Lens.kt\ndev/nino/squareglass/backdrop/effects/LensKt\n*L\n34#1:130\n90#1:136\n91#1:137\n92#1:138\n93#1:139\n114#1:140\n115#1:141\n116#1:142\n117#1:143\n53#1:131\n53#1:134\n53#1:132\n53#1:135\n53#1:133\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0014\n\u0002\u0008\u0003\n\u0002\u0010\u0001\n\u0000\u001a2\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0008\u0008\u0001\u0010\u0003\u001a\u00020\u00042\u0008\u0008\u0001\u0010\u0005\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u00072\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u0007\u001a\u0008\u0010\r\u001a\u00020\u000eH\u0002\"\u001a\u0010\t\u001a\u0004\u0018\u00010\n*\u00020\u00028BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u000b\u0010\u000c\u00a8\u0006\u000f"
    }
    d2 = {
        "lens",
        "",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "refractionHeight",
        "",
        "refractionAmount",
        "depthEffect",
        "",
        "chromaticAberration",
        "cornerRadii",
        "",
        "getCornerRadii",
        "(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)[F",
        "throwUnsupportedSDFException",
        "",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private static final getCornerRadii(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)[F
    .locals 14

    .line 81
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getShape()Landroidx/compose/ui/graphics/Shape;

    move-result-object v0

    .line 82
    instance-of v1, v0, Landroidx/compose/foundation/shape/AbsoluteRoundedCornerShape;

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/high16 v5, 0x40000000    # 2.0f

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v1, :cond_4

    .line 83
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getSize-NH-jbRc()J

    move-result-wide v8

    .line 84
    invoke-static {v8, v9}, Landroidx/compose/ui/geometry/Size;->getMinDimension-impl(J)F

    move-result v1

    div-float/2addr v1, v5

    .line 85
    check-cast v0, Landroidx/compose/foundation/shape/AbsoluteRoundedCornerShape;

    invoke-virtual {v0}, Landroidx/compose/foundation/shape/AbsoluteRoundedCornerShape;->getTopStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v5

    move-object v10, p0

    check-cast v10, Landroidx/compose/ui/unit/Density;

    invoke-interface {v5, v8, v9, v10}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v5

    .line 86
    invoke-virtual {v0}, Landroidx/compose/foundation/shape/AbsoluteRoundedCornerShape;->getTopEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v11

    invoke-interface {v11, v8, v9, v10}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v11

    .line 87
    invoke-virtual {v0}, Landroidx/compose/foundation/shape/AbsoluteRoundedCornerShape;->getBottomEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v12

    invoke-interface {v12, v8, v9, v10}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v12

    .line 88
    invoke-virtual {v0}, Landroidx/compose/foundation/shape/AbsoluteRoundedCornerShape;->getBottomStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v0

    invoke-interface {v0, v8, v9, v10}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v0

    .line 90
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getContentScale()F

    move-result v8

    mul-float/2addr v5, v8

    cmpl-float v8, v5, v1

    if-lez v8, :cond_0

    move v5, v1

    .line 91
    :cond_0
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getContentScale()F

    move-result v8

    mul-float/2addr v11, v8

    cmpl-float v8, v11, v1

    if-lez v8, :cond_1

    move v11, v1

    .line 92
    :cond_1
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getContentScale()F

    move-result v8

    mul-float/2addr v12, v8

    cmpl-float v8, v12, v1

    if-lez v8, :cond_2

    move v12, v1

    .line 93
    :cond_2
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getContentScale()F

    move-result p0

    mul-float/2addr v0, p0

    cmpl-float p0, v0, v1

    if-lez p0, :cond_3

    goto :goto_0

    :cond_3
    move v1, v0

    .line 139
    :goto_0
    new-array p0, v4, [F

    aput v5, p0, v7

    aput v11, p0, v6

    aput v12, p0, v3

    aput v1, p0, v2

    return-object p0

    .line 97
    :cond_4
    instance-of v1, v0, Landroidx/compose/foundation/shape/CornerBasedShape;

    if-eqz v1, :cond_e

    .line 98
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getSize-NH-jbRc()J

    move-result-wide v8

    .line 99
    invoke-static {v8, v9}, Landroidx/compose/ui/geometry/Size;->getMinDimension-impl(J)F

    move-result v1

    div-float/2addr v1, v5

    .line 100
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    move-result-object v5

    sget-object v10, Landroidx/compose/ui/unit/LayoutDirection;->Ltr:Landroidx/compose/ui/unit/LayoutDirection;

    if-ne v5, v10, :cond_5

    move v5, v6

    goto :goto_1

    :cond_5
    move v5, v7

    :goto_1
    if-eqz v5, :cond_6

    .line 102
    move-object v10, v0

    check-cast v10, Landroidx/compose/foundation/shape/CornerBasedShape;

    invoke-virtual {v10}, Landroidx/compose/foundation/shape/CornerBasedShape;->getTopStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v10

    move-object v11, p0

    check-cast v11, Landroidx/compose/ui/unit/Density;

    invoke-interface {v10, v8, v9, v11}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v10

    goto :goto_2

    .line 103
    :cond_6
    move-object v10, v0

    check-cast v10, Landroidx/compose/foundation/shape/CornerBasedShape;

    invoke-virtual {v10}, Landroidx/compose/foundation/shape/CornerBasedShape;->getTopEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v10

    move-object v11, p0

    check-cast v11, Landroidx/compose/ui/unit/Density;

    invoke-interface {v10, v8, v9, v11}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v10

    :goto_2
    if-eqz v5, :cond_7

    .line 105
    move-object v11, v0

    check-cast v11, Landroidx/compose/foundation/shape/CornerBasedShape;

    invoke-virtual {v11}, Landroidx/compose/foundation/shape/CornerBasedShape;->getTopEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v11

    move-object v12, p0

    check-cast v12, Landroidx/compose/ui/unit/Density;

    invoke-interface {v11, v8, v9, v12}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v11

    goto :goto_3

    .line 106
    :cond_7
    move-object v11, v0

    check-cast v11, Landroidx/compose/foundation/shape/CornerBasedShape;

    invoke-virtual {v11}, Landroidx/compose/foundation/shape/CornerBasedShape;->getTopStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v11

    move-object v12, p0

    check-cast v12, Landroidx/compose/ui/unit/Density;

    invoke-interface {v11, v8, v9, v12}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v11

    :goto_3
    if-eqz v5, :cond_8

    .line 108
    move-object v12, v0

    check-cast v12, Landroidx/compose/foundation/shape/CornerBasedShape;

    invoke-virtual {v12}, Landroidx/compose/foundation/shape/CornerBasedShape;->getBottomEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v12

    move-object v13, p0

    check-cast v13, Landroidx/compose/ui/unit/Density;

    invoke-interface {v12, v8, v9, v13}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v12

    goto :goto_4

    .line 109
    :cond_8
    move-object v12, v0

    check-cast v12, Landroidx/compose/foundation/shape/CornerBasedShape;

    invoke-virtual {v12}, Landroidx/compose/foundation/shape/CornerBasedShape;->getBottomStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v12

    move-object v13, p0

    check-cast v13, Landroidx/compose/ui/unit/Density;

    invoke-interface {v12, v8, v9, v13}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v12

    :goto_4
    if-eqz v5, :cond_9

    .line 111
    check-cast v0, Landroidx/compose/foundation/shape/CornerBasedShape;

    invoke-virtual {v0}, Landroidx/compose/foundation/shape/CornerBasedShape;->getBottomStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v0

    move-object v5, p0

    check-cast v5, Landroidx/compose/ui/unit/Density;

    invoke-interface {v0, v8, v9, v5}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v0

    goto :goto_5

    .line 112
    :cond_9
    check-cast v0, Landroidx/compose/foundation/shape/CornerBasedShape;

    invoke-virtual {v0}, Landroidx/compose/foundation/shape/CornerBasedShape;->getBottomEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v0

    move-object v5, p0

    check-cast v5, Landroidx/compose/ui/unit/Density;

    invoke-interface {v0, v8, v9, v5}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v0

    .line 114
    :goto_5
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getContentScale()F

    move-result v5

    mul-float/2addr v10, v5

    cmpl-float v5, v10, v1

    if-lez v5, :cond_a

    move v10, v1

    .line 115
    :cond_a
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getContentScale()F

    move-result v5

    mul-float/2addr v11, v5

    cmpl-float v5, v11, v1

    if-lez v5, :cond_b

    move v11, v1

    .line 116
    :cond_b
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getContentScale()F

    move-result v5

    mul-float/2addr v12, v5

    cmpl-float v5, v12, v1

    if-lez v5, :cond_c

    move v12, v1

    .line 117
    :cond_c
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getContentScale()F

    move-result p0

    mul-float/2addr v0, p0

    cmpl-float p0, v0, v1

    if-lez p0, :cond_d

    goto :goto_6

    :cond_d
    move v1, v0

    .line 143
    :goto_6
    new-array p0, v4, [F

    aput v10, p0, v7

    aput v11, p0, v6

    aput v12, p0, v3

    aput v1, p0, v2

    return-object p0

    :cond_e
    const/4 p0, 0x0

    return-object p0
.end method

.method public static final lens(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFZZ)V
    .locals 8

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRuntimeShaderSupported()Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_1

    :cond_0
    const/4 v0, 0x0

    cmpg-float v1, p1, v0

    if-lez v1, :cond_8

    cmpg-float v1, p2, v0

    if-gtz v1, :cond_1

    goto/16 :goto_1

    .line 33
    :cond_1
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getPadding()F

    move-result v1

    cmpl-float v1, v1, v0

    if-lez v1, :cond_3

    .line 34
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getPadding()F

    move-result v1

    sub-float/2addr v1, p1

    cmpg-float v2, v1, v0

    if-gez v2, :cond_2

    move v1, v0

    :cond_2
    invoke-interface {p0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->setPadding(F)V

    .line 37
    :cond_3
    invoke-static {p0}, Ldev/nino/squareglass/backdrop/effects/LensKt;->getCornerRadii(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)[F

    move-result-object v1

    if-eqz v1, :cond_7

    if-nez p4, :cond_4

    .line 43
    const-string v2, "Refraction"

    .line 44
    const-string v3, "\nuniform shader content;\n\nuniform float2 size;\nuniform float2 offset;\nuniform float4 cornerRadii;\nuniform float refractionHeight;\nuniform float refractionAmount;\nuniform float depthEffect;\n\n\nfloat radiusAt(float2 coord, float4 radii) {\n    if (coord.x >= 0.0) {\n        if (coord.y <= 0.0) return radii.y;\n        else return radii.z;\n    } else {\n        if (coord.y <= 0.0) return radii.x;\n        else return radii.w;\n    }\n}\n\nfloat sdRoundedRect(float2 coord, float2 halfSize, float radius) {\n    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n    float outside = length(max(cornerCoord, 0.0)) - radius;\n    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);\n    return outside + inside;\n}\n\nfloat2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {\n    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {\n        return sign(coord) * normalize(max(cornerCoord, 0.0));\n    } else {\n        float gradX = step(cornerCoord.y, cornerCoord.x);\n        return sign(coord) * float2(gradX, 1.0 - gradX);\n    }\n}\n\nfloat circleMap(float x) {\n    return 1.0 - sqrt(1.0 - x * x);\n}\n\nhalf4 main(float2 coord) {\n    float2 halfSize = size * 0.5;\n    float2 centeredCoord = (coord + offset) - halfSize;\n    float radius = radiusAt(coord, cornerRadii);\n    \n    float sd = sdRoundedRect(centeredCoord, halfSize, radius);\n    if (-sd >= refractionHeight) {\n        return content.eval(coord);\n    }\n    sd = min(sd, 0.0);\n    \n    float d = circleMap(1.0 - -sd / refractionHeight) * refractionAmount;\n    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n    float2 grad = normalize(gradSdRoundedRect(centeredCoord, halfSize, gradRadius) + depthEffect * normalize(centeredCoord));\n    \n    float2 refractedCoord = coord + d * grad;\n    return content.eval(refractedCoord);\n}"

    .line 42
    invoke-interface {p0, v2, v3}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->obtainRuntimeShader(Ljava/lang/String;Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;

    move-result-object v2

    goto :goto_0

    .line 48
    :cond_4
    const-string v2, "RefractionWithDispersion"

    .line 49
    invoke-static {}, Ldev/nino/squareglass/backdrop/internal/ShadersKt;->getRoundedRectRefractionWithDispersionShaderString()Ljava/lang/String;

    move-result-object v3

    .line 47
    invoke-interface {p0, v2, v3}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->obtainRuntimeShader(Ljava/lang/String;Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;

    move-result-object v2

    .line 53
    :goto_0
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getSize-NH-jbRc()J

    move-result-wide v3

    const/16 v5, 0x20

    shr-long/2addr v3, v5

    long-to-int v3, v3

    .line 133
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v3

    .line 53
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getSize-NH-jbRc()J

    move-result-wide v4

    const-wide v6, 0xffffffffL

    and-long/2addr v4, v6

    long-to-int v4, v4

    .line 133
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v4

    .line 53
    const-string v5, "size"

    invoke-interface {v2, v5, v3, v4}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;FF)V

    .line 54
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getPadding()F

    move-result v3

    neg-float v3, v3

    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getPadding()F

    move-result v4

    neg-float v4, v4

    const-string v5, "offset"

    invoke-interface {v2, v5, v3, v4}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;FF)V

    .line 55
    const-string v3, "cornerRadii"

    invoke-interface {v2, v3, v1}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;[F)V

    .line 56
    const-string v1, "refractionHeight"

    invoke-interface {v2, v1, p1}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V

    .line 57
    const-string p1, "refractionAmount"

    neg-float p2, p2

    invoke-interface {v2, p1, p2}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V

    const/high16 p1, 0x3f800000    # 1.0f

    if-eqz p3, :cond_5

    move v0, p1

    .line 58
    :cond_5
    const-string p2, "depthEffect"

    invoke-interface {v2, p2, v0}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V

    if-eqz p4, :cond_6

    .line 60
    const-string p2, "chromaticAberration"

    invoke-interface {v2, p2, p1}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V

    .line 63
    :cond_6
    const-string p1, "content"

    invoke-static {v2, p1}, Ldev/nino/squareglass/backdrop/internal/RenderEffectKt;->RuntimeShaderEffect(Ldev/nino/squareglass/backdrop/RuntimeShader;Ljava/lang/String;)Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p1

    .line 67
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/effects/RenderEffectKt;->effect(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Landroidx/compose/ui/graphics/RenderEffect;)V

    return-void

    .line 65
    :cond_7
    invoke-static {}, Ldev/nino/squareglass/backdrop/effects/LensKt;->throwUnsupportedSDFException()Ljava/lang/Void;

    new-instance p0, Lkotlin/KotlinNothingValueException;

    invoke-direct {p0}, Lkotlin/KotlinNothingValueException;-><init>()V

    throw p0

    :cond_8
    :goto_1
    return-void
.end method

.method public static synthetic lens$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFZZILjava/lang/Object;)V
    .locals 1

    and-int/lit8 p6, p5, 0x4

    const/4 v0, 0x0

    if-eqz p6, :cond_0

    move p3, v0

    :cond_0
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_1

    move p4, v0

    .line 24
    :cond_1
    invoke-static {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/backdrop/effects/LensKt;->lens(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFZZ)V

    return-void
.end method

.method private static final throwUnsupportedSDFException()Ljava/lang/Void;
    .locals 2

    .line 125
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 126
    const-string v1, "Only RoundedRectangularShape or CornerBasedShape is supported in lens effects."

    .line 125
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
