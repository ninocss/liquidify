.class public final synthetic Ldev/nino/squareglass/backdrop/DrawBackdropNode$4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/backdrop/DrawBackdropNode;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode$4;->f$0:Ldev/nino/squareglass/backdrop/DrawBackdropNode;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode$4;->f$0:Ldev/nino/squareglass/backdrop/DrawBackdropNode;

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBackdropLayer$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method
