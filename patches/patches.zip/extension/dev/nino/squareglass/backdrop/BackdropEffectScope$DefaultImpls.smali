.class public final Ldev/nino/squareglass/backdrop/BackdropEffectScope$DefaultImpls;
.super Ljava/lang/Object;
.source "BackdropEffectScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/backdrop/BackdropEffectScope;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "DefaultImpls"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static roundToPx--R2X_6o(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)I
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$roundToPx--R2X_6o$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)I

    move-result p0

    return p0
.end method

.method public static roundToPx-0680j_4(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)I
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$roundToPx-0680j_4$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)I

    move-result p0

    return p0
.end method

.method public static toDp-GaN1DYA(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)F
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toDp-GaN1DYA$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)F

    move-result p0

    return p0
.end method

.method public static toDp-u2uoSUM(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)F
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toDp-u2uoSUM$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)F

    move-result p0

    return p0
.end method

.method public static toDp-u2uoSUM(Ldev/nino/squareglass/backdrop/BackdropEffectScope;I)F
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toDp-u2uoSUM$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;I)F

    move-result p0

    return p0
.end method

.method public static toDpSize-k-rfVVM(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)J
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toDpSize-k-rfVVM$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)J

    move-result-wide p0

    return-wide p0
.end method

.method public static toPx--R2X_6o(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)F
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toPx--R2X_6o$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)F

    move-result p0

    return p0
.end method

.method public static toPx-0680j_4(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)F
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toPx-0680j_4$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)F

    move-result p0

    return p0
.end method

.method public static toRect(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Landroidx/compose/ui/unit/DpRect;)Landroidx/compose/ui/geometry/Rect;
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const-string v0, "$receiver"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toRect$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Landroidx/compose/ui/unit/DpRect;)Landroidx/compose/ui/geometry/Rect;

    move-result-object p0

    return-object p0
.end method

.method public static toSize-XkaWNTQ(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)J
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toSize-XkaWNTQ$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)J

    move-result-wide p0

    return-wide p0
.end method

.method public static toSp-0xMU5do(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)J
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toSp-0xMU5do$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)J

    move-result-wide p0

    return-wide p0
.end method

.method public static toSp-kPz2Gy4(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)J
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toSp-kPz2Gy4$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)J

    move-result-wide p0

    return-wide p0
.end method

.method public static toSp-kPz2Gy4(Ldev/nino/squareglass/backdrop/BackdropEffectScope;I)J
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 19
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->access$toSp-kPz2Gy4$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;I)J

    move-result-wide p0

    return-wide p0
.end method
