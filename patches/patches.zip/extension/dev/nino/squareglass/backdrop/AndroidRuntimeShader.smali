.class public final Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;
.super Ljava/lang/Object;
.source "RuntimeShader.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/RuntimeShader;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0005\n\u0002\u0010\u0014\n\u0000\n\u0002\u0010\u0008\n\u0002\u0010\u0015\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u0001\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\rH\u0016J \u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\rH\u0016J(\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\rH\u0016J0\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\rH\u0016J\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u0013H\u0016J\u0018\u0010\u0014\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\u0015H\u0016J \u0010\u0014\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u00152\u0006\u0010\u000f\u001a\u00020\u0015H\u0016J(\u0010\u0014\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u00152\u0006\u0010\u000f\u001a\u00020\u00152\u0006\u0010\u0010\u001a\u00020\u0015H\u0016J0\u0010\u0014\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u00152\u0006\u0010\u000f\u001a\u00020\u00152\u0006\u0010\u0010\u001a\u00020\u00152\u0006\u0010\u0011\u001a\u00020\u0015H\u0016J\u0018\u0010\u0014\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u0016H\u0016J\u001f\u0010\u0017\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0018\u001a\u00020\u0019H\u0016\u00a2\u0006\u0004\u0008\u001a\u0010\u001bR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007\u00a8\u0006\u001c"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "shader",
        "Landroid/graphics/RuntimeShader;",
        "<init>",
        "(Landroid/graphics/RuntimeShader;)V",
        "getShader",
        "()Landroid/graphics/RuntimeShader;",
        "setFloatUniform",
        "",
        "name",
        "",
        "value",
        "",
        "value1",
        "value2",
        "value3",
        "value4",
        "values",
        "",
        "setIntUniform",
        "",
        "",
        "setColorUniform",
        "color",
        "Landroidx/compose/ui/graphics/Color;",
        "setColorUniform-4WTKRHQ",
        "(Ljava/lang/String;J)V",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final shader:Landroid/graphics/RuntimeShader;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Landroid/graphics/RuntimeShader;)V
    .locals 1

    const-string v0, "shader"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 34
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    return-void
.end method


# virtual methods
.method public final getShader()Landroid/graphics/RuntimeShader;
    .locals 0

    .line 34
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    return-object p0
.end method

.method public setColorUniform-4WTKRHQ(Ljava/lang/String;J)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-static {p2, p3}, Landroidx/compose/ui/graphics/ColorKt;->toArgb-8_81llA(J)I

    move-result p2

    invoke-virtual {p0, p1, p2}, Landroid/graphics/RuntimeShader;->setColorUniform(Ljava/lang/String;I)V

    return-void
.end method

.method public setFloatUniform(Ljava/lang/String;F)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 37
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual {p0, p1, p2}, Landroid/graphics/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V

    return-void
.end method

.method public setFloatUniform(Ljava/lang/String;FF)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual {p0, p1, p2, p3}, Landroid/graphics/RuntimeShader;->setFloatUniform(Ljava/lang/String;FF)V

    return-void
.end method

.method public setFloatUniform(Ljava/lang/String;FFF)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/graphics/RuntimeShader;->setFloatUniform(Ljava/lang/String;FFF)V

    return-void
.end method

.method public setFloatUniform(Ljava/lang/String;FFFF)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual/range {p0 .. p5}, Landroid/graphics/RuntimeShader;->setFloatUniform(Ljava/lang/String;FFFF)V

    return-void
.end method

.method public setFloatUniform(Ljava/lang/String;[F)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "values"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual {p0, p1, p2}, Landroid/graphics/RuntimeShader;->setFloatUniform(Ljava/lang/String;[F)V

    return-void
.end method

.method public setIntUniform(Ljava/lang/String;I)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual {p0, p1, p2}, Landroid/graphics/RuntimeShader;->setIntUniform(Ljava/lang/String;I)V

    return-void
.end method

.method public setIntUniform(Ljava/lang/String;II)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual {p0, p1, p2, p3}, Landroid/graphics/RuntimeShader;->setIntUniform(Ljava/lang/String;II)V

    return-void
.end method

.method public setIntUniform(Ljava/lang/String;III)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 65
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/graphics/RuntimeShader;->setIntUniform(Ljava/lang/String;III)V

    return-void
.end method

.method public setIntUniform(Ljava/lang/String;IIII)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual/range {p0 .. p5}, Landroid/graphics/RuntimeShader;->setIntUniform(Ljava/lang/String;IIII)V

    return-void
.end method

.method public setIntUniform(Ljava/lang/String;[I)V
    .locals 1

    const-string v0, "name"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "values"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/AndroidRuntimeShader;->shader:Landroid/graphics/RuntimeShader;

    invoke-virtual {p0, p1, p2}, Landroid/graphics/RuntimeShader;->setIntUniform(Ljava/lang/String;[I)V

    return-void
.end method
