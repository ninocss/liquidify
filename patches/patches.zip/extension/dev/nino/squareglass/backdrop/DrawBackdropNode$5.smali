.class public final synthetic Ldev/nino/squareglass/backdrop/DrawBackdropNode$5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/backdrop/DrawBackdropNode;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode$5;->f$0:Ldev/nino/squareglass/backdrop/DrawBackdropNode;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode$5;->f$0:Ldev/nino/squareglass/backdrop/DrawBackdropNode;

    invoke-static {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->observeEffects$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
