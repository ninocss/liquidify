.class final Ldev/nino/squareglass/backdrop/backdrops/CombinedBackdrops;
.super Ljava/lang/Object;
.source "CombinedBackdrop.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/Backdrop;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCombinedBackdrop.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CombinedBackdrop.kt\ndev/nino/squareglass/backdrop/backdrops/CombinedBackdrops\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,109:1\n13213#2,2:110\n14048#2:112\n14049#2:114\n1#3:113\n*S KotlinDebug\n*F\n+ 1 CombinedBackdrop.kt\ndev/nino/squareglass/backdrop/backdrops/CombinedBackdrops\n*L\n97#1:110,2\n104#1:112\n104#1:114\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0008\u0006\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0008\u0003\u0018\u00002\u00020\u0001B\u001b\u0012\u0012\u0010\u0002\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u00010\u0003\"\u00020\u0001\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J9\u0010\u000c\u001a\u00020\r*\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u00122\u0019\u0010\u0013\u001a\u0015\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020\r\u0018\u00010\u0014\u00a2\u0006\u0002\u0008\u0016H\u0016R\u001b\u0010\u0002\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u00010\u0003\u00a2\u0006\n\n\u0002\u0010\u0008\u001a\u0004\u0008\u0006\u0010\u0007R\u0014\u0010\t\u001a\u00020\nX\u0096\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\u000b\u00a8\u0006\u0017"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/backdrops/CombinedBackdrops;",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "backdrops",
        "",
        "<init>",
        "([Ldev/nino/squareglass/backdrop/Backdrop;)V",
        "getBackdrops",
        "()[Ldev/nino/squareglass/backdrop/Backdrop;",
        "[Ldev/nino/squareglass/backdrop/Backdrop;",
        "isCoordinatesDependent",
        "",
        "()Z",
        "drawBackdrop",
        "",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "density",
        "Landroidx/compose/ui/unit/Density;",
        "coordinates",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "layerBlock",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "Lkotlin/ExtensionFunctionType;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final backdrops:[Ldev/nino/squareglass/backdrop/Backdrop;

.field private final isCoordinatesDependent:Z


# direct methods
.method public varargs constructor <init>([Ldev/nino/squareglass/backdrop/Backdrop;)V
    .locals 4

    const-string v0, "backdrops"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 93
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/CombinedBackdrops;->backdrops:[Ldev/nino/squareglass/backdrop/Backdrop;

    .line 110
    array-length v0, p1

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    aget-object v3, p1, v2

    .line 97
    invoke-interface {v3}, Ldev/nino/squareglass/backdrop/Backdrop;->isCoordinatesDependent()Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v1, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    iput-boolean v1, p0, Ldev/nino/squareglass/backdrop/backdrops/CombinedBackdrops;->isCoordinatesDependent:Z

    return-void
.end method


# virtual methods
.method public drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Landroidx/compose/ui/unit/Density;",
            "Landroidx/compose/ui/layout/LayoutCoordinates;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "density"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 104
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/CombinedBackdrops;->backdrops:[Ldev/nino/squareglass/backdrop/Backdrop;

    .line 112
    array-length v0, p0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    aget-object v2, p0, v1

    .line 105
    invoke-interface {v2, p1, p2, p3, p4}, Ldev/nino/squareglass/backdrop/Backdrop;->drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final getBackdrops()[Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 0

    .line 93
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/CombinedBackdrops;->backdrops:[Ldev/nino/squareglass/backdrop/Backdrop;

    return-object p0
.end method

.method public isCoordinatesDependent()Z
    .locals 0

    .line 96
    iget-boolean p0, p0, Ldev/nino/squareglass/backdrop/backdrops/CombinedBackdrops;->isCoordinatesDependent:Z

    return p0
.end method
