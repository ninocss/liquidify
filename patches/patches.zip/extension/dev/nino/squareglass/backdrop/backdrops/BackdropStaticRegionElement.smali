.class final Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;
.super Landroidx/compose/ui/node/ModifierNodeElement;
.source "BackdropStaticRegion.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/compose/ui/node/ModifierNodeElement<",
        "Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\u0008\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0005\u0010\u0006J\u0008\u0010\t\u001a\u00020\u0002H\u0016J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\u0002H\u0016J\u000c\u0010\r\u001a\u00020\u000b*\u00020\u000eH\u0016J\u0013\u0010\u000f\u001a\u00020\u00102\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0096\u0002J\u0008\u0010\u0013\u001a\u00020\u0014H\u0016R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008\u00a8\u0006\u0015"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;",
        "Landroidx/compose/ui/node/ModifierNodeElement;",
        "Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V",
        "getBackdrop",
        "()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "create",
        "update",
        "",
        "node",
        "inspectableProperties",
        "Landroidx/compose/ui/platform/InspectorInfo;",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V
    .locals 1

    const-string v0, "backdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    invoke-direct {p0}, Landroidx/compose/ui/node/ModifierNodeElement;-><init>()V

    .line 41
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-void
.end method


# virtual methods
.method public bridge synthetic create()Landroidx/compose/ui/Modifier$Node;
    .locals 0

    .line 40
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->create()Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/Modifier$Node;

    return-object p0
.end method

.method public create()Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;
    .locals 1

    .line 44
    new-instance v0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;-><init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 1

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    return p0

    .line 57
    :cond_0
    instance-of v0, p1, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;

    if-nez v0, :cond_1

    const/4 p0, 0x0

    return p0

    .line 58
    :cond_1
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    check-cast p1, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;

    iget-object p1, p1, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-static {p0, p1}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public final getBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;
    .locals 0

    .line 41
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-object p0
.end method

.method public hashCode()I
    .locals 0

    .line 61
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->hashCode()I

    move-result p0

    return p0
.end method

.method public inspectableProperties(Landroidx/compose/ui/platform/InspectorInfo;)V
    .locals 1

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    const-string v0, "backdropStaticRegion"

    invoke-virtual {p1, v0}, Landroidx/compose/ui/platform/InspectorInfo;->setName(Ljava/lang/String;)V

    .line 52
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object p1

    const-string v0, "backdrop"

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p1, v0, p0}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    return-void
.end method

.method public bridge synthetic update(Landroidx/compose/ui/Modifier$Node;)V
    .locals 0

    .line 40
    check-cast p1, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->update(Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;)V

    return-void
.end method

.method public update(Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;)V
    .locals 1

    const-string v0, "node"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p1, p0}, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;->setBackdrop(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    return-void
.end method
