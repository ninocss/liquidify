.class public final Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropKt;
.super Ljava/lang/Object;
.source "LayerBackdrop.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLayerBackdrop.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LayerBackdrop.kt\ndev/nino/squareglass/backdrop/backdrops/LayerBackdropKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,142:1\n1128#2,6:143\n*S KotlinDebug\n*F\n+ 1 LayerBackdrop.kt\ndev/nino/squareglass/backdrop/backdrops/LayerBackdropKt\n*L\n39#1:143,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a2\u0010\u0005\u001a\u00020\u00062\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u00082\u0019\u0008\u0002\u0010\t\u001a\u0013\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\u0002\u0008\u0004H\u0007\u00a2\u0006\u0002\u0010\n\"\u001f\u0010\u0000\u001a\u0013\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\u0002\u0008\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000b"
    }
    d2 = {
        "DefaultOnDraw",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
        "",
        "Lkotlin/ExtensionFunctionType;",
        "rememberLayerBackdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "graphicsLayer",
        "Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
        "onDraw",
        "(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Lam0/l;Landroidx/compose/runtime/Composer;II)Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final DefaultOnDraw:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 32
    new-instance v0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropKt$0;

    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropKt$0;-><init>()V

    sput-object v0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropKt;->DefaultOnDraw:Lam0/l;

    return-void
.end method

.method static final DefaultOnDraw$lambda$0(Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;
    .locals 1

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method public static final rememberLayerBackdrop(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Lam0/l;Landroidx/compose/runtime/Composer;II)Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)",
            "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;"
        }
    .end annotation

    const-string v0, "C(rememberLayerBackdrop)N(graphicsLayer,onDraw)35@1612L23,38@1723L84:LayerBackdrop.kt#pi0mct"

    const v1, 0x1a4d30a4

    .line 38
    invoke-static {p2, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v0, p4, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    .line 36
    invoke-static {p2, v2}, Landroidx/compose/ui/graphics/GraphicsLayerScopeKt;->rememberGraphicsLayer(Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object p0

    :cond_0
    and-int/lit8 p4, p4, 0x2

    if-eqz p4, :cond_1

    .line 37
    sget-object p1, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropKt;->DefaultOnDraw:Lam0/l;

    :cond_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p4

    if-eqz p4, :cond_2

    const/4 p4, -0x1

    const-string v0, "dev.nino.squareglass.backdrop.backdrops.rememberLayerBackdrop (LayerBackdrop.kt:37)"

    invoke-static {v1, p3, p4, v0}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_2
    const p4, -0x443c5268

    const-string v0, "CC(remember):LayerBackdrop.kt#9igjgp"

    .line 39
    invoke-static {p2, p4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p2, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result p4

    and-int/lit8 v0, p3, 0x70

    xor-int/lit8 v0, v0, 0x30

    const/16 v1, 0x20

    if-le v0, v1, :cond_3

    invoke-interface {p2, p1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    :cond_3
    and-int/lit8 p3, p3, 0x30

    if-ne p3, v1, :cond_5

    :cond_4
    const/4 v2, 0x1

    :cond_5
    or-int p3, p4, v2

    .line 143
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object p4

    if-nez p3, :cond_6

    .line 144
    sget-object p3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {p3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object p3

    if-ne p4, p3, :cond_7

    .line 40
    :cond_6
    new-instance p4, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-direct {p4, p0, p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;-><init>(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Lam0/l;)V

    .line 146
    invoke-interface {p2, p4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 39
    :cond_7
    check-cast p4, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 38
    :cond_8
    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p4
.end method
