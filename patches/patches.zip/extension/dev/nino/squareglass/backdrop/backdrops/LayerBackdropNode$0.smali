.class public final synthetic Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;

.field public final synthetic f$1:Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode$0;->f$0:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;

    iput-object p2, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode$0;->f$1:Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode$0;->f$0:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode$0;->f$1:Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->draw$lambda$0(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
