.class final Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;
.super Landroidx/compose/ui/node/ModifierNodeElement;
.source "LayerBackdropModifier.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/compose/ui/node/ModifierNodeElement<",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0008\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\u0008\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00020\u0001B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u000c\u0010\u0005\u001a\u0008\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u0008\u0010\u000e\u001a\u00020\u0002H\u0016J\u0010\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0002H\u0016J\u000c\u0010\u0012\u001a\u00020\u0010*\u00020\u0013H\u0016J\u0013\u0010\u0014\u001a\u00020\u00072\u0008\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0096\u0002J\u0008\u0010\u0017\u001a\u00020\u0018H\u0016R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000bR\u0017\u0010\u0005\u001a\u0008\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\r\u00a8\u0006\u0019"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;",
        "Landroidx/compose/ui/node/ModifierNodeElement;",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "frozen",
        "Lkotlin/Function0;",
        "",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;)V",
        "getBackdrop",
        "()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "getFrozen",
        "()Lam0/a;",
        "create",
        "update",
        "",
        "node",
        "inspectableProperties",
        "Landroidx/compose/ui/platform/InspectorInfo;",
        "equals",
        "other",
        "",
        "hashCode",
        "",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

.field private final frozen:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v0, "backdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "frozen"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    invoke-direct {p0}, Landroidx/compose/ui/node/ModifierNodeElement;-><init>()V

    .line 37
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    .line 38
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->frozen:Lam0/a;

    return-void
.end method


# virtual methods
.method public bridge synthetic create()Landroidx/compose/ui/Modifier$Node;
    .locals 0

    .line 36
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->create()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/Modifier$Node;

    return-object p0
.end method

.method public create()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;
    .locals 2

    .line 42
    new-instance v0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->frozen:Lam0/a;

    invoke-direct {v0, v1, p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;-><init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    .line 61
    :cond_0
    instance-of v1, p1, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    .line 63
    :cond_1
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    check-cast p1, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    .line 64
    :cond_2
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->frozen:Lam0/a;

    iget-object p1, p1, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->frozen:Lam0/a;

    invoke-static {p0, p1}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    return v2

    :cond_3
    return v0
.end method

.method public final getBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;
    .locals 0

    .line 37
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-object p0
.end method

.method public final getFrozen()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 38
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->frozen:Lam0/a;

    return-object p0
.end method

.method public hashCode()I
    .locals 1

    .line 70
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->frozen:Lam0/a;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public inspectableProperties(Landroidx/compose/ui/platform/InspectorInfo;)V
    .locals 1

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    const-string v0, "layerBackdrop"

    invoke-virtual {p1, v0}, Landroidx/compose/ui/platform/InspectorInfo;->setName(Ljava/lang/String;)V

    .line 56
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object p1

    const-string v0, "backdrop"

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p1, v0, p0}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    return-void
.end method

.method public bridge synthetic update(Landroidx/compose/ui/Modifier$Node;)V
    .locals 0

    .line 36
    check-cast p1, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->update(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;)V

    return-void
.end method

.method public update(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;)V
    .locals 2

    const-string v0, "node"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->getBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-static {v0, v1}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 47
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->getBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->setLayerCoordinates$extension_debug(Landroidx/compose/ui/layout/LayoutCoordinates;)V

    .line 48
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p1, v0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->setBackdrop(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    .line 50
    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;->frozen:Lam0/a;

    invoke-virtual {p1, p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->setFrozen(Lam0/a;)V

    .line 51
    check-cast p1, Landroidx/compose/ui/node/DrawModifierNode;

    invoke-static {p1}, Landroidx/compose/ui/node/DrawModifierNodeKt;->invalidateDraw(Landroidx/compose/ui/node/DrawModifierNode;)V

    return-void
.end method
