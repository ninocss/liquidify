.class public final Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionKt;
.super Ljava/lang/Object;
.source "BackdropStaticRegion.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003\u00a8\u0006\u0004"
    }
    d2 = {
        "backdropStaticRegion",
        "Landroidx/compose/ui/Modifier;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final backdropStaticRegion(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)Landroidx/compose/ui/Modifier;
    .locals 1

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "backdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    new-instance v0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionElement;-><init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    check-cast v0, Landroidx/compose/ui/Modifier;

    invoke-interface {p0, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method
