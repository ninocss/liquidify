.class public final synthetic Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$0;->f$0:Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$0;->f$0:Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;

    invoke-static {p0}, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->frozen$lambda$0(Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;)Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method
