.class public final Ldev/nino/squareglass/backdrop/backdrops/BackdropFreezeKt;
.super Ljava/lang/Object;
.source "BackdropFreeze.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nBackdropFreeze.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BackdropFreeze.kt\ndev/nino/squareglass/backdrop/backdrops/BackdropFreezeKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,56:1\n1128#2,6:57\n*S KotlinDebug\n*F\n+ 1 BackdropFreeze.kt\ndev/nino/squareglass/backdrop/backdrops/BackdropFreezeKt\n*L\n55#1:57,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0010\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u001a\r\u0010\u0002\u001a\u00020\u0003H\u0007\u00a2\u0006\u0002\u0010\u0004\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"
    }
    d2 = {
        "BackdropFreezeSafetyNs",
        "",
        "rememberBackdropFreeze",
        "Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;",
        "(Landroidx/compose/runtime/Composer;I)Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final BackdropFreezeSafetyNs:J = 0x35a4e900L


# direct methods
.method public static final rememberBackdropFreeze(Landroidx/compose/runtime/Composer;I)Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;
    .locals 3

    const-string v0, "C(rememberBackdropFreeze)54@2223L29:BackdropFreeze.kt#pi0mct"

    const v1, -0x1fe4604b

    .line 55
    invoke-static {p0, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.backdrop.backdrops.rememberBackdropFreeze (BackdropFreeze.kt:54)"

    invoke-static {v1, p1, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    const p1, 0x47b28c72

    const-string v0, "CC(remember):BackdropFreeze.kt#9igjgp"

    invoke-static {p0, p1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 57
    invoke-interface {p0}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object p1

    .line 58
    sget-object v0, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v0}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne p1, v0, :cond_1

    .line 55
    new-instance p1, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;

    invoke-direct {p1}, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;-><init>()V

    .line 60
    invoke-interface {p0, p1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 55
    :cond_1
    check-cast p1, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;

    invoke-static {p0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_2
    invoke-static {p0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p1
.end method
