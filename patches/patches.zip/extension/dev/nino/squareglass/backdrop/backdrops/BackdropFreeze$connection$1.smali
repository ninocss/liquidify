.class public final Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$connection$1;
.super Ljava/lang/Object;
.source "BackdropFreeze.kt"

# interfaces
.implements Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000#\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u001f\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0006H\u0016\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J \u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0004\u001a\u00020\nH\u0096@\u00a2\u0006\u0004\u0008\u000c\u0010\r\u00a8\u0006\u000e"
    }
    d2 = {
        "dev/nino/squareglass/backdrop/backdrops/BackdropFreeze$connection$1",
        "Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;",
        "onPreScroll",
        "Landroidx/compose/ui/geometry/Offset;",
        "available",
        "source",
        "Landroidx/compose/ui/input/nestedscroll/NestedScrollSource;",
        "onPreScroll-OzD1aCk",
        "(JI)J",
        "onPostFling",
        "Landroidx/compose/ui/unit/Velocity;",
        "consumed",
        "onPostFling-RZ2iAVY",
        "(JJLkotlin/coroutines/e;)Ljava/lang/Object;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;)V
    .locals 0

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$connection$1;->this$0:Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;

    .line 38
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onPostFling-RZ2iAVY(JJLkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JJ",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Landroidx/compose/ui/unit/Velocity;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 48
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$connection$1;->this$0:Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;

    invoke-static {p0}, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->access$getScrollClockNs$p(Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;)[J

    move-result-object p0

    const/4 p1, 0x0

    const-wide/16 p2, 0x0

    aput-wide p2, p0, p1

    .line 49
    sget-object p0, Landroidx/compose/ui/unit/Velocity;->Companion:Landroidx/compose/ui/unit/Velocity$Companion;

    invoke-virtual {p0}, Landroidx/compose/ui/unit/Velocity$Companion;->getZero-9UxMQ8M()J

    move-result-wide p0

    invoke-static {p0, p1}, Landroidx/compose/ui/unit/Velocity;->box-impl(J)Landroidx/compose/ui/unit/Velocity;

    move-result-object p0

    return-object p0
.end method

.method public bridge onPostScroll-DzOQY0M(JJI)J
    .locals 0

    .line 38
    invoke-super/range {p0 .. p5}, Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;->onPostScroll-DzOQY0M(JJI)J

    move-result-wide p0

    return-wide p0
.end method

.method public bridge onPreFling-QWom1Mo(JLkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Landroidx/compose/ui/unit/Velocity;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 38
    invoke-super {p0, p1, p2, p3}, Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;->onPreFling-QWom1Mo(JLkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public onPreScroll-OzD1aCk(JI)J
    .locals 0

    .line 40
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$connection$1;->this$0:Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;

    invoke-static {p0}, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->access$getScrollClockNs$p(Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;)[J

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide p2

    aput-wide p2, p0, p1

    .line 41
    sget-object p0, Landroidx/compose/ui/geometry/Offset;->Companion:Landroidx/compose/ui/geometry/Offset$Companion;

    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Offset$Companion;->getZero-F1C5BW0()J

    move-result-wide p0

    return-wide p0
.end method
