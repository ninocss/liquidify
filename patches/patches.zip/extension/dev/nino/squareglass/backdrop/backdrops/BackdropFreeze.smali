.class public final Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;
.super Ljava/lang/Object;
.source "BackdropFreeze.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0016\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u0007\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u000b\u001a\u00020\u000c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000e\u00a8\u0006\u000f"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;",
        "",
        "<init>",
        "()V",
        "scrollClockNs",
        "",
        "frozen",
        "Lkotlin/Function0;",
        "",
        "getFrozen",
        "()Lam0/a;",
        "connection",
        "Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;",
        "getConnection",
        "()Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final connection:Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;

.field private final frozen:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private final scrollClockNs:[J


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    .line 29
    new-array v0, v0, [J

    const-wide/16 v1, 0x0

    const/4 v3, 0x0

    aput-wide v1, v0, v3

    iput-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->scrollClockNs:[J

    .line 31
    new-instance v0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$0;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$0;-><init>(Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;)V

    iput-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->frozen:Lam0/a;

    .line 38
    new-instance v0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$connection$1;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze$connection$1;-><init>(Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;)V

    check-cast v0, Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;

    iput-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->connection:Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;

    return-void
.end method

.method public static final synthetic access$getScrollClockNs$p(Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;)[J
    .locals 0

    .line 28
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->scrollClockNs:[J

    return-object p0
.end method

.method static final frozen$lambda$0(Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;)Z
    .locals 5

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->scrollClockNs:[J

    const/4 v0, 0x0

    aget-wide v1, p0, v0

    const-wide/16 v3, 0x0

    cmp-long p0, v1, v3

    if-eqz p0, :cond_0

    .line 35
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    sub-long/2addr v3, v1

    const-wide/32 v1, 0x35a4e900

    cmp-long p0, v3, v1

    if-gez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    return v0
.end method


# virtual methods
.method public final getConnection()Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;
    .locals 0

    .line 38
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->connection:Landroidx/compose/ui/input/nestedscroll/NestedScrollConnection;

    return-object p0
.end method

.method public final getFrozen()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 31
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropFreeze;->frozen:Lam0/a;

    return-object p0
.end method
