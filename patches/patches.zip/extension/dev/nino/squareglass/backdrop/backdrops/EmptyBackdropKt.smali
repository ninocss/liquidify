.class public final Ldev/nino/squareglass/backdrop/backdrops/EmptyBackdropKt;
.super Ljava/lang/Object;
.source "EmptyBackdrop.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0008\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0008\u0010\u0000\u001a\u00020\u0001H\u0007\u00a8\u0006\u0002"
    }
    d2 = {
        "emptyBackdrop",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final emptyBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 1

    .line 21
    sget-object v0, Ldev/nino/squareglass/backdrop/backdrops/EmptyBackdrop;->INSTANCE:Ldev/nino/squareglass/backdrop/backdrops/EmptyBackdrop;

    check-cast v0, Ldev/nino/squareglass/backdrop/Backdrop;

    return-object v0
.end method
