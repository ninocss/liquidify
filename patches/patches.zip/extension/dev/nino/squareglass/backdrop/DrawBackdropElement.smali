.class final Ldev/nino/squareglass/backdrop/DrawBackdropElement;
.super Landroidx/compose/ui/node/ModifierNodeElement;
.source "DrawBackdropModifier.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/compose/ui/node/ModifierNodeElement<",
        "Ldev/nino/squareglass/backdrop/DrawBackdropNode;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u001a\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\u0008\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00020\u0001B\u0099\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0017\u0010\u0007\u001a\u0013\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\n0\u0008\u00a2\u0006\u0002\u0008\u000b\u0012\u0019\u0010\u000c\u001a\u0015\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\n\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\u000b\u0012\u0008\u0010\u000e\u001a\u0004\u0018\u00010\u000f\u0012\u0019\u0010\u0010\u001a\u0015\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\n\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\u000b\u0012=\u0010\u0012\u001a9\u0012\u0004\u0012\u00020\u0011\u0012$\u0012\"\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\n0\u0008\u00a2\u0006\u0002\u0008\u000b\u00a2\u0006\u000c\u0008\u0014\u0012\u0008\u0008\u0015\u0012\u0004\u0008\u0008(\u0016\u0012\u0004\u0012\u00020\n0\u0013\u00a2\u0006\u0002\u0008\u000b\u0012\u0019\u0010\u0017\u001a\u0015\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\n\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\u000b\u0012\u0019\u0010\u0018\u001a\u0015\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\n\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\u000b\u0012\u0006\u0010\u0019\u001a\u00020\u001a\u0012\u000c\u0010\u001b\u001a\u0008\u0012\u0004\u0012\u00020\u001d0\u001c\u0012\u000c\u0010\u001e\u001a\u0008\u0012\u0004\u0012\u00020\u001d0\u001c\u0012\u000e\u0010\u001f\u001a\n\u0012\u0004\u0012\u00020 \u0018\u00010\u001c\u00a2\u0006\u0004\u0008!\u0010\"J\u0008\u00107\u001a\u00020\u0002H\u0016J\u0010\u00108\u001a\u00020\n2\u0006\u00109\u001a\u00020\u0002H\u0016J\u000c\u0010:\u001a\u00020\n*\u00020;H\u0016J\u0013\u0010<\u001a\u00020\u001d2\u0008\u0010=\u001a\u0004\u0018\u00010>H\u0096\u0002J\u0008\u0010?\u001a\u00020 H\u0016R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008#\u0010$R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008%\u0010&R\"\u0010\u0007\u001a\u0013\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\n0\u0008\u00a2\u0006\u0002\u0008\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\'\u0010(R$\u0010\u000c\u001a\u0015\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\n\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008)\u0010(R\u0013\u0010\u000e\u001a\u0004\u0018\u00010\u000f\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008*\u0010+R$\u0010\u0010\u001a\u0015\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\n\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008,\u0010(RH\u0010\u0012\u001a9\u0012\u0004\u0012\u00020\u0011\u0012$\u0012\"\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\n0\u0008\u00a2\u0006\u0002\u0008\u000b\u00a2\u0006\u000c\u0008\u0014\u0012\u0008\u0008\u0015\u0012\u0004\u0008\u0008(\u0016\u0012\u0004\u0012\u00020\n0\u0013\u00a2\u0006\u0002\u0008\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008-\u0010.R$\u0010\u0017\u001a\u0015\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\n\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008/\u0010(R$\u0010\u0018\u001a\u0015\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\n\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u00080\u0010(R\u0011\u0010\u0019\u001a\u00020\u001a\u00a2\u0006\u0008\n\u0000\u001a\u0004\u00081\u00102R\u0017\u0010\u001b\u001a\u0008\u0012\u0004\u0012\u00020\u001d0\u001c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u00083\u00104R\u0017\u0010\u001e\u001a\u0008\u0012\u0004\u0012\u00020\u001d0\u001c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u00085\u00104R\u0019\u0010\u001f\u001a\n\u0012\u0004\u0012\u00020 \u0018\u00010\u001c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u00086\u00104\u00a8\u0006@"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/DrawBackdropElement;",
        "Landroidx/compose/ui/node/ModifierNodeElement;",
        "Ldev/nino/squareglass/backdrop/DrawBackdropNode;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "shapeProvider",
        "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "effects",
        "Lkotlin/Function1;",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "",
        "Lkotlin/ExtensionFunctionType;",
        "layerBlock",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "exportedBackdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "onDrawBehind",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "onDrawBackdrop",
        "Lkotlin/Function2;",
        "Lkotlin/ParameterName;",
        "name",
        "drawBackdrop",
        "onDrawSurface",
        "onDrawFront",
        "backdropScale",
        "",
        "frozen",
        "Lkotlin/Function0;",
        "",
        "heldWhileMoving",
        "loopBucket",
        "",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)V",
        "getBackdrop",
        "()Ldev/nino/squareglass/backdrop/Backdrop;",
        "getShapeProvider",
        "()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "getEffects",
        "()Lam0/l;",
        "getLayerBlock",
        "getExportedBackdrop",
        "()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "getOnDrawBehind",
        "getOnDrawBackdrop",
        "()Lam0/p;",
        "getOnDrawSurface",
        "getOnDrawFront",
        "getBackdropScale",
        "()F",
        "getFrozen",
        "()Lam0/a;",
        "getHeldWhileMoving",
        "getLoopBucket",
        "create",
        "update",
        "node",
        "inspectableProperties",
        "Landroidx/compose/ui/platform/InspectorInfo;",
        "equals",
        "other",
        "",
        "hashCode",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

.field private final backdropScale:F

.field private final effects:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

.field private final frozen:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private final heldWhileMoving:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private final layerBlock:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final loopBucket:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final onDrawBackdrop:Lam0/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final onDrawBehind:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final onDrawFront:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final onDrawSurface:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;",
            "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "-",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;F",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    const-string v0, "backdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shapeProvider"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "effects"

    invoke-static {p3, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDrawBackdrop"

    invoke-static {p7, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "frozen"

    invoke-static {p11, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "heldWhileMoving"

    invoke-static {p12, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 235
    invoke-direct {p0}, Landroidx/compose/ui/node/ModifierNodeElement;-><init>()V

    .line 236
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    .line 237
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    .line 238
    iput-object p3, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->effects:Lam0/l;

    .line 239
    iput-object p4, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->layerBlock:Lam0/l;

    .line 240
    iput-object p5, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    .line 241
    iput-object p6, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBehind:Lam0/l;

    .line 242
    iput-object p7, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBackdrop:Lam0/p;

    .line 243
    iput-object p8, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawSurface:Lam0/l;

    .line 244
    iput-object p9, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawFront:Lam0/l;

    .line 245
    iput p10, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdropScale:F

    .line 246
    iput-object p11, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->frozen:Lam0/a;

    .line 247
    iput-object p12, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->heldWhileMoving:Lam0/a;

    .line 248
    iput-object p13, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->loopBucket:Lam0/a;

    return-void
.end method


# virtual methods
.method public bridge synthetic create()Landroidx/compose/ui/Modifier$Node;
    .locals 0

    .line 235
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->create()Ldev/nino/squareglass/backdrop/DrawBackdropNode;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/Modifier$Node;

    return-object p0
.end method

.method public create()Ldev/nino/squareglass/backdrop/DrawBackdropNode;
    .locals 14

    .line 252
    new-instance v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;

    .line 253
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    .line 254
    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    .line 255
    iget-object v3, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->effects:Lam0/l;

    .line 256
    iget-object v4, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->layerBlock:Lam0/l;

    .line 257
    iget-object v5, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    .line 258
    iget-object v6, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBehind:Lam0/l;

    .line 259
    iget-object v7, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBackdrop:Lam0/p;

    .line 260
    iget-object v8, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawSurface:Lam0/l;

    .line 261
    iget-object v9, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawFront:Lam0/l;

    .line 262
    iget v10, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdropScale:F

    .line 263
    iget-object v11, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->frozen:Lam0/a;

    .line 264
    iget-object v12, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->heldWhileMoving:Lam0/a;

    .line 265
    iget-object v13, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->loopBucket:Lam0/a;

    .line 252
    invoke-direct/range {v0 .. v13}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;-><init>(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    .line 333
    :cond_0
    instance-of v1, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    .line 335
    :cond_1
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    check-cast p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    .line 336
    :cond_2
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    return v2

    .line 337
    :cond_3
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->effects:Lam0/l;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->effects:Lam0/l;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    return v2

    .line 338
    :cond_4
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->layerBlock:Lam0/l;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->layerBlock:Lam0/l;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    return v2

    .line 339
    :cond_5
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    return v2

    .line 340
    :cond_6
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBehind:Lam0/l;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBehind:Lam0/l;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7

    return v2

    .line 341
    :cond_7
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBackdrop:Lam0/p;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBackdrop:Lam0/p;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8

    return v2

    .line 342
    :cond_8
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawSurface:Lam0/l;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawSurface:Lam0/l;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    return v2

    .line 343
    :cond_9
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawFront:Lam0/l;

    iget-object v3, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawFront:Lam0/l;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a

    return v2

    .line 344
    :cond_a
    iget p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdropScale:F

    iget p1, p1, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdropScale:F

    cmpg-float p0, p0, p1

    if-nez p0, :cond_b

    return v0

    :cond_b
    return v2
.end method

.method public final getBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 0

    .line 236
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    return-object p0
.end method

.method public final getBackdropScale()F
    .locals 0

    .line 245
    iget p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdropScale:F

    return p0
.end method

.method public final getEffects()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 238
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->effects:Lam0/l;

    return-object p0
.end method

.method public final getExportedBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;
    .locals 0

    .line 240
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-object p0
.end method

.method public final getFrozen()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 246
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->frozen:Lam0/a;

    return-object p0
.end method

.method public final getHeldWhileMoving()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 247
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->heldWhileMoving:Lam0/a;

    return-object p0
.end method

.method public final getLayerBlock()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 239
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->layerBlock:Lam0/l;

    return-object p0
.end method

.method public final getLoopBucket()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 248
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->loopBucket:Lam0/a;

    return-object p0
.end method

.method public final getOnDrawBackdrop()Lam0/p;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 242
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBackdrop:Lam0/p;

    return-object p0
.end method

.method public final getOnDrawBehind()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 241
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBehind:Lam0/l;

    return-object p0
.end method

.method public final getOnDrawFront()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 244
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawFront:Lam0/l;

    return-object p0
.end method

.method public final getOnDrawSurface()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 243
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawSurface:Lam0/l;

    return-object p0
.end method

.method public final getShapeProvider()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;
    .locals 0

    .line 237
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 350
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    .line 351
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {v1}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 352
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->effects:Lam0/l;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 353
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->layerBlock:Lam0/l;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 354
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->hashCode()I

    move-result v1

    goto :goto_1

    :cond_1
    move v1, v2

    :goto_1
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 355
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBehind:Lam0/l;

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_2

    :cond_2
    move v1, v2

    :goto_2
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 356
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBackdrop:Lam0/p;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 357
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawSurface:Lam0/l;

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_3

    :cond_3
    move v1, v2

    :goto_3
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 358
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawFront:Lam0/l;

    if-eqz v1, :cond_4

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :cond_4
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    .line 359
    iget p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdropScale:F

    invoke-static {p0}, Ljava/lang/Float;->hashCode(F)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public inspectableProperties(Landroidx/compose/ui/platform/InspectorInfo;)V
    .locals 3

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 319
    const-string v0, "drawBackdrop"

    invoke-virtual {p1, v0}, Landroidx/compose/ui/platform/InspectorInfo;->setName(Ljava/lang/String;)V

    .line 320
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object v0

    const-string v1, "backdrop"

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    .line 321
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object v0

    const-string v1, "shapeProvider"

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    .line 322
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object v0

    const-string v1, "effects"

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->effects:Lam0/l;

    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    .line 323
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object v0

    const-string v1, "layerBlock"

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->layerBlock:Lam0/l;

    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    .line 324
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object v0

    const-string v1, "exportedBackdrop"

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    .line 325
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object v0

    const-string v1, "onDrawBehind"

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBehind:Lam0/l;

    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    .line 326
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object v0

    const-string v1, "onDrawBackdrop"

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBackdrop:Lam0/p;

    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    .line 327
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object v0

    const-string v1, "onDrawSurface"

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawSurface:Lam0/l;

    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    .line 328
    invoke-virtual {p1}, Landroidx/compose/ui/platform/InspectorInfo;->getProperties()Landroidx/compose/ui/platform/ValueElementSequence;

    move-result-object p1

    const-string v0, "onDrawFront"

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawFront:Lam0/l;

    invoke-virtual {p1, v0, p0}, Landroidx/compose/ui/platform/ValueElementSequence;->set(Ljava/lang/String;Ljava/lang/Object;)V

    return-void
.end method

.method public bridge synthetic update(Landroidx/compose/ui/Modifier$Node;)V
    .locals 0

    .line 235
    check-cast p1, Ldev/nino/squareglass/backdrop/DrawBackdropNode;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->update(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V

    return-void
.end method

.method public update(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V
    .locals 4

    const-string v0, "node"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 277
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    .line 278
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getShapeProvider()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    if-ne v0, v1, :cond_0

    .line 279
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getEffects()Lam0/l;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->effects:Lam0/l;

    if-ne v0, v1, :cond_0

    .line 280
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getLayerBlock()Lam0/l;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->layerBlock:Lam0/l;

    if-ne v0, v1, :cond_0

    .line 281
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getOnDrawBackdrop()Lam0/p;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBackdrop:Lam0/p;

    if-ne v0, v1, :cond_0

    .line 282
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getBackdropScale()F

    move-result v0

    iget v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdropScale:F

    cmpg-float v0, v0, v1

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    move v0, v2

    .line 284
    :goto_0
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setBackdrop(Ldev/nino/squareglass/backdrop/Backdrop;)V

    .line 285
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setShapeProvider(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V

    .line 286
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->effects:Lam0/l;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setEffects(Lam0/l;)V

    .line 287
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->layerBlock:Lam0/l;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setLayerBlock(Lam0/l;)V

    .line 288
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getExportedBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    move-result-object v1

    iget-object v3, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-static {v1, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    .line 289
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getExportedBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    move-result-object v1

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->setLayerCoordinates$extension_debug(Landroidx/compose/ui/layout/LayoutCoordinates;)V

    .line 290
    :cond_1
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setExportedBackdrop(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    .line 292
    :cond_2
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBehind:Lam0/l;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setOnDrawBehind(Lam0/l;)V

    .line 293
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawBackdrop:Lam0/p;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setOnDrawBackdrop(Lam0/p;)V

    .line 294
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawSurface:Lam0/l;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setOnDrawSurface(Lam0/l;)V

    .line 295
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->onDrawFront:Lam0/l;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setOnDrawFront(Lam0/l;)V

    .line 296
    iget v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->backdropScale:F

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setBackdropScale(F)V

    .line 297
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->frozen:Lam0/a;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setFrozen(Lam0/a;)V

    .line 298
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->heldWhileMoving:Lam0/a;

    invoke-virtual {p1, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setHeldWhileMoving(Lam0/a;)V

    .line 299
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getLoopBucket()Lam0/a;

    move-result-object v1

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;->loopBucket:Lam0/a;

    if-eq v1, p0, :cond_3

    .line 307
    invoke-virtual {p1, p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setLoopBucket(Lam0/a;)V

    .line 308
    invoke-virtual {p1, v2}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setSurfaceDirty$extension_debug(Z)V

    :cond_3
    if-eqz v0, :cond_4

    .line 311
    invoke-virtual {p1, v2}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setSurfaceDirty$extension_debug(Z)V

    .line 312
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->clearLoopPool$extension_debug()V

    .line 315
    :cond_4
    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->invalidateDrawCache()V

    return-void
.end method
