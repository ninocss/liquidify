.class public interface abstract Ldev/nino/squareglass/backdrop/RuntimeShaderCache;
.super Ljava/lang/Object;
.source "RuntimeShaderCache.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0008v\u0018\u00002\u00020\u0001J\u001a\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0008\u0008\u0001\u0010\u0006\u001a\u00020\u0005H&\u0082\u0001\u0003\u0007\u0008\t\u00a8\u0006\n\u00c0\u0006\u0003"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCache;",
        "",
        "obtainRuntimeShader",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "key",
        "",
        "string",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# virtual methods
.method public abstract obtainRuntimeShader(Ljava/lang/String;Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;
.end method
