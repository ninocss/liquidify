.class public final Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;
.super Ljava/lang/Object;
.source "ShapeProvider.kt"

# interfaces
.implements Landroidx/compose/ui/graphics/Shape;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/backdrop/internal/ShapeProvider;-><init>(Lam0/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000%\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\'\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\tH\u0016\u00a2\u0006\u0004\u0008\n\u0010\u000b\u00a8\u0006\u000c"
    }
    d2 = {
        "dev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1",
        "Landroidx/compose/ui/graphics/Shape;",
        "createOutline",
        "Landroidx/compose/ui/graphics/Outline;",
        "size",
        "Landroidx/compose/ui/geometry/Size;",
        "layoutDirection",
        "Landroidx/compose/ui/unit/LayoutDirection;",
        "density",
        "Landroidx/compose/ui/unit/Density;",
        "createOutline-Pq9zytI",
        "(JLandroidx/compose/ui/unit/LayoutDirection;Landroidx/compose/ui/unit/Density;)Landroidx/compose/ui/graphics/Outline;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V
    .locals 0

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createOutline-Pq9zytI(JLandroidx/compose/ui/unit/LayoutDirection;Landroidx/compose/ui/unit/Density;)Landroidx/compose/ui/graphics/Outline;
    .locals 3

    const-string v0, "layoutDirection"

    invoke-static {p3, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "density"

    invoke-static {p4, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->getShapeBlock()Lam0/a;

    move-result-object v0

    invoke-interface {v0}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/Shape;

    .line 39
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$get_shape$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)Landroidx/compose/ui/graphics/Shape;

    move-result-object v1

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 40
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1, v0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$set_shape$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Landroidx/compose/ui/graphics/Shape;)V

    .line 41
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    const/4 v2, 0x0

    invoke-static {v1, v2}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$set_outline$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Landroidx/compose/ui/graphics/Outline;)V

    .line 43
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$get_outline$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)Landroidx/compose/ui/graphics/Outline;

    move-result-object v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$get_size$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)J

    move-result-wide v1

    invoke-static {v1, v2, p1, p2}, Landroidx/compose/ui/geometry/Size;->equals-impl0(JJ)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$get_layoutDirection$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)Landroidx/compose/ui/unit/LayoutDirection;

    move-result-object v1

    if-ne v1, p3, :cond_1

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$get_density$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)Ljava/lang/Float;

    move-result-object v1

    invoke-interface {p4}, Landroidx/compose/ui/unit/Density;->getDensity()F

    move-result v2

    invoke-static {v1, v2}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Float;F)Z

    move-result v1

    if-nez v1, :cond_2

    .line 44
    :cond_1
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1, p1, p2}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$set_size$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;J)V

    .line 45
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {v1, p3}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$set_layoutDirection$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Landroidx/compose/ui/unit/LayoutDirection;)V

    .line 46
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-interface {p4}, Landroidx/compose/ui/unit/Density;->getDensity()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-static {v1, v2}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$set_density$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Ljava/lang/Float;)V

    .line 47
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-interface {v0, p1, p2, p3, p4}, Landroidx/compose/ui/graphics/Shape;->createOutline-Pq9zytI(JLandroidx/compose/ui/unit/LayoutDirection;Landroidx/compose/ui/unit/Density;)Landroidx/compose/ui/graphics/Outline;

    move-result-object p1

    invoke-static {v1, p1}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$set_outline$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Landroidx/compose/ui/graphics/Outline;)V

    .line 50
    :cond_2
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;->this$0:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-static {p0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->access$get_outline$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)Landroidx/compose/ui/graphics/Outline;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/HostCompat;->checkNotNull(Ljava/lang/Object;)V

    return-object p0
.end method
