.class public final Ldev/nino/squareglass/backdrop/internal/ShapeProvider;
.super Ljava/lang/Object;
.source "ShapeProvider.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0007\u0008\u0001\u0018\u00002\u00020\u0001B\u0015\u0012\u000c\u0010\u0002\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0004\u0008\u0005\u0010\u0006R\u0017\u0010\u0002\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008R\u0010\u0010\t\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000c\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\u000eR\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\u0013R\u0011\u0010\u0014\u001a\u00020\u00048F\u00a2\u0006\u0006\u001a\u0004\u0008\u0015\u0010\u0016R\u0011\u0010\u0017\u001a\u00020\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0018\u0010\u0016\u00a8\u0006\u0019"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "",
        "shapeBlock",
        "Lkotlin/Function0;",
        "Landroidx/compose/ui/graphics/Shape;",
        "<init>",
        "(Lam0/a;)V",
        "getShapeBlock",
        "()Lam0/a;",
        "_shape",
        "_outline",
        "Landroidx/compose/ui/graphics/Outline;",
        "_size",
        "Landroidx/compose/ui/geometry/Size;",
        "J",
        "_layoutDirection",
        "Landroidx/compose/ui/unit/LayoutDirection;",
        "_density",
        "",
        "Ljava/lang/Float;",
        "innerShape",
        "getInnerShape",
        "()Landroidx/compose/ui/graphics/Shape;",
        "shape",
        "getShape",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private _density:Ljava/lang/Float;

.field private _layoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

.field private _outline:Landroidx/compose/ui/graphics/Outline;

.field private _shape:Landroidx/compose/ui/graphics/Shape;

.field private _size:J

.field private final shape:Landroidx/compose/ui/graphics/Shape;

.field private final shapeBlock:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Landroidx/compose/ui/graphics/Shape;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Lam0/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "+",
            "Landroidx/compose/ui/graphics/Shape;",
            ">;)V"
        }
    .end annotation

    const-string v0, "shapeBlock"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->shapeBlock:Lam0/a;

    .line 24
    sget-object p1, Landroidx/compose/ui/geometry/Size;->Companion:Landroidx/compose/ui/geometry/Size$Companion;

    invoke-virtual {p1}, Landroidx/compose/ui/geometry/Size$Companion;->getUnspecified-NH-jbRc()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_size:J

    .line 31
    new-instance p1, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider$shape$1;-><init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V

    check-cast p1, Landroidx/compose/ui/graphics/Shape;

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->shape:Landroidx/compose/ui/graphics/Shape;

    return-void
.end method

.method public static final synthetic access$get_density$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)Ljava/lang/Float;
    .locals 0

    .line 19
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_density:Ljava/lang/Float;

    return-object p0
.end method

.method public static final synthetic access$get_layoutDirection$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)Landroidx/compose/ui/unit/LayoutDirection;
    .locals 0

    .line 19
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_layoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

    return-object p0
.end method

.method public static final synthetic access$get_outline$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)Landroidx/compose/ui/graphics/Outline;
    .locals 0

    .line 19
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_outline:Landroidx/compose/ui/graphics/Outline;

    return-object p0
.end method

.method public static final synthetic access$get_shape$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    .line 19
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_shape:Landroidx/compose/ui/graphics/Shape;

    return-object p0
.end method

.method public static final synthetic access$get_size$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)J
    .locals 2

    .line 19
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_size:J

    return-wide v0
.end method

.method public static final synthetic access$set_density$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Ljava/lang/Float;)V
    .locals 0

    .line 19
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_density:Ljava/lang/Float;

    return-void
.end method

.method public static final synthetic access$set_layoutDirection$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Landroidx/compose/ui/unit/LayoutDirection;)V
    .locals 0

    .line 19
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_layoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

    return-void
.end method

.method public static final synthetic access$set_outline$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Landroidx/compose/ui/graphics/Outline;)V
    .locals 0

    .line 19
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_outline:Landroidx/compose/ui/graphics/Outline;

    return-void
.end method

.method public static final synthetic access$set_shape$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Landroidx/compose/ui/graphics/Shape;)V
    .locals 0

    .line 19
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_shape:Landroidx/compose/ui/graphics/Shape;

    return-void
.end method

.method public static final synthetic access$set_size$p(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;J)V
    .locals 0

    .line 19
    iput-wide p1, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->_size:J

    return-void
.end method


# virtual methods
.method public final getInnerShape()Landroidx/compose/ui/graphics/Shape;
    .locals 0

    .line 29
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->shapeBlock:Lam0/a;

    invoke-interface {p0}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/graphics/Shape;

    return-object p0
.end method

.method public final getShape()Landroidx/compose/ui/graphics/Shape;
    .locals 0

    .line 31
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->shape:Landroidx/compose/ui/graphics/Shape;

    return-object p0
.end method

.method public final getShapeBlock()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Landroidx/compose/ui/graphics/Shape;",
            ">;"
        }
    .end annotation

    .line 20
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->shapeBlock:Lam0/a;

    return-object p0
.end method
