.class public final synthetic Ldev/nino/squareglass/SleepTimer$18;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnApplyWindowInsetsListener;


# instance fields
.field public final synthetic f$0:Landroid/widget/LinearLayout;

.field public final synthetic f$1:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/LinearLayout;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$18;->f$0:Landroid/widget/LinearLayout;

    iput-object p2, p0, Ldev/nino/squareglass/SleepTimer$18;->f$1:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SleepTimer$18;->f$0:Landroid/widget/LinearLayout;

    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$18;->f$1:Landroid/content/Context;

    invoke-static {v0, p0, p1, p2}, Ldev/nino/squareglass/SleepTimer;->lambda$content$6(Landroid/widget/LinearLayout;Landroid/content/Context;Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    move-result-object p0

    return-object p0
.end method
