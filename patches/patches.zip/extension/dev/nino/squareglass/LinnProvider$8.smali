.class public final synthetic Ldev/nino/squareglass/LinnProvider$8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Function;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$8;->f$0:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$8;->f$0:Ljava/lang/String;

    check-cast p1, Lp2/a;

    invoke-static {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$snapshot$0(Ljava/lang/String;Lp2/a;)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method
