.class public final synthetic Ldev/nino/squareglass/GlassMotion$7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

.field public final synthetic f$1:J


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/material/InteractiveHighlight;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassMotion$7;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    iput-wide p2, p0, Ldev/nino/squareglass/GlassMotion$7;->f$1:J

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/GlassMotion$7;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    iget-wide v1, p0, Ldev/nino/squareglass/GlassMotion$7;->f$1:J

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static {v0, v1, v2, p1}, Ldev/nino/squareglass/GlassMotion;->$r8$lambda$9G0VtuNC9i2Hx-QqyXYhO6fHA0A(Ldev/nino/squareglass/material/InteractiveHighlight;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
