.class public final synthetic Ldev/nino/squareglass/DesignEntry$23;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:Landroidx/compose/runtime/MutableIntState;


# direct methods
.method public synthetic constructor <init>(ILandroidx/compose/runtime/MutableIntState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Ldev/nino/squareglass/DesignEntry$23;->f$0:I

    iput-object p2, p0, Ldev/nino/squareglass/DesignEntry$23;->f$1:Landroidx/compose/runtime/MutableIntState;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 0
    iget v0, p0, Ldev/nino/squareglass/DesignEntry$23;->f$0:I

    iget-object p0, p0, Ldev/nino/squareglass/DesignEntry$23;->f$1:Landroidx/compose/runtime/MutableIntState;

    invoke-static {v0, p0}, Ldev/nino/squareglass/DesignEntry;->$r8$lambda$ZCOdAMpDnq0rjp2337RTpUltnNA(ILandroidx/compose/runtime/MutableIntState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
