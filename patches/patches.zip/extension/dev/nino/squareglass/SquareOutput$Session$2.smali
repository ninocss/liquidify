.class public final synthetic Ldev/nino/squareglass/SquareOutput$Session$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareOutput$Session;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareOutput$Session;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session$2;->f$0:Ldev/nino/squareglass/SquareOutput$Session;

    return-void
.end method


# virtual methods
.method public final onDismiss()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session$2;->f$0:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->close()V

    return-void
.end method
