.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/layout/Placeable;

.field public final synthetic f$1:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/layout/Placeable;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$15;->f$0:Landroidx/compose/ui/layout/Placeable;

    iput-object p2, p0, Ldev/nino/squareglass/PlayerArtwork$15;->f$1:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/PlayerArtwork$15;->f$0:Landroidx/compose/ui/layout/Placeable;

    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$15;->f$1:Landroid/view/View;

    check-cast p1, Landroidx/compose/ui/layout/Placeable$PlacementScope;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$r3j3GNL4j3Gl2jVjux0_rPmt5yA(Landroidx/compose/ui/layout/Placeable;Landroid/view/View;Landroidx/compose/ui/layout/Placeable$PlacementScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
