.class public final synthetic Ldev/nino/squareglass/NativeBackdrop$4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeBackdrop$4;->f$0:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/NativeBackdrop$4;->f$0:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    check-cast p1, Landroidx/compose/runtime/DisposableEffectScope;

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeBackdrop;->$r8$lambda$2AADHFN_DskU7cptAR596Bu0beI(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method
