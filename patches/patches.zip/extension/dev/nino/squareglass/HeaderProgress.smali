.class public final Ldev/nino/squareglass/HeaderProgress;
.super Ljava/lang/Object;
.source "HeaderProgress.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static opacity(FF)F
    .locals 2

    .line 6
    invoke-static {p0}, Ljava/lang/Float;->isFinite(F)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    cmpg-float v0, p0, v1

    if-lez v0, :cond_1

    cmpg-float v0, p1, v1

    if-gtz v0, :cond_0

    goto :goto_0

    :cond_0
    div-float/2addr p0, p1

    const/high16 p1, 0x3f800000    # 1.0f

    .line 7
    invoke-static {p1, p0}, Ljava/lang/Math;->min(FF)F

    move-result p0

    sub-float p0, p1, p0

    mul-float v0, p0, p0

    mul-float/2addr v0, p0

    sub-float/2addr p1, v0

    return p1

    :cond_1
    :goto_0
    return v1
.end method
