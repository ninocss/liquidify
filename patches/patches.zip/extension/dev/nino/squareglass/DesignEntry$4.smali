.class public final synthetic Ldev/nino/squareglass/DesignEntry$4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/DesignEntry;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:I

.field public final synthetic f$4:I

.field public final synthetic f$5:I

.field public final synthetic f$6:Ljava/lang/String;

.field public final synthetic f$7:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$4;->f$0:Ldev/nino/squareglass/DesignEntry;

    iput-object p2, p0, Ldev/nino/squareglass/DesignEntry$4;->f$1:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/DesignEntry$4;->f$2:Ljava/lang/String;

    iput p4, p0, Ldev/nino/squareglass/DesignEntry$4;->f$3:I

    iput p5, p0, Ldev/nino/squareglass/DesignEntry$4;->f$4:I

    iput p6, p0, Ldev/nino/squareglass/DesignEntry$4;->f$5:I

    iput-object p7, p0, Ldev/nino/squareglass/DesignEntry$4;->f$6:Ljava/lang/String;

    iput p8, p0, Ldev/nino/squareglass/DesignEntry$4;->f$7:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$4;->f$0:Ldev/nino/squareglass/DesignEntry;

    iget-object v1, p0, Ldev/nino/squareglass/DesignEntry$4;->f$1:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/DesignEntry$4;->f$2:Ljava/lang/String;

    iget v3, p0, Ldev/nino/squareglass/DesignEntry$4;->f$3:I

    iget v4, p0, Ldev/nino/squareglass/DesignEntry$4;->f$4:I

    iget v5, p0, Ldev/nino/squareglass/DesignEntry$4;->f$5:I

    iget-object v6, p0, Ldev/nino/squareglass/DesignEntry$4;->f$6:Ljava/lang/String;

    iget v7, p0, Ldev/nino/squareglass/DesignEntry$4;->f$7:I

    move-object v8, p1

    check-cast v8, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v9

    invoke-static/range {v0 .. v9}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$8(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
