.class Ldev/nino/squareglass/QueueGlass$2;
.super Ljava/lang/Object;
.source "QueueGlass.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/QueueGlass;->install(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$glass:Ldev/nino/squareglass/LiquidMenuSurface;

.field final synthetic val$root:Landroid/view/View;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/LiquidMenuSurface;Landroid/view/View;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 73
    iput-object p1, p0, Ldev/nino/squareglass/QueueGlass$2;->val$glass:Ldev/nino/squareglass/LiquidMenuSurface;

    iput-object p2, p0, Ldev/nino/squareglass/QueueGlass$2;->val$root:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    .line 75
    iget-object p1, p0, Ldev/nino/squareglass/QueueGlass$2;->val$glass:Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-virtual {p1}, Ldev/nino/squareglass/LiquidMenuSurface;->release()V

    iget-object p1, p0, Ldev/nino/squareglass/QueueGlass$2;->val$root:Landroid/view/View;

    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method
