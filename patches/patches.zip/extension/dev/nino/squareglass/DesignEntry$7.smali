.class public final synthetic Ldev/nino/squareglass/DesignEntry$7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/DesignEntry;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Ljava/util/List;

.field public final synthetic f$4:I

.field public final synthetic f$5:Lam0/l;

.field public final synthetic f$6:I

.field public final synthetic f$7:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ILam0/l;II)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$7;->f$0:Ldev/nino/squareglass/DesignEntry;

    iput-object p2, p0, Ldev/nino/squareglass/DesignEntry$7;->f$1:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/DesignEntry$7;->f$2:Ljava/lang/String;

    iput-object p4, p0, Ldev/nino/squareglass/DesignEntry$7;->f$3:Ljava/util/List;

    iput p5, p0, Ldev/nino/squareglass/DesignEntry$7;->f$4:I

    iput-object p6, p0, Ldev/nino/squareglass/DesignEntry$7;->f$5:Lam0/l;

    iput p7, p0, Ldev/nino/squareglass/DesignEntry$7;->f$6:I

    iput p8, p0, Ldev/nino/squareglass/DesignEntry$7;->f$7:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$7;->f$0:Ldev/nino/squareglass/DesignEntry;

    iget-object v1, p0, Ldev/nino/squareglass/DesignEntry$7;->f$1:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/DesignEntry$7;->f$2:Ljava/lang/String;

    iget-object v3, p0, Ldev/nino/squareglass/DesignEntry$7;->f$3:Ljava/util/List;

    iget v4, p0, Ldev/nino/squareglass/DesignEntry$7;->f$4:I

    iget-object v5, p0, Ldev/nino/squareglass/DesignEntry$7;->f$5:Lam0/l;

    iget v6, p0, Ldev/nino/squareglass/DesignEntry$7;->f$6:I

    iget v7, p0, Ldev/nino/squareglass/DesignEntry$7;->f$7:I

    move-object v8, p1

    check-cast v8, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v9

    invoke-static/range {v0 .. v9}, Ldev/nino/squareglass/DesignEntry;->CardChoice$lambda$4(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ILam0/l;IILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
