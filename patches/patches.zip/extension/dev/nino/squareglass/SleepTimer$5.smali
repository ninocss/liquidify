.class Ldev/nino/squareglass/SleepTimer$5;
.super Ljava/lang/Object;
.source "SleepTimer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/SleepTimer;->content(Landroid/content/Context;Ldev/nino/squareglass/LiquidMenuSurface;Ljava/lang/Runnable;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$panel:Ldev/nino/squareglass/GlassFrame;

.field final synthetic val$status:Landroid/widget/TextView;

.field final synthetic val$stop:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Landroid/widget/TextView;Landroid/widget/TextView;Ldev/nino/squareglass/GlassFrame;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 146
    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$5;->val$status:Landroid/widget/TextView;

    iput-object p2, p0, Ldev/nino/squareglass/SleepTimer$5;->val$stop:Landroid/widget/TextView;

    iput-object p3, p0, Ldev/nino/squareglass/SleepTimer$5;->val$panel:Ldev/nino/squareglass/GlassFrame;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 147
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgettimer()Ldev/nino/squareglass/SleepDeadline;

    move-result-object v0

    invoke-virtual {v0}, Ldev/nino/squareglass/SleepDeadline;->active()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_1

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->-$$Nest$sfgettrackEnd()Ldev/nino/squareglass/TrackEndGate;

    move-result-object v0

    invoke-virtual {v0}, Ldev/nino/squareglass/TrackEndGate;->active()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    move v0, v1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    iget-object v2, p0, Ldev/nino/squareglass/SleepTimer$5;->val$status:Landroid/widget/TextView;

    if-eqz v0, :cond_2

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->status()Ljava/lang/String;

    move-result-object v3

    goto :goto_2

    :cond_2
    const-string v3, ""

    :goto_2
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 148
    iget-object v2, p0, Ldev/nino/squareglass/SleepTimer$5;->val$status:Landroid/widget/TextView;

    const/16 v3, 0x8

    if-eqz v0, :cond_3

    move v4, v1

    goto :goto_3

    :cond_3
    move v4, v3

    :goto_3
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v2, p0, Ldev/nino/squareglass/SleepTimer$5;->val$stop:Landroid/widget/TextView;

    if-eqz v0, :cond_4

    goto :goto_4

    :cond_4
    move v1, v3

    :goto_4
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 149
    iget-object v0, p0, Ldev/nino/squareglass/SleepTimer$5;->val$panel:Ldev/nino/squareglass/GlassFrame;

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Ldev/nino/squareglass/SleepTimer$5;->val$panel:Ldev/nino/squareglass/GlassFrame;

    const-wide/16 v1, 0x3e8

    invoke-virtual {v0, p0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_5
    return-void
.end method
