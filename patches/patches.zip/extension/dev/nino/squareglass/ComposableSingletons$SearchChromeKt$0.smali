.class public final synthetic Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-static {p1, p0}, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;->lambda_2019281455$lambda$0(Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
