.class public final Ldev/nino/squareglass/PlayerArtwork$frame$lambda$0$0$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source "Effects.kt"

# interfaces
.implements Landroidx/compose/runtime/DisposableEffectResult;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/PlayerArtwork;->frame(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEffects.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Effects.kt\nandroidx/compose/runtime/DisposableEffectScope$onDispose$1\n+ 2 PlayerArtwork.kt\ndev/nino/squareglass/PlayerArtwork\n*L\n1#1,603:1\n65#2:604\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016\u00a8\u0006\u0004\u00b8\u0006\u0000"
    }
    d2 = {
        "androidx/compose/runtime/DisposableEffectScope$onDispose$1",
        "Landroidx/compose/runtime/DisposableEffectResult;",
        "dispose",
        "",
        "runtime"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $frame$inlined:Ldev/nino/squareglass/PlayerArtwork$Frame;

.field final synthetic $view$inlined:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;Ldev/nino/squareglass/PlayerArtwork$Frame;)V
    .locals 0

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$frame$lambda$0$0$$inlined$onDispose$1;->$view$inlined:Landroid/view/View;

    iput-object p2, p0, Ldev/nino/squareglass/PlayerArtwork$frame$lambda$0$0$$inlined$onDispose$1;->$frame$inlined:Ldev/nino/squareglass/PlayerArtwork$Frame;

    .line 66
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public dispose()V
    .locals 2

    .line 604
    invoke-static {}, Ldev/nino/squareglass/PlayerArtwork;->access$getFrames$p()Ljava/util/WeakHashMap;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/PlayerArtwork$frame$lambda$0$0$$inlined$onDispose$1;->$view$inlined:Landroid/view/View;

    invoke-virtual {v0, v1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/PlayerArtwork$frame$lambda$0$0$$inlined$onDispose$1;->$frame$inlined:Ldev/nino/squareglass/PlayerArtwork$Frame;

    if-ne v0, v1, :cond_0

    invoke-static {}, Ldev/nino/squareglass/PlayerArtwork;->access$getFrames$p()Ljava/util/WeakHashMap;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$frame$lambda$0$0$$inlined$onDispose$1;->$view$inlined:Landroid/view/View;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method
