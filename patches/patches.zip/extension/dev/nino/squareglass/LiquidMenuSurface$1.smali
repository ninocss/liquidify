.class public final synthetic Ldev/nino/squareglass/LiquidMenuSurface$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Ldev/nino/squareglass/backdrop/BackdropEffectScope;

    invoke-static {p1}, Ldev/nino/squareglass/LiquidMenuSurface;->$r8$lambda$Z9hYlg3DrJ6oerbwhO2C2cmY2OM(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
