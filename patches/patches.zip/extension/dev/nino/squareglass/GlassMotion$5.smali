.class public final synthetic Ldev/nino/squareglass/GlassMotion$5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/material/InteractiveHighlight;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/material/InteractiveHighlight;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassMotion$5;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/GlassMotion$5;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    check-cast p1, Landroidx/compose/ui/graphics/GraphicsLayerScope;

    invoke-static {p0, p1}, Ldev/nino/squareglass/GlassMotion;->$r8$lambda$JF3huwdLfv04DnoE1gD5GX69y0g(Ldev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/graphics/GraphicsLayerScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
