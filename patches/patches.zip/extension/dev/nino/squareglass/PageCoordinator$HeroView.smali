.class final Ldev/nino/squareglass/PageCoordinator$HeroView;
.super Landroid/view/View;
.source "PageCoordinator.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/PageCoordinator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "HeroView"
.end annotation


# instance fields
.field final hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;


# direct methods
.method constructor <init>(Landroid/view/View;Ldev/nino/squareglass/PageCoordinator$HeroDecoration;)V
    .locals 0

    .line 333
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Ldev/nino/squareglass/PageCoordinator$HeroView;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    const/4 p1, 0x2

    invoke-virtual {p0, p1}, Landroid/view/View;->setImportantForAccessibility(I)V

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 3

    .line 334
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroView;->hero:Ldev/nino/squareglass/PageCoordinator$HeroDecoration;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p0

    int-to-float p0, p0

    const/4 v2, 0x0

    invoke-virtual {v0, p1, v1, v2, p0}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->draw(Landroid/graphics/Canvas;FFF)V

    return-void
.end method
