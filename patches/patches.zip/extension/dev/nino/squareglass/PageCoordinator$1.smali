.class Ldev/nino/squareglass/PageCoordinator$1;
.super Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;
.source "PageCoordinator.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/PageCoordinator;->install(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 57
    invoke-direct {p0}, Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;-><init>()V

    return-void
.end method


# virtual methods
.method public onFragmentPaused(Landroidx/fragment/app/FragmentManager;Landroidx/fragment/app/Fragment;)V
    .locals 0

    .line 58
    invoke-static {}, Ldev/nino/squareglass/NativeBackdrop;->transition()V

    return-void
.end method

.method public onFragmentResumed(Landroidx/fragment/app/FragmentManager;Landroidx/fragment/app/Fragment;)V
    .locals 0

    .line 61
    invoke-static {}, Ldev/nino/squareglass/NativeBackdrop;->transition()V

    .line 62
    invoke-virtual {p2}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-static {p2, p0}, Ldev/nino/squareglass/PageCoordinator;->-$$Nest$smbind(Landroidx/fragment/app/Fragment;Landroid/view/View;)V

    :cond_0
    return-void
.end method

.method public onFragmentViewCreated(Landroidx/fragment/app/FragmentManager;Landroidx/fragment/app/Fragment;Landroid/view/View;Landroid/os/Bundle;)V
    .locals 0

    .line 59
    invoke-static {}, Ldev/nino/squareglass/NativeBackdrop;->transition()V

    invoke-static {p2, p3}, Ldev/nino/squareglass/PageCoordinator;->-$$Nest$smbind(Landroidx/fragment/app/Fragment;Landroid/view/View;)V

    return-void
.end method

.method public onFragmentViewDestroyed(Landroidx/fragment/app/FragmentManager;Landroidx/fragment/app/Fragment;)V
    .locals 0

    .line 65
    invoke-static {}, Ldev/nino/squareglass/NativeBackdrop;->transition()V

    .line 66
    invoke-virtual {p2}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object p0

    invoke-static {}, Ldev/nino/squareglass/PageCoordinator;->-$$Nest$sfgetpages()Ljava/util/WeakHashMap;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/ref/WeakReference;

    if-eqz p0, :cond_0

    .line 67
    invoke-virtual {p0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/PageCoordinator$Page;

    invoke-virtual {p0}, Ldev/nino/squareglass/PageCoordinator$Page;->destroy()V

    :cond_0
    return-void
.end method
