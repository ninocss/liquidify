.class public final Ldev/nino/squareglass/PlayerWindow;
.super Ljava/lang/Object;
.source "PlayerWindow.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/PlayerWindow$MenuAction;,
        Ldev/nino/squareglass/PlayerWindow$Snapshot;
    }
.end annotation


# static fields
.field private static pending:Ldev/nino/squareglass/PlayerWindow$Snapshot;

.field private static player:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static bridge synthetic -$$Nest$sfgetpending()Ldev/nino/squareglass/PlayerWindow$Snapshot;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/PlayerWindow;->pending:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetplayer()Ljava/lang/ref/WeakReference;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/PlayerWindow;->player:Ljava/lang/ref/WeakReference;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfputpending(Ldev/nino/squareglass/PlayerWindow$Snapshot;)V
    .locals 0

    sput-object p0, Ldev/nino/squareglass/PlayerWindow;->pending:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 14
    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/PlayerWindow;->player:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static attach(Landroid/view/View;)V
    .locals 1

    .line 17
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/PlayerWindow;->player:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public static menuAction(Lam0/a;)Lam0/a;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 23
    instance-of v0, p0, Ldev/nino/squareglass/PlayerWindow$MenuAction;

    if-eqz v0, :cond_0

    return-object p0

    :cond_0
    new-instance v0, Ldev/nino/squareglass/PlayerWindow$MenuAction;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/PlayerWindow$MenuAction;-><init>(Lam0/a;)V

    return-object v0
.end method

.method public static source(Landroid/app/Activity;)Landroid/view/View;
    .locals 2

    .line 19
    sget-object v0, Ldev/nino/squareglass/PlayerWindow;->player:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    if-eqz v0, :cond_0

    .line 20
    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public static take()Ldev/nino/squareglass/PlayerWindow$Snapshot;
    .locals 2

    .line 41
    sget-object v0, Ldev/nino/squareglass/PlayerWindow;->pending:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    const/4 v1, 0x0

    sput-object v1, Ldev/nino/squareglass/PlayerWindow;->pending:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    return-object v0
.end method
